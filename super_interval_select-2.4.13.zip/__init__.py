
bl_info = {
    "name": "超级间选",
    "author": "不中用的华强",
    "version": (2, 4, 13),
    "blender": (4, 5, 0),
    "location": "3D View > Sidebar (N) > 超级间选",
    "description": "由AriSelectLoopRing演化而来，按壳层推进间隔选择边循环或边环的综合间选工具",
    "doc_url": "https://space.bilibili.com/29171721",
    "category": "Mesh",
}

import bmesh
import bpy
import ctypes
import copy
import queue
import threading
from ctypes import wintypes
from math import degrees


# The floating tool is a real Windows tool window.  It does not create a
# second Blender window or borrow a VIEW_3D sidebar; the controls below are
# owned by the add-on and forward actions to Blender's existing operators.
_FLOATING_HWND = None
_FLOATING_CONTROLS = {}
_FLOATING_QUEUE = queue.Queue()
_FLOATING_THREAD = None
_FLOATING_WNDPROC = None
_FLOATING_TIMER_ACTIVE = False
_FLOATING_OWNER_WINDOW_POINTER = None
_FLOATING_OWNER_AREA_POINTER = None
_FLOATING_NATIVE_READY = threading.Event()
_FLOATING_CLASS_NAME = "SuperIntervalSelectNativeWindow"
_FLOATING_ACTION_PENDING = False
_FLOATING_PENDING_COMMANDS = 0
_FLOATING_STATUS_TEXT = ""
_FLOATING_WM_STATUS = 0x8002
_FLOATING_ACTION_IDS = frozenset((1010, 1011, 1110, 1111, 2001, 2002, 2003, 2004, 2005))
_FLOATING_CHECKBOXES = {"LOOP": False, "RING": False}
_FLOATING_BRUSHES = {}
_FLOATING_WM_ACTION_COMPLETE = 0x8001

_FLOATING_COLORS = {
    # High-contrast colors follow the supplied Loop/Ring reference image.
    "background": (14, 15, 17),
    "panel": (27, 29, 32),
    "field": (0, 0, 0),
    "field_border": (122, 125, 130),
    "text": (245, 245, 245),
    "muted": (220, 220, 220),
    "loop_panel": (54, 18, 22),
    "loop": (88, 0, 12),
    "loop_pressed": (188, 20, 34),
    "ring_panel": (18, 55, 24),
    "ring": (0, 91, 23),
    "ring_pressed": (20, 174, 52),
    "neutral": (76, 79, 84),
    "neutral_pressed": (151, 155, 161),
    "neutral_panel": (58, 61, 67),
    "checkbox": (230, 230, 230),
}

_FLOATING_STATIC_COLORS = {
    3012: "loop_panel",
    3013: "loop_panel",
    3014: "loop_panel",
    3021: "ring_panel",
    3022: "ring_panel",
    3023: "ring_panel",
    3024: "ring_panel",
}

# The add-on owns its own lightweight selection history.  It makes the Undo
# buttons deterministic even when Blender's global undo stack also contains
# unrelated edit-mode operations.
_SELECTION_HISTORY = []
_SELECTION_HISTORY_LIMIT = 64


def _window_pointer(window):
    try:
        return int(window.as_pointer())
    except (AttributeError, TypeError, ValueError):
        return None


def _floating_window():
    """Return the HWND published by the floating window's own UI thread."""
    return _FLOATING_HWND


def _native_windows_available():
    return hasattr(ctypes, "windll") and hasattr(ctypes.windll, "user32")


def _native_color(name):
    red, green, blue = _FLOATING_COLORS[name]
    return red | (green << 8) | (blue << 16)


def _native_configure_gdi(gdi32):
    hdc = ctypes.c_void_p
    gdi32.CreateSolidBrush.argtypes = [wintypes.DWORD]
    gdi32.CreateSolidBrush.restype = ctypes.c_void_p
    gdi32.SetTextColor.argtypes = [hdc, wintypes.DWORD]
    gdi32.SetTextColor.restype = wintypes.DWORD
    gdi32.SetBkColor.argtypes = [hdc, wintypes.DWORD]
    gdi32.SetBkColor.restype = wintypes.DWORD
    gdi32.SetBkMode.argtypes = [hdc, ctypes.c_int]
    gdi32.SetBkMode.restype = ctypes.c_int
    gdi32.CreateRoundRectRgn.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    gdi32.CreateRoundRectRgn.restype = ctypes.c_void_p
    gdi32.SelectClipRgn.argtypes = [hdc, ctypes.c_void_p]
    gdi32.SelectClipRgn.restype = ctypes.c_int
    gdi32.FrameRgn.argtypes = [hdc, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    gdi32.FrameRgn.restype = wintypes.BOOL
    gdi32.DeleteObject.argtypes = [ctypes.c_void_p]
    gdi32.DeleteObject.restype = wintypes.BOOL


def _native_brush(name):
    brush = _FLOATING_BRUSHES.get(name)
    if brush:
        return brush
    gdi32 = ctypes.windll.gdi32
    _native_configure_gdi(gdi32)
    brush = int(gdi32.CreateSolidBrush(_native_color(name)) or 0)
    _FLOATING_BRUSHES[name] = brush
    return brush


def _native_configure_api(user32):
    """Declare pointer-sized Win32 signatures for Blender's 64-bit Python."""
    handle = ctypes.c_void_p
    user32.IsWindow.argtypes = [handle]
    user32.IsWindow.restype = wintypes.BOOL
    user32.GetWindowTextLengthW.argtypes = [handle]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [handle, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    user32.SetWindowTextW.argtypes = [handle, wintypes.LPCWSTR]
    user32.SetWindowTextW.restype = wintypes.BOOL
    user32.CreateWindowExW.argtypes = [
        wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR, wintypes.DWORD,
        ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int,
        ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p,
    ]
    user32.CreateWindowExW.restype = wintypes.HWND
    user32.SendMessageW.argtypes = [handle, wintypes.UINT, ctypes.c_size_t, ctypes.c_ssize_t]
    user32.SendMessageW.restype = ctypes.c_ssize_t
    user32.DefWindowProcW.argtypes = [handle, wintypes.UINT, ctypes.c_size_t, ctypes.c_ssize_t]
    user32.DefWindowProcW.restype = ctypes.c_ssize_t
    user32.DestroyWindow.argtypes = [handle]
    user32.DestroyWindow.restype = wintypes.BOOL
    user32.PostMessageW.argtypes = [handle, wintypes.UINT, handle, handle]
    user32.PostMessageW.restype = wintypes.BOOL
    user32.CreateWindowExW.restype = wintypes.HWND
    user32.ShowWindow.argtypes = [handle, ctypes.c_int]
    user32.UpdateWindow.argtypes = [handle]
    user32.InvalidateRect.argtypes = [handle, ctypes.POINTER(wintypes.RECT), wintypes.BOOL]
    user32.InvalidateRect.restype = wintypes.BOOL
    user32.FillRect.argtypes = [handle, ctypes.POINTER(wintypes.RECT), ctypes.c_void_p]
    user32.FillRect.restype = ctypes.c_int
    user32.FrameRect.argtypes = [handle, ctypes.POINTER(wintypes.RECT), ctypes.c_void_p]
    user32.FrameRect.restype = ctypes.c_int
    user32.DrawTextW.argtypes = [handle, wintypes.LPCWSTR, ctypes.c_int, ctypes.POINTER(wintypes.RECT), wintypes.UINT]
    user32.DrawTextW.restype = ctypes.c_int
    user32.GetDlgCtrlID.argtypes = [handle]
    user32.GetDlgCtrlID.restype = ctypes.c_int
    user32.GetClientRect.argtypes = [handle, ctypes.POINTER(wintypes.RECT)]
    user32.GetClientRect.restype = wintypes.BOOL


def _native_loword(value):
    return int(value) & 0xFFFF


def _native_hiword(value):
    return (int(value) >> 16) & 0xFFFF


def _native_text(hwnd):
    if not hwnd:
        return ""
    user32 = ctypes.windll.user32
    _native_configure_api(user32)
    length = user32.GetWindowTextLengthW(wintypes.HWND(hwnd))
    buffer = ctypes.create_unicode_buffer(max(1, length + 1))
    user32.GetWindowTextW(wintypes.HWND(hwnd), buffer, len(buffer))
    return buffer.value


def _native_set_text(hwnd, value):
    if hwnd:
        user32 = ctypes.windll.user32
        _native_configure_api(user32)
        user32.SetWindowTextW(
            wintypes.HWND(hwnd), str(value)
        )


def _native_set_checked(hwnd, checked):
    if hwnd:
        user32 = ctypes.windll.user32
        _native_configure_api(user32)
        user32.SendMessageW(
            wintypes.HWND(hwnd), 0x00F1, 1 if checked else 0, 0
        )


def _native_checked(hwnd):
    if not hwnd:
        return False
    user32 = ctypes.windll.user32
    _native_configure_api(user32)
    return bool(user32.SendMessageW(
        wintypes.HWND(hwnd), 0x00F0, 0, 0
    ))


def _native_font():
    try:
        return ctypes.windll.gdi32.GetStockObject(17)  # DEFAULT_GUI_FONT
    except (AttributeError, OSError):
        return 0


def _native_create_control(parent, kind, text, style, ex_style, x, y, width, height, control_id):
    user32 = ctypes.windll.user32
    _native_configure_api(user32)
    handle = user32.CreateWindowExW(
        ex_style,
        kind,
        text,
        style,
        x,
        y,
        width,
        height,
        wintypes.HWND(parent),
        wintypes.HMENU(control_id),
        None,
        None,
    )
    if handle:
        font = _native_font()
        if font:
            user32.SendMessageW(
                wintypes.HWND(handle), 0x0030, int(font), 1
            )
    return int(handle or 0)


def _native_add_group(parent, title, y, height):
    control_id = {"循环边": 3001, "并排边": 3002, "快速工具": 3003}[title]
    return _native_create_control(
        parent,
        "STATIC",
        title,
        0x40000000 | 0x10000000 | 0x00000200,  # CHILD | VISIBLE | SS_CENTERIMAGE
        0,
        8,
        y,
        304,
        22,
        control_id,
    )


def _native_add_static(parent, text, x, y, width=92, height=22, control_id=0):
    return _native_create_control(
        parent,
        "STATIC",
        text,
        0x40000000 | 0x10000000,  # CHILD | VISIBLE
        0,
        x,
        y,
        width,
        height,
        control_id,
    )


def _native_add_edit(parent, control_id, value, x, y, width=68):
    return _native_create_control(
        parent,
        "EDIT",
        str(value),
        0x40000000 | 0x10000000 | 0x00010000 | 0x0002,  # CHILD | VISIBLE | TABSTOP | ES_NUMBER
        0x00000200,  # WS_EX_CLIENTEDGE
        x,
        y,
        width,
        22,
        control_id,
    )


def _native_add_button(parent, control_id, text, x, y, width=138, height=24):
    return _native_create_control(
        parent,
        "BUTTON",
        text,
        0x40000000 | 0x10000000 | 0x00010000 | 0x0000000B,  # CHILD | VISIBLE | TABSTOP | OWNERDRAW
        0,
        x,
        y,
        width,
        height,
        control_id,
    )


def _native_add_checkbox(parent, control_id, text, checked, x, y, width=142):
    handle = _native_create_control(
        parent,
        "BUTTON",
        text,
        0x40000000 | 0x10000000 | 0x00010000 | 0x0000000B,  # CHILD | VISIBLE | TABSTOP | OWNERDRAW
        0,
        x,
        y,
        width,
        22,
        control_id,
    )
    _FLOATING_CHECKBOXES["LOOP" if control_id == 1003 else "RING"] = bool(checked)
    return handle


def _native_build_controls(hwnd, initial):
    loop, ring = initial["LOOP"], initial["RING"]
    _native_add_group(hwnd, "循环边", 8, 156)
    _native_add_static(hwnd, "单元", 22, 35, control_id=3012)
    _FLOATING_CONTROLS["loop_repeat"] = _native_add_edit(hwnd, 1001, loop["repeat"], 130, 32)
    _native_add_static(hwnd, "跳跃", 22, 61, control_id=3013)
    _FLOATING_CONTROLS["loop_jump"] = _native_add_edit(hwnd, 1002, loop["jump"], 130, 58)
    _FLOATING_CONTROLS["loop_reversal"] = _native_add_checkbox(hwnd, 1003, "交替反转", loop["reversal"], 22, 86)
    _native_add_static(hwnd, "Max：", 178, 88, 52, control_id=3014)
    _FLOATING_CONTROLS["loop_max"] = _native_add_edit(hwnd, 1004, loop["max"], 232, 85, 60)
    _FLOATING_CONTROLS["loop_select"] = _native_add_button(hwnd, 1010, "选择边循环", 22, 117, 190)
    _FLOATING_CONTROLS["loop_undo"] = _native_add_button(hwnd, 1011, "撤销", 218, 117, 74)

    _native_add_group(hwnd, "并排边", 172, 156)
    _native_add_static(hwnd, "单元", 22, 199, control_id=3022)
    _FLOATING_CONTROLS["ring_repeat"] = _native_add_edit(hwnd, 1101, ring["repeat"], 130, 196)
    _native_add_static(hwnd, "跳跃", 22, 225, control_id=3023)
    _FLOATING_CONTROLS["ring_jump"] = _native_add_edit(hwnd, 1102, ring["jump"], 130, 222)
    _FLOATING_CONTROLS["ring_reversal"] = _native_add_checkbox(hwnd, 1103, "交替反转", ring["reversal"], 22, 250)
    _native_add_static(hwnd, "Max：", 178, 252, 52, control_id=3024)
    _FLOATING_CONTROLS["ring_max"] = _native_add_edit(hwnd, 1104, ring["max"], 232, 249, 60)
    _FLOATING_CONTROLS["ring_select"] = _native_add_button(hwnd, 1110, "选择边环", 22, 281, 190)
    _FLOATING_CONTROLS["ring_undo"] = _native_add_button(hwnd, 1111, "撤销", 218, 281, 74)

    _native_add_group(hwnd, "快速工具", 336, 108)
    _FLOATING_CONTROLS["quick_loop_extend"] = _native_add_button(hwnd, 2001, "扩展循环", 22, 363, 133)
    _FLOATING_CONTROLS["quick_ring_extend"] = _native_add_button(hwnd, 2002, "扩展并排边", 161, 363, 131)
    _FLOATING_CONTROLS["quick_loop_shrink"] = _native_add_button(hwnd, 2003, "收缩循环", 22, 392, 133)
    _FLOATING_CONTROLS["quick_ring_shrink"] = _native_add_button(hwnd, 2004, "收缩并排边", 161, 392, 131)
    _FLOATING_CONTROLS["quick_reverse"] = _native_add_button(hwnd, 2005, "切换并排边", 22, 421, 133)
    _FLOATING_CONTROLS["status"] = _native_add_static(
        hwnd, "就绪", 8, 452, 304, 24, control_id=4001
    )


def _native_read_module(mode):
    prefix = "loop" if mode == "LOOP" else "ring"
    def read_int(name, default):
        try:
            return int(_native_text(_FLOATING_CONTROLS.get(name)) or default)
        except (TypeError, ValueError):
            return default
    return {
        "repeat": read_int(prefix + "_repeat", 1),
        "jump": read_int(prefix + "_jump", 0),
        "reversal": bool(_FLOATING_CHECKBOXES[mode]),
        "max": read_int(prefix + "_max", 0),
    }


def _native_read_initial(scene):
    result = {}
    for mode, prefix in (("LOOP", "super_interval_loop"), ("RING", "super_interval_ring")):
        result[mode] = {
            "repeat": getattr(scene, prefix + "_repeat"),
            "jump": getattr(scene, prefix + "_jump"),
            "reversal": getattr(scene, prefix + "_reversal"),
            "max": getattr(scene, prefix + "_max"),
        }
    return result


def _native_action_command(control_id):
    if control_id == 1010:
        return ("SELECT", "LOOP", _native_read_module("LOOP"))
    if control_id == 1011:
        return ("UNDO",)
    if control_id == 1110:
        return ("SELECT", "RING", _native_read_module("RING"))
    if control_id == 1111:
        return ("UNDO",)
    quick = {
        2001: ("LOOP", "EXTEND"),
        2002: ("RING", "EXTEND"),
        2003: ("LOOP", "SHRINK"),
        2004: ("RING", "SHRINK"),
        2005: ("RING", "REVERSE_RING"),
    }.get(control_id)
    return ("QUICK", quick[0], quick[1]) if quick else None


def _native_invalidate(hwnd):
    user32 = ctypes.windll.user32
    _native_configure_api(user32)
    user32.InvalidateRect(wintypes.HWND(hwnd), None, True)


class _DRAWITEMSTRUCT(ctypes.Structure):
    _fields_ = [
        ("CtlType", wintypes.UINT),
        ("CtlID", wintypes.UINT),
        ("itemID", wintypes.UINT),
        ("itemAction", wintypes.UINT),
        ("itemState", wintypes.UINT),
        ("hwndItem", ctypes.c_void_p),
        ("hDC", ctypes.c_void_p),
        ("rcItem", wintypes.RECT),
        ("itemData", ctypes.c_size_t),
    ]


def _native_draw_text(hdc, text, rect, color, flags):
    gdi32 = ctypes.windll.gdi32
    user32 = ctypes.windll.user32
    _native_configure_gdi(gdi32)
    _native_configure_api(user32)
    gdi32.SetTextColor(hdc, _native_color(color))
    gdi32.SetBkMode(hdc, 1)  # TRANSPARENT
    user32.DrawTextW(hdc, text, -1, ctypes.byref(rect), flags)


def _native_fill_round_rect(hdc, rect, brush, border_brush, radius=7):
    """Fill an owner-drawn button with clipped rounded corners."""
    gdi32 = ctypes.windll.gdi32
    user32 = ctypes.windll.user32
    _native_configure_gdi(gdi32)
    region = gdi32.CreateRoundRectRgn(
        rect.left, rect.top, rect.right + 1, rect.bottom + 1, radius, radius
    )
    if not region:
        user32.FillRect(hdc, ctypes.byref(rect), ctypes.c_void_p(brush))
        return
    gdi32.SelectClipRgn(hdc, region)
    user32.FillRect(hdc, ctypes.byref(rect), ctypes.c_void_p(brush))
    gdi32.SelectClipRgn(hdc, None)
    gdi32.FrameRgn(hdc, region, ctypes.c_void_p(border_brush), 1, 1)
    gdi32.DeleteObject(region)


def _native_paint_background(hwnd, hdc):
    """Paint module surfaces behind the ordinary child controls."""
    user32 = ctypes.windll.user32
    _native_configure_api(user32)
    client = wintypes.RECT()
    if not user32.GetClientRect(wintypes.HWND(hwnd), ctypes.byref(client)):
        return
    user32.FillRect(hdc, ctypes.byref(client), ctypes.c_void_p(_native_brush("background")))
    surfaces = (
        (8, 30, 312, 164, "loop_panel"),
        (8, 194, 312, 328, "ring_panel"),
        (8, 358, 312, 447, "neutral_panel"),
    )
    for left, top, right, bottom, color in surfaces:
        rect = wintypes.RECT(left, top, right, bottom)
        user32.FillRect(hdc, ctypes.byref(rect), ctypes.c_void_p(_native_brush(color)))


def _native_set_status(text):
    """Send a status update to the native UI thread without touching controls cross-thread."""
    global _FLOATING_STATUS_TEXT
    _FLOATING_STATUS_TEXT = str(text)
    hwnd = _floating_window()
    if not hwnd:
        return
    try:
        user32 = ctypes.windll.user32
        _native_configure_api(user32)
        user32.PostMessageW(wintypes.HWND(hwnd), _FLOATING_WM_STATUS, 0, 0)
    except (AttributeError, OSError, TypeError, ValueError):
        pass


def _native_draw_item(lparam):
    """Paint owner-drawn action buttons and reversal checks in Blender tones."""
    item = ctypes.cast(ctypes.c_void_p(lparam), ctypes.POINTER(_DRAWITEMSTRUCT)).contents
    control_id = int(item.CtlID)
    hdc = item.hDC
    rect = item.rcItem
    user32 = ctypes.windll.user32
    gdi32 = ctypes.windll.gdi32
    _native_configure_api(user32)
    _native_configure_gdi(gdi32)

    if control_id in (1003, 1103):
        module_color = "loop_panel" if control_id == 1003 else "ring_panel"
        user32.FillRect(hdc, ctypes.byref(rect), ctypes.c_void_p(_native_brush(module_color)))
        box = wintypes.RECT(rect.left + 2, rect.top + 4, rect.left + 15, rect.top + 17)
        user32.FrameRect(hdc, ctypes.byref(box), ctypes.c_void_p(_native_brush("field_border")))
        mode = "LOOP" if control_id == 1003 else "RING"
        if _FLOATING_CHECKBOXES[mode]:
            inner = wintypes.RECT(box.left + 3, box.top + 3, box.right - 3, box.bottom - 3)
            user32.FillRect(hdc, ctypes.byref(inner), ctypes.c_void_p(_native_brush("checkbox")))
            _native_draw_text(hdc, "✓", box, "background", 0x00000001 | 0x00000004 | 0x00000020)
        text_rect = wintypes.RECT(rect.left + 21, rect.top, rect.right, rect.bottom)
        _native_draw_text(hdc, "交替反转", text_rect, "text", 0x00000004 | 0x00000020)
        return

    if control_id == 1010:
        color = "loop_pressed" if item.itemState & 0x0001 else "loop"
    elif control_id == 1110:
        color = "ring_pressed" if item.itemState & 0x0001 else "ring"
    else:
        color = "neutral_pressed" if item.itemState & 0x0001 else "neutral"
    border = "field_border" if item.itemState & 0x0010 else "panel"
    _native_fill_round_rect(hdc, rect, _native_brush(color), _native_brush(border))
    _native_draw_text(hdc, _native_text(item.hwndItem), rect, "text", 0x00000001 | 0x00000004 | 0x00000020)


def _native_wnd_proc(hwnd, message, wparam, lparam):
    global _FLOATING_HWND, _FLOATING_ACTION_PENDING, _FLOATING_PENDING_COMMANDS
    try:
        if message == 0x0014:  # WM_ERASEBKGND
            _native_paint_background(hwnd, ctypes.c_void_p(wparam))
            return 1
        if message == 0x002B:  # WM_DRAWITEM
            _native_draw_item(lparam)
            return 1
        if message == 0x0138:  # WM_CTLCOLORSTATIC
            user32 = ctypes.windll.user32
            gdi32 = ctypes.windll.gdi32
            _native_configure_api(user32)
            _native_configure_gdi(gdi32)
            control_id = user32.GetDlgCtrlID(wintypes.HWND(lparam))
            header_colors = {3001: "loop", 3002: "ring", 3003: "neutral"}
            color = header_colors.get(
                control_id, _FLOATING_STATIC_COLORS.get(control_id, "neutral_panel")
            )
            text_color = "text"
            gdi32.SetTextColor(ctypes.c_void_p(wparam), _native_color(text_color))
            gdi32.SetBkColor(ctypes.c_void_p(wparam), _native_color(color))
            return _native_brush(color)
        if message == 0x0133:  # WM_CTLCOLOREDIT
            gdi32 = ctypes.windll.gdi32
            _native_configure_gdi(gdi32)
            gdi32.SetTextColor(ctypes.c_void_p(wparam), _native_color("text"))
            gdi32.SetBkColor(ctypes.c_void_p(wparam), _native_color("field"))
            return _native_brush("field")
        if message == 0x0111:  # WM_COMMAND
            control_id = _native_loword(wparam)
            notification = _native_hiword(wparam)
            if notification == 0 and control_id in (1003, 1103):
                mode = "LOOP" if control_id == 1003 else "RING"
                _FLOATING_CHECKBOXES[mode] = not _FLOATING_CHECKBOXES[mode]
                _native_invalidate(_FLOATING_CONTROLS.get(
                    "loop_reversal" if mode == "LOOP" else "ring_reversal"
                ))
            elif control_id in _FLOATING_ACTION_IDS:
                command = _native_action_command(control_id)
                if command is not None:
                    # Never drop a second click.  The main thread consumes
                    # this FIFO one item per timer turn, so editing stays
                    # serialized without blocking native button messages.
                    _FLOATING_PENDING_COMMANDS += 1
                    _FLOATING_ACTION_PENDING = True
                    _FLOATING_QUEUE.put(command)
        elif message == 0x0010:  # WM_CLOSE
            _FLOATING_QUEUE.put(("CLOSE",))
            ctypes.windll.user32.DestroyWindow(wintypes.HWND(hwnd))
            return 0
        elif message == 0x0002:  # WM_DESTROY
            _FLOATING_QUEUE.put(("DESTROY",))
            _FLOATING_HWND = None
            _FLOATING_ACTION_PENDING = False
            _FLOATING_PENDING_COMMANDS = 0
            ctypes.windll.user32.PostQuitMessage(0)
            return 0
        elif message == _FLOATING_WM_ACTION_COMPLETE:
            _FLOATING_PENDING_COMMANDS = max(0, _FLOATING_PENDING_COMMANDS - 1)
            _FLOATING_ACTION_PENDING = bool(_FLOATING_PENDING_COMMANDS)
            _native_invalidate(hwnd)
            return 0
        elif message == _FLOATING_WM_STATUS:
            _native_set_text(_FLOATING_CONTROLS.get("status"), _FLOATING_STATUS_TEXT)
            _native_invalidate(_FLOATING_CONTROLS.get("status"))
            return 0
    except Exception:
        # Never let a ctypes/GDI callback exception escape into Blender.  A
        # native callback that unwinds unexpectedly can terminate the process.
        pass
    user32 = ctypes.windll.user32
    _native_configure_api(user32)
    return user32.DefWindowProcW(hwnd, message, wparam, lparam)


def _native_window_thread_impl(initial):
    global _FLOATING_HWND, _FLOATING_WNDPROC
    if not _native_windows_available():
        _FLOATING_NATIVE_READY.set()
        return
    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    _native_configure_api(user32)
    user32.GetMessageW.restype = wintypes.BOOL
    kernel32.GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    kernel32.GetModuleHandleW.restype = ctypes.c_void_p
    kernel32.GetCurrentProcessId.restype = wintypes.DWORD
    user32.LoadCursorW.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    user32.LoadCursorW.restype = ctypes.c_void_p
    class_name = _FLOATING_CLASS_NAME + str(kernel32.GetCurrentProcessId())
    _FLOATING_WNDPROC = ctypes.WINFUNCTYPE(
        ctypes.c_ssize_t, wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM
    )(_native_wnd_proc)

    class WNDCLASSW(ctypes.Structure):
        _fields_ = [
            ("style", wintypes.UINT),
            ("lpfnWndProc", ctypes.c_void_p),
            ("cbClsExtra", ctypes.c_int),
            ("cbWndExtra", ctypes.c_int),
            ("hInstance", wintypes.HANDLE),
            ("hIcon", wintypes.HANDLE),
            ("hCursor", wintypes.HANDLE),
            ("hbrBackground", wintypes.HANDLE),
            ("lpszMenuName", wintypes.LPCWSTR),
            ("lpszClassName", wintypes.LPCWSTR),
        ]

    instance = kernel32.GetModuleHandleW(None)
    cursor = user32.LoadCursorW(None, 32512)
    background = _native_brush("background")
    wnd_class = WNDCLASSW(
        0,
        ctypes.cast(_FLOATING_WNDPROC, ctypes.c_void_p),
        0,
        0,
        instance,
        None,
        cursor,
        background,
        None,
        class_name,
    )
    user32.RegisterClassW(ctypes.byref(wnd_class))
    hwnd = user32.CreateWindowExW(
        0x00000080 | 0x00000008,  # WS_EX_TOOLWINDOW | WS_EX_TOPMOST
        class_name,
        "超级间选",
        0x00CF0000 | 0x10000000,  # WS_OVERLAPPEDWINDOW | WS_VISIBLE
        80,
        80,
        320,
        510,
        None,
        None,
        instance,
        None,
    )
    if not hwnd:
        _FLOATING_NATIVE_READY.set()
        return
    _FLOATING_HWND = int(hwnd)
    try:
        # Keep the non-client title bar light, matching the supplied
        # reference, while the add-on-owned client area stays dark.
        light_title = ctypes.c_int(0)
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes.HWND(hwnd), 20, ctypes.byref(light_title), ctypes.sizeof(light_title)
        )
        caption_color = wintypes.DWORD(_native_color("text"))
        caption_text = wintypes.DWORD(_native_color("background"))
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes.HWND(hwnd), 35, ctypes.byref(caption_color), ctypes.sizeof(caption_color)
        )
        ctypes.windll.dwmapi.DwmSetWindowAttribute(
            wintypes.HWND(hwnd), 36, ctypes.byref(caption_text), ctypes.sizeof(caption_text)
        )
    except (AttributeError, OSError, TypeError, ValueError):
        pass
    _native_build_controls(_FLOATING_HWND, initial)
    user32.SetWindowPos(
        wintypes.HWND(_FLOATING_HWND), wintypes.HWND(-1), 0, 0, 320, 510,
        0x0002 | 0x0010 | 0x0040,  # NOMOVE | NOACTIVATE | SHOWWINDOW
    )
    user32.ShowWindow(wintypes.HWND(_FLOATING_HWND), 5)
    user32.UpdateWindow(wintypes.HWND(_FLOATING_HWND))
    _FLOATING_NATIVE_READY.set()
    message = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(message), None, 0, 0) > 0:
        user32.TranslateMessage(ctypes.byref(message))
        user32.DispatchMessageW(ctypes.byref(message))
    _FLOATING_CONTROLS.clear()


def _native_window_thread(initial):
    """Keep Blender's timer alive only while the native thread is healthy."""
    global _FLOATING_HWND, _FLOATING_THREAD
    current = threading.current_thread()
    try:
        _native_window_thread_impl(initial)
    except Exception:
        _FLOATING_HWND = None
    finally:
        _FLOATING_NATIVE_READY.set()
        if _FLOATING_THREAD is current:
            _FLOATING_THREAD = None


def _find_owner_context():
    for window in bpy.context.window_manager.windows:
        if _window_pointer(window) != _FLOATING_OWNER_WINDOW_POINTER:
            continue
        for area in window.screen.areas:
            if _window_pointer(area) == _FLOATING_OWNER_AREA_POINTER:
                region = next((item for item in area.regions if item.type == "WINDOW"), None)
                return window, area, region
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                region = next((item for item in area.regions if item.type == "WINDOW"), None)
                return window, area, region
    return None, None, None


def _native_selected_edge_count(context):
    obj = context.edit_object
    if obj is None or obj.type != "MESH":
        return 0
    bm = bmesh.from_edit_mesh(obj.data)
    bm.edges.ensure_lookup_table()
    return sum(1 for edge in bm.edges if edge.select)


def _run_native_command(command):
    kind = command[0]
    if kind == "DESTROY":
        _SELECTION_HISTORY.clear()
        return
    if kind == "CLOSE":
        return
    status = None
    try:
        window, area, region = _find_owner_context()
        if window is None or area is None or region is None:
            _native_set_status("请在网格编辑模式中使用")
            return
        override = {
            "window": window,
            "screen": window.screen,
            "area": area,
            "region": region,
        }
        with bpy.context.temp_override(**override):
            if kind == "SELECT":
                mode, data = command[1], command[2]
                prefix = "super_interval_loop" if mode == "LOOP" else "super_interval_ring"
                for key, value in data.items():
                    setattr(window.scene, prefix + "_" + key, value)
                # The native window is serviced by a timer context.  Call the
                # unchanged core algorithm directly and keep only a private
                # snapshot, so Blender's global Edit Undo stack is untouched.
                snapshot = _record_selection(bpy.context)
                result, error = _run_selection(
                    bpy.context,
                    mode,
                    getattr(window.scene, prefix + "_repeat"),
                    getattr(window.scene, prefix + "_jump"),
                    getattr(window.scene, prefix + "_reversal"),
                    getattr(window.scene, prefix + "_max"),
                )
                setattr(window.scene, prefix + "_max_exceeded", bool(error and "超过 Max=" in error))
                if error:
                    _discard_selection_snapshot(snapshot)
                    status = "超额预警：" + error if "超过 Max=" in error else "提示：" + error
                else:
                    maximum = int(getattr(window.scene, prefix + "_max"))
                    max_label = "∞" if maximum <= 0 else str(maximum)
                    status = f"当前选边：{_native_selected_edge_count(bpy.context)} / Max={max_label}"
            elif kind == "UNDO":
                restored, error = _restore_selection_snapshot(bpy.context)
                if restored:
                    status = f"已撤销，当前选边：{_native_selected_edge_count(bpy.context)}"
                else:
                    status = "提示：" + error
            elif kind == "QUICK":
                snapshot = _record_selection(bpy.context)
                result, error = _run_quick(bpy.context, command[1], command[2])
                if error:
                    _discard_selection_snapshot(snapshot)
                    status = "提示：" + error
                else:
                    status = f"当前选边：{_native_selected_edge_count(bpy.context)}"
    finally:
        if status is not None:
            _native_set_status(status)
        hwnd = _floating_window()
        if hwnd:
            try:
                user32 = ctypes.windll.user32
                user32.PostMessageW(
                    wintypes.HWND(hwnd), _FLOATING_WM_ACTION_COMPLETE, 0, 0
                )
            except (AttributeError, OSError, TypeError, ValueError):
                pass


def _configure_floating_window():
    global _FLOATING_TIMER_ACTIVE, _FLOATING_HWND
    if not _FLOATING_NATIVE_READY.is_set():
        _FLOATING_TIMER_ACTIVE = True
        return 0.01
    try:
        command = _FLOATING_QUEUE.get_nowait()
    except queue.Empty:
        command = None
    if command is not None:
        try:
            _run_native_command(command)
        except Exception:
            pass
        # Let Win32 finish painting the clicked button before processing the
        # next action.  This keeps rapid clicks ordered and visible.
        return 0.001 if _floating_window() else None
    if _floating_window():
        _FLOATING_TIMER_ACTIVE = True
        return 0.016
    _FLOATING_HWND = None
    _FLOATING_TIMER_ACTIVE = False
    return None


def _schedule_floating_configuration():
    global _FLOATING_TIMER_ACTIVE
    try:
        timer_registered = bpy.app.timers.is_registered(_configure_floating_window)
    except (AttributeError, RuntimeError, TypeError):
        timer_registered = False
    if _FLOATING_TIMER_ACTIVE and timer_registered:
        return
    _FLOATING_NATIVE_READY.clear()
    _FLOATING_TIMER_ACTIVE = True
    try:
        bpy.app.timers.register(_configure_floating_window, first_interval=0.1)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        _FLOATING_TIMER_ACTIVE = False


def _reset_floating_commands():
    """Reset stale actions before a new native window session starts."""
    global _FLOATING_ACTION_PENDING, _FLOATING_PENDING_COMMANDS
    while True:
        try:
            _FLOATING_QUEUE.get_nowait()
        except queue.Empty:
            break
    _FLOATING_ACTION_PENDING = False
    _FLOATING_PENDING_COMMANDS = 0


def _close_floating_window(context=None, window=None):
    hwnd = _floating_window()
    if hwnd:
        try:
            user32 = ctypes.windll.user32
            user32.PostMessageW(wintypes.HWND(hwnd), 0x0010, 0, 0)
        except (AttributeError, OSError, TypeError, ValueError):
            pass


# One session is kept per mesh and per operation.  It deliberately does not
# depend on the active edge: Blender changes the active history while a
# selection is being displayed, and that must not turn a two-sided expansion
# into a one-sided walk.
_SESSION = {}


def _edge_index(edge):
    return int(edge.index)


def _state_key(obj, mode):
    return (int(obj.data.as_pointer()), mode)


def _loop_extension(edge, vert):
    """Return the regular-loop continuation through ``vert``.

    At a four-valence manifold vertex, the two edges belonging to the current
    edge's adjacent face corners are excluded.  The remaining edge is the
    continuation of the same loop.  Returning one edge per endpoint gives
    both sides of a selected seed edge when the shell is expanded.
    """
    if not vert.is_manifold or len(vert.link_loops) != 4:
        return None

    excluded = {edge}
    for loop in edge.link_loops:
        excluded.add(loop.link_loop_next.edge)
        excluded.add(loop.link_loop_prev.edge)

    candidates = [candidate for candidate in vert.link_edges if candidate not in excluded]
    if not candidates:
        return None
    candidates.sort(key=_edge_index)
    return candidates[0]


def _ngon_boundary_extensions(edge, vert):
    """Return loop continuations along an adjacent polygon boundary.

    A capped cylinder has a side edge whose endpoint is shared by one quad
    and one n-gon.  Such a vertex has three incident edge loops instead of
    the four loops used by a regular quad grid, so the regular continuation
    test above correctly rejects it as ambiguous.  For a loop-selection
    operation the unambiguous part is the n-gon's boundary: continue along
    the boundary edges incident to this vertex.  Returning both directions
    keeps a closed cap loop continuous and fixes the one-segment gaps at the
    top and bottom of capped cylinders.

    The helper deliberately only handles polygon faces with more than four
    vertices.  Quads and triangles continue through the original, unchanged
    path so ordinary meshes keep their previous behavior.
    """
    result = set()
    for face in edge.link_faces:
        if len(face.verts) <= 4 or vert not in face.verts:
            continue
        for candidate in face.edges:
            if candidate is edge or vert not in candidate.verts:
                continue
            result.add(candidate)
    return result


def _ring_extension(edge, face):
    """Return the opposite edge of ``edge`` in a quad face."""
    if len(face.verts) != 4:
        return None
    other_verts = [vert for vert in face.verts if vert not in edge.verts]
    if len(other_verts) != 2:
        return None
    for candidate in face.edges:
        if other_verts[0] in candidate.verts and other_verts[1] in candidate.verts:
            return candidate
    return None


def _extensions(edge, mode):
    """Return all valid immediate continuations, without direction bias."""
    if mode == 'LOOP':
        candidates = set()
        for vert in edge.verts:
            boundary = _ngon_boundary_extensions(edge, vert)
            if boundary:
                candidates.update(boundary)
                continue
            continuation = _loop_extension(edge, vert)
            if continuation is not None:
                candidates.add(continuation)
    else:
        candidates = (_ring_extension(edge, face) for face in edge.link_faces)
    return {candidate for candidate in candidates if candidate is not None}


def _boundary_edges(faces):
    """Return edges around the selected faces, preserving face-input mode."""
    face_set = set(faces)
    result = set()
    for face in faces:
        for edge in face.edges:
            # An edge shared only by selected faces is interior and must not
            # become an independent starting strand.
            if any(linked_face not in face_set for linked_face in edge.link_faces):
                result.add(edge)
            elif len(edge.link_faces) == 1:
                result.add(edge)
    return result


def _current_selection(bm, selection_mode):
    """Read the user's intended input from Blender's current select mode.

    Face flags can remain set in a BMesh after switching to edge mode.  The
    active mode is therefore authoritative whenever it has a corresponding
    selection, with a fallback only for an unusual empty mode state.
    """
    selected_edges = {edge for edge in bm.edges if edge.select}
    selected_faces = {face for face in bm.faces if face.select}

    edge_mode = bool(selection_mode[1])
    face_mode = bool(selection_mode[2])
    if edge_mode and selected_edges:
        return selected_edges, set(), False
    if face_mode and selected_faces:
        return _boundary_edges(selected_faces), selected_faces, True
    if selected_edges:
        return selected_edges, set(), False
    if selected_faces:
        return _boundary_edges(selected_faces), selected_faces, True
    return set(), set(), False


def _input_signature(edges, faces, face_input):
    if face_input:
        return ('F', tuple(sorted(int(face.index) for face in faces)))
    return ('E', tuple(sorted(int(edge.index) for edge in edges)))


def _output_signature(bm, face_input):
    if face_input:
        return ('F', tuple(sorted(int(face.index) for face in bm.faces if face.select)))
    return ('E', tuple(sorted(int(edge.index) for edge in bm.edges if edge.select)))


def _new_state(start_edges, face_input, settings):
    base = tuple(sorted(start_edges, key=_edge_index))
    return {
        "settings": settings,
        "face_input": bool(face_input),
        "shells": [tuple(_edge_index(edge) for edge in base)],
        "distance": {_edge_index(edge): 0 for edge in base},
        "click": 0,
        "output_signature": None,
    }


def _ensure_shells(bm, state, mode, radius):
    """Build shell layers from the immutable starting selection."""
    edge_by_index = {int(edge.index): edge for edge in bm.edges}
    visited = set(state["distance"])

    while len(state["shells"]) <= radius:
        previous = {
            edge_by_index[index]
            for index in state["shells"][-1]
            if index in edge_by_index
        }
        if not previous:
            break

        next_shell = set()
        for edge in previous:
            next_shell.update(_extensions(edge, mode))
        # ``visited`` stores stable BMesh indices, while ``next_shell`` is a
        # set of edge objects.  Compare by index explicitly so a multi-edge
        # origin cannot leak back into every subsequent shell.
        next_shell = {
            edge for edge in next_shell if _edge_index(edge) not in visited
        }
        if not next_shell:
            break

        ids = tuple(sorted(int(edge.index) for edge in next_shell))
        state["shells"].append(ids)
        for index in ids:
            state["distance"][index] = len(state["shells"]) - 1
        visited.update(ids)


def _pattern_selected(distance, repeat, jump, reversal, click):
    """Return the selection state for a shell at ``distance``.

    The origin is a selected interval, not a single special edge.  For a
    non-reversed operation, each side starts with ``Jump`` skipped shells and
    then repeats ``Repeat`` selected shells.  Reversal alternates the active
    part of that same period on every click: even clicks use the Repeat part,
    odd clicks use the Jump part.  With no jump shells there is no complement
    to select, so the groups of Repeat shells alternate instead.
    """
    distance = int(distance)
    repeat = max(1, int(repeat))
    jump = max(0, int(jump))
    click = max(0, int(click))

    if distance == 0:
        return (not reversal) or (click % 2 == 0)

    if jump == 0:
        if not reversal:
            return True
        # Number the groups immediately outside the origin from one.  This
        # gives the expected alternating Repeat-wide bands when Jump=0.
        group = (distance - 1) // repeat + 1
        return (group % 2) == (click % 2)

    block = repeat + jump
    offset = (distance - 1) % block
    repeat_part = offset >= jump
    if not reversal or click % 2 == 0:
        return repeat_part
    return not repeat_part


def _max_distance(repeat, jump, reversal, click):
    """Return how far the current click is allowed to advance.

    A normal click advances one complete Repeat+Jump period.  In reversed
    mode, the selected part alternates, so the visible frontier advances one
    period every two clicks (plus the Jump part on odd clicks).  Jump=0 uses
    alternating Repeat-wide groups and therefore advances by Repeat each
    click.
    """
    repeat = max(1, int(repeat))
    jump = max(0, int(jump))
    click = max(0, int(click))
    if not reversal:
        return click * (repeat + jump)
    if jump == 0:
        return click * repeat
    block = repeat + jump
    if click % 2 == 0:
        return (click // 2) * block
    return (click // 2) * block + jump


def _build_result(bm, state, mode, repeat, jump, reversal, click):
    radius = _max_distance(repeat, jump, reversal, click)
    _ensure_shells(bm, state, mode, radius)

    edge_by_index = {int(edge.index): edge for edge in bm.edges}
    result = set()
    for distance, ids in enumerate(state["shells"]):
        if distance > radius:
            break
        if _pattern_selected(distance, repeat, jump, reversal, click):
            result.update(edge_by_index[index] for index in ids if index in edge_by_index)
    return result


def _select_edges(bm, edges):
    for vert in bm.verts:
        vert.select = False
    for face in bm.faces:
        face.select = False
    for edge in bm.edges:
        edge.select = edge in edges
    bm.select_history.clear()
    active = min(edges, key=_edge_index) if edges else None
    if active is not None:
        bm.select_history.add(active)


def _select_faces(bm, edges, exclude_faces=None):
    for vert in bm.verts:
        vert.select = False
    for edge in bm.edges:
        edge.select = False
    for face in bm.faces:
        face.select = False

    selected_faces = set()
    for edge in edges:
        selected_faces.update(edge.link_faces)
    if exclude_faces:
        selected_faces.difference_update(exclude_faces)
    for face in selected_faces:
        face.select = True

    bm.select_history.clear()
    active = min(selected_faces, key=lambda face: int(face.index)) if selected_faces else None
    if active is not None:
        bm.select_history.add(active)


def _selection_snapshot(context):
    """Capture the complete current edit-mode selection before a plug-in action."""
    obj = context.edit_object
    if obj is None or obj.type != 'MESH':
        return None
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    active = bm.select_history.active
    active_type = None
    active_index = None
    if active is not None:
        active_type = type(active).__name__
        active_index = int(active.index)
    edges, faces, face_input = _current_selection(
        bm, tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    )
    if face_input:
        restore_kind = "FACE"
    elif edges:
        restore_kind = "EDGE"
    else:
        restore_kind = "VERT"
    return {
        "mesh": int(obj.data.as_pointer()),
        "select_mode": tuple(bool(value) for value in context.tool_settings.mesh_select_mode),
        "restore_kind": restore_kind,
        "verts": tuple(int(vert.index) for vert in bm.verts if vert.select),
        "edges": tuple(int(edge.index) for edge in bm.edges if edge.select),
        "faces": tuple(int(face.index) for face in bm.faces if face.select),
        "active_type": active_type,
        "active_index": active_index,
        "session": copy.deepcopy(_SESSION),
    }


def _record_selection(context):
    snapshot = _selection_snapshot(context)
    if snapshot is None:
        return None
    _SELECTION_HISTORY.append(snapshot)
    if len(_SELECTION_HISTORY) > _SELECTION_HISTORY_LIMIT:
        del _SELECTION_HISTORY[0]
    return snapshot


def _discard_selection_snapshot(snapshot):
    if snapshot is not None and _SELECTION_HISTORY and _SELECTION_HISTORY[-1] is snapshot:
        _SELECTION_HISTORY.pop()


def _restore_selection_snapshot(context):
    if not _SELECTION_HISTORY:
        return False, "没有可撤销的插件选区操作"
    obj = context.edit_object
    if obj is None or obj.type != 'MESH':
        return False, "请在网格编辑模式中使用"
    snapshot = _SELECTION_HISTORY[-1]
    if snapshot["mesh"] != int(obj.data.as_pointer()):
        return False, "当前网格没有可撤销的插件选区操作"

    _SELECTION_HISTORY.pop()
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    vert_ids = set(snapshot["verts"])
    edge_ids = set(snapshot["edges"])
    face_ids = set(snapshot["faces"])
    context.tool_settings.mesh_select_mode = snapshot["select_mode"]
    # Blender may keep lower or higher element selection flags after a mode
    # switch.  Restore only the selection layer that was actually active; a
    # full raw flag restore would turn a single restored edge into all edges.
    if snapshot["restore_kind"] == "EDGE":
        for vert in bm.verts:
            vert.select = False
        for face in bm.faces:
            face.select = False
        for edge in bm.edges:
            edge.select = int(edge.index) in edge_ids
    elif snapshot["restore_kind"] == "FACE":
        for vert in bm.verts:
            vert.select = False
        for edge in bm.edges:
            edge.select = False
        for face in bm.faces:
            face.select = int(face.index) in face_ids
    else:
        for edge in bm.edges:
            edge.select = False
        for face in bm.faces:
            face.select = False
        for vert in bm.verts:
            vert.select = int(vert.index) in vert_ids
    bm.select_history.clear()
    active_type = snapshot["active_type"]
    active_index = snapshot["active_index"]
    lookup = {
        "BMVert": bm.verts,
        "BMEdge": bm.edges,
        "BMFace": bm.faces,
    }.get(active_type)
    if lookup is not None and active_index is not None and active_index < len(lookup):
        bm.select_history.add(lookup[active_index])
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    _SESSION.clear()
    _SESSION.update(snapshot["session"])
    return True, None


def _run_quick(context, mode, action):
    obj = context.edit_object
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None, "请在网格编辑模式中使用"

    bm = bmesh.from_edit_mesh(obj.data)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    selection_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    start_edges, start_faces, face_input = _current_selection(bm, selection_mode)
    if not start_edges:
        return None, "请先选择一条边或一个面"

    frontier = set()
    for edge in start_edges:
        frontier.update(_extensions(edge, mode))

    if action == 'EXTEND':
        result = start_edges | frontier
    elif action == 'REVERSE_RING':
        result = frontier.difference(start_edges)
    else:
        # A boundary edge has fewer than two selected continuations.  Testing
        # only for an unselected continuation fails at the mesh border: there
        # is no continuation there at all, so a line touching the border was
        # previously treated as having no removable outer shell.  Counting
        # selected neighbours handles both open paths and interior segments.
        boundary = {
            edge for edge in start_edges
            if len(_extensions(edge, mode).intersection(start_edges)) < 2
        }
        result = start_edges.difference(boundary)

    if face_input:
        excluded = start_faces if action == 'REVERSE_RING' else None
        _select_faces(bm, result, excluded)
    else:
        _select_edges(bm, result)
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return len(result), None


def _qol_contiguous_edges(bm, start_edges, angle):
    """One simultaneous endpoint step using QOL's angular continuation rule.

    Based on QOL Select Contiguous 1.0.8 (Rico Holmes), but deliberately NOT
    its full-path walk. Only endpoints of the input selection can extend;
    additions never become new seeds in this step. This makes N repetitions
    advance at most N edges per open end, including open mesh boundaries.
    """
    selected = set(start_edges)
    incident = {}
    for edge in selected:
        for vert in edge.verts:
            incident.setdefault(vert, []).append(edge)
    additions = set()
    for current, linked in incident.items():
        if len(linked) != 1 or current.hide:
            continue
        seed = linked[0]
        previous = seed.other_vert(current)
        incoming = current.co - previous.co
        if incoming.length_squared == 0.0:
            continue
        candidates = [
            edge for edge in current.link_edges
            if edge not in selected and not edge.hide
            and not edge.other_vert(current).hide
            and (not seed.is_boundary or edge.is_boundary)
            and (edge.other_vert(current).co - current.co).length_squared > 0.0
        ]
        if not candidates:
            continue
        if seed.is_boundary:
            # Preserve QOL's boundary preference, but stop after one edge.
            chosen = candidates[0]
        else:
            chosen = min(candidates, key=lambda edge: incoming.angle(edge.other_vert(current).co - current.co))
            turn = degrees(incoming.angle(chosen.other_vert(current).co - current.co))
            if turn >= angle:
                continue
        additions.add(chosen)
    return selected | additions


def _run_angle_loop(context, angle):
    """Add at most one angular continuation per open selection endpoint."""
    obj = context.edit_object
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None, "请在网格编辑模式中使用"
    bm = bmesh.from_edit_mesh(obj.data)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    select_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    start_edges, _, face_input = _current_selection(bm, select_mode)
    if not start_edges:
        return None, "请先选择一条边或一个面"
    result = _qol_contiguous_edges(bm, start_edges, angle)
    if face_input:
        _select_faces(bm, result)
    else:
        _select_edges(bm, result)
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    return len(result), None


def _run_selection(context, mode, repeat, jump, reversal, maximum):
    obj = context.edit_object
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None, "请在网格编辑模式中使用"

    mesh = obj.data
    maximum = max(0, int(maximum))
    bm = bmesh.from_edit_mesh(mesh)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    selection_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    start_edges, start_faces, face_input = _current_selection(bm, selection_mode)
    settings = (int(repeat), int(jump), bool(reversal), int(maximum), bool(face_input))
    key = _state_key(obj, mode)
    state = _SESSION.get(key)

    current_output = _output_signature(bm, face_input)
    state_is_continuation = (
        state is not None
        and state["settings"] == settings
        and state["face_input"] == face_input
        and state["output_signature"] == current_output
        and bool(state["shells"])
    )

    if not state_is_continuation:
        if not start_edges:
            return None, "请先选择一条边或一个面"
        state = _new_state(start_edges, face_input, settings)

    next_click = int(state["click"]) + 1
    result_edges = _build_result(bm, state, mode, repeat, jump, reversal, next_click)
    if maximum > 0 and len(result_edges) > maximum:
        return None, f"结果包含 {len(result_edges)} 条边，超过 Max={maximum}"

    if face_input:
        _select_faces(bm, result_edges)
    else:
        _select_edges(bm, result_edges)
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)

    state["click"] = next_click
    state["output_signature"] = _output_signature(bm, face_input)
    _SESSION[key] = state
    return len(result_edges), None


def _build_angle_selection_result(bm, state, repeat, jump, reversal, click, angle):
    """Change only the path generator; use the existing distance/pattern rules.

    All traversed edges, including skipped shells, remain part of the path.
    Thus a gap or reversal never becomes a new starting point on the next click.
    Only stable indices live in the session, never BMesh references.
    """
    radius = _max_distance(repeat, jump, reversal, click)
    edge_by_index = {int(edge.index): edge for edge in bm.edges}
    visited = {edge_by_index[index] for index in state["distance"] if index in edge_by_index}
    while len(state["shells"]) <= radius:
        next_shell = _qol_contiguous_edges(bm, visited, angle).difference(visited)
        if not next_shell:
            break
        ids = tuple(sorted(int(edge.index) for edge in next_shell))
        state["shells"].append(ids)
        for index in ids:
            state["distance"][index] = len(state["shells"]) - 1
        visited.update(next_shell)

    result = set()
    for distance, ids in enumerate(state["shells"]):
        if distance > radius:
            break
        if _pattern_selected(distance, repeat, jump, reversal, click):
            result.update(edge_by_index[index] for index in ids if index in edge_by_index)
    return result


def _run_angle_selection(context, repeat, jump, reversal, maximum, angle):
    """Loop-only angular paths with the same units/gaps/reversal/Max policy."""
    obj = context.edit_object
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None, "请在网格编辑模式中使用"
    mesh = obj.data
    maximum = max(0, int(maximum))
    bm = bmesh.from_edit_mesh(mesh)
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    selection_mode = tuple(bool(value) for value in context.tool_settings.mesh_select_mode)
    start_edges, _, face_input = _current_selection(bm, selection_mode)
    settings = (int(repeat), int(jump), bool(reversal), maximum, bool(face_input), int(angle))
    # Keep angular traversal separate from the original topology session.
    key = _state_key(obj, 'LOOP_ANGLE')
    state = _SESSION.get(key)
    current_output = _output_signature(bm, face_input)
    state_is_continuation = (
        state is not None
        and state["settings"] == settings
        and state["face_input"] == face_input
        and state["output_signature"] == current_output
        and bool(state["shells"])
    )
    if not state_is_continuation:
        if not start_edges:
            return None, "请先选择一条边或一个面"
        state = _new_state(start_edges, face_input, settings)
    next_click = int(state["click"]) + 1
    result_edges = _build_angle_selection_result(bm, state, repeat, jump, reversal, next_click, angle)
    if maximum > 0 and len(result_edges) > maximum:
        return None, f"结果包含 {len(result_edges)} 条边，超过 Max={maximum}"
    if face_input:
        _select_faces(bm, result_edges)
    else:
        _select_edges(bm, result_edges)
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    state["click"] = next_click
    state["output_signature"] = _output_signature(bm, face_input)
    _SESSION[key] = state
    return len(result_edges), None


class SUPERINTERVAL_OT_select(bpy.types.Operator):
    bl_idname = "mesh.super_interval_select"
    bl_label = "选择边循环 / 边环"
    bl_description = "按单元、跳跃和交替反转设置，从起始选区向两侧推进；可在重做面板调整重复次数"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="选择模式",
        items=(
            ('LOOP', "循环边", "沿边循环向两侧延伸"),
            ('RING', "并排边", "穿过相邻四边面的对边向两侧延伸"),
        ),
    )
    repeat_count: bpy.props.IntProperty(
        name="重复次数",
        description="本次操作连续执行的次数；1 表示执行一次",
        default=1,
        min=1,
        max=10000,
    )

    @classmethod
    def description(cls, context, properties):
        if properties.mode == 'LOOP':
            return "选择边循环：按单元、跳跃和交替反转设置沿循环向两侧推进。单元是每个周期连续选择的层数；重做面板的重复次数等同于多次点击。Max 为 0 时不限数量"
        return "选择边环：沿相邻四边面的对边，按单元、跳跃和交替反转设置向两侧推进。单元是每个周期连续选择的层数；重做面板可调整重复次数。Max 为 0 时不限数量"

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'EDIT_MESH'
            and context.edit_object is not None
            and context.edit_object.type == 'MESH'
        )

    def execute(self, context):
        scene = context.scene
        prefix = "super_interval_loop" if self.mode == 'LOOP' else "super_interval_ring"
        result = None
        for _ in range(max(1, int(self.repeat_count))):
            result, error = _run_selection(
                context,
                self.mode,
                getattr(scene, prefix + "_repeat"),
                getattr(scene, prefix + "_jump"),
                getattr(scene, prefix + "_reversal"),
                getattr(scene, prefix + "_max"),
            )
            setattr(scene, prefix + "_max_exceeded", bool(error and "超过 Max=" in error))
            if error:
                self.report({'WARNING'}, error)
                return {'CANCELLED'}
        self.report({'INFO'}, f"已重复 {int(self.repeat_count)} 次，当前选择 {result} 条边")
        return {'FINISHED'}


class SUPERINTERVAL_OT_select_main(bpy.types.Operator):
    """Two per-mode repeat slots, one switchable native redo operation.

    The legacy super_interval_select stays untouched for existing scripts.
    No update callbacks run selection operations or alter undo history.
    Blender stores both counts together but edits/uses only the active slot.
    """
    bl_idname = "mesh.super_interval_select_main"
    bl_label = "选择边循环 / 边环"
    bl_description = "按同一套单元、跳跃、交替反转和 Max 规则间选；循环边和并排边分别记住重复次数"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="选择模式", default='LOOP',
        items=(('LOOP', "循环边", "沿循环路径间选，可切换布线延伸或角度延伸"),
               ('RING', "并排边", "沿相邻四边面的对边间选，保持原有规则")),
    )
    loop_repeat_count: bpy.props.IntProperty(
        name="重复次数", description="选择边循环本次连续执行的次数；单独记忆，不影响选择边环",
        default=1, min=1, max=10000,
    )
    ring_repeat_count: bpy.props.IntProperty(
        name="重复次数", description="选择边环本次连续执行的次数；单独记忆，不影响选择边循环",
        default=1, min=1, max=10000,
    )
    extend_method: bpy.props.EnumProperty(
        name="延伸方式", description="仅改变循环边的延伸路径；两种方式使用相同的单元、跳跃、交替反转和 Max 规则",
        items=(('TOPOLOGY', "布线延伸", "沿原有循环拓扑生成路径，保持原算法结果"),
               ('QOL_ANGLE', "角度延伸", "按最小转折角逐层生成路径，再执行相同的间选规则")),
        default='TOPOLOGY',
    )
    angle: bpy.props.IntProperty(
        name="角度阈值（°）", description="角度路径的转折角须严格小于此值；开放网格边界沿边界延伸，不受阈值限制。单元与跳跃决定一次推进的层数",
        default=30, min=0, max=360,
    )

    @classmethod
    def poll(cls, context):
        return SUPERINTERVAL_OT_select.poll(context)

    @classmethod
    def description(cls, context, properties):
        if properties.mode == 'LOOP':
            return "选择边循环：布线延伸或角度延伸生成路径，再按同一套单元、跳跃、交替反转和 Max 规则间选。F9 可切换方式；重复次数与选择边环分开记忆，Max=0 不限数量"
        return "选择边环：沿相邻四边面的对边，按原有单元、跳跃、交替反转和 Max 规则间选。F9 保留选择模式切换；重复次数与选择边循环分开记忆，Max=0 不限数量"

    def draw(self, context):
        self.layout.prop(self, "mode")
        if self.mode == 'LOOP':
            self.layout.prop(self, "extend_method")
            if self.extend_method == 'QOL_ANGLE':
                self.layout.prop(self, "angle")
            self.layout.prop(self, "loop_repeat_count")
        else:
            self.layout.prop(self, "ring_repeat_count")

    def execute(self, context):
        scene = context.scene
        is_loop = self.mode == 'LOOP'
        prefix = "super_interval_loop" if is_loop else "super_interval_ring"
        count = self.loop_repeat_count if is_loop else self.ring_repeat_count
        result = None
        for _ in range(max(1, int(count))):
            args = (getattr(scene, prefix + "_repeat"), getattr(scene, prefix + "_jump"),
                    getattr(scene, prefix + "_reversal"), getattr(scene, prefix + "_max"))
            if is_loop and self.extend_method == 'QOL_ANGLE':
                result, error = _run_angle_selection(context, *args, self.angle)
            else:
                result, error = _run_selection(context, self.mode, *args)
            setattr(scene, prefix + "_max_exceeded", bool(error and "超过 Max=" in error))
            if error:
                self.report({'WARNING'}, error)
                return {'CANCELLED'}
        self.report({'INFO'}, f"已重复 {int(count)} 次，当前选择 {result} 条边")
        return {'FINISHED'}


class SUPERINTERVAL_OT_undo(bpy.types.Operator):
    bl_idname = "mesh.super_interval_undo"
    bl_label = "撤销"
    bl_description = "撤销 Blender 最近一步操作，使用 Blender 原生撤销历史"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        bpy.ops.ed.undo()
        return {'FINISHED'}


class SUPERINTERVAL_OT_quick(bpy.types.Operator):
    """Run one independent, one-shell topology operation."""

    bl_idname = "mesh.super_interval_quick"
    bl_label = "快速选择工具"
    bl_description = "对当前选区执行扩展、收缩或切换；可在重做面板调整重复次数"
    bl_options = {'REGISTER', 'UNDO'}

    mode: bpy.props.EnumProperty(
        name="选择模式",
        items=(
            ('LOOP', "循环边", "沿边循环处理当前选区"),
            ('RING', "并排边", "沿四边面的对边处理当前选区"),
        ),
    )
    action: bpy.props.EnumProperty(
        name="操作",
        items=(
            ('EXTEND', "扩展", "保留当前选择并向外延伸"),
            ('SHRINK', "收缩", "去掉当前选区两侧的一个外层"),
            ('REVERSE_RING', "切换并排边", "选择相邻边环并取消原来的选择"),
        ),
    )
    extend_method: bpy.props.EnumProperty(
        name="延伸方式",
        description="仅用于扩展循环；切换时由 Blender 从本次操作前的选区重新计算",
        items=(
            ('TOPOLOGY', "布线延伸", "每次沿循环布线向两侧增加一层"),
            ('QOL_ANGLE', "角度延伸", "按最小转折角，从当前选区每个开放端点最多延伸一条边"),
        ),
        default='TOPOLOGY',
    )
    angle: bpy.props.IntProperty(
        name="角度阈值（°）",
        description="角度延伸选择转折角严格小于此值的边，默认 30°；每次每端最多一步。开放网格边界不受角度限制，但同样只走一步",
        default=30, min=0, max=360,
    )
    repeat_count: bpy.props.IntProperty(
        name="重复次数",
        description="本次快捷操作连续执行的次数；1 表示执行一次",
        default=1,
        min=1,
        max=10000,
    )

    @classmethod
    def description(cls, context, properties):
        descriptions = {
            ('LOOP', 'EXTEND'): "扩展循环：每次向两端各延伸一步。F9 可切换布线延伸或角度延伸；切换从本次操作前的选区重算。记住本工具的延伸方式、角度和重复次数",
            ('RING', 'EXTEND'): "扩展并排边：保留当前选择，并沿相邻四边面的对边向两侧增加一层。可在重做面板调整重复次数",
            ('LOOP', 'SHRINK'): "收缩循环：沿循环拓扑去掉当前选区两侧的一个外层。可在重做面板调整重复次数",
            ('RING', 'SHRINK'): "收缩并排边：沿并排边拓扑去掉当前选区两侧的一个外层。可在重做面板调整重复次数",
            ('RING', 'REVERSE_RING'): "切换并排边：取消当前选择，改选相邻的一层并排边。可在重做面板调整重复次数",
        }
        return descriptions.get((properties.mode, properties.action), cls.bl_description)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "mode")
        layout.prop(self, "action")
        if self.mode == 'LOOP' and self.action == 'EXTEND':
            layout.prop(self, "extend_method")
            if self.extend_method == 'QOL_ANGLE':
                layout.prop(self, "angle")
        layout.prop(self, "repeat_count")

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'EDIT_MESH'
            and context.edit_object is not None
            and context.edit_object.type == 'MESH'
        )

    def execute(self, context):
        result = None
        for _ in range(max(1, int(self.repeat_count))):
            if self.mode == 'LOOP' and self.action == 'EXTEND' and self.extend_method == 'QOL_ANGLE':
                result, error = _run_angle_loop(context, self.angle)
            else:
                result, error = _run_quick(context, self.mode, self.action)
            if error:
                self.report({'WARNING'}, error)
                return {'CANCELLED'}
        self.report({'INFO'}, f"已重复 {int(self.repeat_count)} 次，当前选择 {result} 条边")
        return {'FINISHED'}


def _draw_independent_quick(self, context):
    if self.mode == 'LOOP' and self.action == 'EXTEND':
        self.layout.prop(self, "extend_method")
        if self.extend_method == 'QOL_ANGLE':
            self.layout.prop(self, "angle")
    self.layout.prop(self, "repeat_count")


_QUICK_TOOLS = (
    ("扩展循环", "extend_loop", 'LOOP', 'EXTEND',
     "扩展循环：布线延伸按循环拓扑走一步；角度延伸按最小转折角走一步。每次每端最多增加一条边。F9 切换方式或次数会从本次操作前的选区重算；本工具单独记住方式、角度和次数"),
    ("扩展并排边", "extend_ring", 'RING', 'EXTEND',
     "扩展并排边：沿相邻四边面的对边向两侧增加一层。F9 可调整重复次数，本工具单独记住次数"),
    ("收缩循环", "shrink_loop", 'LOOP', 'SHRINK',
     "收缩循环：沿循环布线去掉选区两侧的一个外层。F9 可调整重复次数，本工具单独记住次数"),
    ("收缩并排边", "shrink_ring", 'RING', 'SHRINK',
     "收缩并排边：沿并排边布线去掉选区两侧的一个外层。F9 可调整重复次数，本工具单独记住次数"),
    ("切换并排边", "reverse_ring", 'RING', 'REVERSE_RING',
     "切换并排边：取消当前选择，改选相邻的一层并排边。F9 可调整重复次数，本工具单独记住次数"),
)


def _make_quick_operator(label, suffix, mode, action, description):
    """Separate RNA types give each button its own Blender last-properties.

    Reuse the existing execute/poll implementation, not a nested bpy.ops call,
    so a button press stays one undoable operator and F9 replays from its seed.
    The legacy mesh.super_interval_quick remains available for old scripts.
    """
    properties = {
        "repeat_count": bpy.props.IntProperty(
            name="重复次数", description="本次操作从初始选区连续执行的次数；只记住当前工具的次数，不影响其他工具",
            default=1, min=1, max=10000,
        ),
    }
    if mode == 'LOOP' and action == 'EXTEND':
        properties.update(
            extend_method=bpy.props.EnumProperty(
                name="延伸方式", description="从本次操作前的选区重新计算；记住选择的方式供下次扩展循环使用",
                items=(
                    ('TOPOLOGY', "布线延伸", "每次沿循环布线向两侧增加一层"),
                    ('QOL_ANGLE', "角度延伸", "每次按最小转折角向选区每个开放端点最多延伸一条边"),
                ), default='TOPOLOGY',
            ),
            angle=bpy.props.IntProperty(
                name="角度阈值（°）", description="选择转折角严格小于此值的边，默认 30°；每次每端最多一步。开放网格边界沿边界走一步，不受角度限制",
                default=30, min=0, max=360,
            ),
        )
    return type("SUPERINTERVAL_OT_" + suffix, (bpy.types.Operator,), {
        "__module__": __name__,
        "__annotations__": properties,
        "bl_idname": "mesh.super_interval_" + suffix,
        "bl_label": label,
        "bl_description": description,
        "bl_options": {'REGISTER', 'UNDO'},
        "mode": mode,
        "action": action,
        "poll": classmethod(SUPERINTERVAL_OT_quick.poll.__func__),
        "execute": SUPERINTERVAL_OT_quick.execute,
        "draw": _draw_independent_quick,
    })


_QUICK_OPERATOR_CLASSES = tuple(_make_quick_operator(*spec) for spec in _QUICK_TOOLS)


class SUPERINTERVAL_OT_float(bpy.types.Operator):
    """Toggle the add-on-owned native Super Interval tool window."""

    bl_idname = "mesh.super_interval_float"
    bl_label = "悬浮超级间选"
    bl_description = "在 Blender 主界面上方打开或关闭超级间选悬浮面板"
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    def execute(self, context):
        global _FLOATING_OWNER_WINDOW_POINTER, _FLOATING_OWNER_AREA_POINTER
        global _FLOATING_THREAD

        if _floating_window() is not None:
            _close_floating_window()
            return {'FINISHED'}

        if _FLOATING_THREAD is not None and _FLOATING_THREAD.is_alive():
            self.report({'WARNING'}, "悬浮窗口正在关闭或启动，请稍候")
            return {'CANCELLED'}

        if not _native_windows_available():
            self.report({'WARNING'}, "Windows 原生置顶浮窗仅支持 Windows")
            return {'CANCELLED'}

        _FLOATING_OWNER_WINDOW_POINTER = _window_pointer(context.window)
        _FLOATING_OWNER_AREA_POINTER = _window_pointer(context.area)
        _reset_floating_commands()
        _SELECTION_HISTORY.clear()
        initial = _native_read_initial(context.scene)
        _FLOATING_CHECKBOXES["LOOP"] = bool(initial["LOOP"]["reversal"])
        _FLOATING_CHECKBOXES["RING"] = bool(initial["RING"]["reversal"])
        _FLOATING_NATIVE_READY.clear()
        _FLOATING_THREAD = threading.Thread(
            target=_native_window_thread,
            args=(initial,),
            name="SuperIntervalSelectWindow",
            daemon=True,
        )
        _FLOATING_THREAD.start()
        _schedule_floating_configuration()
        return {'FINISHED'}


class SUPERINTERVAL_PT_panel(bpy.types.Panel):
    bl_label = "超级间选"
    bl_idname = "SUPERINTERVAL_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "超级间选"

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def draw_header_preset(self, context):
        floating = _floating_window()
        button = self.layout.row(align=True)
        button.operator(
            "mesh.super_interval_float",
            text="",
            icon='PANEL_CLOSE' if floating is not None else 'WINDOW',
            emboss=False,
        )

    def _draw_module(self, layout, scene, mode):
        is_loop = mode == 'LOOP'
        prefix = "super_interval_loop" if is_loop else "super_interval_ring"
        expanded = getattr(scene, prefix + "_expanded")
        box = layout.box()
        header = box.row(align=True)
        header.prop(
            scene,
            prefix + "_expanded",
            text="",
            icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT',
            emboss=False,
        )
        header.label(
            text="循环边" if is_loop else "并排边",
            icon='EDGESEL' if is_loop else 'MESH_GRID',
        )
        if not expanded:
            return

        body = box.column(align=True)
        controls = body.column(align=True)
        row = controls.row(align=True)
        row.prop(scene, prefix + "_repeat", text="单元")
        row = controls.row(align=True)
        row.prop(scene, prefix + "_jump", text="跳跃")
        row = controls.row(align=True)
        row.prop(scene, prefix + "_reversal", text="交替反转")
        max_row = row.row(align=True)
        max_row.alert = getattr(scene, prefix + "_max_exceeded")
        max_row.prop(scene, prefix + "_max", text="Max：")

        actions = body.row(align=True)
        execute = actions.operator(
            "mesh.super_interval_select_main",
            text="选择边循环" if is_loop else "选择边环",
            icon='EDGESEL',
        )
        execute.mode = mode
        actions.operator("mesh.super_interval_undo", text="撤销", icon='LOOP_BACK')

    def _draw_quick_tools(self, layout, scene):
        expanded = scene.super_interval_quick_expanded
        box = layout.box()
        header = box.row(align=True)
        header.prop(
            scene,
            "super_interval_quick_expanded",
            text="",
            icon='TRIA_DOWN' if expanded else 'TRIA_RIGHT',
            emboss=False,
        )
        header.label(text="快速工具", icon='TOOL_SETTINGS')
        if not expanded:
            return

        # Two compact columns keep the panel usable at normal N-panel width.
        grid = box.grid_flow(row_major=True, columns=2, even_columns=True, even_rows=False)
        for label, suffix, mode, action, description in _QUICK_TOOLS:
            row = grid.row(align=True)
            row.scale_y = 1.05
            row.operator("mesh.super_interval_" + suffix, text=label, icon='EDGESEL')

    def draw(self, context):
        layout = self.layout
        self._draw_module(layout, context.scene, 'LOOP')
        self._draw_module(layout, context.scene, 'RING')
        self._draw_quick_tools(layout, context.scene)


classes = (
    SUPERINTERVAL_OT_select,
    SUPERINTERVAL_OT_select_main,
    SUPERINTERVAL_OT_undo,
    SUPERINTERVAL_OT_quick,
    *_QUICK_OPERATOR_CLASSES,
    SUPERINTERVAL_OT_float,
    SUPERINTERVAL_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    scene = bpy.types.Scene
    scene.super_interval_loop_repeat = bpy.props.IntProperty(
        name="循环边单元", description="单元：每个周期连续选择的拓扑层数；不同于重做面板的重复次数",
        default=10, min=1, max=100
    )
    scene.super_interval_loop_jump = bpy.props.IntProperty(
        name="循环边跳跃层数", description="每个周期跳过的拓扑层数；0 表示不跳过",
        default=0, min=0, max=100
    )
    scene.super_interval_loop_reversal = bpy.props.BoolProperty(
        name="循环边交替反转", description="每次点击交替选择单元段和跳跃段；跳跃为 0 时按单元宽度分组交替",
        default=False
    )
    scene.super_interval_loop_max = bpy.props.IntProperty(
        name="循环边 Max", description="Max：本次结果的边数上限；0 表示无上限（∞），正数表示数量上限",
        default=0, min=0, max=1000000
    )
    scene.super_interval_ring_repeat = bpy.props.IntProperty(
        name="并排边单元", description="单元：每个周期连续选择的拓扑层数；不同于重做面板的重复次数",
        default=10, min=1, max=100
    )
    scene.super_interval_ring_jump = bpy.props.IntProperty(
        name="并排边跳跃层数", description="每个周期跳过的拓扑层数；0 表示不跳过",
        default=0, min=0, max=100
    )
    scene.super_interval_ring_reversal = bpy.props.BoolProperty(
        name="并排边交替反转", description="每次点击交替选择单元段和跳跃段；跳跃为 0 时按单元宽度分组交替",
        default=False
    )
    scene.super_interval_ring_max = bpy.props.IntProperty(
        name="并排边 Max", description="Max：本次结果的边数上限；0 表示无上限（∞），正数表示数量上限",
        default=0, min=0, max=1000000
    )
    scene.super_interval_loop_expanded = bpy.props.BoolProperty(
        name="循环边", description="展开或收起循环边设置", default=True
    )
    scene.super_interval_ring_expanded = bpy.props.BoolProperty(
        name="并排边", description="展开或收起并排边设置", default=True
    )
    scene.super_interval_quick_expanded = bpy.props.BoolProperty(
        name="快速工具", description="展开或收起五个快速选择按钮", default=True
    )
    scene.super_interval_loop_max_exceeded = bpy.props.BoolProperty(
        name="循环边超出 Max", default=False, options={'HIDDEN'}
    )
    scene.super_interval_ring_max_exceeded = bpy.props.BoolProperty(
        name="并排边超出 Max", default=False, options={'HIDDEN'}
    )


def unregister():
    global _FLOATING_HWND, _FLOATING_THREAD
    global _FLOATING_TIMER_ACTIVE, _FLOATING_OWNER_WINDOW_POINTER
    global _FLOATING_OWNER_AREA_POINTER
    try:
        if bpy.app.timers.is_registered(_configure_floating_window):
            bpy.app.timers.unregister(_configure_floating_window)
    except (AttributeError, RuntimeError, TypeError):
        pass
    floating_thread = _FLOATING_THREAD
    _close_floating_window()
    if (
        floating_thread is not None
        and floating_thread.is_alive()
        and floating_thread is not threading.current_thread()
    ):
        floating_thread.join(timeout=0.5)
    if floating_thread is None or not floating_thread.is_alive():
        _FLOATING_HWND = None
        _FLOATING_THREAD = None
    _FLOATING_OWNER_WINDOW_POINTER = None
    _FLOATING_OWNER_AREA_POINTER = None
    _FLOATING_NATIVE_READY.clear()
    _FLOATING_TIMER_ACTIVE = False
    _SESSION.clear()
    _SELECTION_HISTORY.clear()
    for name in (
        "super_interval_loop_repeat",
        "super_interval_loop_jump",
        "super_interval_loop_reversal",
        "super_interval_loop_max",
        "super_interval_ring_repeat",
        "super_interval_ring_jump",
        "super_interval_ring_reversal",
        "super_interval_ring_max",
        "super_interval_loop_expanded",
        "super_interval_ring_expanded",
        "super_interval_quick_expanded",
        "super_interval_loop_max_exceeded",
        "super_interval_ring_max_exceeded",
    ):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
