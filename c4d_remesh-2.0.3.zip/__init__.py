
# 运算核心：bin/xremeshlib2.dll（源自 C4D 的 \resource\modules\c4d_objects\libs\win64\）
#
# ── 三个 DLL 版本说明（2026.2 版）──────────────────────────────────────
# xremeshlib2.dll  ZRemesher 重拓扑核心（Exoside QuadRemesher 同源）
#   · 内部导出名必须与文件名一致（改名为其它会触发模块名校验失败 → 空输出）
#   · PE 编译时间 2022-09-07，代码段 .text 经确认与旧版逐字节一致
#   · 2026.2 版带 2026-04-08 DigiCert 代码签名（旧版证书 2022-2023）
#   · 构建树：c:\dev\mxexternallibs\suitesparse-5.6.0（Maxon MXE）
#   · 授权：需 QRLib_start() 一次性初始化；运行中切勿调用 QRLib_end()
#     （QRLib_end 会销毁全局应用对象，导致后续 doQuadRemeshing 空输出）
#
# tbb.dll          Intel Threading Building Blocks 并行库
#   · PE 编译时间 2020-09-15，导出 243 个 tbb::* 符号
#   · 2026.2 版（236 KB）与旧版（445 KB）为不同构建，需与 xremeshlib 成套使用
#   · 提供多线程并行，但实测 ZRemesher 瓶颈为单线程串行阶段，线程数无加速收益
#
# ChSolver.dll     SuiteSparse CHOLMOD 稀疏 Cholesky 分解求解器
#   · CHOLMOD 6.5.0（PDB: CholMod-6.5.0.pdb），源码包 suitesparse-5.6.0
#   · PE 编译时间 2022-09-07（与 xremeshlib 同批构建）
#   · 导出 10 个 cholmod_* 函数（start/analyze/factorize/solve/finish）
#   · 重拓扑内部求解依赖；自身无独立配置项，由 xremeshlib2.dll 运行时调用
# ─────────────────────────────────────────────────────────────────────
# 建议：三个 DLL 必须成套替换，勿混用不同版本的 tbb/ChSolver。
#
# ── v2.0.3 队列式重构 ────────────────────────────────────────────────
# 计算编排已从 Modal 操作符迁至 factory.ZRemeshFactory（单例队列消费者）：
#   submit() -> OrderedDict 队列(物体名去重) -> bpy.app.timers 心跳
#              -> 后台线程跑 DLL -> 主线程写回
# 本文件仅保留 UI(面板/操作符/属性)与注册逻辑；操作符降级为入队入口。
#
# ── 多选批量(默认行为) ───────────────────────────────────────────────
# 操作符始终遍历所有选中网格逐体入队(队列按物体名自动去重), 曲线等
# 非网格物体自动过滤; 面板显示将要处理的数量。
#
# ── ZRemesher 修改器(非破坏) ────────────────────────────────────────
# zm_modifier.py 基于 0820 思路实现"几何节点修改器 + 隐藏缓存物体":
#   OBJECT_MT_modifier_add 添加 → 缓存物体(.ZM_REMESH_*_CACHE)持有结果
#   → 参数修改自动重算(防抖) / 手动刷新 / 实时更新开关(depsgraph)。
#   源网格保留, 可与其他修改器堆叠。

bl_info = {
    'name': 'ZRemesher',
    'description': '最好最快的重拓扑工具，移植自 Maxon-C4D 原生Zremesher',
    'author': 'FQ Maxon',
    'version': (2, 0, 3),
    'blender': (5, 0, 0),
    'location': '3DView->Panel',
}

import os
import bpy

from bpy.props import (IntProperty, BoolProperty, FloatProperty, EnumProperty, StringProperty, PointerProperty)

from .factory import ZRemesherFactory
from . import zm_modifier
from . import zm_history

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_BUNDLED_BIN = os.path.join(_ADDON_DIR, "bin")

_TARGET_MODE_ITEMS = [
    ('COUNT', '多边形数量', '参考指定面数量对网格面进行重拓扑\n请注意，这是一个[非绝对]的目标值，多边形数量会接近这个数值', 1),
    ('EDGE', '多边形长度', '参考指定边长度对网格面进行重拓扑\n注意，边长越短，网格越密，请确保参数不要超出网格尺寸', 2),
    ('PERCENT', '百分比面数', '参考输入网格面数量对网格面进行重拓扑\n100%的表示生成的多边形数量与原始对象几乎相同。数值越小，生成的多边形数量就越少', 3),
]

_HARDEDGE_TYPE_ITEMS = [
    ('AUTO', '角度', '自动识别角度转折', 1),
    ('SHARP', '锐边', '仅使用标记为锐边的边', 2),
    ('VGROUP', '顶点组', '仅使用指定顶点组标记的边', 3),
]

_GUIDE_TYPE_ITEMS = [
    ('CURVE', '曲线物体', '使用样条工具来定义边缘流动的方向', 1),
    ('SHARP_EDGES', '锐边', '使用锐边来定义边缘流动的方向', 2),
    ('SEAM_EDGES', '缝合边', '使用缝合边来定义边缘流动的方向', 3),
]


class ZMRemeshSettings(bpy.types.PropertyGroup):

    polygon_target_mode: EnumProperty(
        name="Polygon 目标模式", items=_TARGET_MODE_ITEMS, default='COUNT',
        description="目标模式:多边形数量 / 网格密度 / 输入面数百分比")
    polygon_count: IntProperty(
        name="多边形数量", default=5000, min=100, soft_max=50000,
        description="目标多边形数量(当模式为“多边形数量”时生效)")
    edge_length: FloatProperty(
        name="目标边长", default=0.1, min=0.001, max=100.0,
        description="目标边长(当模式为“网格密度”时生效)")
    target_percentage: FloatProperty(
        name="目标面数百分比", default=10.0, min=0.1, max=200.0,
        description="目标面数 = 输入面数的百分比(当模式为“输入面数百分比”时生效)")
    polygon_scale: FloatProperty(
        name="面数倍率", default=1.0, min=0.01, max=10.0,
        description="面数倍率——应用于目标数量的倍数")
    density_enable: BoolProperty(
        name="密度图", default=False,
        description="启用密度图控制。关闭后忽略密度图顶点组,\n按均匀密度重拓扑")
    density_map: StringProperty(
        name="密度图",
        description="顶点组,其权重将偏置 ZRemesher 原生的 "
                    "顶点颜色密度管线")
    density_scale: FloatProperty(
        name="密度缩放", default=1.0, min=0.0, soft_max=3.0,
        description="密度图局部集中的强度。\n0 = 关闭(忽略密度图)。1 = 默认(约 2.5×\n绘制区域的多边形)。2-3 = 更强。更高的值\n会增大输入曲率的感应幅度,\n驱动 ZRemesher 的自适应模式在绘制区域\n集中更多的多边形")
    adaptive: BoolProperty(
        name="自适应", default=True,
        description="启用自适应细分")
    adaptiveness: FloatProperty(
        name="自适应强度", default=0.5, min=0.0, max=1.0,
        description="自适应强度 (0=关闭, 1=最大)\n参数越大，网格的均匀性会相应降低，分配更多四边面给局部细节丰富区域\n\n在需提高细节丰富的区域的网格密度时建议设置为1\n在需要输出方形均匀拓扑时建议设置为0")
    hard_edge_enable: BoolProperty(
        name="启用硬边", default=True,
        description="是否开启硬边保护功能")
    hard_edge_type: EnumProperty(
        name="硬边类型", items=_HARDEDGE_TYPE_ITEMS, default='AUTO',
        description="硬边处理模式: 自动检测角度 或 使用手动标记的边")
    hard_edge_vgroup: StringProperty(
        name="硬边顶点组",
        description="顶点组中带权重的顶点用于标记硬边。\n两端点都在该组内(权重 > 0.5)的边\n将作为硬边输入给 ZRemesher")
    hard_edge_angle: FloatProperty(
        name="硬边角度阈值", default=30.0, min=0.0, max=180.0,
        description="自动硬边检测的角度阈值(当模式为“自动”时生效)")
    freeze_borders: BoolProperty(
        name="冻结边界", default=False,
        description="冻结输入边界:边界点保持不动。开启后大幅提速,\n并保持边界轮廓,但边界处的四边形会被固定")
    preprocess_weld: BoolProperty(
        name="预处理焊接", default=False,
        description="重拓扑前焊接输入网格的重复点,改善质量")
    denoise_strength: FloatProperty(
        name="降噪强度", default=0.0, min=0.0, max=1.0,
        description="输出网格的降噪平滑强度 (0=关闭, 1=最大)")
    symmetry_x: BoolProperty(name="对称 X", default=False, description="沿 X 轴对称")
    symmetry_y: BoolProperty(name="对称 Y", default=False, description="沿 Y 轴对称")
    symmetry_z: BoolProperty(name="对称 Z", default=False, description="沿 Z 轴对称")
    sym_direction: EnumProperty(
        name="保留方向",
        items=[('NEGATIVE', '负半空间 (-)', '保留 -X/-Y/-Z,镜像到 +', 0),
               ('POSITIVE', '正半空间 (+)', '保留 +X/+Y/+Z,镜像到 -', 1)],
        default='NEGATIVE',
        description="对称化沿各轴切开后保留哪一侧")

    guide_enable: BoolProperty(
        name="启用流线", default=False,
        description="是否使用曲线或指定网格边作为引导流线")
    guide_type: EnumProperty(
        name="流线来源", items=_GUIDE_TYPE_ITEMS, default='CURVE',
        description="流线数据来源: 曲线物体 / 锐边 / 缝合边")

    guide_splines: PointerProperty(
        name="流线图",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CURVE',
        description="引导曲线(从场景中选取;仅限曲线类型)\n曲线附近的输出四边形会被细分\n半径随模型尺寸自动缩放")

    progress:   FloatProperty(name="进度", default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    status:     StringProperty(name="状态", default="")


class ZMFactoryState(bpy.types.PropertyGroup):
    running: BoolProperty(name="运行中", default=False)
    progress: FloatProperty(name="进度", default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    status: StringProperty(name="状态", default="")
    queue_len: IntProperty(name="队列", default=0)


class MESH_OT_zremesh(bpy.types.Operator):
    bl_idname = "mesh.zremesh_remesh"
    bl_label = "ZRemesher"
    bl_description = "采用ZBrush的ZRemesher算法对网格进行重拓扑\n是在处理有机形状时，该算法能够自动识别边缘循环，并能够以相当高的质量展示这些形状"

    bl_options = {"INTERNAL"}

    polygon_target_mode:   EnumProperty(items=_TARGET_MODE_ITEMS, default='COUNT')
    polygon_count:         IntProperty(default=5000, min=100, soft_max=50000)
    edge_length:           FloatProperty(default=0.1, min=0.001, max=100.0)
    target_percentage:     FloatProperty(default=10.0, min=0.1, max=200.0)
    polygon_scale:         FloatProperty(default=1.0, min=0.01, max=10.0)
    density_enable:        BoolProperty(default=True)
    density_scale:         FloatProperty(default=1.0, min=0.0, soft_max=3.0)
    adaptive:              BoolProperty(default=True)
    adaptiveness:          FloatProperty(default=0.5, min=0.0, max=1.0)
    hard_edge_enable:      BoolProperty(default=False)
    hard_edge_type:        EnumProperty(items=_HARDEDGE_TYPE_ITEMS, default='AUTO')
    hard_edge_vgroup:      StringProperty(default='')
    hard_edge_angle:       FloatProperty(default=30.0, min=0.0, max=180.0)
    freeze_borders:        BoolProperty(default=False)
    preprocess_weld:       BoolProperty(default=False)
    denoise_strength:      FloatProperty(default=0.0, min=0.0, max=1.0)
    symmetry_x:            BoolProperty(default=False)
    symmetry_y:            BoolProperty(default=False)
    symmetry_z:            BoolProperty(default=False)
    sym_direction:         EnumProperty(
        items=[('NEGATIVE', '-', '', 0), ('POSITIVE', '+', '', 1)],
        default='NEGATIVE')
    guide_enable:          BoolProperty(default=False)
    guide_type:            EnumProperty(items=_GUIDE_TYPE_ITEMS, default='CURVE')
    use_scene_props:       BoolProperty(default=False, options={'HIDDEN'})

    _SETTINGS_KEYS = ('polygon_target_mode', 'polygon_count', 'edge_length',
                      'target_percentage', 'polygon_scale', 'density_enable',
                      'density_scale',
                      'adaptive', 'adaptiveness',
                      'hard_edge_enable', 'hard_edge_type', 'hard_edge_vgroup', 'hard_edge_angle',
                      'freeze_borders', 'preprocess_weld', 'denoise_strength',
                      'symmetry_x', 'symmetry_y', 'symmetry_z',
                      'sym_direction', 'guide_enable', 'guide_type')

    @classmethod
    def poll(cls, ctx):
        if ZRemesherFactory.instance().is_busy():
            return False
        return any(o.type == "MESH" for o in ctx.selected_objects)

    def _sync_settings_from_scene(self, ctx):
        if self.use_scene_props:
            p = ctx.scene.zremesh_props
            for k in self._SETTINGS_KEYS:
                setattr(self, k, getattr(p, k))
            self.use_scene_props = False

    def _build_params(self, ctx):
        p = ctx.scene.zremesh_props
        params = {}
        for k in self._SETTINGS_KEYS:
            params[k] = getattr(self, k)
        params['density_map'] = p.density_map
        params['guide_splines'] = p.guide_splines.name if p.guide_splines else ''
        return params

    def invoke(self, ctx, event):
        return self.execute(ctx)

    def execute(self, ctx):
        self._sync_settings_from_scene(ctx)

        if ctx.object and ctx.object.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        if not os.path.isfile(os.path.join(_BUNDLED_BIN, "xremeshlib2.dll")):
            self.report({"ERROR"}, f"动态库缺失:{_BUNDLED_BIN}")
            return {"CANCELLED"}

        targets = [o for o in ctx.selected_objects if o.type == 'MESH']
        if not targets:
            self.report({"ERROR"}, "请先选择网格物体")
            return {"CANCELLED"}

        params = self._build_params(ctx)
        fac = ZRemesherFactory.instance()
        n = 0
        for t in targets:
            mod = zm_modifier.find_modifier(t)
            if mod is not None and (mod.show_viewport or mod.show_render):
                mod.show_viewport = False
                mod.show_render = False
                self.report({"WARNING"}, f"已自动禁用 {t.name} 上的 ZRemesher 修改器")
            if fac.submit(t, params):
                n += 1
        self.report({"INFO"}, f"已加入队列:{n} 个物体")
        return {"FINISHED"}


class MESH_OT_zremesh_cancel(bpy.types.Operator):
    bl_idname = "mesh.zremesh_cancel"
    bl_label = "清空队列"
    bl_description = "清空等待中的任务;正在计算的任务无法中断,完成后将被丢弃"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, ctx):
        fac = ZRemesherFactory.instance()
        return fac.is_busy() or fac.queue_length() > 0

    def execute(self, ctx):
        ZRemesherFactory.instance().cancel_all()
        self.report({"INFO"}, "已清空队列")
        return {"FINISHED"}


class VIEW3D_PT_zremesh(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ZRemesher"
    bl_label = "ZRemesher重拓扑"

    def draw(self, ctx):
        layout = self.layout
        p = ctx.scene.zremesh_props
        fac = ZRemesherFactory.instance()
        split_factor = 0.25

        obj = ctx.active_object
        box = layout.box()
        if obj and obj.type == "MESH":
            row=box.row()
            row.label(text=f"当前物体:{obj.name}", icon="OBJECT_DATAMODE")
            sel_meshes = [o for o in ctx.selected_objects if o.type == 'MESH']
            row.label(text=f"将重拓扑 {len(sel_meshes)} 个选中网格", icon="MOD_REMESH")
            box.label(text=f"顶点:{len(obj.data.vertices)}  面:{len(obj.data.polygons)}")
        else:
            box.label(text="未选择网格物体", icon="INFO")

        box = layout.box()
        box.label(text="目标:", icon="MOD_REMESH")
        row = box.row(align=True)
        row.prop(p, "polygon_target_mode", expand=True)
        row = box.row(align=True)
        if p.polygon_target_mode == 'COUNT':
            row.prop(p, "polygon_count")
        elif p.polygon_target_mode == 'EDGE':
            row.prop(p, "edge_length")
        elif p.polygon_target_mode == 'PERCENT':
            row.prop(p, "target_percentage", slider=True)
        row.prop(p, "polygon_scale")

        box = layout.box()
        split = box.split(factor=split_factor)
        split.prop(p, "density_enable", text="密度图")
        row = split.row(align=True)
        row.enabled = p.density_enable
        if obj and obj.type == "MESH":
            row.prop_search(p, "density_map", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
        else:
            row.enabled = False
            row.prop(p, "density_map", text="")
        row.prop(p, "density_scale", slider=True)

        split = box.split(factor=split_factor)
        split.prop(p, "adaptive", text="自适应")
        row = split.row(align=True)
        row.enabled = p.adaptive
        row.prop(p, "adaptiveness")

        split = box.split(factor=split_factor)
        split.prop(p, "hard_edge_enable", text="硬边保护")
        row = split.row(align=True)
        row.enabled = p.hard_edge_enable
        row.prop(p, "hard_edge_type", text="")
        if p.hard_edge_type == 'AUTO':
            row.prop(p, "hard_edge_angle", slider=True)
        elif p.hard_edge_type == 'SHARP':
            row.label(text="使用标记的锐边", icon='EDGESEL')
        elif p.hard_edge_type == 'VGROUP':
            if obj and obj.type == 'MESH':
                row.prop_search(p, "hard_edge_vgroup", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
            else:
                row.prop(p, "hard_edge_vgroup", text="")

        split = box.split(factor=split_factor)
        split.prop(p, "guide_enable", text="流线引导")
        row = split.row(align=True)
        row.enabled = p.guide_enable
        row.prop(p, "guide_type", text="")

        if p.guide_type == 'CURVE':
            row.prop(p, "guide_splines", text="")
        elif p.guide_type == 'SHARP_EDGES':
            row.label(text="锐边作为流线", icon="EDGESEL")
        elif p.guide_type == 'SEAM_EDGES':
            row.label(text="UV缝合边作为流线", icon="UV")

        box = layout.box()
        split = box.split(factor=split_factor)
        split.label(text="优化", icon="SHADING_RENDERED")
        row = split.row()
        row.prop(p, "freeze_borders", text="锁定边界", toggle=True)
        row.prop(p, "preprocess_weld", text="预焊接", toggle=True)
        row.prop(p, "denoise_strength", text="", slider=True)
        split = box.split(factor=split_factor)
        split.label(text="对称", icon="MOD_MIRROR")
        row = split.row(align=True)
        row.prop(p, "symmetry_x", icon="EVENT_X", text="", toggle=True)
        row.prop(p, "symmetry_y", icon="EVENT_Y", text="", toggle=True)
        row.prop(p, "symmetry_z", icon="EVENT_Z", text="", toggle=True)
        row.separator()
        sub = row.row()
        sub.enabled = p.symmetry_x or p.symmetry_y or p.symmetry_z
        sub.prop(p, "sym_direction", expand=True)

        layout.separator()

        box = layout.box()
        col = box.column(align=True)
        col.scale_y = 1.5
        if fac.is_busy():
            col.enabled = False
            col.operator(MESH_OT_zremesh.bl_idname, text="运行中…", icon="TIME")
        else:
            op = col.operator(MESH_OT_zremesh.bl_idname, text="执行重拓扑", icon="MOD_REMESH")
            op.use_scene_props = True

        fs = ctx.window_manager.zremesh_factory
        split = box.split(factor=split_factor)
        split.label(text="进度", icon="INFO")
        row = split.row(align=True)
        row.enabled = False
        row.prop(fs, "progress", text="", slider=True)
        if fs.status:
            box.label(text=fs.status)
        if fs.running:
            box.label(text=f"队列:{fs.queue_len}", icon="FILE_TICK")
            box.operator(MESH_OT_zremesh_cancel.bl_idname, text="清空队列", icon="CANCEL")

        if obj and obj.type == "MESH":
            zm_history.draw_history(box, obj)


def _load_post(dummy):
    ZRemesherFactory.instance().cancel_all()
    ZRemesherFactory.instance()._stop()


_REGISTER_CLASSES = (ZMRemeshSettings, ZMFactoryState,
                     MESH_OT_zremesh, MESH_OT_zremesh_cancel,
                     VIEW3D_PT_zremesh)


def register():
    for c in _REGISTER_CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.zremesh_props = PointerProperty(type=ZMRemeshSettings)
    bpy.types.WindowManager.zremesh_factory = PointerProperty(type=ZMFactoryState)
    if _load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_load_post)
    zm_modifier.register()
    zm_history.register()


def unregister():
    zm_history.unregister()
    zm_modifier.unregister()
    if _load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post)
    ZRemesherFactory.instance().shutdown()
    try:
        del bpy.types.WindowManager.zremesh_factory
    except Exception:
        pass
    try:
        del bpy.types.Scene.zremesh_props
    except Exception:
        pass
    for c in reversed(_REGISTER_CLASSES):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
