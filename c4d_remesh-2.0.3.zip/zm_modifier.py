# -*- coding: utf-8 -*-
# ZRemesher 修改器: 基于 0820 思路的"几何节点修改器 + 隐藏缓存物体"实现
#
# 原理:
#   在源物体上加一个 NODES 修改器, 节点组内用 Object Info 指向一个
#   不链入场景的隐藏缓存物体(.ZM_REMESH_<obj>_CACHE)。计算时:
#     1. 临时关闭插件修改器及其下游 → evaluated_depsgraph 提取"上游网格"
#     2. DLL 重拓扑(队列工厂后台线程, 本地坐标)
#     3. 主线程把结果写回缓存物体 mesh → 修改器即显示结果
#   非破坏: 源网格保留, 可与其他修改器堆叠/应用。
#
# 触发: 属性 update(防抖) / 手动刷新 / 实时更新开关(depsgraph, 实验性)

import time

import bpy
import numpy as np

from . import factory as fac_mod

_CACHE_PREFIX = ".ZM_REMESH_"
_CACHE_SUFFIX = "_CACHE"

_tracked = set()
_dirty = set()
_timer_handle = None
_last_trigger = {}

_TARGET_MODE_ITEMS = [
    ('COUNT', '多边形数量', '参考指定面数量重拓扑', 1),
    ('EDGE', '多边形长度', '参考指定边长度重拓扑', 2),
    ('PERCENT', '百分比面数', '参考输入面数百分比重拓扑', 3),
]
_HARDEDGE_TYPE_ITEMS = [
    ('AUTO', '角度', '自动识别角度转折', 1),
    ('SHARP', '锐边', '仅使用标记为锐边的边', 2),
    ('VGROUP', '顶点组', '仅使用指定顶点组标记的边', 3),
]
_GUIDE_TYPE_ITEMS = [
    ('CURVE', '曲线物体', '使用样条定义边缘流动方向', 1),
    ('SHARP_EDGES', '锐边', '使用锐边定义边缘流动方向', 2),
    ('SEAM_EDGES', '缝合边', '使用缝合边定义边缘流动方向', 3),
]


def _cache_name(obj):
    return f"{_CACHE_PREFIX}{obj.name}{_CACHE_SUFFIX}"


def _is_cache_name(name):
    return name.startswith(_CACHE_PREFIX) and name.endswith(_CACHE_SUFFIX)


def find_modifier(obj):
    """在修改器栈中寻找本插件的 NODES 修改器。"""
    if not obj or not hasattr(obj, "modifiers"):
        return None
    for m in obj.modifiers:
        if m.type == 'NODES' and m.node_group:
            if _is_cache_name(m.node_group.name):
                return m
    return None


def setup(obj):
    """创建/校验 缓存物体 + 节点组 + NODES 修改器。返回 (cache_obj, mod)。"""
    if not obj or obj.type != 'MESH':
        return None, None
    cname = _cache_name(obj)

    cache_obj = bpy.data.objects.get(cname)
    if cache_obj is None:
        mesh = bpy.data.meshes.new(cname)
        cache_obj = bpy.data.objects.new(cname, mesh)
    cache_obj.hide_viewport = True
    cache_obj.hide_render = True

    nt = bpy.data.node_groups.get(cname)
    if nt is None:
        nt = bpy.data.node_groups.new(cname, 'GeometryNodeTree')
    if hasattr(nt, "interface"):
        if not nt.interface.items_tree:
            nt.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')

    node_info = next((n for n in nt.nodes if n.type == 'OBJECT_INFO'), None)
    if not node_info:
        node_info = nt.nodes.new('GeometryNodeObjectInfo')
        node_info.location = (-200, 0)
    node_out = next((n for n in nt.nodes if n.type == 'GROUP_OUTPUT'), None)
    if not node_out:
        node_out = nt.nodes.new('NodeGroupOutput')
        node_out.location = (200, 0)
    if node_info.inputs[0].default_value != cache_obj:
        node_info.inputs[0].default_value = cache_obj
    if not any(l for l in nt.links if l.to_node == node_out):
        nt.links.new(node_info.outputs['Geometry'], node_out.inputs[0])

    mod = find_modifier(obj)
    if mod:
        if mod.node_group != nt:
            mod.node_group = nt
    else:
        mod = obj.modifiers.new(name="ZRemesher", type='NODES')
        mod.node_group = nt
    mod.show_manage_panel = False
    mod.show_group_selector = False

    _tracked.add(obj.name)
    return cache_obj, mod


def teardown(obj):
    """移除修改器及其缓存物体/节点组。"""
    mod = find_modifier(obj)
    if mod:
        obj.modifiers.remove(mod)
    cname = _cache_name(obj)
    if cname in bpy.data.objects:
        bpy.data.objects.remove(bpy.data.objects[cname], do_unlink=True)
    if cname in bpy.data.node_groups:
        bpy.data.node_groups.remove(bpy.data.node_groups[cname])
    _tracked.discard(obj.name)


def _extract_local(obj, ctx):
    """提取上游网格(本地坐标 + 三角形), 需已禁用插件修改器及下游。"""
    depsgraph = ctx.evaluated_depsgraph_get()
    eo = obj.evaluated_get(depsgraph)
    tmp = eo.to_mesh()
    try:
        n_v = len(tmp.vertices)
        co = np.empty(n_v * 3, dtype=np.float32)
        tmp.vertices.foreach_get("co", co)
        tmp.calc_loop_triangles()
        n_t = len(tmp.loop_triangles)
        tris = np.empty(n_t * 3, dtype=np.int32)
        tmp.loop_triangles.foreach_get("vertices", tris)
        tris = tris.reshape(-1, 3)
    finally:
        eo.to_mesh_clear()
    return co.reshape(-1, 3), tris


def _mod_prepare(task):
    p = task.params
    obj = bpy.data.objects.get(task.object_name)
    cache_obj = task.cache_obj
    if obj is None or obj.type != 'MESH' or cache_obj is None:
        task.status = f'跳过: 找不到 {task.object_name}'
        return None
    ctx = bpy.context

    mod = find_modifier(obj)
    states = [m.show_viewport for m in obj.modifiers]
    idx = obj.modifiers.find(mod.name) if mod else len(states)
    for i in range(idx, len(states)):
        obj.modifiers[i].show_viewport = False
    try:
        try:
            depsgraph = ctx.evaluated_depsgraph_get()
            depsgraph.update()
        except Exception:
            pass
        input_data = _extract_local(obj, ctx)
    finally:
        for i, s in enumerate(states):
            obj.modifiers[i].show_viewport = s

    cfg = fac_mod._build_dll_config(p)

    vertex_weights = None
    vg_name = (p.get('density_map') or '').strip()
    if p.get('density_enable') and vg_name and vg_name in obj.vertex_groups:
        ws = fac_mod._read_vertex_group_weights(obj, vg_name)
        if ws is not None and any(w > 0 for w in ws):
            vertex_weights = ws

    input_hard_edges = None
    source_midpoints = []
    if p.get('hard_edge_enable'):
        pairs, midpoints = fac_mod._collect_hard_edges(obj, p)
        if pairs:
            input_hard_edges = pairs
            source_midpoints = midpoints

    guide_curves = None
    if p.get('guide_enable'):
        guide_curves = fac_mod._collect_guide_curves(ctx, obj, p)

    return {
        'obj': obj,
        'cache_obj': cache_obj,
        'cfg': cfg,
        'input_data': input_data,
        'vertex_weights': vertex_weights,
        'input_hard_edges': input_hard_edges,
        'source_midpoints': source_midpoints,
        'guide_curves': guide_curves,
    }


def _mod_writeback(task):
    """主线程: 把 DLL 结果写回缓存物体 mesh。"""
    prep = task.prep
    cache_obj = prep['cache_obj']
    job = task.job
    verts = job.verts
    faces = job.faces
    if not verts or not faces:
        return
    me = cache_obj.data

    me.clear_geometry()
    n_v = len(verts)
    n_f = len(faces)
    total_l = 0
    for f in faces:
        total_l += len(f)
    me.vertices.add(n_v)
    me.loops.add(total_l)
    me.polygons.add(n_f)

    co_flat = np.ascontiguousarray(verts, dtype=np.float32).ravel()
    me.vertices.foreach_set("co", co_flat)

    lv = np.empty(total_l, dtype=np.int32)
    ls = np.empty(n_f, dtype=np.int32)
    lt = np.empty(n_f, dtype=np.int32)
    base = 0
    for i, f in enumerate(faces):
        c = len(f)
        lv[base:base + c] = f
        ls[i] = base
        lt[i] = c
        base += c
    me.loops.foreach_set("vertex_index", lv)
    me.polygons.foreach_set("loop_start", ls)
    me.polygons.foreach_set("loop_total", lt)
    me.update()
    me.validate(verbose=False)

    p = task.params
    hard_edges = job.hard_edges or []
    if hard_edges and p.get('hard_edge_enable'):
        key_set = set((a, b) if a < b else (b, a) for a, b in hard_edges)
        for e in me.edges:
            v0, v1 = e.vertices[0], e.vertices[1]
            key = (v0, v1) if v0 < v1 else (v1, v0)
            if key in key_set:
                e.use_edge_sharp = True

    _last_trigger[task.object_name] = time.time()
    try:
        g = getattr(bpy.data.objects.get(task.object_name), 'zremesh_mod', None)
        if g is not None:
            g.progress = 100.0
            g.status = f'完成:{n_v}v {n_f}f'
    except Exception:
        pass


def _mod_params_dict(g):
    return {
        'polygon_target_mode': g.polygon_target_mode,
        'polygon_count': g.polygon_count,
        'edge_length': g.edge_length,
        'target_percentage': g.target_percentage,
        'polygon_scale': g.polygon_scale,
        'density_enable': g.density_enable,
        'density_scale': g.density_scale,
        'density_map': g.density_map,
        'adaptive': g.adaptive,
        'adaptiveness': g.adaptiveness,
        'hard_edge_enable': g.hard_edge_enable,
        'hard_edge_type': g.hard_edge_type,
        'hard_edge_vgroup': g.hard_edge_vgroup,
        'hard_edge_angle': g.hard_edge_angle,
        'freeze_borders': g.freeze_borders,
        'preprocess_weld': g.preprocess_weld,
        'denoise_strength': g.denoise_strength,
        'symmetry_x': g.symmetry_x,
        'symmetry_y': g.symmetry_y,
        'symmetry_z': g.symmetry_z,
        'sym_direction': g.sym_direction,
        'guide_enable': g.guide_enable,
        'guide_type': g.guide_type,
        'guide_splines': g.guide_splines.name if g.guide_splines else '',
    }


def request_refresh(obj):
    """提交一次刷新任务(防抖: 同物体最新参数覆盖队列)。"""
    if not obj or obj.type != 'MESH':
        return
    cache_obj, mod = setup(obj)
    if cache_obj is None:
        return
    g = getattr(obj, 'zremesh_mod', None)
    if g is None:
        return
    g.status = '排队…'
    g.progress = 0.0
    task = fac_mod.RemeshTask(object_name=obj.name, params=_mod_params_dict(g))
    task.prepare_fn = _mod_prepare
    task.writeback_fn = _mod_writeback
    task.cache_obj = cache_obj
    fac_mod.ZRemesherFactory.instance().submit_task(task)


def _mod_param_update(self, context):
    obj = self.id_data
    if isinstance(obj, bpy.types.Object) and find_modifier(obj):
        request_refresh(obj)


class ZMRemeshModSettings(bpy.types.PropertyGroup):
    polygon_target_mode: bpy.props.EnumProperty(
        name="目标模式", items=_TARGET_MODE_ITEMS, default='COUNT', update=_mod_param_update)
    polygon_count: bpy.props.IntProperty(
        name="多边形数量", default=5000, min=100, soft_max=50000, update=_mod_param_update)
    edge_length: bpy.props.FloatProperty(
        name="目标边长", default=0.1, min=0.01, max=100.0, update=_mod_param_update)
    target_percentage: bpy.props.FloatProperty(
        name="面数百分比", default=10.0, min=0.1, max=200.0, update=_mod_param_update)
    polygon_scale: bpy.props.FloatProperty(
        name="面数倍率", default=1.0, min=0.01, max=10.0, update=_mod_param_update)
    density_enable: bpy.props.BoolProperty(
        name="密度图", default=False, update=_mod_param_update)
    density_map: bpy.props.StringProperty(
        name="密度图顶点组", description="顶点组权重驱动局部密度", update=_mod_param_update)
    density_scale: bpy.props.FloatProperty(
        name="密度缩放", default=1.0, min=0.0, soft_max=3.0, update=_mod_param_update)
    adaptive: bpy.props.BoolProperty(
        name="自适应", default=True, update=_mod_param_update)
    adaptiveness: bpy.props.FloatProperty(
        name="自适应强度", default=0.5, min=0.0, max=1.0, update=_mod_param_update)
    hard_edge_enable: bpy.props.BoolProperty(
        name="硬边保护", default=True, update=_mod_param_update)
    hard_edge_type: bpy.props.EnumProperty(
        name="硬边类型", items=_HARDEDGE_TYPE_ITEMS, default='AUTO', update=_mod_param_update)
    hard_edge_vgroup: bpy.props.StringProperty(
        name="硬边顶点组", update=_mod_param_update)
    hard_edge_angle: bpy.props.FloatProperty(
        name="硬边角度", default=30.0, min=0.0, max=180.0, update=_mod_param_update)
    freeze_borders: bpy.props.BoolProperty(
        name="冻结边界", default=False, update=_mod_param_update)
    preprocess_weld: bpy.props.BoolProperty(
        name="预处理焊接", default=False, update=_mod_param_update)
    denoise_strength: bpy.props.FloatProperty(
        name="降噪强度", default=0.0, min=0.0, max=1.0, update=_mod_param_update)
    symmetry_x: bpy.props.BoolProperty(name="对称 X", default=False, update=_mod_param_update)
    symmetry_y: bpy.props.BoolProperty(name="对称 Y", default=False, update=_mod_param_update)
    symmetry_z: bpy.props.BoolProperty(name="对称 Z", default=False, update=_mod_param_update)
    sym_direction: bpy.props.EnumProperty(
        name="保留方向",
        items=[('NEGATIVE', '负半空间 (-)', '', 0), ('POSITIVE', '正半空间 (+)', '', 1)],
        default='NEGATIVE', update=_mod_param_update)
    guide_enable: bpy.props.BoolProperty(
        name="启用流线", default=False, update=_mod_param_update)
    guide_type: bpy.props.EnumProperty(
        name="流线来源", items=_GUIDE_TYPE_ITEMS, default='CURVE', update=_mod_param_update)
    guide_splines: bpy.props.PointerProperty(
        name="流线图", type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CURVE', update=_mod_param_update)
    auto_refresh: bpy.props.BoolProperty(
        name="实时更新", default=False,
        description="上游修改器/网格变化时自动重新计算(实验性)")
    progress: bpy.props.FloatProperty(name="进度", default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    status: bpy.props.StringProperty(name="状态", default="")


class MESH_OT_zremesh_add_modifier(bpy.types.Operator):
    bl_idname = "mesh.zremesh_add_modifier"
    bl_label = "ZRemesher 重拓扑"
    bl_description = "以非破坏修改器方式添加 ZRemesher 重拓扑"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        return ctx.object and ctx.object.type == 'MESH' and find_modifier(ctx.object) is None

    def execute(self, ctx):
        obj = ctx.object
        if not obj or obj.type != 'MESH':
            self.report({"ERROR"}, "请选择网格物体")
            return {"CANCELLED"}
        if find_modifier(obj) is not None:
            self.report({"INFO"}, "该物体已有 ZRemesher 修改器")
            return {"CANCELLED"}
        setup(obj)
        request_refresh(obj)
        try:
            bpy.ops.ed.undo_push(message="Add ZRemesher Modifier")
        except Exception:
            pass
        return {"FINISHED"}


class MESH_OT_zremesh_modifier_refresh(bpy.types.Operator):
    bl_idname = "mesh.zremesh_modifier_refresh"
    bl_label = "刷新重拓扑"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, ctx):
        return ctx.object and ctx.object.type == 'MESH' and find_modifier(ctx.object) is not None

    def execute(self, ctx):
        obj = ctx.object
        if obj is None:
            return {"CANCELLED"}
        request_refresh(obj)
        self.report({"INFO"}, f"已提交刷新:{obj.name}")
        return {"FINISHED"}


class MESH_OT_zremesh_modifier_remove(bpy.types.Operator):
    bl_idname = "mesh.zremesh_modifier_remove"
    bl_label = "移除 ZRemesher 修改器"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        return ctx.object and find_modifier(ctx.object) is not None

    def execute(self, ctx):
        obj = ctx.object
        teardown(obj)
        try:
            bpy.ops.ed.undo_push(message="Remove ZRemesher Modifier")
        except Exception:
            pass
        return {"FINISHED"}


class MODIFIER_PT_zremesh(bpy.types.Panel):
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "modifier"
    bl_label = "ZRemesher 重拓扑"

    @classmethod
    def poll(cls, ctx):
        obj = ctx.object
        if not obj or obj.type != 'MESH':
            return False
        return find_modifier(obj) is not None

    def draw(self, ctx):
        layout = self.layout
        obj = ctx.object
        g = obj.zremesh_mod

        box = layout.box()
        row = box.row()
        row.prop(g, "polygon_target_mode", expand=True)
        
        row = box.row(align=True)
        if g.polygon_target_mode == 'COUNT':
            row.prop(g, "polygon_count")
        elif g.polygon_target_mode == 'EDGE':
            row.prop(g, "edge_length")
        else:
            row.prop(g, "target_percentage", slider=True)
        row.prop(g, "polygon_scale")

        box = layout.box()
        split = box.split(factor=0.3)
        split.prop(g, "density_enable", text="密度图")
        row = split.row(align=True)
        row.enabled = g.density_enable
        row.prop_search(g, "density_map", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
        row.prop(g, "density_scale", slider=True)

        split = box.split(factor=0.3)
        split.prop(g, "adaptive", text="自适应")
        row = split.row(align=True)
        row.enabled = g.adaptive
        row.prop(g, "adaptiveness")

        split = box.split(factor=0.3)
        split.prop(g, "hard_edge_enable", text="硬边保护")
        row = split.row(align=True)
        row.enabled = g.hard_edge_enable
        row.prop(g, "hard_edge_type", text="")
        if g.hard_edge_type == 'AUTO':
            row.prop(g, "hard_edge_angle", slider=True)
        elif g.hard_edge_type == 'SHARP':
            row.label(text="使用标记的锐边", icon='EDGESEL')
        else:
            row.prop_search(g, "hard_edge_vgroup", obj, "vertex_groups", text="", icon='GROUP_VERTEX')

        split = box.split(factor=0.3)
        split.prop(g, "guide_enable", text="流线引导")
        row = split.row(align=True)
        row.enabled = g.guide_enable
        row.prop(g, "guide_type", text="")
        if g.guide_type == 'CURVE':
            row.prop(g, "guide_splines", text="")
        elif g.guide_type == 'SHARP_EDGES':
            row.label(text="锐边作为流线", icon="EDGESEL")
        else:
            row.label(text="UV缝合边作为流线", icon="UV")

        box = layout.box()
        split = box.split(factor=0.3)
        split.label(text="优化", icon="SHADING_RENDERED")
        row = split.row()
        row.prop(g, "freeze_borders", text="锁定边界", toggle=True)
        row.prop(g, "preprocess_weld", text="预焊接", toggle=True)
        row.prop(g, "denoise_strength", text="", slider=True)
        split = box.split(factor=0.3)
        split.label(text="对称", icon="MOD_MIRROR")
        row = split.row(align=True)
        row.prop(g, "symmetry_x", icon="EVENT_X", text="", toggle=True)
        row.prop(g, "symmetry_y", icon="EVENT_Y", text="", toggle=True)
        row.prop(g, "symmetry_z", icon="EVENT_Z", text="", toggle=True)
        row.separator()
        sub = row.row()
        sub.enabled = g.symmetry_x or g.symmetry_y or g.symmetry_z
        sub.prop(g, "sym_direction", expand=True)

        layout.separator()
        box = layout.box()
        box.prop(g, "auto_refresh")
        row = box.row(align=True)
        row.scale_y = 1.4
        row.operator(MESH_OT_zremesh_modifier_refresh.bl_idname, text="刷新重拓扑", icon="MOD_REMESH")
        row.operator(MESH_OT_zremesh_modifier_remove.bl_idname, text="", icon="X")
        split = box.split(factor=0.3)
        split.label(text="进度", icon="INFO")
        r = split.row(align=True)
        r.enabled = False
        r.prop(g, "progress", text="", slider=True)
        if g.status:
            box.label(text=g.status)


def object_mt_modifier_custom_draw(self, context):
    obj = context.object
    if obj and obj.type == 'MESH' and find_modifier(obj) is None:
        self.layout.operator(MESH_OT_zremesh_add_modifier.bl_idname, icon='MOD_REMESH')


def _ensure_debounce():
    global _timer_handle
    if _timer_handle is None:
        _timer_handle = bpy.app.timers.register(_debounce_flush, first_interval=0.3)


def _debounce_flush():
    global _timer_handle
    _timer_handle = None
    dirty = list(_dirty)
    _dirty.clear()
    for name in dirty:
        obj = bpy.data.objects.get(name)
        if obj is None or obj.type != 'MESH':
            continue
        if not find_modifier(obj):
            _tracked.discard(name)
            continue
        g = getattr(obj, 'zremesh_mod', None)
        if g is None or not g.auto_refresh:
            continue
        _last_trigger[name] = time.time()
        request_refresh(obj)
    return None


@bpy.app.handlers.persistent
def _depsgraph_update_post(depsgraph):
    if not _tracked:
        return
    now = time.time()
    any_dirty = False
    for name in list(_tracked):
        obj = bpy.data.objects.get(name)
        if obj is None or obj.type != 'MESH':
            _tracked.discard(name)
            continue
        if not find_modifier(obj):
            _tracked.discard(name)
            continue
        g = getattr(obj, 'zremesh_mod', None)
        if g is None or not g.auto_refresh:
            continue
        if now - _last_trigger.get(name, 0.0) < 0.5:
            continue
        _dirty.add(name)
        any_dirty = True
    if any_dirty:
        _ensure_debounce()


@bpy.app.handlers.persistent
def _load_post(dummy):
    _tracked.clear()
    _dirty.clear()
    _last_trigger.clear()


def register():
    for c in (ZMRemeshModSettings, MESH_OT_zremesh_add_modifier,
              MESH_OT_zremesh_modifier_refresh, MESH_OT_zremesh_modifier_remove,
              MODIFIER_PT_zremesh):
        bpy.utils.register_class(c)
    bpy.types.Object.zremesh_mod = bpy.props.PointerProperty(type=ZMRemeshModSettings)
    bpy.types.OBJECT_MT_modifier_add.append(object_mt_modifier_custom_draw)
    bpy.app.handlers.depsgraph_update_post.append(_depsgraph_update_post)
    bpy.app.handlers.load_post.append(_load_post)


def unregister():
    global _timer_handle
    if _timer_handle is not None:
        try:
            bpy.app.timers.unregister(_timer_handle)
        except Exception:
            pass
        _timer_handle = None
    if _depsgraph_update_post in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_update_post)
    if _load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post)
    try:
        bpy.types.OBJECT_MT_modifier_add.remove(object_mt_modifier_custom_draw)
    except Exception:
        pass
    for c in reversed((ZMRemeshModSettings, MESH_OT_zremesh_add_modifier,
                       MESH_OT_zremesh_modifier_refresh, MESH_OT_zremesh_modifier_remove,
                       MODIFIER_PT_zremesh)):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
    try:
        del bpy.types.Object.zremesh_mod
    except Exception:
        pass
    _tracked.clear()
    _dirty.clear()
    _last_trigger.clear()
