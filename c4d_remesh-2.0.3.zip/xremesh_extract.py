
import ctypes, os, time, struct, json, pickle, hashlib
import ctypes.wintypes as w
import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_EMBEDDED_BIN = os.path.join(_HERE, 'bin')

if os.path.isfile(os.path.join(_EMBEDDED_BIN, 'xremeshlib2.dll')):
    LIB_DIR = _EMBEDDED_BIN
else:
    raise RuntimeError('xremeshlib2.dll not found in ./bin/')

def _load_dlls():
    os.add_dll_directory(LIB_DIR)
    ctypes.CDLL(os.path.join(LIB_DIR, 'tbb.dll'))
    ctypes.CDLL(os.path.join(LIB_DIR, 'ChSolver.dll'))
    return ctypes.CDLL(os.path.join(LIB_DIR, 'xremeshlib2.dll'))

def _bind(qr):
    qr.QRLib_start.argtypes = [ctypes.c_char_p]
    qr.QRLib_setProgressCallback.argtypes = [ctypes.c_void_p]
    qr.QRLib_setOutputCallback.argtypes = [ctypes.c_void_p]
    qr.QRLib_startInputMesh.argtypes = [ctypes.c_void_p]
    qr.QRLib_endInputMesh.argtypes = [ctypes.c_void_p]
    qr.QRLib_setPoints_AllocMem.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_int, ctypes.c_void_p]

    qr.QRLib_setPointColors_AllocMem.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_int, ctypes.c_void_p]
    qr.QRLib_setPointColors_AllocMem.restype  = None
    qr.QRLib_setPointColors.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p]
    qr.QRLib_setPointColors.restype  = ctypes.c_bool
    qr.QRLib_setTriangles_AllocMem.argtypes = [ctypes.POINTER(ctypes.c_void_p), ctypes.c_int, ctypes.c_void_p]
    qr.QRLib_setInputMesh.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    qr.QRLib_setRemeshSettings.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    qr.QRLib_setRemeshSettings.restype = ctypes.c_bool
    qr.QRLib_setHashCode.argtypes = [ctypes.c_int, ctypes.c_void_p]
    qr.QRLib_startOneRemeshing.argtypes = [ctypes.c_void_p]
    qr.QRLib_startOneRemeshing.restype = ctypes.c_void_p
    qr.QRLib_doQuadRemeshing.argtypes = [ctypes.c_void_p]
    qr.QRLib_doQuadRemeshing.restype = ctypes.c_int

    qr.QRLib_getPoints.argtypes = [ctypes.POINTER(ctypes.c_void_p),
                                    ctypes.POINTER(ctypes.c_int), ctypes.c_void_p]
    qr.QRLib_addCurve.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    qr.QRLib_addCurve.restype  = ctypes.c_bool

    qr.QRLib_getFaces.argtypes  = [ctypes.POINTER(ctypes.c_void_p),
                                    ctypes.POINTER(ctypes.c_int),
                                    ctypes.POINTER(ctypes.c_void_p),
                                    ctypes.POINTER(ctypes.c_int),
                                    ctypes.c_void_p]
    qr.QRLib_getHardEdges.argtypes = [ctypes.POINTER(ctypes.c_void_p),
                                       ctypes.POINTER(ctypes.c_int),
                                       ctypes.c_void_p]
    qr.QRLib_setHardEdges.argtypes = [ctypes.c_void_p, ctypes.c_int,
                                       ctypes.c_void_p]
    qr.QRLib_setHardEdges.restype  = ctypes.c_bool

    qr.QRLib_setInputOption_int.argtypes   = [ctypes.c_char_p, ctypes.c_int, ctypes.c_void_p]
    qr.QRLib_setInputOption_int.restype    = ctypes.c_bool
    qr.QRLib_setInputOption_float.argtypes = [ctypes.c_char_p, ctypes.c_float, ctypes.c_void_p]
    qr.QRLib_setInputOption_float.restype  = ctypes.c_bool
    qr.QRLib_setInputOption_cstr.argtypes  = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_void_p]
    qr.QRLib_setInputOption_cstr.restype   = ctypes.c_bool

def _apply_patches(qr_base):

    k32 = ctypes.WinDLL('kernel32', use_last_error=True)
    k32.VirtualProtect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, w.DWORD, ctypes.POINTER(w.DWORD)]
    k32.FlushInstructionCache.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t]
    def patch(va, data):
        old = w.DWORD()
        k32.VirtualProtect(ctypes.c_void_p(va), len(data), 0x40, ctypes.byref(old))
        for i, b in enumerate(data):
            ctypes.c_ubyte.from_address(va + i).value = b
        k32.FlushInstructionCache(ctypes.c_void_p(-1), ctypes.c_void_p(va), len(data))
    patch(qr_base + 0x1508fe, b'\x90\x90')
    patch(qr_base + 0x150907, b'\x90\x90')
    patch(qr_base + 0x14816e, b'\x90' * 6)
    return k32, patch

def _load_obj(path):
    verts, tris = [], []
    with open(path, encoding='utf-8', errors='replace') as f:
        for line in f:
            p = line.split()
            if not p: continue
            if p[0] == 'v':
                verts.append((float(p[1]), float(p[2]), float(p[3])))
            elif p[0] == 'f':
                idx = [int(s.split('/')[0]) - 1 for s in p[1:]]
                for i in range(1, len(idx) - 1):
                    tris.append((idx[0], idx[i], idx[i + 1]))
    return verts, tris

def _cache_key(input_obj, settings):

    h = hashlib.sha256()
    with open(input_obj, 'rb') as f:
        while True:
            chunk = f.read(65536)
            if not chunk: break
            h.update(chunk)
    h.update(b'|')
    h.update(json.dumps(settings, sort_keys=True).encode())
    return h.hexdigest()[:16]

def _cache_key_data(verts, tris, settings):

    h = hashlib.sha256()
    if isinstance(verts, np.ndarray) and isinstance(tris, np.ndarray):
        h.update(np.ascontiguousarray(verts, dtype=np.float32).tobytes())
        h.update(np.ascontiguousarray(tris, dtype=np.int32).tobytes())
        h.update(b'|')
        h.update(json.dumps(settings, sort_keys=True).encode())
        return h.hexdigest()[:16]
    for v in verts:
        h.update(struct.pack('<3f', *(float(c) for c in v)))
    for t in tris:
        h.update(struct.pack('<3i', *(int(c) for c in t)))
    h.update(b'|')
    h.update(json.dumps(settings, sort_keys=True).encode())
    return h.hexdigest()[:16]

_DEFAULT_SETTINGS = {
    'target_quads':        5000,
    'edge_length':         -1.0,
    'target_percentage':   10.0,
    'polygon_scale':       1.0,
    'polygon_target_mode': 1,
    'adaptive':            False,
    'adaptiveness':        0.5,
    'hard_edge_mode':      0,
    'hard_edge_angle':     30.0,
    'freeze_borders':      False,
    'preprocess_weld':     False,
    'denoise_strength':    0.0,

    'symmetry_x':          False,
    'symmetry_y':          False,
    'symmetry_z':          False,
}

def _pack_settings(s):

    buf = (ctypes.c_ubyte * 56)()

    scale = float(s.get('polygon_scale', 1.0))
    eff_count = max(100, int(int(s['target_quads']) * scale))
    struct.pack_into('<I', buf, 0x00, eff_count)

    struct.pack_into('<f', buf, 0x04, -1.0)

    mode = int(s['polygon_target_mode']) & 0xff
    el = float(s['edge_length']) if mode == 2 else -1.0
    struct.pack_into('<f', buf, 0x08, el)

    struct.pack_into('<B', buf, 0x0c, mode)

    adapt_val = float(s['adaptiveness']) if s.get('adaptive', False) else 0.0
    struct.pack_into('<f', buf, 0x10, adapt_val * 100.0)

    struct.pack_into('<B', buf, 0x20, 1)
    struct.pack_into('<i', buf, 0x24, -1)
    struct.pack_into('<B', buf, 0x28, 1)
    return buf

def _cache_dir():
    d = os.path.join(os.environ.get('TEMP', _HERE), 'xremesh_cache')
    os.makedirs(d, exist_ok=True)
    return d

class _CurveSeg(ctypes.Structure):
    _fields_ = [
        ('point_buffer', ctypes.c_void_p),  # Vec3<float>[] 缓冲,count 个三维向量
        ('point_count',  ctypes.c_int32),
        ('curve_type',   ctypes.c_int32),   # 按 Maxon 用法固定为 2
        ('weight',       ctypes.c_float),   # 按 Maxon 用法固定为 50.0
        ('reserved',     ctypes.c_int32),
    ]


def extract_mesh(input_obj=None, settings=None, use_cache=True,
                 progress_callback=None, guide_curves=None,
                 vertex_weights=None, input_hard_edges=None,
                 input_data=None):
    """guide_curves:可选的多层世界坐标点列表 (x,y,z),每个引导样条线一层。
    通过 ZRemesher 原生的 QRLib_addCurve API 传入,使边流对齐到曲线。
    vertex_weights:可选的浮点权重列表(0..1),按 OBJ 顶点顺序一一对应。
    通过 ZRemesher 原生的 QRLib_setPointColors API 以灰度 RGB 传入,
    使局部目标密度随权重变化。
    input_data:可选的 (verts, tris) 序列对,完全绕过 OBJ 文件 IO。
     verts 为 (x,y,z) 元组,tris 为顶点索引三元组。
    传入时 input_obj 可为 None。"""

    eff = dict(_DEFAULT_SETTINGS)
    if settings:
        eff.update(settings)

    # 曲线 / 顶点权重 / 用户硬边会破坏缓存——每一项都可能改变输出拓扑
    # 或面标记,而缓存键只哈希输入网格 + 设置字典。
    if guide_curves:
        use_cache = False
    if vertex_weights:
        use_cache = False
    if input_hard_edges:
        use_cache = False

    if use_cache:
        if input_data is not None:
            key = _cache_key_data(input_data[0], input_data[1], eff)
        else:
            key = _cache_key(input_obj, eff)
        cached = os.path.join(_cache_dir(), f'{key}.mesh.pkl')
        if os.path.isfile(cached) and os.path.getsize(cached) > 100:
            with open(cached, 'rb') as f:
                data = pickle.load(f)
            print(f'[extract] CACHE HIT {key}: {len(data["verts"])}v {len(data["faces"])}f',
                  flush=True)
            return data['verts'], data['faces'], data.get('hard_edges', [])

    qr = _load_dlls(); _bind(qr); qr_base = qr._handle
    k32, patch = _apply_patches(qr_base)

    settings_buf = _pack_settings(eff)
    print(f'[extract] settings: {eff}', flush=True)

    PROG_CB = ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_float, ctypes.c_char_p, ctypes.c_void_p)
    OUT_CB  = ctypes.CFUNCTYPE(None, ctypes.c_char_p, ctypes.c_void_p)
    @PROG_CB
    def prog_cb(pct, msg, ud):
        if progress_callback is not None:
            try:
                m = msg.decode('utf-8', 'replace') if msg else ''
                progress_callback(float(pct), m)
            except Exception:
                pass
        return True
    @OUT_CB
    def out_cb(msg, ud): pass

    qr.QRLib_start(b'Maxon')
    qr.QRLib_setProgressCallback(ctypes.cast(prog_cb, ctypes.c_void_p))
    qr.QRLib_setOutputCallback(ctypes.cast(out_cb, ctypes.c_void_p))

    ctor = ctypes.CFUNCTYPE(ctypes.c_void_p, ctypes.c_void_p)(qr_base + 0x14c540)
    ctx = (ctypes.c_ubyte * (16 * 1024))()
    ctx_ptr = ctypes.cast(ctx, ctypes.c_void_p)
    ctor(ctx_ptr)

    if input_data is not None:
        verts, tris = input_data
        print(f'[extract] direct-array input: {len(verts)} verts, {len(tris)} tris',
              flush=True)
    else:
        print(f'[extract] loading {input_obj}...', flush=True)
        verts, tris = _load_obj(input_obj)
        print(f'[extract] input: {len(verts)} verts, {len(tris)} tris', flush=True)
    NV, NT = len(verts), len(tris)

    qr.QRLib_startInputMesh(ctx_ptr)

    pt = ctypes.c_void_p(0)
    qr.QRLib_setPoints_AllocMem(ctypes.byref(pt), NV, ctx_ptr)
    if isinstance(verts, np.ndarray):
        verts_c = np.ascontiguousarray(verts, dtype=np.float32)
        ctypes.memmove(pt.value, verts_c.ctypes.data, NV * 3 * 4)
    else:
        verts_flat = (ctypes.c_float * (NV * 3))(*(c for v in verts for c in v))
        ctypes.memmove(pt.value, verts_flat, NV * 3 * 4)

    tr = ctypes.c_void_p(0)
    qr.QRLib_setTriangles_AllocMem(ctypes.byref(tr), NT * 3, ctx_ptr)
    if isinstance(tris, np.ndarray):
        tris_c = np.ascontiguousarray(tris, dtype=np.int32)
        ctypes.memmove(tr.value, tris_c.ctypes.data, NT * 3 * 4)
    else:
        tris_flat = (ctypes.c_int32 * (NT * 3))(*(i for t in tris for i in t))
        ctypes.memmove(tr.value, tris_flat, NT * 3 * 4)

    qr.QRLib_endInputMesh(ctx_ptr)

    session = qr.QRLib_startOneRemeshing(ctx_ptr)
    src = ctypes.c_void_p(ctx_ptr.value + 0x240)
    qr.QRLib_setInputMesh(src, session)
    qr.QRLib_setRemeshSettings(ctypes.cast(settings_buf, ctypes.c_void_p), session)
    qr.QRLib_setHashCode(42, session)
    ctypes.c_uint32.from_address(session + 0x52C).value = 0
    ctypes.c_uint32.from_address(session + 0x534).value = 1

    # 当用户要求 NONE 硬边模式时,同时关闭 DLL 的自动硬边检测器。
    # 否则即使选择了"无",DLL 仍会在输入网格中找折痕,使特征线附近
    # 产生更多顶点。
    # NONE(0) 和 FROM_EDGES(2) 都关闭 DLL 自动检测。NONE 表示
    # "完全忽略硬边";FROM_EDGES 表示"只使用用户显式标记的
    # (来自锐边标记 + hard_edge_vgroup)"。
    # AUTO(1) 保持 DLL 默认阈值下的自动检测。
    mode = int(eff.get('hard_edge_mode', 0))
    if mode == 1:
        # AUTO:开启自动检测并使用用户设置的角度阈值
        qr.QRLib_setInputOption_cstr(b'AutoDetectHardEdges', b'true',
                                      ctypes.c_void_p(session))
        qr.QRLib_setInputOption_float(
            b'AutoDetectHardEdges_Angle', float(eff.get('hard_edge_angle', 30.0)),
            ctypes.c_void_p(session))
    else:
        qr.QRLib_setInputOption_cstr(b'AutoDetectHardEdges', b'false',
                                      ctypes.c_void_p(session))

    # 通过选项表覆盖目标模式(对 EDGE / PERCENT 模式比 56 字节
    # 设置结构体更直接)。EDGE 驱动 TargetEdgeLength,
    # PERCENT 驱动 TargetQuadCountAsInputPercentage。
    tmode = int(eff.get('polygon_target_mode', 1))
    if tmode == 2:
        qr.QRLib_setInputOption_float(
            b'TargetEdgeLength', float(eff.get('edge_length', -1.0)),
            ctypes.c_void_p(session))
    elif tmode == 3:
        qr.QRLib_setInputOption_float(
            b'TargetQuadCountAsInputPercentage',
            float(eff.get('target_percentage', 10.0)),
            ctypes.c_void_p(session))

    # 优化 / 质量选项。
    if eff.get('freeze_borders'):
        qr.QRLib_setInputOption_cstr(b'FreezeBorders', b'true',
                                      ctypes.c_void_p(session))
    if eff.get('preprocess_weld'):
        qr.QRLib_setInputOption_cstr(b'PreProcess_WeldPoints', b'true',
                                      ctypes.c_void_p(session))
    den = float(eff.get('denoise_strength', 0.0))
    if den > 0.0:
        qr.QRLib_setInputOption_float(b'DenoiseStrength', den,
                                       ctypes.c_void_p(session))

    # 用户提供的硬边((v0, v1) 索引对列表)。通过 QRLib_setHardEdges
    # 传入,该函数写入 session+0x2c0(指针)、+0x2c8(数量)。
    _hardedge_keepalive = None
    if input_hard_edges:
        n = len(input_hard_edges)
        buf = (ctypes.c_uint32 * (n * 2))()
        for i, (a, b) in enumerate(input_hard_edges):
            buf[i*2]   = a
            buf[i*2+1] = b
        ok = qr.QRLib_setHardEdges(ctypes.cast(buf, ctypes.c_void_p),
                                    n, ctypes.c_void_p(session))
        _hardedge_keepalive = buf
        print(f'[extract] setHardEdges: {n} pairs rc={ok}', flush=True)

    # 原生顶点权重密度(colorToDensity)。逆向得出的公式:
    #   density = (C2 - (G+B)*k1 + C3) / (C2 - R*k2 + C4)
    # → 红色通道提高密度(更多多边形),G/B 降低密度,黑色为中性。
    # 正确编码:绘制过的顶点设 R=255*weight,未绘制的保持黑色。
    # 配合 VarDensityRatio 增强,可使局部浓度最高达 9 倍。
    # (早期尝试用灰色到黑色,那是中性到中性,毫无效果;
    #  经过极性扫描才确定这个编码。)
    _color_keepalive = None
    scale = float((settings or {}).get('density_scale', 1.0))
    if vertex_weights and len(vertex_weights) == NV and scale > 0.0:
        col_buf = (ctypes.c_ubyte * (NV * 3))()
        for i, wt in enumerate(vertex_weights):
            r = max(0, min(255, int(255 * wt)))
            col_buf[i*3]   = r   # R = 密度强度
            col_buf[i*3+1] = 0
            col_buf[i*3+2] = 0
        qr.QRLib_setInputOption_cstr(b'UseVertexColorMap', b'true', ctypes.c_void_p(session))
        # 密度缩放 → VarDensityRatio。scale=0 完全禁用密度
        # (被外层检查跳过)。scale=1 → VR=2.0(约 8.5 倍浓度,
        # 默认);scale=3 → VR=4.0(DLL 内部约在 3 处截断)。
        vr = max(1.0, min(4.0, 1.0 + scale))
        qr.QRLib_setInputOption_cstr(b'VarDensityRatio', f'{vr:.3f}'.encode(), ctypes.c_void_p(session))
        # 第二个参数是 STRIDE(RGB=3, RGBA=4),不是顶点数。
        qr.QRLib_setPointColors(ctypes.cast(col_buf, ctypes.c_void_p),
                                 3, ctypes.c_void_p(session))
        _color_keepalive = col_buf
        print(f'[extract] vertex weights native: {NV} verts, '
              f'{sum(1 for w in vertex_weights if w > 0)} non-zero, '
              f'RED-channel encoding, VarDensityRatio={vr:.2f}', flush=True)

    # 通过原生 API 传入引导曲线。点缓冲区必须保持存活
    # 直到 doQuadRemeshing 结束——ZRemesher 只存指针,不复制。
    _curve_keepalive = []
    if guide_curves:
        n_total = 0
        for curve_pts in guide_curves:
            if not curve_pts: continue
            npt = len(curve_pts)
            flat = (ctypes.c_float * (3 * npt))(*(c for p in curve_pts for c in p))
            _curve_keepalive.append(flat)
            seg = _CurveSeg(
                point_buffer=ctypes.cast(flat, ctypes.c_void_p),
                point_count=npt, curve_type=2, weight=50.0, reserved=0)
            _curve_keepalive.append(seg)
            qr.QRLib_addCurve(ctypes.byref(seg), ctypes.c_void_p(session))
            n_total += npt
        print(f'[extract] guide curves: {len(guide_curves)} splines, '
              f'{n_total} total points', flush=True)

    t0 = time.time()
    rc = qr.QRLib_doQuadRemeshing(session)
    print(f'[extract] rc={rc}, elapsed={time.time() - t0:.1f}s', flush=True)

    OUT_DESC = session + 0x448
    out_pts = ctypes.c_void_p(0);  out_np  = ctypes.c_int(0)
    qr.QRLib_getPoints(ctypes.byref(out_pts), ctypes.byref(out_np),
                       ctypes.c_void_p(OUT_DESC))
    out_off = ctypes.c_void_p(0);  out_noff = ctypes.c_int(0)
    out_idx = ctypes.c_void_p(0);  out_nidx = ctypes.c_int(0)
    qr.QRLib_getFaces(ctypes.byref(out_off), ctypes.byref(out_noff),
                      ctypes.byref(out_idx), ctypes.byref(out_nidx),
                      ctypes.c_void_p(OUT_DESC))

    n_pts = out_np.value
    n_off = out_noff.value
    n_idx = out_nidx.value
    n_faces = n_off - 1
    if n_pts <= 0 or n_faces <= 0:
        # DLL 的 rc=1 不代表成功——输出无效时 rc 仍为 1。此分支常见于:
        # 1) DLL 模块名被改(必须为 xremeshlib2.dll)
        # 2) 运行中误调了 QRLib_end(销毁全局应用对象)
        # 3) FreezeBorders 遇到破碎/非流形边界
        raise RuntimeError(
            f'Invalid output mesh: n_pts={n_pts} n_faces={n_faces} '
            f'(rc={rc}, elapsed={time.time()-t0:.2f}s, input={NV}v/{NT}t)')
    print(f'[extract] output: {n_pts} verts, {n_faces} faces, {n_idx} indices', flush=True)

    pts_bytes = ctypes.string_at(out_pts.value, n_pts * 12)
    off_bytes = ctypes.string_at(out_off.value, n_off * 4)
    idx_bytes = ctypes.string_at(out_idx.value, n_idx * 4)
    pts_flat = struct.unpack(f'<{n_pts*3}f', pts_bytes)
    off_flat = struct.unpack(f'<{n_off}I',   off_bytes)
    idx_flat = struct.unpack(f'<{n_idx}I',   idx_bytes)

    verts_out = [(pts_flat[i*3], pts_flat[i*3+1], pts_flat[i*3+2])
                 for i in range(n_pts)]
    faces_out = [tuple(idx_flat[off_flat[fi]:off_flat[fi+1]])
                 for fi in range(n_faces)]

    # 取出 DLL 检测到的硬边对。格式为反汇编还原:
    # 若干对 u32 输出顶点索引,交错存储。
    out_he  = ctypes.c_void_p(0);  out_nhe = ctypes.c_int(0)
    qr.QRLib_getHardEdges(ctypes.byref(out_he), ctypes.byref(out_nhe),
                           ctypes.c_void_p(OUT_DESC))
    n_he = out_nhe.value
    hard_edges_out = []
    if n_he > 0 and out_he.value:
        he_bytes = ctypes.string_at(out_he.value, n_he * 8)
        he_flat  = struct.unpack(f'<{n_he*2}I', he_bytes)
        hard_edges_out = [(he_flat[i*2], he_flat[i*2+1]) for i in range(n_he)]
        print(f'[extract] hard edges: {n_he} pairs', flush=True)

    if use_cache:
        if input_data is not None:
            key = _cache_key_data(input_data[0], input_data[1], eff)
        else:
            key = _cache_key(input_obj, eff)
        cached = os.path.join(_cache_dir(), f'{key}.mesh.pkl')
        try:
            with open(cached, 'wb') as f:
                pickle.dump({'verts': verts_out, 'faces': faces_out,
                             'hard_edges': hard_edges_out}, f,
                            protocol=pickle.HIGHEST_PROTOCOL)
            print(f'[extract] cached → {cached}', flush=True)
        except Exception as e:
            print(f'[extract] cache save failed: {e}', flush=True)

    return verts_out, faces_out, hard_edges_out
