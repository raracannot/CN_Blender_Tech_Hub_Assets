# XRemesher DLL API 安全使用手册（完整反汇编梳理）

> 本文档对 `bin/xremeshlib2.dll` 的**全部 QRLib 导出 API** 做了系统反汇编与调用契约梳理，
> 目标是**防止再次发生 `QRLib_end` 误用类事故**。
> 每一节标注：参数契约、返回值语义、副作用、全局状态影响、安全等级。

- DLL：`bin/xremeshlib2.dll`（PE 内部导出名必须与文件名一致，改名会导致模块校验失败）
- ImageBase：`0x180000000`（运行时 ASLR 重定位，地址计算一律用 `qr._handle`）
- 全局区：`.data` 段 `0x3db000` 起、`.bss` 附近（`0x3e0000` 起）

---

## 1. 生命周期 API（高风险区）

### 1.1 `QRLib_start(host_name)` — 只调一次，幂等

```c
// 反汇编 0x141e20
if (g_started[0x3e0ed0] != 0) return false;   // 已初始化 → 返回 False（正常！）
g_started[0x3e0ed0] = 1;
doInit_PreSettingsLoading();
strcpy(g_host, host);                          // 存宿主名（无授权门禁，已被补丁短路）
doInit_PostSettingsLoading();
return true;
```

**契约**：
- 参数：`c_char_p` 宿主名（传 `b'Maxon'` 即可，任意字符串均可——授权已短路）
- 返回：`c_bool`。**第二次调用返回 False 是正常幂等行为，不是错误**
- 副作用：写全局 `0x3e0ed0`、`0x3db258`、`0x3db0e0`
- **安全等级：⚠️ 只调一次**。重复调用无害（返回 False），但**不要配合 `QRLib_end` 反复重启**

### 1.2 `QRLib_end()` — ⚠️ 危险，进程退出才用

```c
// 反汇编 0x141da0
lock();
if (g_app_inited == 0) return false;          // 未初始化 → 返回 False
ptr = g_app_ptr;                              // 0x3e0f00 全局应用对象
g_app_inited = 0;
dtor(ptr);                                    // 0x14c200 析构
delete(ptr, 0x818);                           // 0x1332cc 释放内存
g_app_ptr = NULL;
doReleaseApp();                               // 0x14ca90
unlock();
return true;
```

**契约**：
- 参数：无。返回：`c_bool`
- 副作用：**销毁全局应用对象**（析构 + delete + 指针置空）
- **安全等级：🔴 致命风险**。运行中调用会破坏后续所有 `doQuadRemeshing`（0ms 短路空输出）。
  仅应在**插件卸载/进程退出**时调用。**这是上次事故的直接原因，永远不要在每次 remesh 前 end/start 重启。**

### 1.3 `QRLib_isStarted()` — 只读查询

```c
// 反汇编 0x141d70
lock(); unlock();
return g_started[0x3e0ed0];                    // 只读，无副作用
```

**契约**：无参，返回 `c_bool`。**安全**。仅用于查询是否已 start，**不要**据此决定调用 `end`。

---

## 2. 输入网格 API（安全区）

### 2.1 `QRLib_startInputMesh(ctx)` / `QRLib_endInputMesh(ctx)` — 空壳

```c
// 0x141bd0 / 0x141bc0
return (ctx != NULL);                          // 仅非空检查，无实际作用
```

**安全等级：✅ 无副作用**。可调用可省略（当前插件已调用，保留无碍）。

### 2.2 `QRLib_setPoints_AllocMem(&ptr, count, ctx)` — 分配 + 写 ctx

分配 `count*3*4` 字节，返回指针到 `*ptr`，并记录到 ctx。**缓冲区由调用方 memmove 填充**。
- 参数：`(POINTER(c_void_p), c_int, c_void_p)`
- 安全：✅ 会话级，无全局副作用

### 2.3 `QRLib_setTriangles_AllocMem(&ptr, count, ctx)` — 分配三角索引

分配在 `ctx+0x308`，指针记录到 `ctx+0x250`、数量到 `ctx+0x268`。
- 安全：✅

### 2.4 `QRLib_setPointColors_AllocMem(&ptr, stride, ctx)` — 顶点色

第二参数是 **STRIDE**（3=RGB→`ctx+0x3c8`，4=RGBA→`ctx+0x3e0`）。指针记到 `ctx+0x2a8`。
- 安全：✅（stride 只能传 3 或 4，其他值返回 False）

### 2.5 低层直接 setter（绕过 AllocMem，直接写 session）

| API | 写入 session | 参数顺序 |
|---|---|---|
| `QRLib_setPoints(ptr, count, session)` | +0x240/+0x248 | (ptr,count,sess) |
| `QRLib_setPointColors(ptr, stride, session)` | +0x2a8/+0x2b0 | (ptr,stride,sess) |
| `QRLib_setHardEdges(pairs, n, session)` | +0x2c0/+0x2c8 | (ptr,n,sess) |
| `QRLib_setNormals(ptr,a,b,session)` | +0x288/+0x290/+0x298 | (ptr,?,?,sess) 4参 |

**安全等级：✅**。均为会话级指针写入，缓冲区必须保活到 `doQuadRemeshing` 返回。

### 2.6 `QRLib_setInputMesh(src, session)` — 数据搬运

```c
// 0x141c40
if (session == NULL) return false;
memcpy(session+0x240, src, 152);              // src=ctx+0x240 的 152 字节
return true;
```
把 ctx 里的输入网格描述（点/三角/颜色等）拷到 session。**必须传 `ctx+0x240` 作为 src**。
- 安全：✅

### 2.7 `QRLib_setFaces_AllocMem(&off,&idx,na,nb,ctx)` — 面 + 索引

分配两段（`ctx+0x2f0` 偏移、`ctx+0x308` 索引）。**5 个参数**（含两个输出指针）。
- 安全：✅

---

## 3. 会话配置 API（安全区）

### 3.1 `QRLib_setRemeshSettings(buf56, session)` — 56 字节设置

```c
// 0x141290
memcpy(session+0x410, buf, 56);               // 拷到会话，doQuadRemeshing 时展开
return true;
```
- 安全：✅。结构体偏移见 `XRemesher_DLL_API_Reference.md §4`

### 3.2 `QRLib_setHashCode(code, session)` — 哈希种子

```c
// 0x140d90
session->+0x238 = 1;
session->+0x234 = code + 0x1b;
return true;
```
**实测对输出无影响**（不同 seed 输出完全一致）。安全：✅。

### 3.3 `QRLib_setInputOption_int/float/cstr/utf8str(name, value, session)` — 选项表

写 `session+0x5f0` 选项表（std::map）。`doQuadRemeshing` 在 `0x140d52` 检测 `session+0x610` 后应用。
- **安全等级：✅ 会话级，无全局副作用**
- 参数名/类型见参考文档 §3

### 3.4 `QRLib_rmvInputOption(name, session)` — 移除选项

安全：✅。仅操作会话选项表。

### 3.5 `QRLib_addCurve(seg, session)` / `QRLib_addCurve2` — 曲线引导

```c
// 0x141be0: 24字节 _CurveSeg 值拷贝到 session+0x3f8 容器
```
- **注意参数顺序 `(seg, session)`**；`addCurve2` 是 5 参数变体（含 xmm3）
- **安全等级：⚠️ 缓冲区保活**。`_CurveSeg.point_buffer` 指向的 float 数组必须存活到 `doQuadRemeshing` 返回

### 3.6 Callback 设置（`setProgressCallback`/`setOutputCallback`/`setUserLogFlags`）

写全局 `0x3db260/0x3db268/0x3db270`。**进程级**，重复设置会覆盖。
- 安全：✅（正常用法，每次 start 后设置）

---

## 4. 执行 API

### 4.1 `QRLib_doQuadRemeshing(session)` — 核心执行

```c
// 0x140d00
if (session == NULL) return false;
if (session->+0x7c8 == 0) session->+0x7c8 = default;   // 惰性初始化
if (session->+0x7d0 == 0) session->+0x7d0 = default;
apply_settings_struct(session, session+0x410);         // 展开 56B 设置
if (session->+0x610 != 0) apply_option_table(session, session+0x5f0); // 应用选项
main_remesh_exec(session);                              // 0x14e500 真正执行
return true;                                            // ★ rc=1 不代表成功!
```

**返回码陷阱**：`rc=1` 只表示"执行函数被调用并返回"，**不表示输出有效**。必须检查 `getPoints` 返回的 `n_pts > 0`。**空输出时 rc 仍为 1**——这是上次事故的读取端防线。

### 4.2 输出描述符（`desc = session + 0x448`）

`main_remesh_exec` 成功时填充 `session+0x448` 处的输出描述符结构。读取 API 只是**从该结构取指针/计数**：
- `getPoints(&ptr,&n, desc)` → 从 `desc+0x0/+0x8`
- `getFaces(&off,&noff,&idx,&nidx, desc)` → 从 `desc+0x10/+0x18/+0x20/+0x28`
- `getHardEdges(&ptr,&n, desc)` → 从 `desc+0x80/+0x88`

**安全等级：✅ 只读**，无副作用。但**必须 doQuadRemeshing 成功填充后才有效**。

---

## 5. 输出读取 API（全部只读，安全）

| API | 读取 desc 偏移 | 参数 |
|---|---|---|
| `getPoints` | +0x0 (ptr), +0x8 (count) | (ptr*,count*,desc) |
| `getFaces` | +0x10 (off), +0x18 (noff), +0x20 (idx), +0x28 (nidx) | (off*,noff*,idx*,nidx*,desc) 5参 |
| `getHardEdges` | +0x80 (ptr), +0x88 (count) | (ptr*,count*,desc) |
| `getSmoothingGroups` | +0x90 | (ptr*,desc) |
| `getPolygonGroups` | +0x78 | (ptr*,desc) |
| `getMaterialIds` | +0x60 | (ptr*,desc) |
| `getPointColors` | +0x68 (ptr), +0x70 (count) | (ptr*,count*,desc) |
| `getNormals` | +0x48/+0x50/+0x58 | (ptr*,ptr*,count*,desc) 4参 |
| `getUVs` | +0x30/+0x38/+0x40 | (ptr*,ptr*,count*,desc) 4参 |

**注意参数个数差异**（2/3/4/5 参数都有），绑定 argtypes 时勿搞混。

---

## 6. 文件/设置驱动 API（高风险区，慎用）

| API | 行为 | 安全等级 |
|---|---|---|
| `QRLib_readSettings(path)` | 读设置文件，写全局 `0x3db010` | ⚠️ 有全局写 |
| `QRLib_saveCurrentMeshAndSettings(path)` | 保存，写全局 `0x3db010` | ⚠️ |
| `QRLib_callQRLibAPI_fromSettingsFile(path)` | 从文件驱动完整流程，写全局 | 🔴 会自行 start/end |
| `QRLib_runSavedRemeshingCase(path)` | 重跑用例 | ⚠️ |
| `QRLib_InternalDebug(...)` | 调试，写全局 | 🔴 勿用 |

**`QRLib_callQRLibAPI_fromSettingsFile` 可能内部调用 `QRLib_end`/重新初始化，与主流程冲突。不建议与 `QRLib_start`+`doQuadRemeshing` 混用。**

---

## 7. 陷阱清单（防事故速查）

| # | 陷阱 | 后果 | 规避 |
|---|---|---|---|
| 1 | **运行中调 `QRLib_end`** | 全局对象销毁 → 后续 remesh 0ms 空输出 | 只在进程退出用 |
| 2 | **依赖 `QRLib_start` 返回值做判断** | 二次调用返回 False 被误判为失败 | 只调一次，忽略返回值 |
| 3 | **`rc=1` 当成成功** | 空输出时 rc 仍为 1 | 必须校验 `n_pts > 0` |
| 4 | **DLL 改名**（`xremeshlib2`→其他） | 内部模块校验失败 → 空输出 | 文件名必须匹配导出名 |
| 5 | **`addCurve` 缓冲区未保活** | 曲线指针悬垂 → 崩溃/错误拓扑 | `_curve_keepalive` 保活到返回 |
| 6 | **AllocMem 后忘记 memmove** | 数据未填充 → 空/错输出 | 分配后立即写数据 |
| 7 | **getter 参数个数绑定错** | ctypes 调用崩溃 | 按 §5 表格逐一定 argtypes |
| 8 | **`setPointColors` 传顶点数** | stride 语义错误 → 返回 False | 第二参数是 STRIDE(3/4) |
| 9 | **`callQRLibAPI_fromSettingsFile` 混用** | 内部 end/start 冲突 | 只走 QRLib_start+doQuadRemeshing |

---

## 8. 推荐的安全调用序列（当前插件已验证）

```
QRLib_start(b'Maxon')                       # 进程内只一次
QRLib_setProgressCallback(cb)               # 可选
QRLib_setOutputCallback(cb)                 # 可选
# ── 每次 remesh 重复以下 ──
QRLib_startInputMesh(ctx)                   # 空壳，可省略
QRLib_setPoints_AllocMem(&p, N, ctx)        # memmove 填充
QRLib_setTriangles_AllocMem(&t, M*3, ctx)   # memmove 填充
QRLib_endInputMesh(ctx)                     # 空壳，可省略
session = QRLib_startOneRemeshing(ctx)      # 分配 session
QRLib_setInputMesh(ctx+0x240, session)
QRLib_setRemeshSettings(buf, session)
QRLib_setHashCode(42, session)              # 无实际效果，可留
QRLib_setInputOption_*(name, val, session)  # 可选覆盖
QRLib_setHardEdges(...)                     # 可选
QRLib_setPointColors(...)                   # 可选
QRLib_addCurve(seg, session)                # 可选，保活缓冲
QRLib_doQuadRemeshing(session)              # rc=1 ≠ 成功
QRLib_getPoints(&p, &n, session+0x448)
if (n <= 0): 报错（输出无效）              # ★ 必检
QRLib_getFaces(&off,&noff,&idx,&nidx, session+0x448)
# 读取完成，session 由下一轮 startOneRemeshing 新建，无需手动释放
```

**关键原则**：`QRLib_start` 一次、`QRLib_end` 永不（或仅在卸载时）、每轮 remesh 新建独立 session、始终校验输出点数。
