# ZRemesher 插件逆向·优化·重构经验总结

> 本文档记录对 `c4d_standalone_remesh`（Blender 四边面重拓扑插件）从分析、逆向到优化的完整过程与经验。
> 侧重**方法论**——遇到什么问题、如何分析、什么结论，供后续类似任务复用。
> 配套参考：`XRemesher_DLL_API_Reference.md`（纯逆向数据）。

---

## 1. 项目背景与插件架构

### 1.1 插件是什么

- **本质**：一个把商业级 ZRemesher（Maxon）重拓扑能力"搬进" Blender 的插件
- **核心资产**：`bin/xremeshlib2.dll`（4.2MB）+ `tbb.dll` + `ChSolver.dll`（CHOLMOD 稀疏求解）
- **当前形态**（重构后）：
  - `__init__.py`：UI 面板 + 主操作符（模态线程）
  - `xremesh_extract.py`：ctypes 封装 DLL 的底层实现
  - `blender_manifest.toml`：Blender 4.2+ 扩展清单
  - `bin/`：DLL 三件套

### 1.2 数据流（重构后：无 OBJ 中转）

```
Blender Mesh
  → foreach_get + numpy 提取 (verts, tris)
  → input_data 直传 DLL (ctypes memmove)
  → doQuadRemeshing 执行
  → getPoints/getFaces 读回
  → numpy 向量化世界坐标→本地坐标
  → foreach_set 写回新 mesh
```

### 1.3 功能面板（最终版）

| 区块 | 参数 |
|---|---|
| 目标 | 多边形数量 / 网格密度 / 输入面数百分比 + 面数倍率 + 密度图 |
| 自适应 | 开关 + 强度 |
| 硬边 | 无 / 自动(含角度阈值) / 着色(顶点组) |
| 优化 | 冻结边界 / 预处理焊接 / 降噪强度 |
| 对称 | X/Y/Z + 保留方向 |
| 流线图 | 曲线对象引导边流 |

---

## 2. 逆向方法论（可复用）

### 2.1 工具链

| 工具 | 用途 |
|---|---|
| `pefile` | 解析 PE：导出表、节表、IAT、导入名 |
| `capstone` | x64 反汇编 |
| `ctypes` + `struct` | 运行时 hook、内存读写、调用未导出函数 |
| Windows API | `VirtualProtect`（内存写补丁）、`FlushInstructionCache`、`AddVectoredExceptionHandler` |

### 2.2 逆向流程（踩坑总结）

**第一步：从导出表出发**
- 插件已用 `QRLib_*` 公开 API（90 个导出），先列出全部，标记已用/未用
- **高价值遗漏**：`getNormals/getUVs/getMaterialIds/getPolygonGroups` 等输出 API、`callQRLibAPI_fromSettingsFile`（批量参数入口）

**第二步：字符串表挖掘参数名**
- 正则提取 `.rdata` 中 ASCII 字符串
- 用 `\b[A-Za-z][A-Za-z0-9_]{3,}\b` 过滤出 `TargetQuadCount`、`FreezeBorders`、`MaxThreadCount` 等参数名
- **关键技巧**：选项名在 `.rdata` 连续排布，找到首个即能顺藤摸瓜

**第三步：交叉引用定位参数类型**
- 搜索代码中对参数字符串 VA 的 `lea rdx,[rip+disp]` 引用
- 反汇编确定类型读取器：
  - bool `0x1801b7120` / int `0x1801b7340` / float `0x1801b7230` / str `0x1801b7570`

**第四步：类型读取器 → 参数行为**
- bool 读取器解析 true/false/yes/no/1/0
- 分析读取器调用方（如 `0x123a40` 线程计算），还原 C 语义

### 2.3 关键踩坑

| 坑 | 教训 |
|---|---|
| **`lea` 指令长度**：`lea rdx,[rip+disp]` 是 7 字节，不能用 `+4` 计算目标 | 必须用 `i.address + i.size + disp`，否则目标偏移全错 |
| **`.rdata` 读取方式**：用 `Misc_VirtualSize` 截断会丢尾部字符串 | 用 `PointerToRawData + (rva - VirtualAddress)` 直接索引文件字节 |
| **寄存器误判**：`0x2f0`/`0x2f4`/`0x2f8` 访问很多但多为栈偏移 | 要聚焦 session 结构体指针寄存器的访问，避免噪声 |
| **DLL 非确定性**：多线程竞争导致同参数多次运行面数 ±2% | 性能对比必须多次运行取均值/最小值 |
| **结构体 vs 选项表**：`setRemeshSettings` 写 `session+0x410`，`setInputOption` 写 `session+0x5f0`，`doQuadRemeshing` 用选项表**覆盖**结构体 | 注入参数时确认走哪条通道 |

---

## 3. 性能优化路径（决策记录）

### 3.1 演进路线

| 阶段 | 改动 | 效果 |
|---|---|---|
| ① 基线 | OBJ 导出→子进程/线程→OBJ 回读→from_pydata | 慢，IO 多 |
| ② 无 OBJ | `foreach_get`+numpy → `input_data` 直传 → `foreach_set` 写回 | 消除文件 IO，读回快 200× |
| ③ 参数注入 | `setInputOption_*` 暴露 5 个新参数 | FreezeBorders 8× 提速 |
| ④ 无轮子 | 删 capstone/pefile + 旧 `extract()` 探测路径 | 零 Python 依赖，更稳 |

### 3.2 性能剖析结论（实测数据）

**耗时分布**（32514v/65024t 输入，target=20000）：
- DLL 重拓扑 ≈ 97%
- 网格提取 ≈ 1.5%（45ms）
- 缓存命中 ≈ 0.5%（14ms）
- 对称化 ≈ 0.3%

**决定性发现**：
- 耗时**随输入规模超线性增长**（2k→1.9s，131k→5.8s）
- 耗时**与输出目标面数几乎无关**（2k→2.9s，40k→3.0s）
- 耗时**与线程数几乎无关**（1 线程 3.0s，24 线程 2.6s）

### 3.3 线程逆向的"死胡同"（重要经验）

用户期望通过线程控制加速，逆向发现并实测否决：

1. **反汇编 `0x123a40`** 破解线程计算逻辑：默认 `hardware_concurrency()`，**硬编码上限 6**
2. **补丁实验**：把 `mov eax,6` 改成 `mov eax,16/24`，或 NOP 掉 `cmovg`
3. **实测**：1 线程 3.04s，6 线程 2.59s，24 线程 2.56s → 瓶颈是单线程串行阶段（CHOLMOD 求解/主算法），并行度无收益
4. **结论**：线程方向**彻底否决**，不做无意义暴露

> **经验**：逆向得到"能改什么"≠"值得改"。任何参数改动都应**先小规模实测**，用数据否决，而不是凭直觉投入。

### 3.4 有效的加速杠杆（按收益）

| 杠杆 | 机理 | 实测 |
|---|---|---|
| `FreezeBorders` | 跳过大量内部边界处理 | 3.8s → 0.5s（8×）|
| 缓存命中 | 同输入+同设置 | 3s → 14ms（200×）|
| 降低输入面数 | 输入规模主导耗时 | 131k→8k 省 ~4s |
| numpy 向量化 | 消除逐顶点 Python 循环 | 小项但稳 |

### 3.5 参数有效性实测矩阵

| 参数 | 类型 | 实测效果 |
|---|---|---|
| `TargetEdgeLength` | float | **极显著**：0.05→38590面，0.3→1066面 |
| `FreezeBorders` | bool | 显著提速 + 保边界（但破碎边界网格会空输出）|
| `TargetQuadCountAsInputPercentage` | float | 生效（输入面数百分比）|
| `AutoDetectHardEdges_Angle` | float | 生效（硬边角度阈值）|
| `CurvatureAdaptivness` | float | **无效**（被结构体 `adaptiveness*100` 覆盖）|
| `MaxThreadCount`/`MaxNumThread` | int | **无效**（6 线程硬上限 + 非瓶颈）|
| `DenoiseStrength` | float | 注入正常，效果平滑 |
| `PreProcess_WeldPoints` | bool | 注入正常 |

---

## 4. 重构经验

### 4.1 无 OBJ 中转改造

**关键决策**：从 `from_pydata` 改为 `foreach_set` 直接构建 mesh
```python
# 关键模式：先 add 顶点/loop/polygon 数量，再 foreach_set
me.vertices.add(n_v); me.loops.add(total_l); me.polygons.add(n_f)
me.vertices.foreach_set("co", co_flat)
me.loops.foreach_set("vertex_index", lv)
me.polygons.foreach_set("loop_start", ls)
me.polygons.foreach_set("loop_total", lt)
me.update(); me.validate()
```

**坐标空间统一**：提取时本地→世界（`co @ m3.T + t`），回写时世界→本地（`mw_inv`）。DLL 全程处理世界坐标，与流线图/硬边中点一致。

### 4.2 线程安全

- DLL 调用放后台线程，**所有 ctypes 缓冲必须保活到 `doQuadRemeshing` 返回**（`_curve_keepalive`/`_color_keepalive`/`_hardedge_keepalive`）
- 主线程只做 `_build_and_replace`（UI 安全区）
- 模态计时器 0.2s 刷新进度，`area.tag_redraw()` 保持视口响应

### 4.3 无轮子化

- `capstone` 是分析工具，**生产代码零引用** → 直接删
- `pefile` 只在旧版 `extract()`（点云调试入口）用 → 连旧入口一起删
- 移除后 `blender_manifest.toml` 无 `wheels` 段，零 Python 依赖

### 4.4 致命坑：误用 `QRLib_end` 导致 DLL 空输出（已修复）

**现象**：重拓扑报 `Invalid output mesh: n_pts=0 n_faces=-1`，`doQuadRemeshing` 返回 `rc=1` 但 0ms 短路、输出描述符（session+0x448）全零。

**我的误判**：排查时发现 `QRLib_start` 第二次调用返回 `False`（因为全局标志 `g_started[0x3e0ed0]` 残留为 1），误以为"重复调用导致初始化不完整"，于是加了：
```python
if qr.QRLib_isStarted():
    qr.QRLib_end()      # ← 致命
qr.QRLib_start(b'Blender')
```

**真相（反汇编 QRLib_end @ 0x141da0 证实）**：
```c
if (g_app == 0) return false;
rbx = g_app_ptr;              // 0x3e0f00 全局应用对象
g_inited_flag = 0;
call 0x14c200;                // ★ 析构全局应用对象
call 0x1332cc(ptr, 0x818);    // ★ operator delete
g_app_ptr = 0;                // 指针置空
call 0x14ca90;                // doReleaseApp()
```
`QRLib_end()` 是**重量级销毁**：析构并释放 DLL 全局应用对象，不是简单重置标志。

**因果链**：
1. `QRLib_start` 的 `g_started` 是**幂等标志**——二次调用返回 False 是正常设计（DLL 已在运行），不影响后续 `doQuadRemeshing`（每次用独立 session）
2. 我加的 `QRLib_end()` 销毁了全局应用对象
3. 之后 `QRLib_start` 虽重建标志，但全局对象重建不完整
4. `doQuadRemeshing` 因全局对象失效 → 0ms 短路空输出

**为何独立进程第一遍也失败**：`ctypes.CDLL()` 同进程返回同一 DLL 实例，`extract_mesh` 每次调用都走 `QRLib_isStarted()`（二次起为 True）→ 每次触发 `QRLib_end()` → 状态越来越乱。

**验证链（独立进程对照）**：
| 版本 | 结果 |
|---|---|
| 旧版（无 end/start, Maxon） | ✅ 363v/361f |
| 误加 end/start + Blender | ❌ 0ms 空输出 |
| 修复版（去掉 end/start, Maxon） | ✅ 363v/361f ×3 |

**教训**：
1. **不要凭部分逆向推断去"修复"看似异常的行为**——`QRLib_start` 返回 False 是 DLL 正常幂等设计
2. 任何改动前先在**独立进程**做对照实验（当时先改了代码才测，走了弯路）
3. `QRLib_end` 只在进程退出时调用，正常运行绝不碰

**附带修正**：DLL 文件名必须匹配其内部导出名 `xremeshlib2.dll`（改名 `xremeshlib.dll` 后 DLL 内部模块名校验失败也会空输出，属同族问题）。

---

## 5. 测试方法论

### 5.1 用 MCP 在真实 Blender 中验证

每次改动都在真实 Blender 中跑：
1. `importlib.reload` 模块（扩展已加载时用 `spec_from_file_location` 加载磁盘新代码）
2. 无法实例化 operator → 用 `object.__new__` + `MethodType` 绑方法测试（失败）
   → **改为独立复刻核心逻辑**，或 `bl_rna_get_subclass_py` 拿已注册类
3. 端到端：设 scene props → 调 `bpy.ops.mesh.c4d_standalone_remesh()` → 等 `is_running=False`

### 5.2 参数对比规则

- DLL 非确定性 → 同配置跑 3 次取均值/最小
- 用输出**面数** + **耗时** + **拓扑特征**三维判断是否生效
- 从特征参数（FreezeBorders）验证注入通道通了，再测其余

### 5.3 缓存测试陷阱

- 首次 `use_cache=False` 不写缓存，后续 `use_cache=True` 测"命中"会**误判为冷跑**
- 正确做法：第一次 `use_cache=True`（写），第二次同参 `use_cache=True`（读）

---

## 6. 遗留问题 / 可探索方向

1. **`CallQRLibAPI_fromSettingsFile` / 命令行参数**：可能解锁未暴露的参数（如 `MemoryUsagePolicy`、`SymMode` 枚举值），值得用设置文件实验一次
2. **`GlobalCurvesType`/`GlobalCurvesStrength`**：对应 `_CurveSeg` 的 `curve_type`/`weight` 硬编码字段，曲线引导能力可增强
3. **`getNormals/getUVs` 输出管线**：当前只回读 points/faces，如需保留法线/UV 可扩展
4. **`FreezeBorders` 破碎边界空输出**：DLL 自身限制，已写入 UI description 提示，未做软件兜底
5. **`_pack_settings` 结构体 +0x24 可直通 MaxNumThread**：逆向证实可行但实测无加速，未实施

---

## 7. 关键地址速查（逆向产出）

| 地址 | 含义 |
|---|---|
| `0x141be0` | QRLib_addCurve（24 字节结构值拷贝到 session+0x3f8）|
| `0x140e90` | 56 字节设置结构体 → session 字段展开器 |
| `0x140d52` | doQuadRemeshing 选项表覆盖点（session+0x5f0）|
| `0x123a40` | 线程数计算函数（6 线程硬上限在 0x123aa1）|
| `0x14b4d0` | 选项表完整解析器（全部参数名）|
| `0x141da0` | **QRLib_end（销毁全局应用对象，勿在运行中调用）** |
| `0x3e0ed0` | `g_started` 幂等标志（QRLib_start 二次调用返回 False 的原因）|
| `0x3e0f00` | 全局应用对象指针（QRLib_end 置空）|
| `session+0x178` | MaxNumThread 字段 |
| `session+0x410` | 设置结构体拷贝位置 |
| `session+0x448` | 输出描述符 |
