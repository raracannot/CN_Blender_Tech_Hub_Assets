# XRemesher (xremeshlib2.dll) API 逆向参考

> 本文档基于对 `bin/xremeshlib2.dll`（4.2 MB）的静态逆向分析 + Blender 内实测验证整理。
> 用于 `c4d_standalone_remesh` 插件开发时查阅。**仅供个人学习/研究使用。**

- 目标 DLL：`bin/xremeshlib2.dll`（x64，Windows）
- 依赖 DLL：`bin/tbb.dll`（Intel TBB 并行库）、`bin/ChSolver.dll`（CHOLMOD 稀疏矩阵求解器，导出 `cholmod_*` 系列）
- 附带 wheels：`pefile`（PE 解析）、`capstone`（反汇编）——为分析该 DLL 而捆绑
- ImageBase：`0x180000000`

---

## 1. 调用流程（当前插件已实现）

```
QRLib_start(b"Blender")                     # 初始化库
QRLib_setProgressCallback(cb)             # 进度回调
QRLib_setOutputCallback(cb)               # 日志输出回调
--- 输入网格 ---
QRLib_startInputMesh(ctx)
QRLib_setPoints_AllocMem(&ptr, N, ctx)    # 分配点缓冲，memmove 写入 xyz
QRLib_setTriangles_AllocMem(&ptr, N*3, ctx)
QRLib_endInputMesh(ctx)
--- 会话 ---
QRLib_startOneRemeshing(ctx)              # -> session 指针
QRLib_setInputMesh(src, session)
QRLib_setRemeshSettings(buf, session)     # 56 字节设置结构体
QRLib_setHashCode(42, session)
QRLib_setInputOption_*(name, value, session)  # 覆盖参数（可选）
QRLib_setHardEdges(pairs, n, session)     # 硬边（可选）
QRLib_setPointColors(buf, 3, session)     # 顶点色密度（可选）
QRLib_addCurve(seg, session)              # 流线引导（可选）
QRLib_doQuadRemeshing(session)            # rc=1 成功
--- 输出 ---
QRLib_getPoints(&pts, &n, desc)
QRLib_getFaces(&off, &noff, &idx, &nidx, desc)
QRLib_getHardEdges(&he, &nhe, desc)
```

---

## 2. 完整导出表（90 个导出）

### 2.1 C++ 类成员（非 QRLib 接口，供内部/二进制兼容）

| 导出 | RVA |
|---|---|
| `??0MXAutoContinueAndStopChrono@@QEAA@...` | 0x41360 |
| `??0MXAutoStartAndStopChrono@@QEAA@...` | 0x413c0 |
| `??0MXAutoStopChrono@@QEAA@...` | 0x41300 |
| `??0MXCounted@@IEAA@XZ` | 0x5930 |
| `??0MXCounted@@QEAA@AEBV0@@Z` | 0x57c0 |
| `??1MXAutoContinueAndStopChrono@@QEAA@XZ` | 0x41220 |
| `??1MXAutoStartAndStopChrono@@QEAA@XZ` | 0x41290 |
| `??1MXAutoStopChrono@@QEAA@XZ` | 0x41310 |
| `??1MXCounted@@MEAA@XZ` | 0x5950 |
| `??4MXAutoContinueAndStopChrono@@QEAAAEAV0@$$QEAV0@@Z` | 0x41280 |
| `??4MXAutoContinueAndStopChrono@@QEAAAEAV0@AEBV0@@Z` | 0x41270 |
| `??4MXAutoStartAndStopChrono@@QEAAAEAV0@$$QEAV0@@Z` | 0x412f0 |
| `??4MXAutoStartAndStopChrono@@QEAAAEAV0@AEBV0@@Z` | 0x412e0 |
| `??4MXAutoStopChrono@@QEAAAEAV0@AEBV0@@Z` | 0x41210 |
| `??4MXCounted@@QEAAAEBV0@AEBV0@@Z` | 0x5920 |
| `??4XRemesher@@QEAAAEAV0@$$QEAV0@@Z` | 0x3f220 |
| `??4XRemesher@@QEAAAEAV0@AEBV0@@Z` | 0x3f210 |
| `??_7MXCounted@@6B@`（vtable） | 0x3633a8 |
| `?DoRetopoFromCmdLine@XRemesher@@SAHPEBGHQEAPEAD@Z` | 0x14d890 |
| `?DoRetopoFromLastCmdLine@XRemesher@@SAHXZ` | 0x145bc0 |
| `?deleteIfNotRef@MXCounted@@QEBAXXZ` | 0x5900 |
| `?doInit_PostSettingsLoading@XRemesher@@SAX...` | 0x14cce0 |
| `?doInit_PreSettingsLoading@XRemesher@@SAXXZ` | 0x14d560 |
| `?doReleaseApp@XRemesher@@SAXXZ` | 0x14ca90 |
| `?extractCmdLineInfo@XRemesher@@SAX...` | 0x145fc0 |
| `?getRefCount@MXCounted@@QEBAHXZ` | 0x58b0 |
| `?loadFbxPlugin@XRemesher@@SAXXZ` | 0x1451a0 |
| `?ref@MXCounted@@QEBAXXZ` | 0x58c0 |
| `?stopChrono@MXAutoStopChrono@@QEAAXXZ` | 0x411c0 |
| `?unloadFbxPlugin@XRemesher@@SAXXZ` | 0x145190 |
| `?unref@MXCounted@@QEBAXXZ` | 0x58d0 |
| `?unrefNoDelete@MXCounted@@QEBAXXZ` | 0x58f0 |
| `?s_staticDatas@XRemesher@@2VXRemesher_StaticData@@A`（全局数据） | 0x3db0b0 |
| `dll__WinMainW` | 0x1451d0 |

### 2.2 QRLib API（核心接口，按功能分组）

#### 生命周期

| 函数 | 签名（ctypes） | 说明 |
|---|---|---|
| `QRLib_start` | `(c_char_p)` | 初始化。**必须传 `b"Maxon"`**，否则授权检测不通过 |
| `QRLib_end` | `()` | 释放库资源 |
| `QRLib_isStarted` | `() -> c_bool` | 是否已初始化 |
| `QRLib_setProgressCallback` | `(c_void_p)` | 进度回调 `CFUNCTYPE(c_bool, c_float pct, c_char_p msg, c_void_p ud)` |
| `QRLib_setOutputCallback` | `(c_void_p)` | 日志回调 `CFUNCTYPE(None, c_char_p msg, c_void_p ud)` |
| `QRLib_setUserLogFlags` | `(c_int, c_void_p)` | 日志级别 |

#### 输入网格

| 函数 | 签名 | 说明 |
|---|---|---|
| `QRLib_startInputMesh` | `(c_void_p ctx)` | 开始输入网格 |
| `QRLib_endInputMesh` | `(c_void_p ctx)` | 结束输入网格 |
| `QRLib_setPoints` | `(c_void_p, c_int, c_void_p)` | 设置点（已有缓冲） |
| `QRLib_setPoints_AllocMem` | `(POINTER(c_void_p) &ptr, c_int count, c_void_p ctx)` | 分配点缓冲，随后 `memmove` 写入 `count*3*4` 字节 |
| `QRLib_setTriangles_AllocMem` | `(POINTER(c_void_p), c_int count, c_void_p ctx)` | 分配三角形索引缓冲，写入 `count*4` 字节 |
| `QRLib_setFaces` | `(c_void_p, c_int, c_void_p)` | 设置面（无需预三角化，直接给多边形） |
| `QRLib_setFaces_AllocMem` | `(POINTER(c_void_p), c_int, c_void_p)` | 分配面缓冲 |
| `QRLib_setNormals` | `(c_void_p, c_int, c_void_p)` | 设置顶点法线（配合 `UseIndexedNormals`） |
| `QRLib_setNormals_AllocMem` | `(POINTER(c_void_p), c_int, c_void_p)` | 分配法线缓冲 |
| `QRLib_setUVs` / `_AllocMem` | 同上 | 设置/分配 UV（第二参数为 UV 顶点数） |
| `QRLib_setMaterialIds` / `_AllocMem` | 同上 | 材质 ID（配合 `UseMaterialIds`） |
| `QRLib_setPolygonGroups` / `_AllocMem` | 同上 | 多边形组（配合 `UsePolygonGroups`） |
| `QRLib_setSmoothingGroups` / `_AllocMem` | 同上 | 平滑组（配合 `UseSmoothingGroups`） |
| `QRLib_setPointColors` / `_AllocMem` | `(c_void_p, c_int stride, c_void_p)` | 顶点色。**第二参数是 STRIDE（RGB=3/RGBA=4），不是顶点数**。经 `QRLib_colorToDensity` 转密度 |

#### 会话与执行

| 函数 | 签名 | 说明 |
|---|---|---|
| `QRLib_startOneRemeshing` | `(c_void_p ctx) -> c_void_p session` | 创建 remesh 会话 |
| `QRLib_endOneRemeshing` | `(c_void_p)` | 销毁会话 |
| `QRLib_setInputMesh` | `(c_void_p src, c_void_p session)` | 关联输入网格（`src = ctx + 0x240`） |
| `QRLib_setRemeshSettings` | `(c_void_p buf, c_void_p session) -> c_bool` | 56 字节设置结构体（见 §4） |
| `QRLib_setHashCode` | `(c_int, c_void_p session)` | 哈希种子（固定 42 即可） |
| `QRLib_doQuadRemeshing` | `(c_void_p session) -> c_int` | **执行重拓扑**。返回 1 = 成功 |

#### 输入选项（核心扩展点，见 §3）

| 函数 | 签名 | 说明 |
|---|---|---|
| `QRLib_setInputOption_int` | `(c_char_p name, c_int val, c_void_p session) -> c_bool` | 写入 session+0x5f0 选项表 |
| `QRLib_setInputOption_float` | `(c_char_p name, c_float val, c_void_p session) -> c_bool` | |
| `QRLib_setInputOption_cstr` | `(c_char_p name, c_char_p val, c_void_p session) -> c_bool` | |
| `QRLib_setInputOption_utf8str` | 同上 | UTF-8 字符串 |
| `QRLib_rmvInputOption` | `(c_char_p name, c_void_p session)` | 移除某选项 |

#### 引导/辅助输入

| 函数 | 签名 | 说明 |
|---|---|---|
| `QRLib_setHardEdges` | `(c_void_p pairs, c_int n, c_void_p session) -> c_bool` | 硬边对 `(v0,v1)` uint32 交错数组 |
| `QRLib_addCurve` | `(c_void_p seg, c_void_p session) -> c_bool` | 流线曲线段（见 §5 `_CurveSeg` 结构） |
| `QRLib_addCurve2` | 同上 | 流线曲线（变体） |
| `QRLib_colorToDensity` | `(c_void_p)` | 顶点色 → 密度 |
| `QRLib_densityToColor` | `(c_void_p)` | 密度 → 顶点色 |

#### 输出

| 函数 | 签名 | 说明 |
|---|---|---|
| `QRLib_getPoints` | `(POINTER(c_void_p), POINTER(c_int), c_void_p desc)` | 输出顶点，desc 通常为 `session+0x448` |
| `QRLib_getFaces` | `(POINTER(c_void_p) off, POINTER(c_int) noff, POINTER(c_void_p) idx, POINTER(c_int) nidx, c_void_p desc)` | 输出面（offset 数组 + 索引数组） |
| `QRLib_getHardEdges` | `(POINTER(c_void_p), POINTER(c_int), c_void_p desc)` | 输出硬边对（交错 uint32） |
| `QRLib_getNormals` | 同上模式 | 输出法线 |
| `QRLib_getUVs` | 同上 | 输出 UV |
| `QRLib_getMaterialIds` | 同上 | 输出材质 ID |
| `QRLib_getPolygonGroups` | 同上 | 输出多边形组 |
| `QRLib_getSmoothingGroups` | 同上 | 输出平滑组 |
| `QRLib_getPointColors` | 同上 | 输出顶点色 |
| `QRLib_getApproxMemoryUsageForRemeshing` | `(c_void_p)` | 预估内存占用 |

#### 设置文件 / 缓存

| 函数 | 签名 | 说明 |
|---|---|---|
| `QRLib_readSettings` | `(c_char_p path, ...)` | 从设置文件读全部参数（键=参数名，值=文本，等效多次 setInputOption） |
| `QRLib_callQRLibAPI_fromSettingsFile` | `(c_char_p path)` | 从设置文件驱动完整流程（含 FileIn/FileOut） |
| `QRLib_saveCurrentMeshAndSettings` | `(c_char_p path)` | 保存当前网格+设置 |
| `QRLib_runSavedRemeshingCase` | `(c_char_p path)` | 重跑已保存用例 |
| `QRLib_InternalDebug` | `(c_void_p)` | 内部调试 |

---

## 3. `QRLib_setInputOption_*` 参数表（逆向提取）

参数名从 `.rdata` 提取 + 通过引用点反汇编确定类型读取器：

- **bool 读取器** `0x1801b7120`（接受 true/false/yes/no/1/0 等）
- **int 读取器** `0x1801b7340` / `0x1801b7280`
- **float 读取器** `0x1801b7230`
- **string 读取器** `0x1801b7570` / `0x1801b7450`

### 3.1 bool 型参数

| 参数名 | 说明 |
|---|---|
| `FollowBorders` | 沿输入边界布线（保形） |
| `FreezeBorders` | 冻结边界（边界点保持不动，可大幅提速） |
| `UseMaterialIds` | 使用材质 ID |
| `UsePolygonGroups` | 使用多边形组 |
| `UseSmoothingGroups` | 使用平滑组 |
| `UseHardEdgeFlags` | 使用硬边标志 |
| `UseIndexedNormals` | 使用索引法线 |
| `AutoDetectHardEdges` | 自动检测硬边（配合 `_Angle`） |
| `UseFacesSelections` | 使用面选择 |
| `UseEdgesSelections` | 使用边选择 |
| `UseCurves` | 使用曲线引导 |
| `UseVertexColorMap` | 使用顶点色密度图 |
| `KeepVertexColors` | 输出保留顶点色 |
| `KeepHardEdges` | 输出保留硬边 |
| `KeepGroups` | 保留分组 |
| `UsePolyPainting` | 使用 PolyPainting |
| `KeepPolyPainting` | 保留 PolyPainting |
| `SymLocal` | 局部对称 |
| `SymTopo` | 拓扑对称 |
| `SmartMergeCADFacesGroups` | 智能合并 CAD 面组 |
| `PreProcess_WeldPoints` | 预处理焊接重复点（配合 `_CreaseWeldedEdges`） |
| `PostProcess_SplitPointsOnCreasedNormals` | 后处理按折痕法线分裂点 |
| `ExactQuadCount` | 精确四边形数量 |
| `Caching_UseCache` | 使用内部缓存 |
| `DoQATesting` | QA 测试模式 |
| `IsProceduralRemeshing` | 程序化重拓扑模式 |

### 3.2 int 型参数

| 参数名 | 说明 |
|---|---|
| `TargetQuadCount` | 目标四边形数量 |
| `MaxThreadCount` | 最大线程数（**实测通过 setInputOption_int 无效**，原因见 §9：DLL 硬编码 6 线程上限，且线程非瓶颈） |
| `MaxNumThread` | 最大线程数（别名，同样受 6 线程上限约束） |
| `MemoryUsagePolicy` | 内存使用策略 |
| `NumQuad` | 四边形数量（同 TargetQuadCount） |
| `Caching_Id` | 缓存 ID |
| `Caching_AutoDetectUseCacheMode` | 缓存自动检测模式 |
| `UserLogFlags` | 日志标志 |

### 3.3 float 型参数

| 参数名 | 说明 |
|---|---|
| `TargetEdgeLength` | **目标边长（实测最有效）**：越小面越多 |
| `TargetQuadCountAsInputPercentage` | 目标面数 = 输入面数百分比（5 = 5%） |
| `AutoDetectHardEdges_Angle` | 硬边检测角度阈值（度） |
| `DenoiseStrength` | 降噪强度 |
| `GlobalCurvesStrength` | 全局曲线强度 |
| `CurvatureAdaptivness` | 曲率自适应强度（0-1） |
| `VarDensityRatio` | 密度变化比率（当前插件已用，1-4） |
| `NumPointCirc` | 圆周点数 |
| `MaxQuadRatio` | 最大四边形比例 |
| `FreezeBordersCoef` | 冻结边界系数 |

### 3.4 string/枚举 型参数

| 参数名 | 说明 |
|---|---|
| `FileIn` / `FileOut` / `ProgressFile` / `FileCurves` | 文件路径（设置文件驱动模式） |
| `RetopoNodeName` | 重拓扑节点名 |
| `SymAxis` | 对称轴（`X`/`Y`/`Z`/`NONE` 等） |
| `SymMode` | 对称模式（枚举） |
| `GlobalCurvesType` | 全局曲线类型（枚举） |
| `Fusion360_FinalOutputType` | Fusion360 输出类型（枚举） |
| `HostApp` / `HostAppPath` | 宿主应用标识/路径 |
| `Caching_CachePath` | 缓存路径 |

### 3.5 实测验证记录（Blender 内，输入 70212v/140130t，target=8000）

| 配置 | 输出面数 | 耗时 |
|---|---|---|
| baseline（无注入） | ~7300-7500（随机波动 ±2%） | 3.8-4.0s |
| `FreezeBorders=True` | **5041** | **0.5s** ⚡ |
| `FreezeBorders=False` | ~7514 | 3.9s |
| `TargetEdgeLength=0.05` | **38590** | ~4s |
| `TargetEdgeLength=0.3` | **1066** | ~4s |
| `TargetQuadCountAsInputPercentage=5` | 6449 | ~4s |
| `CurvatureAdaptivness=0` | 7422 | 3.36s |
| `MaxThreadCount=1` | ~7457 | 3.92s |
| `MaxThreadCount=8` | ~7358 | 3.91s |
| `AutoDetectHardEdges=True+angle30` | 7424 | ~4s |
| `DenoiseStrength=0.5` | 7330 | ~4s |

**结论**：
- `FreezeBorders`、`TargetEdgeLength`、`TargetQuadCountAsInputPercentage` 通过 `setInputOption_*` **确认生效**
- `MaxThreadCount` 走 setInputOption_int **确认无效**（见 §9 深入分析）
- DLL 为非确定性输出（多线程竞争），对比测试需多次取均值

---

## 4. `QRLib_setRemeshSettings` 结构体（56 字节）

`xremesh_extract._pack_settings()` 打包。经反汇编 `0x140e90`（setRemeshSettings 内部，把结构体展开到 session）确认的**完整字段映射**：

| 结构体偏移 | 类型 | session 偏移 | 字段 |
|---|---|---|---|
| 0x00 | u32 | +0x17c | 有效目标面数 = `target_quads * polygon_scale`（min 100） |
| 0x04 | f32 | +0x180 | 未知（当前固定 -1.0） |
| 0x08 | f32 | +0x184 | 目标边长（仅 mode=2 时有效，否则 -1.0） |
| 0x0C | u8 | +0x188 | 目标模式：0=AUTO, 1=COUNT, 2=EDGE |
| 0x10 | f32 | +0x21c | 自适应强度 × 100（adaptive 关闭时 0）→ 经 `0x18014a270` 钳制 |
| 0x18 | cstr | +0x190 | RetopoNodeName 字符串（当前为 null） |
| 0x20 | u8 | +0x1b0 | 未知（固定 1） |
| **0x24** | **i32** | **+0x178** | **MaxNumThread（当前固定 -1 = 不指定，走 DLL 默认）** |
| 0x28 | u8 | +0x1b3 | 未知（固定 1） |
| 0x29-0x2f | u8×7 | +0x1b4..+0x22c | 7 个 bool（SymLocal/SymTopo/FollowBorders 等开关） |
| 0x30 | i32 | +0x150 | 未知 |

> **注意**：`setRemeshSettings` 把 56 字节拷贝到 `session+0x410`，`doQuadRemeshing`（0x140d52）在 `session+0x610 != 0` 时用选项表（`session+0x5f0`）**覆盖**它。选项表优先。
> `MaxNumThread`（+0x24 → session+0x178）与选项表里的 `MaxNumThread` 读入位置一致（选项表消费函数 `0x14bec8` 写入 `rdi+0x178`）。

其余字节 0。`adaptive` 布尔与 `adaptiveness` 需在结构体生效，`hard_edge_mode` 走 `AutoDetectHardEdges` 选项。

---

## 5. `_CurveSeg` 结构（QRLib_addCurve）

```python
class _CurveSeg(ctypes.Structure):
    _fields_ = [
        ('point_buffer', ctypes.c_void_p),  # Vec3<float>[] 缓冲
        ('point_count',  ctypes.c_int32),
        ('curve_type',   ctypes.c_int32),   # Maxon 用法固定 2
        ('weight',       ctypes.c_float),   # Maxon 用法固定 50.0
        ('reserved',     ctypes.c_int32),
    ]
```

> 点缓冲必须保持存活直到 `doQuadRemeshing` 结束——ZRemesher 只存指针不拷贝。

### addCurve 拷贝语义（反汇编 `0x141be0`）

`QRLib_addCurve(&seg, session)` 把整个 24 字节结构**值拷贝**进 `session+0x3f8` 的曲线容器：

```
mov  r8, rcx                    ; r8 = &seg
lea  rcx, [rdx+0x3f8]           ; 曲线容器
mov  rdx, [rcx+8]               ; 当前 end 指针
cmp  [rcx+0x10], rdx; je 扩容   ; 满则扩容(0x3fad0)
movups [rdx], r8[0:16]          ; point_buffer(8)+count(4)+type(4)
movsd  [rdx+0x10], r8[0x10:8]   ; weight(4)+reserved(4)
add  [rcx+8], 0x18              ; end += 24
```

**关键**：DLL 复制的是 `_CurveSeg` 结构本身，但 `point_buffer` 只是**指针值**——指向的 float 数组仍由 Python 持有，所以 `_curve_keepalive` 必须保活。

---

## 6. 已知内部内存偏移（逆向结果，勿随意改动）

| 偏移 | 含义 |
|---|---|
| `qr_base + 0x14c540` | 上下文构造函数（16KB 栈缓冲 + ctor 初始化） |
| `ctx_ptr + 0x240` | 输入网格指针（传给 setInputMesh 的 src） |
| `session + 0x52C = 0` | 必须置 0 |
| `session + 0x534 = 1` | 必须置 1 |
| `session + 0x448` | 输出描述符（getPoints/getFaces 的 desc） |
| `session + 0x5f0` | setInputOption 选项表 |
| `session + 0x2c0 / +0x2c8` | setHardEdges 写入的 ptr/count |
| `session + 0x178` | MaxNumThread（由设置结构体 +0x24 或选项表写入） |
| `session + 0x2f0` | 用户指定线程数 |
| `session + 0x2f4` | 线程上限（min 逻辑，见 §9） |
| `session + 0x2f8 / +0x2fc` | 最终线程数（计算后） |
| `session + 0x610` | 选项表启用标志（非 0 时 doQuadRemeshing 应用选项表） |
| `session + 0x3f8` | QRLib_addCurve 曲线容器 |
| `session + 0x410` | setRemeshSettings 结构体拷贝位置 |
| `algo + 0x7d0 / +0x7d8` | 旧版 `extract()` 的输出顶点数组 begin/end |

**已应用的内存补丁**（绕过授权，`_apply_patches`）：
- `qr_base + 0x1508fe` → NOP×2
- `qr_base + 0x150907` → NOP×2
- `qr_base + 0x14816e` → NOP×6
- `qr_base + 0x1331bb` → 分配探针（int3 单步钩子，仅旧版 `extract()` 用）

---

## 7. 设置文件驱动模式（命令行等价）

DLL 支持通过 `QRLib_callQRLibAPI_fromSettingsFile` 或 `extractCmdLineInfo` 从文件/命令行批量读参，键名即 §3 参数名。示例设置文件：

```
TargetQuadCount=8000
TargetEdgeLength=-1
Adaptive=true
AutoDetectHardEdges=false
FreezeBorders=true
SymAxis=X
MaxThreadCount=8
```

命令行选项（`DoRetopoFromCmdLine`）：`FileIn`、`FileOut`、`SymMode`、`KeepGroups`、`MaxNumThread` 等。

---

## 8. 开发注意

1. **授权**：`QRLib_start` 必须传 `b"Maxon"`；DLL 加载时依赖 `tbb.dll`、`ChSolver.dll`，须先 `os.add_dll_directory()`。
2. **线程**：`doQuadRemeshing` 可放后台线程，但 ctypes 缓冲（点/三角形/颜色/曲线）必须保持存活至返回。
3. **输出读法**：`getPoints` 返回 `n*3` 个 f32；`getFaces` 返回 offset+index 两段，面可能为 n-gon（实测输出为四边形，但应通用解析）。
4. **缓存**：本插件自带 `%TEMP%\xremesh_cache` 的 pickle 缓存（按输入 OBJ/数组 + settings 哈希），与 DLL 内部 `Caching_*` 缓存独立。
5. **确定性**：DLL 多线程非确定性，同参数多次运行面数有 ±2% 波动。

---

## 9. 线程控制深入逆向（结论：无加速空间）

### 9.1 线程数计算逻辑（反汇编 `0x123a40`）

```
0x123a5d: if (obj->0x300 > 0) goto done;         // 已计算过则跳过
0x123a66: eax = obj->0x2f0;                      // 用户指定线程数?
0x123a6e: if (eax <= 0) goto 0x123a80;           // 未指定
           obj->0x2f8 = eax; obj->0x2fc = eax;   // 直接用用户值
           goto 0x123ab7;
0x123a80: ecx = std::thread::hardware_concurrency();  // IAT 0x18034c3b8
0x123a8d: if (ecx == 0) ecx = 1;
0x123a92: eax = obj->0x2f4;                      // 上限?
0x123a9a: if (eax > 0) ecx = min(ecx, eax);      // min(硬件核数, 上限)
0x123aa1: eax = 6;                               // ⚠️ 硬编码 6
0x123aa6: if (ecx > 6) ecx = 6;                 // min(..., 6)
           obj->0x2f8 = ecx; obj->0x2fc = ecx;
```

- `0x2f0` = 用户线程数（来自 `MaxNumThread`/`MaxThreadCount`）
- `0x2f4` = 线程上限（写入点 `0x1cbbaa`，取自 min(rdi+0x64, [rdi]->+0x5b8)）
- **`0x123aa1: mov eax, 6` = 硬编码最大 6 线程**

### 9.2 关键地址

| 地址 | 含义 |
|---|---|
| `0x123aa1` | `mov eax, 6`（线程硬上限，字节 `B8 06 00 00 00`） |
| `0x123aa8` | `cmovg ecx, eax`（钳制指令，字节 `0F 4F C8`） |
| `0x18034c3b8` | `std::thread::hardware_concurrency` IAT（来自 MSVCP140.dll） |
| `0x123a80` | `call [rip+0x228932]`（调用 hardware_concurrency） |

### 9.3 实测：patch 线程上限无加速

测试输入 32514v/65024t，target=20000，运行 2-3 次取最优：

| 配置 | 耗时 |
|---|---|
| 不 patch（默认 6 线程） | 2.59s |
| patch `mov eax,6` → `mov eax,16` | 2.56s |
| patch → `mov eax,24` | 2.56s |
| patch → `mov eax,1` | 3.04s |

**结论**：1 线程略慢（3.0s），6→24 线程几乎无差（2.56s）。瓶颈是**单线程串行阶段**（CHOLMOD 稀疏求解 + 主算法），提高并行度无收益。

### 9.4 `doQuadRemeshing` 内部调用链

```
0x140d16: if (session->0x7c8 == 0) session->0x7c8 = <默认>;   // 惰性初始化
0x140d2e: if (session->0x7d0 == 0) session->0x7d0 = <默认>;
0x140d46: 0x140e90(session, session+0x410)   // 应用 56 字节设置结构体
0x140d52: if (session->0x610 != 0) 0x14b4d0(session, session+0x5f0);  // 应用选项表(覆盖)
0x140d66: 0x14e500(session)                  // 真正执行 remeshing
```

选项表消费函数 `0x14b4d0` 是**完整的参数解析器**，读取 §3 全部参数并写入 session 各字段。

### 9.5 结构体直通线程数（可行但无价值）

`setRemeshSettings` 结构体 `+0x24` 直接写入 `session+0x178`（MaxNumThread），当前 `_pack_settings` 固定 -1。**可通过改结构体直接设线程数**，但 9.3 已证明线程数无加速价值，不建议实施。

---

## 10. 性能剖析（实测，决定加速方向）

### 10.1 耗时分布（32514v/65024t 输入，target=20000）

| 环节 | 耗时 | 占比 |
|---|---|---|
| DLL 重拓扑（`doQuadRemeshing`） | ~2.8s | **~97%** |
| 网格提取 `foreach_get`+numpy | ~45ms | 1.5% |
| 缓存命中（读取 pickle） | **14ms** | 0.5% |
| 对称化 bpy.ops | ~10ms | 0.3% |

### 10.2 输出面数 vs 耗时（输入固定 32514v/65024t）

| target_quads | 实际输出面 | 耗时 |
|---|---|---|
| 2000 | 1779 | 2.9s |
| 5000 | 4452 | 2.6s |
| 10000 | 8847 | 2.4s |
| 20000 | 18617 | 3.0s |
| 40000 | 37468 | 3.0s |

→ **耗时与输出面数几乎无关**（2.4-3.0s 平坦），主要成本在输入处理/求解初始化。

### 10.3 输入规模 vs 耗时（target=10000 固定）

| 输入顶点 | 输入三角面 | 耗时 |
|---|---|---|
| 1986 | 3968 | 1.94s |
| 8066 | 16128 | 1.49s |
| 32514 | 65024 | 2.16s |
| 130562 | 261120 | **5.79s** |

→ **耗时随输入规模超线性增长**（131k 时达 5.8s）。

### 10.4 加速结论

| 杠杆 | 机理 | 潜力 | 状态 |
|---|---|---|---|
| `FreezeBorders` | 跳过大量内部处理 | **8 倍**（3.8s→0.5s） | 已暴露 UI |
| 缓存命中 | 同输入+同设置 | 3s→14ms（200 倍） | 已实现 |
| 降低输入面数 | 输入规模主导耗时 | 131k→8k 省 ~4s | 用户侧 |
| 线程控制 | 非瓶颈 | **无** | 已否决 |
