# -*- coding: utf-8 -*-
# ZRemesher 历史记录: 命名 + 正则扫描方案(参考"物体快照"插件)
#
# 命名规范:
#   原版网格 = {real_name}                    (物体初始网格, 永久保留)
#   拓扑网格 = {real_name}.zm{YYYYMMDDHHMMSSffffff}
#
# 元数据(存 mesh 自定义属性):
#   zm_time   显示时间戳 "MM/DD HH:MM"
#   zm_params 本次使用的参数 dict(JSON), 供将来"用该参数重算"
#
# 上限: 5 个拓扑 + 原版永久(共 6 个常驻), 超限淘汰最旧未被引用的拓扑。

import datetime
import json
import re

import bpy

_HISTORY_CAP = 5
_NAME_FORMAT = "%Y%m%d%H%M%S%f"
_DISPLAY_FORMAT = "%m/%d %H:%M"


def get_real_data_name(data_name):
    """去掉 .zm<时间戳> 后缀, 得到真实(原版)网格名。"""
    m = re.match(r"^(.*?)(\.zm\d+)$", data_name)
    return m.group(1) if m else data_name


def get_zm_meshes(real_name):
    """返回属于该真实名的所有拓扑网格(未排序)。"""
    pattern = re.compile(rf"^{re.escape(real_name)}\.zm\d+$")
    return [m for m in bpy.data.meshes if pattern.match(m.name)]


def new_mesh_name(real_name):
    return f"{real_name}.zm{datetime.datetime.now().strftime(_NAME_FORMAT)}"


def display_now():
    return datetime.datetime.now().strftime(_DISPLAY_FORMAT)


def get_display_time(mesh):
    return mesh.get("zm_time", "--")


def get_params_json(mesh):
    return mesh.get("zm_params", "")


def get_stats(mesh):
    return f"{len(mesh.vertices)}v {len(mesh.polygons)}f"


def params_summary(p_json):
    try:
        p = json.loads(p_json)
    except Exception:
        return ""
    mode = p.get('polygon_target_mode', 'COUNT')
    if mode == 'EDGE':
        return f"边长{p.get('edge_length', '')}"
    if mode == 'PERCENT':
        return f"{p.get('target_percentage', '')}%"
    cnt = p.get('polygon_count', 0)
    sc = p.get('polygon_scale', 1.0)
    return f"{cnt}面" if sc == 1.0 else f"{cnt}x{sc}面"


def apply_params_to_scene(params_json, props):
    """把历史条目的参数 JSON 填入面板(scene.zremesh_props), 供参考/重跑。"""
    if not params_json:
        return
    try:
        params = json.loads(params_json)
    except Exception:
        return
    if not isinstance(params, dict):
        return
    for k, v in params.items():
        if k == 'guide_splines':
            obj = bpy.data.objects.get(v) if v else None
            try:
                props.guide_splines = obj if obj and obj.type == 'CURVE' else None
            except Exception:
                pass
        elif k == 'density_map':
            try:
                props.density_map = v or ''
            except Exception:
                pass
        else:
            if not hasattr(props, k):
                continue
            try:
                setattr(props, k, v)
            except Exception:
                pass


def enforce_cap(real_name, obj, cap=_HISTORY_CAP):
    """超上限时淘汰最旧拓扑网格。跳过仍被引用的(当前 obj.data 或其它物体)。"""
    candidates = sorted(get_zm_meshes(real_name), key=lambda m: m.name)
    if len(candidates) <= cap:
        return
    protected = {m.name for m in candidates if m.users > 0}
    removable = [m for m in candidates if m.name not in protected]
    excess = len(candidates) - cap
    if excess <= 0:
        return
    for m in removable[:excess]:
        try:
            bpy.data.meshes.remove(m, do_unlink=False)
        except Exception:
            pass


class MESH_OT_zremesh_history_switch(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_switch"
    bl_label = "切换历史"
    bl_description = "将物体网格数据切换为该历史版本"
    bl_options = {'REGISTER', 'UNDO'}
    mesh_name: bpy.props.StringProperty()

    def execute(self, ctx):
        obj = ctx.object
        if not obj:
            return {"CANCELLED"}
        mesh = bpy.data.meshes.get(self.mesh_name)
        if mesh is None:
            self.report({"WARNING"}, "历史网格不存在(可能已被清理)")
            return {"CANCELLED"}
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        obj.data = mesh
        # 自动把该历史的参数填入面板
        apply_params_to_scene(mesh.get("zm_params", ""), ctx.scene.zremesh_props)
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 切换历史")
        except Exception:
            pass
        return {"FINISHED"}


class MESH_OT_zremesh_history_remove(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_remove"
    bl_label = "删除历史"
    bl_description = "删除该历史网格(正被引用时不可删除)"
    bl_options = {'REGISTER', 'UNDO'}
    mesh_name: bpy.props.StringProperty()

    def execute(self, ctx):
        mesh = bpy.data.meshes.get(self.mesh_name)
        if mesh is None:
            return {"CANCELLED"}
        if mesh.users > 0:
            self.report({"WARNING"}, f"{mesh.name} 正被引用, 无法删除")
            return {"CANCELLED"}
        bpy.data.meshes.remove(mesh, do_unlink=True)
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 删除历史")
        except Exception:
            pass
        return {"FINISHED"}


def apply_history(obj, mesh_name):
    """应用历史: 将目标提升为原始, 清理其余历史与原稿。返回 (removed, skipped, real_name)。"""
    mesh = bpy.data.meshes.get(mesh_name)
    if mesh is None:
        return 0, 0, None
    real = get_real_data_name(mesh.name)
    if obj.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    others = []
    origin = bpy.data.meshes.get(real)
    if origin is not None and origin != mesh:
        others.append(origin)
    for m in get_zm_meshes(real):
        if m != mesh:
            others.append(m)

    if obj.data != mesh:
        obj.data = mesh

    removed = skipped = 0
    for m in others:
        if m.users > 0:
            skipped += 1
            continue
        bpy.data.meshes.remove(m, do_unlink=True)
        removed += 1

    if bpy.data.meshes.get(real) is None and mesh.name != real:
        mesh.name = real
    obj.data = mesh
    return removed, skipped, real


class MESH_OT_zremesh_history_apply(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_apply"
    bl_label = "应用历史"
    bl_description = "将所选历史提升为原始, 清理其余历史与原稿(高危操作, 需二次确认)"
    bl_options = {'REGISTER', 'UNDO'}
    mesh_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.object
        if not obj:
            return {"CANCELLED"}
        removed, skipped, real = apply_history(obj, self.mesh_name)
        if real is None:
            self.report({"WARNING"}, "历史网格不存在(可能已被清理)")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已应用历史 [{real}], 清理 {removed} 个, 跳过 {skipped} 个(被引用)")
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 应用历史")
        except Exception:
            pass
        return {"FINISHED"}


class MESH_OT_zremesh_history_clear(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_clear"
    bl_label = "清空历史"
    bl_description = "清除该物体的所有拓扑历史, 保留原版网格"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, ctx):
        obj = ctx.object
        if not obj:
            return {"CANCELLED"}
        real = get_real_data_name(obj.data.name)
        removed = skipped = 0
        for m in get_zm_meshes(real):
            if m.users > 0:
                skipped += 1
                continue
            bpy.data.meshes.remove(m, do_unlink=True)
            removed += 1
        self.report({"INFO"}, f"已清空 {removed} 个历史, 跳过 {skipped} 个(被引用)")
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 清空历史")
        except Exception:
            pass
        return {"FINISHED"}


def draw_history(layout, obj):
    """在 N 面板绘制历史列表。"""
    real = get_real_data_name(obj.data.name)
    box = layout.box()
    row = box.row()
    row.label(text="历史", icon="TIME")
    row.operator(MESH_OT_zremesh_history_clear.bl_idname, text="清空", icon="TRASH")

    def _row(mesh, label=None, icon='MESH_DATA', show_apply=True, show_remove=True):
        r = box.row(align=True)
        is_current = obj.data == mesh
        op = r.operator(MESH_OT_zremesh_history_switch.bl_idname, text="", icon="FILE_REFRESH",
                        depress=is_current)
        op.mesh_name = mesh.name
        r.label(text=label if label else get_display_time(mesh), icon=icon)
        r.label(text=get_stats(mesh))
        summary = "" if label else params_summary(get_params_json(mesh))
        if summary:
            r.label(text=summary)
        if show_apply:
            op = r.operator(MESH_OT_zremesh_history_apply.bl_idname, text="应用", icon="CHECKMARK")
            op.mesh_name = mesh.name
        if show_remove:
            op = r.operator(MESH_OT_zremesh_history_remove.bl_idname, text="", icon="X")
            op.mesh_name = mesh.name

    origin = bpy.data.meshes.get(real)
    if origin is not None:
        _row(origin, label="原版", icon='OBJECT_ORIGIN', show_apply=False, show_remove=False)

    snaps = sorted(get_zm_meshes(real), key=lambda m: m.name)
    if not snaps and origin is None:
        box.label(text="暂无历史", icon="INFO")
        return
    for m in snaps:
        _row(m)


def register():
    for c in (MESH_OT_zremesh_history_switch, MESH_OT_zremesh_history_apply,
              MESH_OT_zremesh_history_remove, MESH_OT_zremesh_history_clear):
        bpy.utils.register_class(c)


def unregister():
    for c in reversed((MESH_OT_zremesh_history_switch, MESH_OT_zremesh_history_apply,
                       MESH_OT_zremesh_history_remove, MESH_OT_zremesh_history_clear)):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
