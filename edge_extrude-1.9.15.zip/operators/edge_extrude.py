# SPDX-License-Identifier: GPL-3.0-or-later
"""Blender operators and live parameter-dialog handling."""

import bpy
import bmesh
from bpy.props import BoolProperty, FloatProperty

from ..geometry.edge_extrude_mesh import EdgeExtrudeData

def _capture_current_selection(context):
    obj = context.object
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return None, "请在网格编辑模式使用"

    context.tool_settings.mesh_select_mode = (False, True, False)
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    bm.verts.index_update()
    bm.edges.index_update()
    bm.faces.index_update()

    selected = [e for e in bm.edges if e.select]
    if not selected:
        return None, "请先在边模式选择要挤出的边"

    data = EdgeExtrudeData()
    data.capture(bm, selected)
    if not data.has_selection():
        return None, "没有有效选中边"
    return data, ""




def _dialog_prop_update(self, context):
    try:
        if getattr(self, "_suspend_preview", False):
            return
        if getattr(self, "_data", None) is None:
            return
        self._apply_preview(context, select_result=False)
    except Exception:
        pass


class MESH_OT_edge_extrude_float_panel(bpy.types.Operator):
    bl_idname = "mesh.edge_extrude_float_panel"
    bl_label = "挤出边"
    bl_description = "右键菜单打开 Blender 原生浮动参数框，用 Width / Height 实时调整选中边挤出"
    bl_options = {'REGISTER', 'UNDO'}

    width: FloatProperty(
        name="Width",
        description="挤出边 Width：跟随场景单位显示，底部总宽度，两侧各 Width/2，不生成上下端封口面",
        default=0.1,
        min=0.0,
        subtype='DISTANCE',
        unit='LENGTH',
        precision=4,
        step=1,
        update=_dialog_prop_update,
    )

    height: FloatProperty(
        name="Height",
        description="挤出边 Height：跟随场景单位显示，沿平均表面法线推出/压入，正负方向可切换凹凸",
        default=0.0,
        soft_min=-10.0,
        subtype='DISTANCE',
        unit='LENGTH',
        precision=4,
        step=1,
        update=_dialog_prop_update,
    )

    select_left: BoolProperty(
        name="左边",
        description="挤出完成后选中左侧结果线",
        default=False,
        update=_dialog_prop_update,
    )

    select_middle: BoolProperty(
        name="中间",
        description="挤出完成后选中新生成的中间凸起线",
        default=True,
        update=_dialog_prop_update,
    )

    select_right: BoolProperty(
        name="右边",
        description="挤出完成后选中右侧结果线",
        default=False,
        update=_dialog_prop_update,
    )

    @classmethod
    def poll(cls, context):
        obj = context.object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def invoke(self, context, event):
        data, msg = _capture_current_selection(context)
        if data is None:
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        self._obj_name = context.object.name
        self._mesh_name = context.object.data.name
        self._data = data
        self._suspend_preview = True
        scn = context.scene
        last_width = getattr(scn, "edge_extrude_width", 0.0)
        last_height = getattr(scn, "edge_extrude_height", 0.0)
        self.width = last_width if last_width > 0.0 else data.default_width()
        self.height = last_height
        self.select_left = bool(getattr(scn, "edge_extrude_select_left", False))
        self.select_middle = bool(getattr(scn, "edge_extrude_select_middle", True))
        self.select_right = bool(getattr(scn, "edge_extrude_select_right", False))
        self._suspend_preview = False

        # 打开弹窗和调参数时，只显示几何预览，不选中任何结果线。
        # 最终选中状态只在点击“确定”后按左/中/右按钮决定。
        self._apply_preview(context, select_result=False)

        # 使用 Blender 原生属性弹窗，不再绘制自定义悬浮面板。
        return context.window_manager.invoke_props_dialog(self, width=230, title="挤出边")

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.prop(self, "width", text="Width")
        col.prop(self, "height", text="Height")

        layout.separator()
        row = layout.row(align=True)
        row.prop(self, "select_left", text="左边", toggle=True)
        row.prop(self, "select_middle", text="中间", toggle=True)
        row.prop(self, "select_right", text="右边", toggle=True)

    def check(self, context):
        # Blender calls check() after property edits in the dialog; applying here
        # makes slider/number edits update the mesh immediately.
        if not getattr(self, "_suspend_preview", False):
            self._apply_preview(context, select_result=False)
        return True

    def execute(self, context):
        if getattr(self, "_data", None) is None:
            return {'CANCELLED'}

        # 点击“确定”时，才根据左/中/右按钮组合设置最终选中结果。
        self._apply_preview(context, select_result=True)
        if hasattr(context.scene, "edge_extrude_width"):
            context.scene.edge_extrude_width = self.width
        if hasattr(context.scene, "edge_extrude_height"):
            context.scene.edge_extrude_height = self.height
        if hasattr(context.scene, "edge_extrude_select_left"):
            context.scene.edge_extrude_select_left = self.select_left
        if hasattr(context.scene, "edge_extrude_select_middle"):
            context.scene.edge_extrude_select_middle = self.select_middle
        if hasattr(context.scene, "edge_extrude_select_right"):
            context.scene.edge_extrude_select_right = self.select_right
        return {'FINISHED'}

    def cancel(self, context):
        if getattr(self, "_data", None) is not None and self._is_valid(context):
            self._data.restore_to_mesh(context.object.data)
        if context.area:
            context.area.tag_redraw()

    def _is_valid(self, context):
        obj = context.object
        return (
            obj is not None
            and obj.type == 'MESH'
            and context.mode == 'EDIT_MESH'
            and obj.name == getattr(self, "_obj_name", None)
            and obj.data.name == getattr(self, "_mesh_name", None)
        )

    def _apply_preview(self, context, select_result=False):
        if getattr(self, "_data", None) is None:
            return False
        if not self._is_valid(context):
            return False

        # 始终保持边选择模式。
        context.tool_settings.mesh_select_mode = (False, True, False)

        # 核心修改：
        # select_result=False：挤出预览/调参数阶段，所有线都保持未选中。
        # select_result=True ：点击“确定”后，才按左/中/右按钮组合选中结果线。
        if select_result:
            select_left = bool(self.select_left)
            select_middle = bool(self.select_middle)
            select_right = bool(self.select_right)
        else:
            select_left = False
            select_middle = False
            select_right = False

        self._data.apply_to_mesh(
            context.object.data,
            self.width,
            self.height,
            select_left,
            select_middle,
            select_right,
        )
        if context.area:
            context.area.tag_redraw()
        return True
