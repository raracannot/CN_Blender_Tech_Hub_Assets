# SPDX-License-Identifier: GPL-3.0-or-later
"""Package constants."""

TUTORIAL_URL = "https://www.bilibili.com/video/BV11KKn6nE2J/"
REPOSITORY_URL = "https://pan.quark.cn/s/341c52c3a6f4"

ICON_FILES = {
    "tutorial": "bili.png",
    "repository": "repository.png",
}
