# SPDX-License-Identifier: GPL-3.0-or-later
"""Load and release bundled custom preview icons."""

from pathlib import Path

import bpy

from .constants import ICON_FILES

_PREVIEW_COLLECTIONS = {}


def _icons_dir():
    return Path(__file__).resolve().parent.parent / "icons"


def load_icons():
    if _PREVIEW_COLLECTIONS.get("main") is not None:
        return

    try:
        import bpy.utils.previews
    except Exception as ex:
        print("[Edge Extrude] Cannot load custom icon previews:", ex)
        return

    collection = bpy.utils.previews.new()
    icons_dir = _icons_dir()
    for key, filename in ICON_FILES.items():
        icon_path = icons_dir / filename
        if not icon_path.is_file():
            print("[Edge Extrude] Icon file not found:", icon_path)
            continue
        try:
            collection.load(key, str(icon_path), "IMAGE")
        except Exception as ex:
            print(f"[Edge Extrude] Failed to load icon {icon_path}: {ex}")

    _PREVIEW_COLLECTIONS["main"] = collection


def unload_icons():
    collection = _PREVIEW_COLLECTIONS.pop("main", None)
    if collection is None:
        return

    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(collection)
    except Exception:
        pass


def icon_id(name):
    collection = _PREVIEW_COLLECTIONS.get("main")
    if collection is None:
        return 0
    try:
        preview = collection.get(name)
    except Exception:
        preview = None
    return getattr(preview, "icon_id", 0) if preview is not None else 0
