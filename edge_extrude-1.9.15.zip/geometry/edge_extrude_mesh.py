# SPDX-License-Identifier: GPL-3.0-or-later
"""Core mesh reconstruction and edge-extrusion algorithms."""

import math

import bmesh
from mathutils import Vector
from mathutils.geometry import normal as geom_normal

def _larger(a, b):
    return a if a >= b else b


def _largest(values):
    it = iter(values)
    try:
        out = next(it)
    except StopIteration:
        return 0.0
    for value in it:
        out = _larger(out, value)
    return out


def _ekey(a, b):
    return (a, b) if a < b else (b, a)


def _edge_get(bm, v1, v2):
    e = bm.edges.get((v1, v2))
    if e is None:
        e = bm.edges.get((v2, v1))
    return e


def _clean_face_indices(indices):
    out = []
    for idx in indices:
        if idx is None:
            continue
        if not out or out[-1] != idx:
            out.append(idx)
    if len(out) > 1 and out[0] == out[-1]:
        out.pop()

    seen = set()
    final = []
    for idx in out:
        if idx in seen:
            return []
        seen.add(idx)
        final.append(idx)
    return final if len(final) >= 3 else []


class EdgeExtrudeData:
    def __init__(self):
        self.orig_verts = []
        self.orig_faces = []
        self.orig_loose_edges = []
        # 记录用户原模型中本来就存在的孤立点。重建挤出结果时只保留这些点，
        # 不再保留被 ridge/support 替代后失去连接的旧端点。
        self.orig_loose_verts = set()
        self.selected_edge_keys = set()
        self.selected_edge_dirs = {}
        self.last_unsupported_multi_faces = 0
        self.last_left_edge_keys = set()
        self.last_middle_edge_keys = set()
        self.last_right_edge_keys = set()
        self.last_ridge_edge_keys = set()

    def capture(self, bm, selected_edges):
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()

        self.orig_verts = [v.co.copy() for v in bm.verts]
        self.orig_faces = []
        for f in bm.faces:
            self.orig_faces.append({
                "verts": [v.index for v in f.verts],
                "material_index": f.material_index,
                "smooth": f.smooth,
            })

        self.orig_loose_edges = []
        for e in bm.edges:
            if len(e.link_faces) == 0:
                self.orig_loose_edges.append((e.verts[0].index, e.verts[1].index))

        self.orig_loose_verts = {
            v.index for v in bm.verts
            if len(v.link_edges) == 0 and len(v.link_faces) == 0
        }

        self.selected_edge_keys = set()
        self.selected_edge_dirs = {}
        for e in selected_edges:
            a = e.verts[0].index
            b = e.verts[1].index
            key = _ekey(a, b)
            self.selected_edge_keys.add(key)
            # Store one stable direction for left/right classification. The middle
            # line is always the new ridge; left/right are the two support lines
            # on each side of the selected edge.
            self.selected_edge_dirs.setdefault(key, (a, b))

    def has_selection(self):
        return bool(self.selected_edge_keys)

    def calc_sensitivity(self):
        if not self.orig_verts:
            return 0.005
        min_v = Vector((min(v.x for v in self.orig_verts), min(v.y for v in self.orig_verts), min(v.z for v in self.orig_verts)))
        hi_v = Vector((_largest(v.x for v in self.orig_verts), _largest(v.y for v in self.orig_verts), _largest(v.z for v in self.orig_verts)))
        diag = (hi_v - min_v).length
        if diag <= 1e-8:
            diag = 1.0
        return _larger(diag * 0.0008, 0.00001)

    def default_width(self):
        return _larger(self.calc_sensitivity() * 25.0, 0.0001)

    def _face_normal(self, vert_indices):
        coords = [self.orig_verts[i] for i in vert_indices if 0 <= i < len(self.orig_verts)]
        if len(coords) < 3:
            return Vector((0.0, 0.0, 1.0))
        n = geom_normal(coords)
        if n.length <= 1e-10:
            return Vector((0.0, 0.0, 1.0))
        return n.normalized()

    def _build_maps(self):
        edge_faces = {}
        face_normals = []
        all_vertex_normal = {i: Vector((0.0, 0.0, 0.0)) for i in range(len(self.orig_verts))}

        for fi, item in enumerate(self.orig_faces):
            inds = item["verts"]
            n = self._face_normal(inds)
            face_normals.append(n)
            for vi in inds:
                if vi in all_vertex_normal:
                    all_vertex_normal[vi] += n
            count = len(inds)
            for i in range(count):
                a = inds[i]
                b = inds[(i + 1) % count]
                edge_faces.setdefault(_ekey(a, b), []).append(fi)

        selected_vertex_normal = {}
        for a, b in self.selected_edge_keys:
            faces = edge_faces.get(_ekey(a, b), [])
            edge_n = Vector((0.0, 0.0, 0.0))
            for fi in faces:
                edge_n += face_normals[fi]
            if edge_n.length <= 1e-10:
                edge_n = all_vertex_normal.get(a, Vector((0.0, 0.0, 1.0))) + all_vertex_normal.get(b, Vector((0.0, 0.0, 1.0)))
            if edge_n.length <= 1e-10:
                edge_n = Vector((0.0, 0.0, 1.0))
            edge_n.normalize()

            selected_vertex_normal.setdefault(a, Vector((0.0, 0.0, 0.0)))
            selected_vertex_normal.setdefault(b, Vector((0.0, 0.0, 0.0)))
            selected_vertex_normal[a] += edge_n
            selected_vertex_normal[b] += edge_n

        for vi, n in list(selected_vertex_normal.items()):
            if n.length <= 1e-10:
                fallback = all_vertex_normal.get(vi, Vector((0.0, 0.0, 1.0)))
                if fallback.length <= 1e-10:
                    fallback = Vector((0.0, 0.0, 1.0))
                n = fallback
            selected_vertex_normal[vi] = n.normalized()

        return edge_faces, face_normals, selected_vertex_normal

    def _use_plugin1_topology(self):
        """Use plugin 1's stable path when selected edges do not share endpoints."""
        if not self.selected_edge_keys:
            return False
        degree = {}
        for a, b in self.selected_edge_keys:
            degree[a] = degree.get(a, 0) + 1
            degree[b] = degree.get(b, 0) + 1
        return bool(degree) and all(count == 1 for count in degree.values())

    def create_style_mesh(self, width, height):
        # 1.9.9：视频中的圆柱竖边属于“互不相连的边”。
        # 对这类选择完整采用插件1算法，正/负高度共用同一套拓扑，拖过 0 时不会切换结构。
        if self._use_plugin1_topology():
            return self._create_style_mesh_legacy(width, height)
        return self._create_style_mesh_advanced(width, height)

    def _create_style_mesh_legacy(self, width, height):
        # 插件1的稳定拓扑实现：用于彼此不相连的选中边（视频中的圆柱整圈竖边）。
        # 这种选择若走插件2的复杂端点/封口分支，向内挤出时会产生重复支撑点和反法向面。
        _edge_faces, _face_normals, selected_vertex_normal = self._build_maps()
        half_width = _larger(float(width) * 0.5, 0.0)
        selected_vertices = set()
        for a, b in self.selected_edge_keys:
            selected_vertices.add(a)
            selected_vertices.add(b)

        new_verts = [v.copy() for v in self.orig_verts]
        new_faces = []
        new_edges_loose = []
        ridge_map = {}
        support_map = {}
        ridge_edge_keys = []
        left_edge_keys = []
        middle_edge_keys = ridge_edge_keys
        right_edge_keys = []
        unsupported_multi_faces = 0

        def add_vert(co):
            new_verts.append(co.copy())
            return len(new_verts) - 1

        def ridge_vertex(orig_idx):
            # Keep a separate ridge vertex instead of moving the original vertex.
            # Moving the original endpoint makes cap/end faces stretch and can create
            # broken/ngon faces on capped cylinders. End faces are rebuilt below so
            # they connect to this ridge vertex without tearing.
            if orig_idx not in ridge_map:
                n = selected_vertex_normal.get(orig_idx, Vector((0.0, 0.0, 1.0)))
                ridge_map[orig_idx] = add_vert(self.orig_verts[orig_idx] + n * float(height))
            return ridge_map[orig_idx]

        def support_vertex(orig_idx, neighbor_idx):
            key = (orig_idx, neighbor_idx)
            if key not in support_map:
                a = self.orig_verts[orig_idx]
                b = self.orig_verts[neighbor_idx]
                vec = b - a
                length = vec.length
                if length <= 1e-10 or half_width <= 1e-12:
                    co = a.copy()
                else:
                    d = min(half_width, length * 0.95)
                    co = a + vec.normalized() * d
                support_map[key] = add_vert(co)
            return support_map[key]

        def append_connected_end_vertex(out, vi, prev_i, next_i):
            # A selected edge endpoint can also belong to end/cap faces that do not
            # contain the selected edge itself, for example the top/bottom cap of a
            # cylinder. Those faces must be rebuilt to touch the new ridge vertex;
            # otherwise the extrusion opens a hole at both ends.
            if half_width <= 1e-12:
                out.append(ridge_vertex(vi))
            else:
                out.append(support_vertex(vi, prev_i))
                out.append(ridge_vertex(vi))
                out.append(support_vertex(vi, next_i))

        def remember_side_edge(orig_a, orig_b, support_a, support_b, ridge_a, ridge_b):
            # Record the two outside result lines as Left / Right so the dialog
            # buttons can control which lines stay selected after the extrusion.
            key = _ekey(orig_a, orig_b)
            dir_a, dir_b = self.selected_edge_dirs.get(key, (orig_a, orig_b))
            edge_dir = self.orig_verts[dir_b] - self.orig_verts[dir_a]
            if edge_dir.length <= 1e-10:
                edge_dir = self.orig_verts[orig_b] - self.orig_verts[orig_a]
            if edge_dir.length <= 1e-10:
                return
            edge_dir.normalize()

            ridge_center = (new_verts[ridge_a] + new_verts[ridge_b]) * 0.5
            support_center = (new_verts[support_a] + new_verts[support_b]) * 0.5
            side_vec = support_center - ridge_center
            if side_vec.length <= 1e-10:
                return

            n = selected_vertex_normal.get(orig_a, Vector((0.0, 0.0, 1.0))) + selected_vertex_normal.get(orig_b, Vector((0.0, 0.0, 1.0)))
            if n.length <= 1e-10:
                n = Vector((0.0, 0.0, 1.0))
            n.normalize()

            support_key = _ekey(support_a, support_b)
            # 1.9.13：修正结果边“左/右”与面板按钮相反的问题。
            # 几何测试得到的是相对于 BMesh 内部边方向的侧别，而该方向与插件 UI
            # 既有的左/右约定正好相反；在这里统一转换，预览、确认及最终选择保持一致。
            if edge_dir.cross(side_vec).dot(n) >= 0.0:
                right_edge_keys.append(support_key)
            else:
                left_edge_keys.append(support_key)

        def add_face(indices, source_item=None, tag=False):
            clean = _clean_face_indices(indices)
            if not clean:
                return None
            try:
                base = new_verts[clean[0]]
                area = 0.0
                for i in range(1, len(clean) - 1):
                    area += ((new_verts[clean[i]] - base).cross(new_verts[clean[i + 1]] - base)).length * 0.5
                if area <= 1e-14:
                    return None
            except Exception:
                pass

            new_faces.append({
                "verts": clean,
                "material_index": source_item.get("material_index", 0) if source_item else 0,
                "smooth": source_item.get("smooth", False) if source_item else False,
                "tag": tag,
            })
            return len(new_faces) - 1

        for item in self.orig_faces:
            inds = item["verts"]
            count = len(inds)
            if count < 3:
                continue

            sel_positions = []
            for i in range(count):
                a = inds[i]
                b = inds[(i + 1) % count]
                if _ekey(a, b) in self.selected_edge_keys:
                    sel_positions.append(i)

            if len(sel_positions) == 0:
                # The face does not contain the selected edge, but it may contain
                # selected edge endpoints. Rebuild those endpoint corners so caps or
                # end faces follow the extrusion and no open/broken faces appear.
                if any(vi in selected_vertices for vi in inds):
                    connected_face = []
                    for vi_pos in range(count):
                        vi = inds[vi_pos]
                        if vi in selected_vertices:
                            append_connected_end_vertex(
                                connected_face,
                                vi,
                                inds[(vi_pos - 1) % count],
                                inds[(vi_pos + 1) % count],
                            )
                        else:
                            connected_face.append(vi)
                    add_face(connected_face, item, tag=False)
                else:
                    add_face(inds, item, tag=False)
                continue

            sel_set = set(sel_positions)

            # Build the remaining original face after removing the Width strip for
            # every selected edge on this face. This is the v1.4 multi-edge fix:
            # multiple selected edges on one polygon are no longer ignored.
            remaining = []
            for vi_pos in range(count):
                vi = inds[vi_pos]
                prev_i = inds[(vi_pos - 1) % count]
                next_i = inds[(vi_pos + 1) % count]
                prev_sel = ((vi_pos - 1) % count) in sel_set
                next_sel = vi_pos in sel_set

                if prev_sel and next_sel:
                    remaining.append(support_vertex(vi, next_i))
                    remaining.append(support_vertex(vi, prev_i))
                elif prev_sel:
                    remaining.append(support_vertex(vi, next_i))
                elif next_sel:
                    remaining.append(support_vertex(vi, prev_i))
                elif vi in selected_vertices:
                    append_connected_end_vertex(remaining, vi, prev_i, next_i)
                else:
                    remaining.append(vi)

            add_face(remaining, item, tag=False)

            for i in sel_positions:
                a = inds[i]
                b = inds[(i + 1) % count]
                c = inds[(i + 2) % count]
                d = inds[(i - 1) % count]

                ra = ridge_vertex(a)
                rb = ridge_vertex(b)
                sa = support_vertex(a, d)
                sb = support_vertex(b, c)

                add_face([ra, rb, sb, sa], item, tag=True)
                ridge_edge_keys.append(_ekey(ra, rb))
                remember_side_edge(a, b, sa, sb, ra, rb)

        face_edges = set()
        for f in new_faces:
            inds = f["verts"]
            for i in range(len(inds)):
                face_edges.add(_ekey(inds[i], inds[(i + 1) % len(inds)]))
        for a, b in self.orig_loose_edges:
            if _ekey(a, b) not in self.selected_edge_keys and _ekey(a, b) not in face_edges:
                new_edges_loose.append((a, b))

        self.last_unsupported_multi_faces = unsupported_multi_faces
        self.last_left_edge_keys = set(left_edge_keys)
        self.last_middle_edge_keys = set(middle_edge_keys)
        self.last_right_edge_keys = set(right_edge_keys)
        self.last_ridge_edge_keys = set(middle_edge_keys)
        return new_verts, new_faces, new_edges_loose, left_edge_keys, middle_edge_keys, right_edge_keys

    def _create_style_mesh_advanced(self, width, height):
        height_sign = 1.0 if float(height) >= 0.0 else -1.0
        # Max 的“Edge Extrude”不是把每条边单独拉出来，而是先按面切出 Width 区域，
        # 再把选中边复制成一条共享的 ridge 线。连续边必须共用转角支撑点，
        # 只碰到端点的相邻面也要被裁掉角，但绝不能把 ridge 塞进这些面里。
        _edge_faces, face_normals, selected_vertex_normal = self._build_maps()
        half_width = _larger(float(width) * 0.5, 0.0)

        selected_vertices = set()
        selected_incident_edges = {}
        for a, b in self.selected_edge_keys:
            selected_vertices.add(a)
            selected_vertices.add(b)
            selected_incident_edges.setdefault(a, set()).add(b)
            selected_incident_edges.setdefault(b, set()).add(a)

        new_verts = [v.copy() for v in self.orig_verts]
        new_faces = []
        new_edges_loose = []
        ridge_map = {}
        support_map = {}
        face_miter_support_map = {}
        # 折线转角的另一侧也必须使用一个共享的斜接点。
        # 旧版在外侧保留两个独立支撑点，再额外补一个 ridge 三角面；
        # 向内挤出时这个三角面会直接露在凹槽中，形成视频里的多余面。
        corner_outer_support_map = {}
        corner_inner_face_map = {}
        supports_by_orig = {}
        # 只用于端头/转角封口的支撑点。
        # cap_supports_by_orig：包含普通相邻面裁角点，主要给 L/折线转角找“外侧开口”用。
        # selected_cap_supports_by_orig：只记录包含选中边的面产生的两侧支撑点。
        # Max 的链条首尾端头只用这两个点和 ridge 点封一个小三角面，
        # 不能把端点一圈普通裁角点都连到 ridge，否则首尾会出现多余小面/点没有合并的效果。
        cap_supports_by_orig = {}
        selected_cap_supports_by_orig = {}
        # 记录已经由“不含选中边的完整封口面”直接连接到 ridge 的顶点。
        # 这类顶点不能再进入后面的端点补面，否则会重复生成端墙，
        # 出现缩小圆盖、内部重叠面或黑线。
        ridge_connected_plain_vertices = set()
        ridge_edge_keys = []
        left_edge_keys = []
        middle_edge_keys = ridge_edge_keys
        right_edge_keys = []
        unsupported_multi_faces = 0

        def add_vert(co):
            new_verts.append(co.copy())
            return len(new_verts) - 1

        def remember_support(orig_idx, support_idx):
            if orig_idx not in supports_by_orig:
                supports_by_orig[orig_idx] = []
            if support_idx not in supports_by_orig[orig_idx]:
                supports_by_orig[orig_idx].append(support_idx)

        def remember_cap_support(orig_idx, support_idx):
            if support_idx is None:
                return
            if orig_idx not in cap_supports_by_orig:
                cap_supports_by_orig[orig_idx] = []
            if support_idx not in cap_supports_by_orig[orig_idx]:
                cap_supports_by_orig[orig_idx].append(support_idx)

        def remember_selected_cap_support(orig_idx, support_idx):
            if support_idx is None:
                return
            if orig_idx not in selected_cap_supports_by_orig:
                selected_cap_supports_by_orig[orig_idx] = []
            if support_idx not in selected_cap_supports_by_orig[orig_idx]:
                selected_cap_supports_by_orig[orig_idx].append(support_idx)

        def _cross2(a, b):
            return a[0] * b[1] - a[1] * b[0]

        def _planar_chain_ridge_overrides():
            # 1.9.14：闭合边环和开放边链统一使用“平面等距偏移”生成 ridge。
            #
            # 旧版只有闭合共面边环会进入平行偏移；开放链仍逐点沿各自顶点法线移动。
            # 在圆柱/弧面上，各顶点法线方向不同，因此开放链的中间线会被扭斜，
            # 与左右支撑线不再逐段平行。
            #
            # 现在对无分叉、共面的闭环或开链都执行以下规则：
            # 1. 每一段 ridge 都是原选中边的平行偏移线；
            # 2. 内部顶点由前后两条偏移线求交，保持连续斜接；
            # 3. 开链首尾点直接落在首、尾偏移线上，后面的三角封口逻辑保持不变；
            # 4. 正负 Height 共用同一拓扑，只改变偏移方向。
            overrides = {}
            if abs(float(height)) <= 1e-12:
                return overrides

            def component_vertices(start_vi, visited):
                component = set()
                stack = [start_vi]
                visited.add(start_vi)
                while stack:
                    vi = stack.pop()
                    component.add(vi)
                    for nb in selected_incident_edges.get(vi, set()):
                        if nb not in visited:
                            visited.add(nb)
                            stack.append(nb)
                return component

            def ordered_component(component):
                if len(component) < 2:
                    return None, False

                degrees = {
                    vi: len(selected_incident_edges.get(vi, set()))
                    for vi in component
                }
                if any(degree < 1 or degree > 2 for degree in degrees.values()):
                    return None, False

                endpoints = sorted(vi for vi, degree in degrees.items() if degree == 1)
                is_closed = len(component) >= 3 and not endpoints and all(
                    degree == 2 for degree in degrees.values()
                )
                is_open = len(endpoints) == 2 and all(
                    degree == 2 or vi in endpoints
                    for vi, degree in degrees.items()
                )
                if not is_closed and not is_open:
                    return None, False

                first = min(component) if is_closed else endpoints[0]
                ordered = []
                previous = None
                current = first

                while True:
                    ordered.append(current)
                    neighbors = sorted(selected_incident_edges.get(current, set()))
                    candidates = [nb for nb in neighbors if nb != previous]

                    if is_closed:
                        if not candidates:
                            return None, False
                        nxt = candidates[0]
                        if nxt == first:
                            break
                    else:
                        if not candidates:
                            break
                        if len(candidates) != 1:
                            return None, False
                        nxt = candidates[0]

                    if nxt in ordered or nxt not in component:
                        return None, False
                    previous, current = current, nxt
                    if len(ordered) > len(component):
                        return None, False

                if len(ordered) != len(component):
                    return None, False
                if not is_closed and ordered[-1] != endpoints[1]:
                    return None, False
                return ordered, is_closed

            def chain_plane(coords, ordered):
                # 非直线链：把开放链临时以首尾弦闭合后使用 Newell 法线。
                # 只要这些点来自同一切割平面，开放与闭合都能得到相同平面。
                plane_n = Vector((0.0, 0.0, 0.0))
                for i, p in enumerate(coords):
                    q = coords[(i + 1) % len(coords)]
                    plane_n.x += (p.y - q.y) * (p.z + q.z)
                    plane_n.y += (p.z - q.z) * (p.x + q.x)
                    plane_n.z += (p.x - q.x) * (p.y + q.y)

                if plane_n.length > 1e-10:
                    plane_n.normalize()
                    return plane_n

                # 单边或共线开放链没有唯一几何平面。
                # 用链方向与平均表面法线构造“链方向 + Height 方向”的工作平面，
                # 让整条 ridge 使用同一偏移方向，仍能保证与左右线平行。
                chain_dir = coords[-1] - coords[0]
                if chain_dir.length <= 1e-10:
                    for i in range(len(coords) - 1):
                        chain_dir = coords[i + 1] - coords[i]
                        if chain_dir.length > 1e-10:
                            break
                if chain_dir.length <= 1e-10:
                    return None
                chain_dir.normalize()

                avg_height = Vector((0.0, 0.0, 0.0))
                for vi in ordered:
                    n = selected_vertex_normal.get(vi)
                    if n is not None and n.length > 1e-10:
                        avg_height += n.normalized()
                if avg_height.length <= 1e-10:
                    avg_height = Vector((0.0, 0.0, 1.0))

                # 去掉沿链方向的分量，避免工作平面退化。
                avg_height = avg_height - chain_dir * avg_height.dot(chain_dir)
                if avg_height.length <= 1e-10:
                    fallback_axes = (
                        Vector((1.0, 0.0, 0.0)),
                        Vector((0.0, 1.0, 0.0)),
                        Vector((0.0, 0.0, 1.0)),
                    )
                    for axis in fallback_axes:
                        candidate = axis - chain_dir * axis.dot(chain_dir)
                        if candidate.length > 1e-10:
                            avg_height = candidate
                            break
                if avg_height.length <= 1e-10:
                    return None
                avg_height.normalize()

                plane_n = chain_dir.cross(avg_height)
                if plane_n.length <= 1e-10:
                    return None
                plane_n.normalize()
                return plane_n

            def intersect_offset_lines(line1, dir1, line2, dir2):
                den = _cross2(dir1, dir2)
                if abs(den) <= 1e-10:
                    return None
                delta = (line2[0] - line1[0], line2[1] - line1[1])
                t = _cross2(delta, dir2) / den
                return (line1[0] + dir1[0] * t,
                        line1[1] + dir1[1] * t)

            def parallel_miter_point(p, prev_n, curr_n, distance):
                # 前后边几乎共线时，用两侧法线的角平分方向生成稳定斜接点。
                mx = prev_n[0] + curr_n[0]
                my = prev_n[1] + curr_n[1]
                ml = math.hypot(mx, my)
                if ml <= 1e-10:
                    mx, my = curr_n
                    ml = 1.0
                mx /= ml
                my /= ml
                denom = mx * curr_n[0] + my * curr_n[1]
                scale = distance / max(abs(denom), 1e-6)
                if denom < 0.0:
                    scale = -scale
                return (p[0] + mx * scale, p[1] + my * scale)

            visited = set()
            for start_vi in sorted(selected_vertices):
                if start_vi in visited:
                    continue

                component = component_vertices(start_vi, visited)
                ordered, is_closed = ordered_component(component)
                if not ordered:
                    continue

                coords = [self.orig_verts[vi] for vi in ordered]
                plane_n = chain_plane(coords, ordered)
                if plane_n is None or plane_n.length <= 1e-10:
                    continue

                origin = coords[0]
                diag = max(((p - origin).length for p in coords[1:]), default=0.0)
                planarity_tol = max(1e-7, diag * 1e-5)
                if any(abs((p - origin).dot(plane_n)) > planarity_tol for p in coords):
                    # 真正的空间折线继续使用原高级逻辑，避免强行压平模型。
                    continue

                axis_x = None
                edge_count = len(coords) if is_closed else len(coords) - 1
                for i in range(edge_count):
                    edge = coords[(i + 1) % len(coords)] - coords[i]
                    edge = edge - plane_n * edge.dot(plane_n)
                    if edge.length > 1e-10:
                        axis_x = edge.normalized()
                        break
                if axis_x is None:
                    continue

                axis_y = plane_n.cross(axis_x)
                if axis_y.length <= 1e-10:
                    continue
                axis_y.normalize()

                points = []
                for p in coords:
                    rel = p - origin
                    points.append((rel.dot(axis_x), rel.dot(axis_y)))

                edge_dirs = []
                edge_normals = []
                valid_edges = True
                for i in range(edge_count):
                    p = points[i]
                    q = points[(i + 1) % len(points)]
                    d = (q[0] - p[0], q[1] - p[1])
                    length = math.hypot(d[0], d[1])
                    if length <= 1e-12:
                        valid_edges = False
                        break
                    d = (d[0] / length, d[1] / length)
                    edge_dirs.append(d)
                    # 统一取有向链的左法线，最后再整体判断正负 Height 的方向。
                    edge_normals.append((-d[1], d[0]))
                if not valid_edges:
                    continue

                def offset_closed(distance):
                    result = []
                    count = len(points)
                    for i, p in enumerate(points):
                        prev_i = (i - 1) % count
                        prev_p = points[prev_i]
                        prev_d = edge_dirs[prev_i]
                        curr_d = edge_dirs[i]
                        prev_n = edge_normals[prev_i]
                        curr_n = edge_normals[i]
                        line1 = (prev_p[0] + prev_n[0] * distance,
                                 prev_p[1] + prev_n[1] * distance)
                        line2 = (p[0] + curr_n[0] * distance,
                                 p[1] + curr_n[1] * distance)
                        hit = intersect_offset_lines(line1, prev_d, line2, curr_d)
                        if hit is None:
                            hit = parallel_miter_point(p, prev_n, curr_n, distance)
                        result.append(hit)
                    return result

                def offset_open(distance):
                    count = len(points)
                    if count == 2:
                        n0 = edge_normals[0]
                        return [
                            (points[0][0] + n0[0] * distance,
                             points[0][1] + n0[1] * distance),
                            (points[1][0] + n0[0] * distance,
                             points[1][1] + n0[1] * distance),
                        ]

                    result = [
                        (points[0][0] + edge_normals[0][0] * distance,
                         points[0][1] + edge_normals[0][1] * distance)
                    ]
                    for i in range(1, count - 1):
                        prev_p = points[i - 1]
                        p = points[i]
                        prev_d = edge_dirs[i - 1]
                        curr_d = edge_dirs[i]
                        prev_n = edge_normals[i - 1]
                        curr_n = edge_normals[i]
                        line1 = (prev_p[0] + prev_n[0] * distance,
                                 prev_p[1] + prev_n[1] * distance)
                        line2 = (p[0] + curr_n[0] * distance,
                                 p[1] + curr_n[1] * distance)
                        hit = intersect_offset_lines(line1, prev_d, line2, curr_d)
                        if hit is None:
                            hit = parallel_miter_point(p, prev_n, curr_n, distance)
                        result.append(hit)

                    last_n = edge_normals[-1]
                    result.append((
                        points[-1][0] + last_n[0] * distance,
                        points[-1][1] + last_n[1] * distance,
                    ))
                    return result

                offset_path = offset_closed if is_closed else offset_open

                # 有向链的“左侧”未必等于插件原来正 Height 的方向。
                # 用所有顶点的原表面法线评分，只做一次整体翻转，不能逐段翻转，
                # 否则相邻偏移线会交叉，中间线仍会失去平行关系。
                unit_offset = offset_path(1.0)
                direction_score = 0.0
                for vi, p2, q2 in zip(ordered, points, unit_offset):
                    delta3 = axis_x * (q2[0] - p2[0]) + axis_y * (q2[1] - p2[1])
                    n = selected_vertex_normal.get(vi)
                    if n is not None and n.length > 1e-10:
                        direction_score += delta3.dot(n.normalized())
                sign_factor = 1.0 if direction_score >= 0.0 else -1.0
                final_points = offset_path(float(height) * sign_factor)

                for vi, p2 in zip(ordered, final_points):
                    overrides[vi] = origin + axis_x * p2[0] + axis_y * p2[1]

            return overrides

        planar_chain_ridge = _planar_chain_ridge_overrides()

        def ridge_vertex(orig_idx):
            if orig_idx not in ridge_map:
                if orig_idx in planar_chain_ridge:
                    co = planar_chain_ridge[orig_idx]
                else:
                    n = selected_vertex_normal.get(orig_idx, Vector((0.0, 0.0, 1.0)))
                    if n.length <= 1e-10:
                        n = Vector((0.0, 0.0, 1.0))
                    co = self.orig_verts[orig_idx] + n.normalized() * float(height)
                ridge_map[orig_idx] = add_vert(co)
            return ridge_map[orig_idx]

        def support_on_edge(orig_idx, neighbor_idx):
            # 支撑点必须落在原来的相邻边上，这样端点周围的普通面可以一起裁角，
            # 不会出现视频里那种面被拉飞或拓扑断开的情况。
            key = (orig_idx, neighbor_idx)
            if key not in support_map:
                a = self.orig_verts[orig_idx]
                b = self.orig_verts[neighbor_idx]
                vec = b - a
                length = vec.length
                if length <= 1e-10 or half_width <= 1e-12:
                    co = a.copy()
                else:
                    # Width 调整不能再卡在相邻边的一半。
                    # 这里按 offset-edge-loop 的 slide 思路，让支撑点沿相邻边继续滑移，
                    # 只在快到下一个顶点前留极小余量，避免真正越点后面翻转。
                    d = min(half_width, length * 0.98)
                    co = a + vec.normalized() * d
                support_map[key] = add_vert(co)
            remember_support(orig_idx, support_map[key])
            return support_map[key]

        def append_ridge_connected_cap_vertex(out, vi, prev_i, next_i):
            # 参考旧版正确的封闭圆柱处理：
            # 顶盖/底盖本身不包含所选竖边，但它的每个边界顶点都是所选边端点。
            # 不能只把这些角裁掉后保留一个缩小的圆盖；必须把封口面边界直接
            # 连接到新 ridge 顶点，形成连续的“支撑点-ridge-支撑点”轮廓。
            if half_width <= 1e-12:
                out.append(ridge_vertex(vi))
            else:
                out.append(support_on_edge(vi, prev_i))
                out.append(ridge_vertex(vi))
                out.append(support_on_edge(vi, next_i))
            ridge_connected_plain_vertices.add(vi)

        def line_intersection_on_face(p1, d1, p2, d2, n):
            den = d1.cross(d2).dot(n)
            if abs(den) <= 1e-10:
                return None
            t = (p2 - p1).cross(d2).dot(n) / den
            return p1 + d1 * t

        def miter_support(fi, vi_pos, inds, sel_set):
            vi = inds[vi_pos]
            key = (fi, vi)
            if key in face_miter_support_map:
                return face_miter_support_map[key]

            count = len(inds)
            prev_i = inds[(vi_pos - 1) % count]
            next_i = inds[(vi_pos + 1) % count]
            v = self.orig_verts[vi]
            prev_co = self.orig_verts[prev_i]
            next_co = self.orig_verts[next_i]
            n = face_normals[fi] if 0 <= fi < len(face_normals) else self._face_normal(inds)
            if n.length <= 1e-10:
                n = selected_vertex_normal.get(vi, Vector((0.0, 0.0, 1.0)))
            if n.length <= 1e-10:
                n = Vector((0.0, 0.0, 1.0))
            n = n.normalized()

            d_prev = v - prev_co
            d_next = next_co - v
            len_prev = d_prev.length
            len_next = d_next.length
            if len_prev <= 1e-10 or len_next <= 1e-10 or half_width <= 1e-12:
                idx = add_vert(v.copy())
                face_miter_support_map[key] = idx
                remember_support(vi, idx)
                return idx

            dir_prev = d_prev.normalized()
            dir_next = d_next.normalized()

            # L 转角 Width/厚度修复二：上一版把 miter 点强制钳在当前小面内部，
            # 所以视频里 Width 调大后会像被卡住一样。这里改成真正的“偏移线相交 + 滑移”:
            # 1. 正常情况下直接用 half_width 求两条偏移边线交点，Width 会持续变大；
            # 2. 只有当数值误差/曲面折角导致交点远大于理论 miter 长度时，
            #    才退回到角平分线上的理论位置，防止 L 角炸出长飞面。
            corner_prev = prev_co - v
            corner_next = next_co - v
            angle = 1.57079632679
            if corner_prev.length > 1e-10 and corner_next.length > 1e-10:
                try:
                    angle = corner_prev.normalized().angle(corner_next.normalized())
                except Exception:
                    angle = 1.57079632679
            angle = max(0.01745329252, min(3.12413936107, angle))
            sin_half = math.sin(angle * 0.5)
            expected_miter_dist = half_width / max(sin_half, 1e-4)

            inward_prev = n.cross(dir_prev)
            inward_next = n.cross(dir_next)
            if inward_prev.length <= 1e-10:
                inward_prev = (next_co - v)
            if inward_next.length <= 1e-10:
                inward_next = (prev_co - v)
            if inward_prev.length <= 1e-10:
                inward_prev = n
            if inward_next.length <= 1e-10:
                inward_next = n
            inward_prev.normalize()
            inward_next.normalize()

            p1 = v + inward_prev * half_width
            p2 = v + inward_next * half_width
            co = line_intersection_on_face(p1, dir_prev, p2, dir_next, n)

            # 不是按边长硬钳制；只过滤“不符合当前角度理论 miter 长度”的异常交点。
            # 这样 L 角 Width 可以继续增大，同时避免极小夹角/曲面法线误差造成长飞面。
            max_dist = max(expected_miter_dist * 1.35, half_width * 1.6, min(len_prev, len_next) * 0.98)
            if co is None or (co - v).length > max_dist:
                fallback = inward_prev + inward_next
                if fallback.length <= 1e-10:
                    center = Vector((0.0, 0.0, 0.0))
                    for idx0 in inds:
                        center += self.orig_verts[idx0]
                    center /= float(len(inds))
                    fallback = center - v
                if fallback.length <= 1e-10:
                    fallback = n
                fallback.normalize()
                co = v + fallback * expected_miter_dist

            idx = add_vert(co)
            face_miter_support_map[key] = idx
            remember_support(vi, idx)
            return idx

        def corner_inner_face(vi):
            # 找到同时包含该转角两条选中边的那一个面。
            # 该面已有正常的面内 miter 点；另一侧支撑点以它为基准镜像得到，
            # 从而让转角外侧的两个相邻斜面共用同一个顶点。
            if vi in corner_inner_face_map:
                return corner_inner_face_map[vi]

            incident = selected_incident_edges.get(vi, set())
            if len(incident) != 2:
                corner_inner_face_map[vi] = None
                return None

            for inner_fi, inner_item in enumerate(self.orig_faces):
                inner_inds = inner_item["verts"]
                if vi not in inner_inds or len(inner_inds) < 3:
                    continue
                try:
                    vi_pos = inner_inds.index(vi)
                except ValueError:
                    continue
                prev_i = inner_inds[(vi_pos - 1) % len(inner_inds)]
                next_i = inner_inds[(vi_pos + 1) % len(inner_inds)]
                if prev_i in incident and next_i in incident:
                    inner_sel_positions = []
                    for edge_pos in range(len(inner_inds)):
                        if _ekey(inner_inds[edge_pos], inner_inds[(edge_pos + 1) % len(inner_inds)]) in self.selected_edge_keys:
                            inner_sel_positions.append(edge_pos)
                    info = (inner_fi, vi_pos, inner_inds, set(inner_sel_positions))
                    corner_inner_face_map[vi] = info
                    return info

            corner_inner_face_map[vi] = None
            return None

        def corner_outer_support(vi):
            # 折线转角不能再使用两个 support_on_edge 点加一个三角封口。
            # 这里生成与内侧 miter 对应的外侧共享 miter 点，供转角外侧的
            # 两个选中边相邻面以及中间普通面共同使用。
            if vi in corner_outer_support_map:
                return corner_outer_support_map[vi]
            if half_width <= 1e-12:
                corner_outer_support_map[vi] = vi
                return vi

            info = corner_inner_face(vi)
            if info is None:
                corner_outer_support_map[vi] = None
                return None

            inner_fi, vi_pos, inner_inds, inner_sel_set = info
            inner_idx = miter_support(inner_fi, vi_pos, inner_inds, inner_sel_set)
            origin = self.orig_verts[vi]
            inner_vec = new_verts[inner_idx] - origin

            n = selected_vertex_normal.get(vi, Vector((0.0, 0.0, 1.0)))
            if n.length <= 1e-10:
                n = Vector((0.0, 0.0, 1.0))
            n = n.normalized()

            # 只在当前顶点的切平面内镜像，避免曲面上把外侧点推离表面法向太远。
            tangent = inner_vec - n * inner_vec.dot(n)
            if tangent.length <= 1e-10:
                center_dir = Vector((0.0, 0.0, 0.0))
                incident = list(selected_incident_edges.get(vi, []))
                for nb in incident:
                    d = self.orig_verts[nb] - origin
                    d = d - n * d.dot(n)
                    if d.length > 1e-10:
                        center_dir += d.normalized()
                if center_dir.length <= 1e-10:
                    corner_outer_support_map[vi] = None
                    return None
                center_dir.normalize()

                angle = 1.57079632679
                if len(incident) == 2:
                    d0 = self.orig_verts[incident[0]] - origin
                    d1 = self.orig_verts[incident[1]] - origin
                    d0 = d0 - n * d0.dot(n)
                    d1 = d1 - n * d1.dot(n)
                    if d0.length > 1e-10 and d1.length > 1e-10:
                        try:
                            angle = d0.normalized().angle(d1.normalized())
                        except Exception:
                            angle = 1.57079632679
                angle = max(0.01745329252, min(3.12413936107, angle))
                dist = half_width / max(math.sin(angle * 0.5), 1e-4)
                co = origin - center_dir * dist
            else:
                # 内、外两侧斜接长度保持一致；镜像后相邻斜面在转角处直接共边。
                co = origin - tangent

            idx = add_vert(co)
            corner_outer_support_map[vi] = idx
            remember_support(vi, idx)
            return idx

        def face_support(fi, vi_pos, inds, sel_set, remember_for_cap=False):
            # 面内连续边：端点落在相邻未选边上；连续转角使用面内 miter 点。
            # remember_for_cap 只记录“包含选中边的面”产生的支撑点，
            # 后面端头/转角封口只用这些点，避免普通相邻面的裁角点被误连成内部多余面。
            count = len(inds)
            vi = inds[vi_pos]
            prev_sel = ((vi_pos - 1) % count) in sel_set
            next_sel = vi_pos in sel_set
            if prev_sel and next_sel:
                idx = miter_support(fi, vi_pos, inds, sel_set)
            elif prev_sel != next_sel and _selected_corner_kind(vi) == 'corner':
                if _is_classic_l_corner(vi):
                    # 真正的 L 型 90°转角完全保留旧版做法：
                    # 两个外侧相邻面各自落在原边支撑点上，后面再补旧版局部三角面。
                    if next_sel:
                        idx = support_on_edge(vi, inds[(vi_pos - 1) % count])
                    else:
                        idx = support_on_edge(vi, inds[(vi_pos + 1) % count])
                else:
                    # 非 L 型连续折线统一使用共享外侧 miter 点。
                    # 两块斜面直接在同一顶点闭合，不生成任何转角补面。
                    idx = corner_outer_support(vi)
                    if idx is None:
                        if next_sel:
                            idx = support_on_edge(vi, inds[(vi_pos - 1) % count])
                        else:
                            idx = support_on_edge(vi, inds[(vi_pos + 1) % count])
            elif next_sel:
                idx = support_on_edge(vi, inds[(vi_pos - 1) % count])
            elif prev_sel:
                idx = support_on_edge(vi, inds[(vi_pos + 1) % count])
            else:
                idx = vi
            if remember_for_cap and idx != vi:
                remember_cap_support(vi, idx)
                # 这是当前选中边所在面的支撑点。链条首尾端头封面时，
                # 只允许用这类点，才能和 3ds Max 的挤出线首尾一致。
                remember_selected_cap_support(vi, idx)
            return idx

        def _poly_area(indices):
            try:
                base = new_verts[indices[0]]
                area = 0.0
                for i in range(1, len(indices) - 1):
                    area += ((new_verts[indices[i]] - base).cross(new_verts[indices[i + 1]] - base)).length * 0.5
                return area
            except Exception:
                return 0.0

        def _poly_normal(indices):
            try:
                coords = [new_verts[i] for i in indices]
                if len(coords) < 3:
                    return Vector((0.0, 0.0, 0.0))
                n0 = geom_normal(coords)
                if n0.length > 1e-10:
                    return n0.normalized()
            except Exception:
                pass
            try:
                n = Vector((0.0, 0.0, 0.0))
                for i in range(len(indices)):
                    p = new_verts[indices[i]]
                    q = new_verts[indices[(i + 1) % len(indices)]]
                    n.x += (p.y - q.y) * (p.z + q.z)
                    n.y += (p.z - q.z) * (p.x + q.x)
                    n.z += (p.x - q.x) * (p.y + q.y)
                if n.length > 1e-10:
                    return n.normalized()
            except Exception:
                pass
            return Vector((0.0, 0.0, 0.0))

        def add_face(indices, source_item=None, tag=False, ref_normal=None):
            clean = _clean_face_indices(indices)
            if not clean:
                return None
            if _poly_area(clean) <= 1e-14:
                return None

            # 关键修复：所有新面按参考法线自动翻面。
            # 原来侧面/转角封口按固定顶点顺序创建，在球面或连续折线处很容易出现红色反法线。
            if ref_normal is not None and ref_normal.length > 1e-10:
                n0 = _poly_normal(clean)
                if n0.length > 1e-10 and n0.dot(ref_normal.normalized()) < 0.0:
                    clean = list(reversed(clean))

            stored_ref_normal = None
            if ref_normal is not None and ref_normal.length > 1e-10:
                stored_ref_normal = ref_normal.normalized().copy()

            new_faces.append({
                "verts": clean,
                "material_index": source_item.get("material_index", 0) if source_item else 0,
                "smooth": source_item.get("smooth", False) if source_item else False,
                "tag": tag,
                # 1.9.15：保留每个面的目标法向。仅在数组阶段用 geom_normal 判断还不够，
                # 高度/宽度较大时非共面四边形的 geom_normal 与 BMesh 最终 BMFace.normal
                # 可能方向相反，导致拖动参数时局部面突然变红。重建 BMesh 后会再次按
                # 这个参考方向校正真实面法向。
                "ref_normal": stored_ref_normal,
            })
            return len(new_faces) - 1

        def _side_quad_reference(ra, rb, sb, sa, fallback):
            # 侧斜面在 Height 很大、Width 很小时几乎与原面垂直，直接拿原面法线
            # 当参考会得到接近 0 的点积，浮点误差会让同一个面在拖动参数时反复翻转。
            # 使用四边形自身“沿边方向 × 跨带方向”构造稳定参考；它由固定拓扑顺序
            # [ridge_a, ridge_b, support_b, support_a] 决定，正负高度均连续稳定。
            try:
                along = ((new_verts[rb] - new_verts[ra]) +
                         (new_verts[sb] - new_verts[sa])) * 0.5
                across = ((new_verts[sa] - new_verts[ra]) +
                          (new_verts[sb] - new_verts[rb])) * 0.5
                ref = along.cross(across)
                if ref.length > 1e-10:
                    return ref.normalized()
            except Exception:
                pass
            if fallback is not None and fallback.length > 1e-10:
                return fallback.normalized().copy()
            return None

        def _selected_corner_kind(vi):
            # 返回当前选中链顶点的类型：
            # endpoint  : 链端点，普通相邻面要裁角并和 ridge 端头封闭；
            # corner    : L/折线转角，内外两侧分别使用共享 miter 点，不生成中间三角封口；
            # straight  : 连续直线点，不裁普通相邻面；
            # none      : 非选中链顶点。
            inc = list(selected_incident_edges.get(vi, []))
            if len(inc) == 1:
                return 'endpoint'
            if len(inc) == 2:
                d0 = self.orig_verts[inc[0]] - self.orig_verts[vi]
                d1 = self.orig_verts[inc[1]] - self.orig_verts[vi]
                if d0.length > 1e-10 and d1.length > 1e-10:
                    d0.normalize()
                    d1.normalize()
                    # 两条边几乎反向，说明只是直线连续点，不需要裁外侧普通面。
                    # 不是反向就是 L / 折角；内外两侧都改用共享 miter 点，
                    # 相邻斜面直接共边闭合，不再生成额外三角面。
                    if d0.dot(d1) < -0.965:
                        return 'straight'
                    return 'corner'
            return 'none'

        def _should_trim_plain_face_corner(vi):
            return _selected_corner_kind(vi) in {'endpoint', 'corner'}

        def _is_classic_l_corner(vi):
            # 1.9.7：L 型必须同时满足两个条件，不能再只凭“同面相邻”判断：
            # 1. 两条选中边是同一个原面在该顶点处的相邻边；
            # 2. 两条边投影到局部切平面后接近严格 90°。
            #
            # 圆柱上的缓折线、锯齿线虽然也可能是同面相邻边，但角度并非 90°，
            # 必须走共享 miter，不允许恢复旧版三角补面。
            incident = list(selected_incident_edges.get(vi, []))
            if len(incident) != 2:
                return False

            n = selected_vertex_normal.get(vi, Vector((0.0, 0.0, 1.0)))
            if n.length <= 1e-10:
                n = Vector((0.0, 0.0, 1.0))
            n = n.normalized()

            d0 = self.orig_verts[incident[0]] - self.orig_verts[vi]
            d1 = self.orig_verts[incident[1]] - self.orig_verts[vi]
            d0 = d0 - n * d0.dot(n)
            d1 = d1 - n * d1.dot(n)
            if d0.length <= 1e-10 or d1.length <= 1e-10:
                return False
            d0.normalize()
            d1.normalize()

            # 约 82°～98°才视为真正 L 型。比这个更缓或更尖的连续折线都不是 L 型。
            if abs(d0.dot(d1)) > 0.14:
                return False

            incident_set = set(incident)
            for item0 in self.orig_faces:
                inds0 = item0.get("verts", [])
                if len(inds0) < 3 or vi not in inds0:
                    continue
                try:
                    pos0 = inds0.index(vi)
                except ValueError:
                    continue
                prev0 = inds0[(pos0 - 1) % len(inds0)]
                next0 = inds0[(pos0 + 1) % len(inds0)]
                if prev0 in incident_set and next0 in incident_set:
                    return True
            return False

        # 记录每条选中连续线是否包含真正 L 型转角。
        # 只有这种连续线才完整保留旧版 L 型端头；纯缓折线/锯齿线的端头直接并入相邻原面，
        # 不再单独生成视频里可见的红色三角端面。
        selected_component_has_l = {}
        visited_component_vertices = set()
        for start_vi in selected_vertices:
            if start_vi in visited_component_vertices:
                continue
            stack = [start_vi]
            component = []
            visited_component_vertices.add(start_vi)
            while stack:
                current_vi = stack.pop()
                component.append(current_vi)
                for nb in selected_incident_edges.get(current_vi, set()):
                    if nb in selected_vertices and nb not in visited_component_vertices:
                        visited_component_vertices.add(nb)
                        stack.append(nb)
            has_l = any(_is_classic_l_corner(v0) for v0 in component)
            for v0 in component:
                selected_component_has_l[v0] = has_l

        def remember_side_edge(orig_a, orig_b, support_a, support_b, ridge_a, ridge_b):
            key = _ekey(orig_a, orig_b)
            dir_a, dir_b = self.selected_edge_dirs.get(key, (orig_a, orig_b))
            edge_dir = self.orig_verts[dir_b] - self.orig_verts[dir_a]
            if edge_dir.length <= 1e-10:
                edge_dir = self.orig_verts[orig_b] - self.orig_verts[orig_a]
            if edge_dir.length <= 1e-10:
                return
            edge_dir.normalize()

            ridge_center = (new_verts[ridge_a] + new_verts[ridge_b]) * 0.5
            support_center = (new_verts[support_a] + new_verts[support_b]) * 0.5
            side_vec = support_center - ridge_center
            if side_vec.length <= 1e-10:
                return

            n = selected_vertex_normal.get(orig_a, Vector((0.0, 0.0, 1.0))) + selected_vertex_normal.get(orig_b, Vector((0.0, 0.0, 1.0)))
            if n.length <= 1e-10:
                n = Vector((0.0, 0.0, 1.0))
            n.normalize()

            support_key = _ekey(support_a, support_b)
            # 1.9.13：修正结果边“左/右”与面板按钮相反的问题。
            # 几何测试得到的是相对于 BMesh 内部边方向的侧别，而该方向与插件 UI
            # 既有的左/右约定正好相反；在这里统一转换，预览、确认及最终选择保持一致。
            if edge_dir.cross(side_vec).dot(n) >= 0.0:
                right_edge_keys.append(support_key)
            else:
                left_edge_keys.append(support_key)

        for fi, item in enumerate(self.orig_faces):
            inds = item["verts"]
            count = len(inds)
            if count < 3:
                continue

            sel_positions = []
            for i in range(count):
                if _ekey(inds[i], inds[(i + 1) % count]) in self.selected_edge_keys:
                    sel_positions.append(i)
            sel_set = set(sel_positions)

            if len(sel_positions) == 0:
                # 封闭物体端盖修复（支持单边、连续几边和整圈边）：
                # 顶盖/底盖本身通常不包含所选竖边，只包含这些竖边的端点。
                # 旧判断只有“整圈所有顶点都被选中”时才把端盖接到 ridge，
                # 因而单边/局部边仍走普通裁角 + 额外端墙，产生视频中的底部三角破面。
                #
                # 这里不再按“是否整圈”判断，而是识别真正的端盖：
                # 所选边从该面的平面方向明显穿出（边方向与面法线接近平行）。
                # 对这种面，只替换被选中的角，其余边界保持原样；这样单边、局部链
                # 和整圈都会使用与插件1一致的“支撑点-ridge-支撑点”端盖轮廓。
                selected_positions_on_face = [
                    vi_pos for vi_pos, vi in enumerate(inds)
                    if vi in selected_vertices
                ]
                face_n = face_normals[fi] if 0 <= fi < len(face_normals) else self._face_normal(inds)
                if face_n.length <= 1e-10:
                    face_n = Vector((0.0, 0.0, 1.0))
                face_n = face_n.normalized()

                cap_selected_vertices = set()
                for vi_pos in selected_positions_on_face:
                    vi = inds[vi_pos]
                    incident = selected_incident_edges.get(vi, set())
                    if not incident:
                        continue
                    # 只要至少一条所选入射边明显离开当前面平面，当前角就是端盖角。
                    # 侧面普通相邻四边面的所选边位于面内，点积接近 0，不会误判。
                    for nb in incident:
                        edge_vec = self.orig_verts[nb] - self.orig_verts[vi]
                        if edge_vec.length <= 1e-10:
                            continue
                        if abs(edge_vec.normalized().dot(face_n)) >= 0.45:
                            cap_selected_vertices.add(vi)
                            break

                if cap_selected_vertices:
                    connected_cap = []
                    for vi_pos in range(count):
                        vi = inds[vi_pos]
                        if vi in cap_selected_vertices:
                            append_ridge_connected_cap_vertex(
                                connected_cap,
                                vi,
                                inds[(vi_pos - 1) % count],
                                inds[(vi_pos + 1) % count],
                            )
                        else:
                            connected_cap.append(vi)
                    add_face(connected_cap, item, tag=False, ref_normal=face_n)
                    continue

                # 其他不包含选中边的普通相邻面仍按第二插件原有逻辑裁角，
                # 保留 L 形转角、折线端点以及普通链条的现有修复。
                if any((vi in selected_vertices and _should_trim_plain_face_corner(vi)) for vi in inds):
                    trimmed = []
                    for vi_pos in range(count):
                        vi = inds[vi_pos]
                        if vi in selected_vertices and _should_trim_plain_face_corner(vi):
                            corner_kind = _selected_corner_kind(vi)
                            if corner_kind == 'corner' and not _is_classic_l_corner(vi):
                                # 非 L 型折线：普通面和两块斜面共用一个外侧 miter 点，
                                # 转折处完全闭合，不产生独立三角补面。
                                outer_idx = corner_outer_support(vi)
                                if outer_idx is not None:
                                    trimmed.append(outer_idx)
                                    remember_support(vi, outer_idx)
                                else:
                                    # 极端非流形兜底只重切原面，后面也绝不生成转角补面。
                                    s0 = support_on_edge(vi, inds[(vi_pos - 1) % count])
                                    s1 = support_on_edge(vi, inds[(vi_pos + 1) % count])
                                    trimmed.append(s0)
                                    trimmed.append(s1)
                            else:
                                # 开放边链的首尾端点必须保留独立封口三角面。
                                # 这里只裁掉原表面端点并记录两侧支撑点，不把 ridge 直接塞进原面；
                                # 后面的端点封口阶段会固定生成“左支撑点-ridge-右支撑点”三角面。
                                # 内部非 L 型转折仍在上面的共享 miter 分支处理，不会恢复中间多余三角面。
                                s0 = support_on_edge(vi, inds[(vi_pos - 1) % count])
                                s1 = support_on_edge(vi, inds[(vi_pos + 1) % count])
                                trimmed.append(s0)
                                trimmed.append(s1)
                                remember_cap_support(vi, s0)
                                remember_cap_support(vi, s1)
                        else:
                            trimmed.append(vi)
                    add_face(trimmed, item, tag=False, ref_normal=face_normals[fi])
                else:
                    add_face(inds, item, tag=False, ref_normal=face_normals[fi])
                continue

            # 原面：把所有选中边链替换为面内支撑链。
            remaining = []
            for vi_pos in range(count):
                vi = inds[vi_pos]
                if ((vi_pos - 1) % count) in sel_set or vi_pos in sel_set:
                    remaining.append(face_support(fi, vi_pos, inds, sel_set, remember_for_cap=True))
                else:
                    remaining.append(vi)
            add_face(remaining, item, tag=False, ref_normal=face_normals[fi])

            # 两侧斜面：ridge 线与当前面的支撑线连接。连续边会共享 ridge 顶点。
            for i in sel_positions:
                a = inds[i]
                b = inds[(i + 1) % count]
                ra = ridge_vertex(a)
                rb = ridge_vertex(b)
                sa = face_support(fi, i, inds, sel_set)
                sb = face_support(fi, (i + 1) % count, inds, sel_set)
                side_ref = _side_quad_reference(
                    ra, rb, sb, sa,
                    face_normals[fi] if 0 <= fi < len(face_normals) else None,
                )
                add_face([ra, rb, sb, sa], item, tag=True, ref_normal=side_ref)
                edge_key = _ekey(ra, rb)
                if edge_key not in ridge_edge_keys:
                    ridge_edge_keys.append(edge_key)
                if sa != sb:
                    remember_side_edge(a, b, sa, sb, ra, rb)

        def support_sort_key(orig_idx, support_idx, axis_x, axis_y):
            vec = new_verts[support_idx] - self.orig_verts[orig_idx]
            if vec.length <= 1e-12:
                return 0.0
            return math.atan2(vec.dot(axis_y), vec.dot(axis_x))

        # 端点/转角封口：所有相邻面只裁角，ridge 只在这里封闭，避免飞面。
        # 关键：链条首尾端点按 Max 处理——只拿选中边两侧面的支撑点封三角端面。
        # 普通相邻面的裁角点只用于原表面重切，不再参与端头封面。
        cap_vertex_keys = set(cap_supports_by_orig.keys()) | set(selected_cap_supports_by_orig.keys())
        for vi in cap_vertex_keys:
            if vi not in selected_vertices:
                continue
            # 顶盖/底盖已经直接连接到 ridge，不再重复生成端点补面。
            if vi in ridge_connected_plain_vertices:
                continue

            inc_count = len(selected_incident_edges.get(vi, []))
            # 非 L 型的所有内部连续节点无条件禁止生成封口面。
            # 只有通过“同面相邻 + 接近 90°”双重判断的真正 L 型节点，
            # 才允许进入下面的旧版局部三角逻辑。
            if inc_count == 2 and not _is_classic_l_corner(vi):
                continue

            # Max 的首尾端点不是只用选中边两侧两个点封一个小三角。
            # 它会把端点周围已经裁角的普通相邻面支撑点一起纳入同一个端面，
            # 再让 ridge 端点只连接这个端面两端的支撑点。这样端头不会出现三角破面/内部竖线。
            support_indices = cap_supports_by_orig.get(vi, [])

            unique = []
            for idx in support_indices:
                if idx not in unique:
                    unique.append(idx)
            if len(unique) < 2:
                continue

            n = selected_vertex_normal.get(vi, Vector((0.0, 0.0, 1.0)))
            if n.length <= 1e-10:
                n = Vector((0.0, 0.0, 1.0))
            n = n.normalized()
            axis_x = None
            for idx in unique:
                v = new_verts[idx] - self.orig_verts[vi]
                if v.length > 1e-10:
                    axis_x = v - n * v.dot(n)
                    if axis_x.length > 1e-10:
                        axis_x.normalize()
                        break
            if axis_x is None or axis_x.length <= 1e-10:
                axis_x = n.cross(Vector((1.0, 0.0, 0.0)))
                if axis_x.length <= 1e-10:
                    axis_x = n.cross(Vector((0.0, 1.0, 0.0)))
                axis_x.normalize()
            axis_y = n.cross(axis_x)
            if axis_y.length <= 1e-10:
                continue
            axis_y.normalize()

            # 直线连续点不需要额外封口面；两侧斜面已经在同一个 ridge 顶点上闭合。
            # 旧版在每个内部点都扇形补三角面，所以视频里会看到内部多余面。
            inc = list(selected_incident_edges.get(vi, []))
            if len(inc) == 2:
                d0 = self.orig_verts[inc[0]] - self.orig_verts[vi]
                d1 = self.orig_verts[inc[1]] - self.orig_verts[vi]
                if d0.length > 1e-10 and d1.length > 1e-10:
                    d0.normalize()
                    d1.normalize()
                    if d0.dot(d1) < -0.965:
                        continue

            ordered = sorted(unique, key=lambda idx: support_sort_key(vi, idx, axis_x, axis_y))
            rv = ridge_vertex(vi)

            # 封口面的法线不能再用表面法线 n。
            # 正向挤出时，端头墙面法线沿“远离选中链”的方向；
            # 负向挤入时，端头墙面要朝向凹槽内部，方向正好相反。
            # 旧版用 n 做参考时，cap 面与 n 几乎垂直，add_face 无法判断正反，
            # 所以向内挤出会出现红色反法线/破面。
            cap_ref = Vector((0.0, 0.0, 0.0))
            inc_for_ref = list(selected_incident_edges.get(vi, []))
            for nb in inc_for_ref:
                d = self.orig_verts[vi] - self.orig_verts[nb]
                d = d - n * d.dot(n)
                if d.length > 1e-10:
                    cap_ref += d.normalized()
            if cap_ref.length <= 1e-10 and ordered:
                # 直线内点已经跳过；尖角或异常拓扑时，用支撑点分布兜底。
                for idx in ordered:
                    d = new_verts[idx] - self.orig_verts[vi]
                    d = d - n * d.dot(n)
                    if d.length > 1e-10:
                        cap_ref += d.normalized()
            if cap_ref.length > 1e-10:
                cap_ref.normalize()
                cap_ref *= height_sign
            else:
                cap_ref = n.copy()

            if inc_count == 2:
                # 真正 L 型 90°转角恢复旧版“外侧切角 + 局部三角连接”。
                # 其他任何角度的连续折线在上方已经跳过，绝不会进入这里。
                if len(ordered) >= 2:
                    center_dir = Vector((0.0, 0.0, 0.0))
                    for nb in selected_incident_edges.get(vi, []):
                        d = self.orig_verts[nb] - self.orig_verts[vi]
                        d = d - n * d.dot(n)
                        if d.length > 1e-10:
                            center_dir += d.normalized()
                    if center_dir.length > 1e-10:
                        center_dir.normalize()
                        scored = []
                        for idx in ordered:
                            d = new_verts[idx] - self.orig_verts[vi]
                            d = d - n * d.dot(n)
                            if d.length > 1e-10:
                                d.normalize()
                                scored.append((d.dot(center_dir), idx))
                        scored.sort()
                        pair = [idx for _, idx in scored[:2]]
                    else:
                        pair = [ordered[0], ordered[-1]]

                    if len(pair) == 2 and pair[0] != pair[1]:
                        pos = {idx: k for k, idx in enumerate(ordered)}
                        pair.sort(key=lambda idx: pos.get(idx, 0))
                        add_face([pair[0], rv, pair[1]], None, tag=True, ref_normal=cap_ref)
                continue

            # 以下只处理真正的链条首尾端点。
            # 内部转折点已经在上面跳过，因此这里恢复首尾封口不会重新带回中间多余三角面。
            # 首尾优先只使用选中边两侧的两个支撑点，强制生成一个三角端墙；
            # 只有非流形/异常拓扑拿不到两个支撑点时，才退回完整裁角链封口。
            selected_endpoint_supports = []
            for idx in selected_cap_supports_by_orig.get(vi, []):
                if idx in ordered and idx not in selected_endpoint_supports:
                    selected_endpoint_supports.append(idx)

            if inc_count == 1 and len(selected_endpoint_supports) >= 2:
                if len(selected_endpoint_supports) == 2:
                    endpoint_pair = selected_endpoint_supports
                else:
                    # 非流形兜底：从所有候选中选夹角最大的两个，代表挤出线左右两侧。
                    endpoint_pair = None
                    best_sep = -1.0
                    for i0 in range(len(selected_endpoint_supports)):
                        d0 = new_verts[selected_endpoint_supports[i0]] - self.orig_verts[vi]
                        d0 = d0 - n * d0.dot(n)
                        if d0.length <= 1e-10:
                            continue
                        d0.normalize()
                        for i1 in range(i0 + 1, len(selected_endpoint_supports)):
                            d1 = new_verts[selected_endpoint_supports[i1]] - self.orig_verts[vi]
                            d1 = d1 - n * d1.dot(n)
                            if d1.length <= 1e-10:
                                continue
                            d1.normalize()
                            sep = 1.0 - d0.dot(d1)
                            if sep > best_sep:
                                best_sep = sep
                                endpoint_pair = [selected_endpoint_supports[i0], selected_endpoint_supports[i1]]
                    if endpoint_pair is None:
                        endpoint_pair = selected_endpoint_supports[:2]

                if endpoint_pair[0] != endpoint_pair[1]:
                    add_face([endpoint_pair[0], rv, endpoint_pair[1]], None, tag=True, ref_normal=cap_ref)
                continue

            def endpoint_cap_chain():
                if len(ordered) <= 2:
                    return list(ordered)

                selected_pts = []
                for idx in selected_cap_supports_by_orig.get(vi, []):
                    if idx in ordered and idx not in selected_pts:
                        selected_pts.append(idx)

                if len(selected_pts) < 2:
                    # 边界边/非流形兜底：没有足够的选中边两侧支撑点时，
                    # 用完整裁角链做一个整体端面，至少保证不漏面。
                    return list(ordered)

                pos = {idx: k for k, idx in enumerate(ordered)}
                chain_dir = Vector((0.0, 0.0, 0.0))
                for nb in selected_incident_edges.get(vi, []):
                    d = self.orig_verts[nb] - self.orig_verts[vi]
                    d = d - n * d.dot(n)
                    if d.length > 1e-10:
                        chain_dir += d.normalized()
                if chain_dir.length > 1e-10:
                    chain_dir.normalize()

                def arc_forward(start_idx, end_idx):
                    out = []
                    k = start_idx
                    limit = len(ordered) + 1
                    while limit > 0:
                        out.append(ordered[k % len(ordered)])
                        if (k % len(ordered)) == end_idx:
                            break
                        k += 1
                        limit -= 1
                    return out

                def arc_score(arc):
                    # 选择背离选中边方向的那段支撑链；Max 的端面底边在链条首尾的外侧。
                    avg = Vector((0.0, 0.0, 0.0))
                    for idx in arc:
                        d = new_verts[idx] - self.orig_verts[vi]
                        d = d - n * d.dot(n)
                        if d.length > 1e-10:
                            avg += d.normalized()
                    if avg.length > 1e-10:
                        avg.normalize()
                    away_score = 0.0
                    if chain_dir.length > 1e-10 and avg.length > 1e-10:
                        away_score = -avg.dot(chain_dir)
                    # 同分时优先保留更多普通裁角点，避免重新退化成小三角。
                    return away_score + len(arc) * 0.025

                best_arc = None
                best_score = -1e18
                for a_i in range(len(selected_pts)):
                    for b_i in range(a_i + 1, len(selected_pts)):
                        ia = pos.get(selected_pts[a_i])
                        ib = pos.get(selected_pts[b_i])
                        if ia is None or ib is None or ia == ib:
                            continue
                        arc1 = arc_forward(ia, ib)
                        arc2 = arc_forward(ib, ia)
                        for arc in (arc1, arc2):
                            score = arc_score(arc)
                            if score > best_score:
                                best_score = score
                                best_arc = arc

                if best_arc and len(best_arc) >= 2:
                    return best_arc
                return list(ordered)

            cap_chain = endpoint_cap_chain()
            if len(cap_chain) == 2:
                add_face([cap_chain[0], rv, cap_chain[1]], None, tag=True, ref_normal=cap_ref)
            elif len(cap_chain) > 2:
                add_face(cap_chain + [rv], None, tag=True, ref_normal=cap_ref)

        face_edges = set()
        for f in new_faces:
            inds = f["verts"]
            for i in range(len(inds)):
                face_edges.add(_ekey(inds[i], inds[(i + 1) % len(inds)]))
        for a, b in self.orig_loose_edges:
            if _ekey(a, b) not in self.selected_edge_keys and _ekey(a, b) not in face_edges:
                new_edges_loose.append((a, b))

        self.last_unsupported_multi_faces = unsupported_multi_faces
        self.last_left_edge_keys = set(left_edge_keys)
        self.last_middle_edge_keys = set(middle_edge_keys)
        self.last_right_edge_keys = set(right_edge_keys)
        self.last_ridge_edge_keys = set(middle_edge_keys)
        return new_verts, new_faces, new_edges_loose, left_edge_keys, middle_edge_keys, right_edge_keys

    def rebuild_bmesh(self, bm, verts_co, faces_data, loose_edges, select_edge_keys):
        bm.clear()

        # 1.9.10：只创建最终拓扑真正引用到的顶点。
        # create_style_mesh 会以全部原顶点为索引基础生成新数据，但选中边的原端点
        # 往往已被 ridge/support 顶点完全替代。旧版仍逐个创建 verts_co，导致这些
        # 已无任何边和面连接的旧端点变成“每次挤出都会多出来的孤立点”。
        used_indices = set(self.orig_loose_verts)
        for item in faces_data:
            for idx in item.get("verts", []):
                if isinstance(idx, int) and 0 <= idx < len(verts_co):
                    used_indices.add(idx)
        for a, b in loose_edges:
            if 0 <= a < len(verts_co):
                used_indices.add(a)
            if 0 <= b < len(verts_co):
                used_indices.add(b)

        # 保持旧索引到 BMesh 顶点的映射，使面、边和左/中/右选择键无需改写。
        bm_verts = {}
        for old_idx in sorted(used_indices):
            bm_verts[old_idx] = bm.verts.new(verts_co[old_idx])
        bm.verts.ensure_lookup_table()

        created_faces = []
        for item in faces_data:
            indices = item["verts"]
            if any(i not in bm_verts for i in indices):
                continue
            try:
                f = bm.faces.new([bm_verts[i] for i in indices])
                f.material_index = item.get("material_index", 0)
                f.smooth = item.get("smooth", False)
                created_faces.append((f, item))
            except ValueError:
                pass

        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        for a, b in loose_edges:
            va = bm_verts.get(a)
            vb = bm_verts.get(b)
            if va is not None and vb is not None:
                if _edge_get(bm, va, vb) is None:
                    try:
                        bm.edges.new((va, vb))
                    except ValueError:
                        pass

        # 1.9.15：必须以 BMesh 实际生成后的 BMFace.normal 为最终依据。
        # mathutils.geometry.normal 对高度很大、宽度很小的非共面四边形，可能与
        # Blender 建面后的法向算法给出相反方向；之前只在 add_face 阶段翻面，
        # 因此拖动 Height/Width 时会有一部分面突然显示为红色反法向。
        bm.normal_update()
        flipped_any = False
        for face, item in created_faces:
            if not face.is_valid:
                continue
            ref = item.get("ref_normal")
            if ref is None:
                continue
            try:
                if ref.length <= 1e-10 or face.normal.length <= 1e-10:
                    continue
                # ref 已是单位向量；保留很小容差，避免接近退化状态时因数值噪声抖动。
                if face.normal.dot(ref) < -1e-7:
                    face.normal_flip()
                    flipped_any = True
            except Exception:
                continue
        if flipped_any:
            bm.normal_update()

        # 若某个候选面因重复面/退化面创建失败，其专用新点也不能残留。
        # 只豁免用户原模型中本来就存在的孤立点。
        orphan_verts = [
            v for old_idx, v in bm_verts.items()
            if v.is_valid
            and old_idx not in self.orig_loose_verts
            and len(v.link_edges) == 0
            and len(v.link_faces) == 0
        ]
        if orphan_verts:
            bmesh.ops.delete(bm, geom=orphan_verts, context='VERTS')

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        # 不再对整个非流形预览网格做 recalc_face_normals。
        # 向内挤出时整体重算会把凹槽端头/侧墙当成错误外壳来翻面，
        # 面的正反已经在 add_face 中按原面法线和 cap_ref 单独校正。

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()

        # 关键修复：不要再选中 tag_faces。
        # 之前即使只勾选“左边/中间”，侧面面片也会被选中，
        # bm.select_flush_mode() 会把面片边界一起选中，导致按钮组合看起来没有效果。
        for v in bm.verts:
            v.select_set(False)
        for e in bm.edges:
            e.select_set(False)
        for f in bm.faces:
            f.select_set(False)

        final_keys = set(select_edge_keys or [])
        for a, b in final_keys:
            va = bm_verts.get(a)
            vb = bm_verts.get(b)
            if va is not None and vb is not None and va.is_valid and vb.is_valid:
                e = _edge_get(bm, va, vb)
                if e and e.is_valid:
                    e.select_set(True)
                    for v in e.verts:
                        v.select_set(True)

        bm.select_flush_mode()
        bm.normal_update()

    def rebuild_original_bmesh(self, bm):
        bm.clear()
        verts = []
        for co in self.orig_verts:
            verts.append(bm.verts.new(co))
        bm.verts.ensure_lookup_table()

        for item in self.orig_faces:
            try:
                f = bm.faces.new([verts[i] for i in item["verts"]])
                f.material_index = item["material_index"]
                f.smooth = item["smooth"]
            except ValueError:
                pass

        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        for a, b in self.orig_loose_edges:
            if a < len(verts) and b < len(verts):
                if _edge_get(bm, verts[a], verts[b]) is None:
                    try:
                        bm.edges.new((verts[a], verts[b]))
                    except ValueError:
                        pass

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()
        return verts

    def select_original_edges(self, bm, verts):
        for v in bm.verts:
            v.select_set(False)
        for e in bm.edges:
            e.select_set(False)
        for f in bm.faces:
            f.select_set(False)

        for a, b in self.selected_edge_keys:
            if a < len(verts) and b < len(verts):
                e = _edge_get(bm, verts[a], verts[b])
                if e is not None:
                    e.select_set(True)
                    for v in e.verts:
                        v.select_set(True)
        bm.select_flush_mode()

    def apply_to_mesh(self, mesh, width, height, select_left=False, select_middle=True, select_right=False):
        bm = bmesh.from_edit_mesh(mesh)
        if float(width) <= 1e-12 and abs(float(height)) <= 1e-12:
            verts = self.rebuild_original_bmesh(bm)

            # 预览阶段可能会传入 False, False, False。
            # 这里不要再因为“没有勾选左/右”而自动选回原始边；
            # 只有真正要求选中中间线时，才恢复选中原边。
            if select_middle:
                self.select_original_edges(bm, verts)
            else:
                for v in bm.verts:
                    v.select_set(False)
                for e in bm.edges:
                    e.select_set(False)
                for f in bm.faces:
                    f.select_set(False)
                bm.select_flush_mode()
        else:
            verts_co, faces_data, loose_edges, left_edge_keys, middle_edge_keys, right_edge_keys = self.create_style_mesh(_larger(float(width), 0.0), float(height))
            select_edge_keys = set()
            if select_left:
                select_edge_keys.update(left_edge_keys)
            if select_middle:
                select_edge_keys.update(middle_edge_keys)
            if select_right:
                select_edge_keys.update(right_edge_keys)
            self.rebuild_bmesh(bm, verts_co, faces_data, loose_edges, select_edge_keys)

        # Width=0 且 Height=0 时会走“恢复原网格”分支。
        # 该分支通过 bm.clear() 重建了所有面，如果不主动刷新法线，
        # 编辑模式预览会继续使用已经失效的法线缓存，整个模型就会显示成黑色。
        # 放在两个分支之后统一更新，也能保证连续拖动参数时显示始终正确。
        bm.normal_update()
        bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)

    def restore_to_mesh(self, mesh):
        bm = bmesh.from_edit_mesh(mesh)
        verts = self.rebuild_original_bmesh(bm)
        self.select_original_edges(bm, verts)
        bm.normal_update()
        bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)
