# SPDX-License-Identifier: GPL-3.0-or-later
"""Geometry and mesh-building algorithms."""

from .edge_extrude_mesh import EdgeExtrudeData

__all__ = ("EdgeExtrudeData",)
