# SPDX-License-Identifier: GPL-3.0-or-later
"""Edge Extrude Blender extension entry point."""

bl_info = {
    "name": "挤出边",
    "author": "CYX",
    "version": (1, 9, 15),
    "blender": (4, 2, 0),
    "location": "Edit Mode > Right Click Menu > 挤出边",
    "description": "Extrude selected mesh edges with live width and height controls",
    "category": "Mesh",
}

import bpy

from .operators import MESH_OT_edge_extrude_float_panel
from .properties import register_properties, unregister_properties
from .ui import (
    EDGE_EXTRUDE_AddonPreferences,
    EDGE_EXTRUDE_OT_open_link,
    register_menu,
    unregister_menu,
)
from .utils import load_icons, unload_icons

_CLASSES = (
    EDGE_EXTRUDE_OT_open_link,
    EDGE_EXTRUDE_AddonPreferences,
    MESH_OT_edge_extrude_float_panel,
)


def register():
    load_icons()
    try:
        for cls in _CLASSES:
            bpy.utils.register_class(cls)
        register_properties()
        register_menu()
    except Exception:
        unregister_menu()
        unregister_properties()
        for cls in reversed(_CLASSES):
            try:
                bpy.utils.unregister_class(cls)
            except Exception:
                pass
        unload_icons()
        raise


def unregister():
    unregister_menu()
    unregister_properties()
    for cls in reversed(_CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    unload_icons()


if __name__ == "__main__":
    register()
