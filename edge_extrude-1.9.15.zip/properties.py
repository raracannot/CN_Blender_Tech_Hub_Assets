# SPDX-License-Identifier: GPL-3.0-or-later
"""Persistent scene properties used to remember the last operation values."""

import bpy
from bpy.props import BoolProperty, FloatProperty

_PROPERTY_NAMES = (
    "edge_extrude_width",
    "edge_extrude_height",
    "edge_extrude_select_left",
    "edge_extrude_select_middle",
    "edge_extrude_select_right",
)


def register_properties():
    bpy.types.Scene.edge_extrude_width = FloatProperty(
        name="Width",
        default=0.1,
        min=0.0,
        subtype="DISTANCE",
        unit="LENGTH",
        precision=4,
        step=1,
    )
    bpy.types.Scene.edge_extrude_height = FloatProperty(
        name="Height",
        default=0.0,
        soft_min=-10.0,
        subtype="DISTANCE",
        unit="LENGTH",
        precision=4,
        step=1,
    )
    bpy.types.Scene.edge_extrude_select_left = BoolProperty(
        name="左边",
        default=False,
    )
    bpy.types.Scene.edge_extrude_select_middle = BoolProperty(
        name="中间",
        default=True,
    )
    bpy.types.Scene.edge_extrude_select_right = BoolProperty(
        name="右边",
        default=False,
    )


def unregister_properties():
    for name in reversed(_PROPERTY_NAMES):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
