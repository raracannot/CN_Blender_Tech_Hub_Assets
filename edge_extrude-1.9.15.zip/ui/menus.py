# SPDX-License-Identifier: GPL-3.0-or-later
"""3D Viewport menu integration."""

import bpy

from ..operators import MESH_OT_edge_extrude_float_panel

def _draw_edge_extrude_context_menu(self, context):
    obj = context.object
    if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
        return

    layout = self.layout
    layout.operator_context = 'INVOKE_DEFAULT'

    # 放到右键菜单最上方：按钮前不加 separator，按钮后加一条分隔线。
    layout.operator(
        MESH_OT_edge_extrude_float_panel.bl_idname,
        text="挤出边",
        icon='MOD_SOLIDIFY',
    )
    layout.separator()


def register_menu():
    if hasattr(bpy.types, "VIEW3D_MT_edit_mesh_context_menu"):
        menu = bpy.types.VIEW3D_MT_edit_mesh_context_menu
        # 先移除一次，避免重复注册时菜单里出现多个“挤出边”。
        try:
            menu.remove(_draw_edge_extrude_context_menu)
        except Exception:
            pass
        # prepend 才会显示在右键菜单第一个位置；append 会追加到菜单底部。
        menu.prepend(_draw_edge_extrude_context_menu)


def unregister_menu():
    if hasattr(bpy.types, "VIEW3D_MT_edit_mesh_context_menu"):
        try:
            bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(_draw_edge_extrude_context_menu)
        except Exception:
            pass
