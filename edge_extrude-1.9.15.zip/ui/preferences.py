# SPDX-License-Identifier: GPL-3.0-or-later
"""Add-on preferences and explicitly invoked external-link actions."""

import bpy
from bpy.props import StringProperty

from ..utils.constants import REPOSITORY_URL, TUTORIAL_URL
from ..utils.icons import icon_id

ADDON_PACKAGE = __package__.rsplit(".", 1)[0]


class EDGE_EXTRUDE_OT_open_link(bpy.types.Operator):
    bl_idname = "edge_extrude.open_link"
    bl_label = "打开链接"
    bl_description = "打开插件相关链接"
    bl_options = {"INTERNAL"}

    url: StringProperty(
        name="链接",
        default="",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        if not self.url:
            self.report({"WARNING"}, "链接为空")
            return {"CANCELLED"}

        try:
            bpy.ops.wm.url_open(url=self.url)
        except Exception:
            try:
                import webbrowser
                webbrowser.open(self.url)
            except Exception as ex:
                self.report({"ERROR"}, "打开链接失败: %s" % ex)
                return {"CANCELLED"}

        return {"FINISHED"}


class EDGE_EXTRUDE_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_PACKAGE

    def draw(self, context):
        layout = self.layout

        row = layout.row(align=True)
        row.scale_y = 1.0
        split = row.split(factor=0.5, align=True)

        tutorial_row = split.row(align=True)
        tutorial_icon = icon_id("tutorial")
        if tutorial_icon:
            op = tutorial_row.operator(
                "edge_extrude.open_link",
                text="插件教程",
                icon_value=tutorial_icon,
            )
        else:
            op = tutorial_row.operator(
                "edge_extrude.open_link",
                text="插件教程",
                icon="HELP",
            )
        op.url = TUTORIAL_URL

        repository_row = split.row(align=True)
        repository_icon = icon_id("repository")
        if repository_icon:
            op = repository_row.operator(
                "edge_extrude.open_link",
                text="插件仓库",
                icon_value=repository_icon,
            )
        else:
            op = repository_row.operator(
                "edge_extrude.open_link",
                text="插件仓库",
                icon="FILE_FOLDER",
            )
        op.url = REPOSITORY_URL
