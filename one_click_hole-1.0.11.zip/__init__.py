bl_info = {
    "name": "一键布线开洞",
    "author": "CYX",
    "version": (1, 0, 11),
    "blender": (4, 0, 0),
    "location": "编辑模式 > 右键菜单 > 一键布线开洞",
    "description": "编辑模式的一键布线开洞",
    "category": "Mesh",
}

import os
import math
from collections import defaultdict, deque

import bpy
import bmesh
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.types import Operator
from bpy.props import FloatProperty, StringProperty


_EPS = 1.0e-7

_PREVIEW_COLLECTIONS = {}
_PLUGIN_TUTORIAL_URL = "https://www.bilibili.com/video/BV1wHT96VEHs/"
_PLUGIN_REPOSITORY_URL = "https://pan.quark.cn/s/341c52c3a6f4"
_ICON_FILES = {
    "tutorial": "bili.png",
    "repository": "repository.jpg",
}


def _addon_icons_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")


def _load_custom_icons():
    if _PREVIEW_COLLECTIONS.get("main") is not None:
        return

    try:
        import bpy.utils.previews
    except Exception as ex:
        print("[One Click Hole] 无法加载自定义图标预览:", ex)
        return

    pcoll = bpy.utils.previews.new()
    icons_dir = _addon_icons_dir()

    for key, filename in _ICON_FILES.items():
        icon_path = os.path.join(icons_dir, filename)
        if not os.path.exists(icon_path):
            print("[One Click Hole] 图标文件不存在:", icon_path)
            continue
        try:
            pcoll.load(key, icon_path, "IMAGE")
        except Exception as ex:
            print("[One Click Hole] 加载图标失败 %s: %s" % (icon_path, ex))

    _PREVIEW_COLLECTIONS["main"] = pcoll


def _unload_custom_icons():
    pcoll = _PREVIEW_COLLECTIONS.pop("main", None)
    if pcoll is None:
        return

    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(pcoll)
    except Exception:
        pass


def _custom_icon_id(name):
    pcoll = _PREVIEW_COLLECTIONS.get("main")
    if pcoll is None:
        return 0

    try:
        preview = pcoll.get(name)
    except Exception:
        preview = None

    if preview is None:
        return 0

    return getattr(preview, "icon_id", 0)






def _safe_normalize(v, fallback=None):
    v = v.copy()
    if v.length <= _EPS:
        return fallback.copy() if fallback is not None else Vector((0.0, 0.0, 1.0))
    v.normalize()
    return v


def _average_face_normal(faces):
    n = Vector((0.0, 0.0, 0.0))
    for f in faces:
        try:
            n += f.normal * max(f.calc_area(), _EPS)
        except Exception:
            n += f.normal
    return _safe_normalize(n, Vector((0.0, 0.0, 1.0)))


def _object_matrices(obj):

    if obj is None:
        return None, None
    mw = obj.matrix_world.copy()
    try:
        imw = mw.inverted()
    except Exception:
        imw = None
    return mw, imw


def _local_to_world(mw, co):
    if mw is None:
        return co.copy()
    return mw @ co


def _world_to_local(imw, co):
    if imw is None:
        return co.copy()
    return imw @ co


def _normal_to_world(mw, normal):

    if mw is None:
        return _safe_normalize(normal, Vector((0.0, 0.0, 1.0)))
    try:
        nmat = mw.to_3x3().inverted().transposed()
        return _safe_normalize(nmat @ normal, Vector((0.0, 0.0, 1.0)))
    except Exception:
        try:
            return _safe_normalize(mw.to_3x3() @ normal, Vector((0.0, 0.0, 1.0)))
        except Exception:
            return _safe_normalize(normal, Vector((0.0, 0.0, 1.0)))


def _world_loop_positions(loop_verts, mw):
    return [_local_to_world(mw, v.co) for v in loop_verts]


def _selected_face_islands(selected_faces):

    selected = set(selected_faces)
    islands = []

    while selected:
        first = selected.pop()
        island = [first]
        q = deque([first])
        while q:
            f = q.popleft()
            for e in f.edges:
                for lf in e.link_faces:
                    if lf in selected:
                        selected.remove(lf)
                        island.append(lf)
                        q.append(lf)
        islands.append(island)
    return islands


def _boundary_edges_from_faces(faces):
    face_set = set(faces)
    boundary = set()
    for f in faces:
        for e in f.edges:
            count = 0
            for lf in e.link_faces:
                if lf in face_set:
                    count += 1
            if count == 1:
                boundary.add(e)
    return list(boundary)


def _vertex_stable_key(v):

    idx = getattr(v, "index", -1)
    if idx is not None and idx >= 0:
        return (0, idx)
    co = getattr(v, "co", Vector((0.0, 0.0, 0.0)))
    return (1, round(co.x, 8), round(co.y, 8), round(co.z, 8))


def _rotate_loop_and_coords_to_anchor(loop, coords):

    if not loop or not coords or len(loop) != len(coords):
        return loop, coords

    anchor_i = min(range(len(loop)), key=lambda i: _vertex_stable_key(loop[i]))
    if anchor_i == 0:
        return loop, coords

    return loop[anchor_i:] + loop[:anchor_i], coords[anchor_i:] + coords[:anchor_i]


def _ordered_boundary_loop(boundary_edges):

    if len(boundary_edges) < 4:
        return None, "边界边数量不足，至少需要一个四边形区域。"

    adj = defaultdict(list)
    for e in boundary_edges:
        v1, v2 = e.verts
        adj[v1].append(v2)
        adj[v2].append(v1)



    for v in adj:
        adj[v].sort(key=_vertex_stable_key)

    bad = [v for v, ns in adj.items() if len(ns) != 2]
    if bad:
        return None, "选区边界不是单一闭合矩形环，请确认选中的面连成一个完整矩形区域。"

    start = min(adj.keys(), key=_vertex_stable_key)
    loop = [start]
    prev = None
    cur = start

    for _ in range(len(adj) + 2):
        ns = adj[cur]
        if prev is None:
            nxt = ns[0]
        else:
            nxt = ns[0] if ns[0] != prev else ns[1]

        if nxt == start:
            break
        if nxt in loop:
            return None, "边界环排序失败，可能存在交叉或分叉选区。"

        loop.append(nxt)
        prev, cur = cur, nxt

    if len(loop) != len(adj):
        return None, "检测到多个边界环，请只选择一个矩形面区域。"
    return loop, ""


def _make_plane_basis_from_points(points, normal):

    p = None
    max_len = 0.0
    count = len(points)
    for i in range(count):
        a = points[i]
        b = points[(i + 1) % count]
        d = b - a
        d = d - normal * d.dot(normal)
        if d.length > max_len:
            max_len = d.length
            p = d

    if p is None or p.length <= _EPS:
        if abs(normal.z) < 0.9:
            p = normal.cross(Vector((0.0, 0.0, 1.0)))
        else:
            p = normal.cross(Vector((0.0, 1.0, 0.0)))

    p = _safe_normalize(p, Vector((1.0, 0.0, 0.0)))
    q = _safe_normalize(normal.cross(p), Vector((0.0, 1.0, 0.0)))
    return p, q


def _make_plane_basis(loop_verts, normal):

    return _make_plane_basis_from_points([v.co.copy() for v in loop_verts], normal)


def _project_points_to_2d(points, origin, p, q):
    coords = []
    for co in points:
        d = co - origin
        coords.append((d.dot(p), d.dot(q)))
    return coords


def _project_loop_to_2d(loop_verts, origin, p, q):
    return _project_points_to_2d([v.co.copy() for v in loop_verts], origin, p, q)


def _signed_area_2d(coords):
    area = 0.0
    n = len(coords)
    for i in range(n):
        x1, y1 = coords[i]
        x2, y2 = coords[(i + 1) % n]
        area += x1 * y2 - y1 * x2
    return area * 0.5


def _polygon_centroid_2d(coords):
    area2 = 0.0
    cx = 0.0
    cy = 0.0
    n = len(coords)
    for i in range(n):
        x1, y1 = coords[i]
        x2, y2 = coords[(i + 1) % n]
        cross = x1 * y2 - x2 * y1
        area2 += cross
        cx += (x1 + x2) * cross
        cy += (y1 + y2) * cross

    if abs(area2) <= _EPS:
        sx = sum(c[0] for c in coords) / max(1, len(coords))
        sy = sum(c[1] for c in coords) / max(1, len(coords))
        return sx, sy

    return cx / (3.0 * area2), cy / (3.0 * area2)


def _dist_point_to_segment_2d(px, py, ax, ay, bx, by):
    vx = bx - ax
    vy = by - ay
    wx = px - ax
    wy = py - ay
    vv = vx * vx + vy * vy
    if vv <= _EPS:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, (wx * vx + wy * vy) / vv))
    cx = ax + vx * t
    cy = ay + vy * t
    return math.hypot(px - cx, py - cy)


def _max_inside_radius(coords, cx, cy):

    n = len(coords)
    distances = []
    for i in range(n):
        ax, ay = coords[i]
        bx, by = coords[(i + 1) % n]
        distances.append(_dist_point_to_segment_2d(cx, cy, ax, ay, bx, by))
    r = min(distances) if distances else 0.0
    if r <= _EPS:
        r = sum(math.hypot(x - cx, y - cy) for x, y in coords) / max(1, len(coords)) * 0.5
    return max(r, _EPS)


def _perimeter_lengths(coords):
    n = len(coords)
    lengths = [0.0]
    total = 0.0
    for i in range(1, n):
        x1, y1 = coords[i - 1]
        x2, y2 = coords[i]
        total += math.hypot(x2 - x1, y2 - y1)
        lengths.append(total)
    x1, y1 = coords[-1]
    x2, y2 = coords[0]
    total += math.hypot(x2 - x1, y2 - y1)
    return lengths, max(total, _EPS)






def _circle_ring_points(coords, hole_size=0.72, regular=True, angle=0.0):













    cx, cy = _polygon_centroid_2d(coords)
    max_r = _max_inside_radius(coords, cx, cy)
    radius = max_r * max(0.0, min(1.0, hole_size))

    n = len(coords)
    if n < 3:
        return []

    first_angle = math.atan2(coords[0][1] - cy, coords[0][0] - cx)

    new_coords = []
    if regular:
        step = math.tau / n
        for i in range(n):
            a = first_angle + step * i + angle
            new_coords.append((cx + math.cos(a) * radius, cy + math.sin(a) * radius))
    else:
        for x, y in coords:
            a = math.atan2(y - cy, x - cx) + angle
            new_coords.append((cx + math.cos(a) * radius, cy + math.sin(a) * radius))

    return new_coords


def _build_hole_data_for_island(obj, island, hole_size, regular, angle):
    boundary_edges = _boundary_edges_from_faces(island)
    outer_loop, err = _ordered_boundary_loop(boundary_edges)
    if not outer_loop:
        return None, err

    mw, imw = _object_matrices(obj)




    local_normal = _average_face_normal(island)
    world_normal = _normal_to_world(mw, local_normal)

    world_loop = _world_loop_positions(outer_loop, mw)
    origin_world = Vector((0.0, 0.0, 0.0))
    for co in world_loop:
        origin_world += co
    origin_world /= len(world_loop)

    p_world, q_world = _make_plane_basis_from_points(world_loop, world_normal)
    coords = _project_points_to_2d(world_loop, origin_world, p_world, q_world)


    if _signed_area_2d(coords) < 0.0:
        outer_loop.reverse()
        world_loop = list(reversed(world_loop))
        coords = list(reversed(coords))


    outer_loop, coords = _rotate_loop_and_coords_to_anchor(outer_loop, coords)

    inner_2d = _circle_ring_points(
        coords,
        hole_size=hole_size,
        regular=regular,
        angle=angle,
    )
    if len(inner_2d) != len(outer_loop):
        return None, "圆环顶点生成失败。"



    inner_world = [origin_world + p_world * x + q_world * y for x, y in inner_2d]
    inner_local = [_world_to_local(imw, co) for co in inner_world]

    return {
        "faces": list(island),
        "boundary_edges": set(boundary_edges),
        "outer_loop": list(outer_loop),
        "inner_3d": inner_local,
        "inner_world": inner_world,
        "origin": origin_world.copy(),
        "p": p_world.copy(),
        "q": q_world.copy(),
        "coords": list(coords),
        "normal": local_normal.copy(),
        "world_normal": world_normal.copy(),
        "matrix_world": mw.copy() if mw is not None else None,
        "matrix_world_inverted": imw.copy() if imw is not None else None,
    }, ""


def _clear_selection(bm):
    for f in bm.faces:
        f.select_set(False)
    for e in bm.edges:
        e.select_set(False)
    for v in bm.verts:
        v.select_set(False)


def _select_inner_edges(bm, inner_loops):
    _clear_selection(bm)
    inner_vert_set = set()
    for loop in inner_loops:
        for v in loop:
            if v.is_valid:
                v.select_set(True)
                inner_vert_set.add(v)
    for e in bm.edges:
        if e.is_valid and e.verts[0] in inner_vert_set and e.verts[1] in inner_vert_set:
            e.select_set(True)


def _force_edge_select_mode(context, bm=None):
    if bm is not None:
        try:
            bm.select_mode = {'EDGE'}
            bm.select_flush_mode()
        except Exception:
            pass
    try:
        context.tool_settings.mesh_select_mode = (False, True, False)
    except Exception:
        pass
    try:
        bpy.ops.mesh.select_mode(type='EDGE')
    except Exception:
        pass







def _build_snap_bvh_from_faces(faces, matrix=None):




    vert_map = {}
    verts = []
    polygons = []

    for f in faces:
        if not f.is_valid or f.hide:
            continue

        poly = []
        for v in f.verts:
            if not v.is_valid:
                continue
            idx = vert_map.get(v)
            if idx is None:
                idx = len(verts)
                vert_map[v] = idx
                co = v.co.copy()
                if matrix is not None:
                    co = matrix @ co
                verts.append(co)
            poly.append(idx)

        if len(poly) >= 3:
            polygons.append(poly)

    if not verts or not polygons:
        return None

    try:
        return BVHTree.FromPolygons(verts, polygons, all_triangles=False, epsilon=0.0)
    except Exception:

        tris = []
        for poly in polygons:
            if len(poly) == 3:
                tris.append(poly)
            elif len(poly) > 3:
                base = poly[0]
                for i in range(1, len(poly) - 1):
                    tris.append([base, poly[i], poly[i + 1]])
        if not tris:
            return None
        try:
            return BVHTree.FromPolygons(verts, tris, all_triangles=True, epsilon=0.0)
        except Exception:
            return None


def _snap_co_to_mesh_bvh(co, bvh):
    if bvh is None:
        return co
    try:
        hit = bvh.find_nearest(co)
        if hit and hit[0] is not None:
            return hit[0].copy()
    except Exception:
        pass
    return co







_TEMP_WRAP_PREFIX = "__OneClickHole_SnapWrap"
_TEMP_WRAP_TARGET_PREFIX = "__OneClickHole_SnapTarget"


def _get_temp_wrap(obj, mod_name=""):
    if obj is None:
        return None

    if mod_name:
        mod = obj.modifiers.get(mod_name)
        if mod and mod.type == 'SHRINKWRAP':
            return mod

    for mod in obj.modifiers:
        if mod.type == 'SHRINKWRAP' and mod.name.startswith(_TEMP_WRAP_PREFIX):
            return mod
    return None


def _safe_remove_object_and_mesh(obj):
    if obj is None:
        return

    mesh = getattr(obj, "data", None)
    try:
        bpy.data.objects.remove(obj, do_unlink=True)
    except Exception:
        pass

    if mesh is not None:
        try:
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh, do_unlink=True)
        except Exception:
            pass


def _set_modifier_attr_safe(mod, name, value):
    try:
        setattr(mod, name, value)
    except Exception:
        pass


def _move_modifier_to_top(obj, mod):
    try:
        idx = obj.modifiers.find(mod.name)
        if idx > 0:
            obj.modifiers.move(idx, 0)
    except Exception:
        pass


def _start_temp_wrap(context, obj):





    state = {
        "enabled": False,
        "mod_name": "",
        "target_name": "",
    }

    if obj is None or obj.type != 'MESH':
        return state


    if getattr(obj.data, "shape_keys", None):
        return state


    stale = _get_temp_wrap(obj)
    if stale:
        _finish_temp_wrap(context, obj, {"mod_name": stale.name}, apply=False)

    try:
        if context.mode == 'EDIT_MESH':
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    except Exception:
        pass

    try:
        obj.update_from_editmode()
    except Exception:
        pass

    try:
        target_mesh = obj.data.copy()
        target_mesh.name = f"{obj.data.name}_OCH_Snap"
        target = bpy.data.objects.new(name=f"{_TEMP_WRAP_TARGET_PREFIX}_{obj.name}", object_data=target_mesh)
        target.matrix_world = obj.matrix_world.copy()
        target.hide_select = True
        target.hide_render = True
        target.hide_viewport = True

        mod = obj.modifiers.new(name=f"{_TEMP_WRAP_PREFIX}_{obj.name}", type='SHRINKWRAP')
        mod.target = target
        mod.offset = 0.0


        _set_modifier_attr_safe(mod, "show_in_editmode", True)
        _set_modifier_attr_safe(mod, "show_on_cage", True)
        _set_modifier_attr_safe(mod, "show_viewport", True)
        _move_modifier_to_top(obj, mod)

        state["enabled"] = True
        state["mod_name"] = mod.name
        state["target_name"] = target.name
        return state

    except Exception:

        try:
            if "mod" in locals() and mod.name in obj.modifiers:
                obj.modifiers.remove(mod)
        except Exception:
            pass
        try:
            if "target" in locals():
                _safe_remove_object_and_mesh(target)
        except Exception:
            pass
        return state


def _finish_temp_wrap(context, obj, state, apply=True):




    if obj is None or obj.type != 'MESH':
        return

    state = state or {}
    mod = _get_temp_wrap(obj, state.get("mod_name", ""))
    target = None

    if mod:
        target = getattr(mod, "target", None)

    if target is None and state.get("target_name"):
        target = bpy.data.objects.get(state.get("target_name"))

    if mod is None and target is None:
        return

    was_edit = context.mode == 'EDIT_MESH'

    try:
        if was_edit:
            try:
                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            except Exception:
                pass
            bpy.ops.object.mode_set(mode='OBJECT')

        try:
            context.view_layer.objects.active = obj
            obj.select_set(True)
        except Exception:
            pass

        if mod:
            if apply:
                try:
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                except Exception:

                    try:
                        obj.modifiers.remove(mod)
                    except Exception:
                        pass
            else:
                try:
                    obj.modifiers.remove(mod)
                except Exception:
                    pass

    finally:
        if target is not None:
            _safe_remove_object_and_mesh(target)

        if was_edit:
            try:
                bpy.ops.object.mode_set(mode='EDIT')
            except Exception:
                pass





class ONE_CLICK_HOLE_OT_open_link(Operator):
    bl_idname = "one_click_hole.open_link"
    bl_label = "打开链接"
    bl_description = "打开插件相关链接"
    bl_options = {"INTERNAL"}

    url: StringProperty(
        name="链接",
        default="",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        if not self.url:
            self.report({"WARNING"}, "链接为空")
            return {"CANCELLED"}

        try:
            bpy.ops.wm.url_open(url=self.url)
        except Exception:
            try:
                import webbrowser
                webbrowser.open(self.url)
            except Exception as ex:
                self.report({"ERROR"}, "打开链接失败: %s" % ex)
                return {"CANCELLED"}

        return {"FINISHED"}


class ONE_CLICK_HOLE_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__ or __name__

    def draw(self, context):
        layout = self.layout

        row = layout.row(align=True)
        row.scale_y = 1.0
        split = row.split(factor=0.5, align=True)

        tutorial_row = split.row(align=True)
        tutorial_icon = _custom_icon_id("tutorial")
        if tutorial_icon:
            op = tutorial_row.operator(
                "one_click_hole.open_link",
                text="插件教程",
                icon_value=tutorial_icon,
            )
        else:
            op = tutorial_row.operator(
                "one_click_hole.open_link",
                text="插件教程",
                icon="HELP",
            )
        op.url = _PLUGIN_TUTORIAL_URL

        repository_row = split.row(align=True)
        repository_icon = _custom_icon_id("repository")
        if repository_icon:
            op = repository_row.operator(
                "one_click_hole.open_link",
                text="插件仓库",
                icon_value=repository_icon,
            )
        else:
            op = repository_row.operator(
                "one_click_hole.open_link",
                text="插件仓库",
                icon="FILE_FOLDER",
            )
        op.url = _PLUGIN_REPOSITORY_URL


class MESH_OT_one_click_hole(Operator):
    bl_idname = "mesh.one_click_hole"
    bl_label = "一键布线开洞"
    bl_description = "先做内插圆环，再删除洞内面；点击后移动鼠标可调整洞口大小"
    bl_options = {'REGISTER', 'UNDO'}

    hole_size: FloatProperty(
        name="洞口大小",
        description="圆洞相对当前选区边界的大小；数值越大，洞越大",
        default=0.72,
        min=0.0,
        max=1.0,
        soft_min=0.0,
        soft_max=1.0,
        subtype='FACTOR',
    )

    rotate_angle: FloatProperty(
        name="洞口旋转",
        description="微调洞口圆环顶点起始角度",
        default=0.0,
        subtype='ANGLE',
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def draw(self, context):

        layout = self.layout
        layout.prop(self, "hole_size", slider=True)
        layout.prop(self, "rotate_angle")




    def execute(self, context):



        result, _records = self._apply_hole(context, interactive=False, use_snap=True)

        if result == {'FINISHED'}:
            try:
                bm = bmesh.from_edit_mesh(context.active_object.data)
                _force_edge_select_mode(context, bm)
                bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=False)
            except Exception:
                pass

        return result




    def invoke(self, context, event):
        self._interactive_records = []
        self._backup_mesh = None
        self._snap_wrap_state = {"enabled": False, "mod_name": "", "target_name": ""}
        self._target_object_name = context.active_object.name if context.active_object else ""
        self._area = context.area
        self._start_mouse_x = event.mouse_x
        self._last_mouse_x = event.mouse_x
        self._region_width = getattr(context.region, "width", 1000) or 1000
        self._start_hole_size = max(0.0, min(1.0, float(self.hole_size)))
        self._last_hole_size = self._start_hole_size


        obj = context.active_object
        try:
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        except Exception:
            pass
        try:
            self._backup_mesh = obj.data.copy()
        except Exception:
            self._backup_mesh = None


        self._snap_wrap_state = _start_temp_wrap(context, obj)

        result, records = self._apply_hole(context, interactive=True)
        if result != {'FINISHED'}:
            _finish_temp_wrap(context, obj, self._snap_wrap_state, apply=False)
            self._remove_unused_backup()
            self._clear_header(context)
            return result

        self._interactive_records = records
        self._update_header(context)

        try:
            context.window.cursor_modal_set('MOVE_X')
        except Exception:
            pass

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':

            last_mouse_x = getattr(self, "_last_mouse_x", event.mouse_x)
            delta = event.mouse_x - last_mouse_x
            self._last_mouse_x = event.mouse_x

            sensitivity = 1.0 / max(260.0, self._region_width * 0.55)
            if getattr(event, "shift", False):
                sensitivity *= 0.18

            new_size = self._last_hole_size + delta * sensitivity
            new_size = max(0.0, min(1.0, new_size))

            if abs(new_size - self._last_hole_size) > 0.0005:
                self.hole_size = new_size
                self._last_hole_size = new_size
                self._update_interactive_geometry(context)
                self._update_header(context)
            return {'RUNNING_MODAL'}

        if event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER', 'SPACE'}:
            if event.type != 'LEFTMOUSE' or event.value == 'PRESS':
                self._finish_interactive(context)
                return {'FINISHED'}
            return {'RUNNING_MODAL'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            if event.type == 'ESC' or event.value == 'PRESS':
                self._cancel_interactive(context)
                return {'CANCELLED'}
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}

    def _apply_hole(self, context, interactive=False, use_snap=True):
        obj = context.active_object
        mesh = obj.data
        bm = bmesh.from_edit_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()

        selected_faces = [f for f in bm.faces if f.select and not f.hide]
        if len(selected_faces) < 4:
            self.report({'WARNING'}, "请至少选择 4 个面，并保证外边界是矩形。")
            return {'CANCELLED'}, []

        islands = _selected_face_islands(selected_faces)
        hole_datas = []
        errors = []
        mw, imw = _object_matrices(obj)

        for island in islands:


            snap_bvh = _build_snap_bvh_from_faces(island, mw) if use_snap else None

            data, err = _build_hole_data_for_island(
                obj,
                island,
                self.hole_size,
                True,
                self.rotate_angle,
            )
            if data is None:
                errors.append(err)
            else:
                data["snap_bvh"] = snap_bvh
                hole_datas.append(data)

        if not hole_datas:
            self.report({'WARNING'}, errors[0] if errors else "没有找到可开洞的闭合选区。")
            return {'CANCELLED'}, []


        all_delete_faces = []
        all_old_edges = set()
        all_old_verts = set()
        all_boundary_edges = set()
        all_boundary_verts = set()

        for data in hole_datas:
            all_delete_faces.extend(data["faces"])
            all_boundary_edges.update(data["boundary_edges"])
            all_boundary_verts.update(data["outer_loop"])
            for f in data["faces"]:
                all_old_edges.update(f.edges)
                all_old_verts.update(f.verts)


        bmesh.ops.delete(bm, geom=list(set(all_delete_faces)), context='FACES_ONLY')


        for e in list(all_old_edges):
            if not e.is_valid:
                continue
            if e in all_boundary_edges:
                continue
            if len(e.link_faces) == 0:
                try:
                    bm.edges.remove(e)
                except ValueError:
                    pass

        for v in list(all_old_verts):
            if not v.is_valid:
                continue
            if v in all_boundary_verts:
                continue
            if len(v.link_edges) == 0 and len(v.link_faces) == 0:
                try:
                    bm.verts.remove(v)
                except ValueError:
                    pass

        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()

        new_faces = []
        inner_loops = []
        interactive_records = []

        for data in hole_datas:
            outer = data["outer_loop"]
            normal = data["normal"]
            inner = []

            snap_bvh = data.get("snap_bvh")
            imw = data.get("matrix_world_inverted")
            inner_world_list = data.get("inner_world", [])
            inner_local_list = data.get("inner_3d", [])
            for idx, co_local in enumerate(inner_local_list):


                if idx < len(inner_world_list):
                    co_world = _snap_co_to_mesh_bvh(inner_world_list[idx], snap_bvh)
                    co_local = _world_to_local(imw, co_world)
                inner.append(bm.verts.new(co_local))
            bm.verts.ensure_lookup_table()
            inner_loops.append(inner)

            count = len(outer)
            for i in range(count):
                v1 = outer[i]
                v2 = outer[(i + 1) % count]
                v3 = inner[(i + 1) % count]
                v4 = inner[i]

                if not (v1.is_valid and v2.is_valid and v3.is_valid and v4.is_valid):
                    continue

                try:
                    f = bm.faces.new((v1, v2, v3, v4))
                except ValueError:
                    continue


                if f.normal.dot(normal) < 0.0:
                    f.normal_flip()
                new_faces.append(f)

        bm.normal_update()
        bm.verts.index_update()
        bm.edges.index_update()
        bm.faces.index_update()

        if interactive:
            for data, inner in zip(hole_datas, inner_loops):
                interactive_records.append({
                    "origin": data["origin"].copy(),
                    "p": data["p"].copy(),
                    "q": data["q"].copy(),
                    "coords": list(data["coords"]),
                    "snap_bvh": data.get("snap_bvh"),
                    "matrix_world_inverted": data.get("matrix_world_inverted"),
                    "inner_indices": [v.index for v in inner if v.is_valid],
                })


        _select_inner_edges(bm, inner_loops)
        _force_edge_select_mode(context, bm)
        bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=True)
        _force_edge_select_mode(context, None)


        return {'FINISHED'}, interactive_records

    def _update_interactive_geometry(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH' or context.mode != 'EDIT_MESH':
            return

        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()

        inner_loops = []
        for record in self._interactive_records:
            coords = record.get("coords", [])
            indices = record.get("inner_indices", [])
            if len(coords) != len(indices):
                continue

            inner_2d = _circle_ring_points(
                coords,
                hole_size=self.hole_size,
                regular=True,
                angle=self.rotate_angle,
            )
            if len(inner_2d) != len(indices):
                continue

            loop = []
            origin = record["origin"]
            p = record["p"]
            q = record["q"]
            snap_bvh = record.get("snap_bvh")
            imw = record.get("matrix_world_inverted")
            for idx, (x, y) in zip(indices, inner_2d):
                if 0 <= idx < len(bm.verts):
                    v = bm.verts[idx]
                    if v.is_valid:
                        co_world = origin + p * x + q * y
                        co_world = _snap_co_to_mesh_bvh(co_world, snap_bvh)
                        v.co = _world_to_local(imw, co_world)
                        loop.append(v)
            if loop:
                inner_loops.append(loop)

        bm.normal_update()


        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

    def _finish_interactive(self, context):
        self._clear_header(context)
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass

        obj = context.active_object

        _finish_temp_wrap(context, obj, getattr(self, "_snap_wrap_state", None), apply=False)
        self._remove_unused_backup()

        try:
            bm = bmesh.from_edit_mesh(context.active_object.data)
            _force_edge_select_mode(context, bm)
            bmesh.update_edit_mesh(context.active_object.data, loop_triangles=True, destructive=False)
        except Exception:
            pass

    def _cancel_interactive(self, context):
        self._clear_header(context)
        try:
            context.window.cursor_modal_restore()
        except Exception:
            pass

        _finish_temp_wrap(context, context.active_object, getattr(self, "_snap_wrap_state", None), apply=False)
        self._restore_backup_mesh(context)

    def _restore_backup_mesh(self, context):
        backup = getattr(self, "_backup_mesh", None)
        obj = context.active_object
        if backup is None or obj is None:
            return

        old_mesh = obj.data
        try:
            if context.mode == 'EDIT_MESH':
                bpy.ops.object.mode_set(mode='OBJECT')
            obj.data = backup
            self._backup_mesh = None
            if old_mesh.users == 0:
                bpy.data.meshes.remove(old_mesh)
            bpy.ops.object.mode_set(mode='EDIT')
        except Exception:

            self._backup_mesh = backup

    def _remove_unused_backup(self):
        backup = getattr(self, "_backup_mesh", None)
        if backup is not None:
            try:
                if backup.users == 0:
                    bpy.data.meshes.remove(backup)
            except Exception:
                pass
        self._backup_mesh = None

    def _update_header(self, context):
        area = getattr(self, "_area", None) or getattr(context, "area", None)
        if area is not None:
            try:
                area.header_text_set(
                    "洞口大小 %.2f  |  移动鼠标调整  |  Shift缓慢调整  |  左键/回车确认  |  右键/ESC取消" % self.hole_size
                )
            except Exception:
                pass

    def _clear_header(self, context):
        area = getattr(self, "_area", None) or getattr(context, "area", None)
        if area is not None:
            try:
                area.header_text_set(None)
            except Exception:
                try:
                    area.header_text_set("")
                except Exception:
                    pass






def _draw_one_click_hole_menu(self, context):
    obj = context.active_object
    if obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH':
        self.layout.separator()
        old_context = self.layout.operator_context
        self.layout.operator_context = 'INVOKE_DEFAULT'
        self.layout.operator(MESH_OT_one_click_hole.bl_idname, text="一键布线开洞")
        self.layout.operator_context = old_context


classes = (
    ONE_CLICK_HOLE_OT_open_link,
    ONE_CLICK_HOLE_AddonPreferences,
    MESH_OT_one_click_hole,
)


def register():
    _load_custom_icons()
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.prepend(_draw_one_click_hole_menu)


def unregister():
    try:
        bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(_draw_one_click_hole_menu)
    except Exception:
        pass
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    _unload_custom_icons()


if __name__ == "__main__":
    register()
