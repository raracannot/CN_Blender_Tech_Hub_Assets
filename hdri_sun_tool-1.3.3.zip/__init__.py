
bl_info = {
    "name": "HDRI_Sun_Tool",
    "author": "浪里浇花",
    "version": (1, 2, 2),
    "blender": (4, 5, 0),
    'doc_url': 'https://space.bilibili.com/382662799',
}

import bpy
import math
import os
from mathutils import Vector, Matrix

# ---------------------------------------------------------------------------
# HDRI 工具
#  - Align Sun to HDRI       : 用 mini_hdri_tool 对准最亮点（X/Z 旋转，Y=0）
#  - Match Color & Strength  : 用 HDRI 太阳处的颜色和辐照度匹配灯光
#  - 跟随 Yaw                : 背景控制节点组里的 Yaw 变化时，太阳绕世界 Z 轴同步转
#  - 面板暴露：太阳、X 轴、角度、高光可见、颜色、强度、两个渲染开关
# ---------------------------------------------------------------------------

SUN_NAME = "HDRI_Sun"
SUN_ENERGY = 3.0
SUN_ANGLE_DEG = 0.526
ADDON_HINT = "mini_hdri_tool"
SAMPLE_RADIUS = 8
STRENGTH_SCALE = 1.0
GROUP_NAME_DEFAULT = "BG_Widen"
YAW_SOCKET = "水平旋转"
SOCKET_CN = {
    "Widen": "视野",
    "Z Compress": "垂直压缩",
    "Z Knee": "地平线保护带",
    "Yaw": "水平旋转",
    "Height": "高度",
    "Horizon": "俯仰角",
}


def _find_env_image():
    scene = bpy.context.scene
    if scene.world is None or scene.world.node_tree is None:
        return None
    nt = scene.world.node_tree
    out = next((n for n in nt.nodes if n.bl_idname == "ShaderNodeOutputWorld"), None)
    if out is None or not out.inputs["Surface"].links:
        return None
    seen, stack = set(), [out]
    tex_env = tex_img = None
    while stack:
        node = stack.pop()
        if node.name in seen:
            continue
        seen.add(node.name)
        if node.bl_idname == "ShaderNodeTexEnvironment" and node.image is not None and tex_env is None:
            tex_env = node.image
        if node.bl_idname == "ShaderNodeTexImage" and node.image is not None and tex_img is None:
            tex_img = node.image
        for sock in node.inputs:
            for link in sock.links:
                stack.append(link.from_node)
    return tex_env or tex_img


def _data_path(name):
    try:
        here = os.path.dirname(os.path.abspath(__file__))
    except NameError:
        return None
    return os.path.join(here, "data", name)


def _ensure_group():
    """确保 BG_Widen 节点组存在于文件里，缺了就从插件自带的数据文件载入。"""
    grp = bpy.data.node_groups.get(GROUP_NAME_DEFAULT)
    if grp is not None:
        return grp
    path = _data_path("bg_widen.blend")
    if path is None or not os.path.exists(path):
        return None
    with bpy.data.libraries.load(path, link=False) as (src, dst):
        dst.node_groups = [n for n in src.node_groups]
    grp = next((x for x in dst.node_groups if x is not None), None)
    if grp is not None and grp.name != GROUP_NAME_DEFAULT:
        grp.name = GROUP_NAME_DEFAULT
    return grp


def _find_group_node(scene, group_name):
    """按节点组名称在世界里找背景控制节点。"""
    if scene.world is None or scene.world.node_tree is None:
        return None
    for n in scene.world.node_tree.nodes:
        if n.bl_idname == "ShaderNodeGroup" and n.node_tree is not None:
            if n.node_tree.name == group_name or n.name == group_name:
                return n
    return None


def _group_yaw(node):
    if node is None or YAW_SOCKET not in node.inputs:
        return None
    return float(node.inputs[YAW_SOCKET].default_value)


def _find_sun_pixel(image):
    """返回最亮像素坐标 (col, row)，row 以图像底部为 0。"""
    import numpy as np
    pixels, w, h = _read_pixels(image)
    if pixels is None:
        return None
    rgb = pixels[..., :3]
    lum = rgb[..., 0] * 0.2126 + rgb[..., 1] * 0.7152 + rgb[..., 2] * 0.0722
    idx = int(np.argmax(lum))
    row, col = divmod(idx, w)
    return (col, row)


def _pixel_to_dir(col, row, w, h):
    """等距柱状图像坐标 -> 世界方向（与 hdri-sun-aligner 的换算一致）。"""
    lon = (col * 2.0 * math.pi / w) - math.pi
    lat = (row * math.pi / h) - math.pi * 0.5
    cl = math.cos(lat)
    return Vector((cl * math.cos(lon), -cl * math.sin(lon), math.sin(lat)))


def _align_sun(image, sun):
    """在贴图里找最亮像素，算出方向并写到太阳灯上。返回 (像素, 方向)。"""
    pos = _find_sun_pixel(image)
    if pos is None:
        return None, None
    w, h = image.size
    d = _pixel_to_dir(pos[0], pos[1], w, h)
    sun.rotation_mode = 'XYZ'
    sun.rotation_euler = _dir_to_euler(d)
    return pos, d


def _ensure_sun(context):
    sun = bpy.data.objects.get(SUN_NAME)
    if sun is None or sun.type != 'LIGHT':
        data = bpy.data.lights.new(SUN_NAME, 'SUN')
        data.energy = SUN_ENERGY
        data.angle = math.radians(SUN_ANGLE_DEG)
        sun = bpy.data.objects.new(SUN_NAME, data)
        context.scene.collection.objects.link(sun)
    return sun


def _is_sun(ob):
    return ob is not None and ob.type == 'LIGHT' and ob.data.type == 'SUN'


def _read_pixels(image):
    import numpy as np
    w, h = image.size
    if w == 0 or h == 0:
        return None, 0, 0
    buf = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(buf)
    return buf.reshape(h, w, 4), w, h


def _sample_sun(image, pos):
    """返回 (rgb, 辐照度)。辐照度 = Σ 亮区亮度 × 像素立体角。"""
    import numpy as np
    pixels, w, h = _read_pixels(image)
    if pixels is None:
        return None, 0.0
    rgb_all = pixels[..., :3]
    lum_all = rgb_all[..., 0] * 0.2126 + rgb_all[..., 1] * 0.7152 + rgb_all[..., 2] * 0.0722

    cx, cy = int(pos[0]), int(pos[1])
    x0, x1 = max(0, cx - SAMPLE_RADIUS), min(w, cx + SAMPLE_RADIUS + 1)
    y0, y1 = max(0, cy - SAMPLE_RADIUS), min(h, cy + SAMPLE_RADIUS + 1)
    patch = rgb_all[y0:y1, x0:x1]
    lum_patch = lum_all[y0:y1, x0:x1]
    if patch.size == 0:
        return None, 0.0
    mask = lum_patch >= float(lum_patch.mean())
    if not mask.any():
        mask = np.ones_like(lum_patch, dtype=bool)
    rgb = [float(c) for c in patch[mask].mean(axis=0)]

    lat = (np.arange(h, dtype=np.float32) + 0.5) / h * math.pi - math.pi * 0.5
    omega_row = (2.0 * math.pi / w) * (math.pi / h) * np.cos(lat)
    omega = np.repeat(omega_row[:, None], w, axis=1)
    peak = float(lum_all.max())
    bright = lum_all > peak * 0.3
    irradiance = float((lum_all[bright] * omega[bright]).sum())
    return rgb, max(irradiance, 1e-4)


def _apply_color_strength(sun, rgb, irradiance):
    peak = max(rgb) if rgb else 0.0
    if peak > 1e-6:
        sun.data.color = [min(1.0, c / peak) for c in rgb]
    sun.data.energy = max(1e-4, irradiance * STRENGTH_SCALE)
    return sun.data.color[:], sun.data.energy


def _dir_to_euler(d):
    """由方向求 X/Z 欧拉角（Y 恒为 0）。"""
    d = d.normalized()
    rx = math.acos(max(-1.0, min(1.0, d.z)))
    rz = math.atan2(d.x, -d.y) if math.sin(rx) > 1e-6 else 0.0
    return (rx, 0.0, rz)


def _sun_dir(sun):
    return sun.rotation_euler.to_quaternion() @ Vector((0.0, 0.0, 1.0))


def _apply_yaw_follow(context):
    """按 Yaw 的增量绕世界 Z 轴旋转太阳。

    只做"差分"旋转：当前太阳方向 × Rz(-Δyaw)，
    因此用户手动改过的 X（仰角）、Z（方位）以及灯的 Angle 都不会被覆盖。
    """
    scene = context.scene
    props = scene.hdri_tools
    if not props.sync_yaw:
        return False
    node = _find_group_node(scene, props.group_name)
    yaw = _group_yaw(node)
    if yaw is None:
        return False
    delta = yaw - props.last_yaw
    props.last_yaw = yaw
    if abs(delta) < 1e-5 or not _is_sun(props.sun):
        return False

    d = Matrix.Rotation(math.radians(-delta), 3, 'Z') @ _sun_dir(props.sun)
    props.sun.rotation_mode = 'XYZ'
    rx, _, rz = _dir_to_euler(d)
    props.sun.rotation_euler = (rx, 0.0, rz)   # 只写 X / Z，不动 Angle
    return True


def _yaw_handler(scene, depsgraph=None):
    try:
        props = scene.hdri_tools
    except Exception:
        return
    if not props.sync_yaw:
        return
    node = _find_group_node(scene, props.group_name)
    yaw = _group_yaw(node)
    if yaw is None or abs(yaw - props.last_yaw) < 1e-5:
        return
    _apply_yaw_follow(bpy.context)


def _tag_redraw(context):
    try:
        context.view_layer.update()
    except Exception:
        pass
    screen = getattr(context, "screen", None)
    if screen is None:
        return
    for area in screen.areas:
        try:
            area.tag_redraw()
        except Exception:
            pass


def _update_world_sampling(self, context):
    w = context.scene.world
    if w is not None and w.cycles is not None:
        w.cycles.sampling_method = 'NONE' if self.world_sampling_off else 'AUTOMATIC'
        w.update_tag()
    context.scene.update_tag()
    _tag_redraw(context)


def _update_clamp_direct(self, context):
    context.scene.cycles.sample_clamp_direct = 30.0 if self.clamp_direct_30 else 0.0
    context.scene.update_tag()
    _tag_redraw(context)


def _update_sync_yaw(self, context):
    if self.sync_yaw:
        _apply_yaw_follow(context)
    _tag_redraw(context)


class HDRI_TOOLS_Props(bpy.types.PropertyGroup):
    sun: bpy.props.PointerProperty(
        name="太阳", description="被对准的太阳灯", type=bpy.types.Object,
        poll=lambda self, ob: ob.type == 'LIGHT')

    group_name: bpy.props.StringProperty(
        name="背景节点组", default=GROUP_NAME_DEFAULT,
        description="要跟随的背景控制节点组名称（按名字在世界里查找）")

    sync_yaw: bpy.props.BoolProperty(
        name="跟随水平旋转", default=False,
        description="节点组的「水平旋转」改变时，太阳绕世界 Z 轴同步旋转", update=_update_sync_yaw)

    base_dir: bpy.props.FloatVectorProperty(
        name="基准方向", size=3, default=(0.0, 0.0, 1.0),
        description="Yaw = 0 时太阳的方向，跟随 Yaw 时以此为基准旋转")

    last_yaw: bpy.props.FloatProperty(name="上次 Yaw", default=-1e9)

    world_sampling_off: bpy.props.BoolProperty(
        name="环境采样 = 无", default=False, update=_update_world_sampling)

    clamp_direct_30: bpy.props.BoolProperty(
        name="直接光钳制 = 30", default=False, update=_update_clamp_direct)


class WORLD_OT_align_sun_to_hdri(bpy.types.Operator):
    bl_idname = "world.align_sun_to_hdri"
    bl_label = "Align Sun to HDRI"
    bl_description = "对准 HDRI 最亮点，并匹配颜色与强度（X/Z 旋转，Y 恒为 0）"

    match_light: bpy.props.BoolProperty(name="同时匹配颜色与强度", default=True)

    def execute(self, context):
        image = _find_env_image()
        if image is None:
            self.report({'ERROR'}, "世界节点里没找到环境贴图")
            return {'CANCELLED'}
        props = context.scene.hdri_tools
        sun = props.sun if _is_sun(props.sun) else _ensure_sun(context)
        sun.rotation_mode = 'XYZ'
        pos, d = _align_sun(image, sun)
        if pos is None:
            self.report({'ERROR'}, "环境贴图里找不到亮点")
            return {'CANCELLED'}

        sun.rotation_euler = _dir_to_euler(_sun_dir(sun))
        props.sun = sun
        props.base_dir = _sun_dir(sun)
        node = _find_group_node(context.scene, props.group_name)
        props.last_yaw = _group_yaw(node) or 0.0
        _apply_yaw_follow(context)

        msg = "已对齐 %s" % sun.name
        if self.match_light:
            rgb, irr = _sample_sun(image, pos)
            if rgb:
                col, energy = _apply_color_strength(sun, rgb, irr)
                msg += "，颜色 (%.2f, %.2f, %.2f)，强度 %.3f" % (col[0], col[1], col[2], energy)

        # 一并对齐后自动打开三个开关
        props.world_sampling_off = True
        props.clamp_direct_30 = True
        props.sync_yaw = True
        _tag_redraw(context)
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class WORLD_OT_match_sun_light(bpy.types.Operator):
    bl_idname = "world.match_sun_light"
    bl_label = "Match Color & Strength"
    bl_description = "按 HDRI 太阳处的颜色和亮度，设置太阳灯的颜色与强度"

    def execute(self, context):
        image = _find_env_image()
        if image is None:
            self.report({'ERROR'}, "世界节点里没找到环境贴图")
            return {'CANCELLED'}
        props = context.scene.hdri_tools
        sun = props.sun if _is_sun(props.sun) else _ensure_sun(context)
        pos = _find_sun_pixel(image)
        if pos is None:
            self.report({'ERROR'}, "环境贴图里找不到亮点")
            return {'CANCELLED'}
        rgb, irr = _sample_sun(image, pos)
        if not rgb:
            self.report({'ERROR'}, "采样失败")
            return {'CANCELLED'}
        col, energy = _apply_color_strength(sun, rgb, irr)
        props.sun = sun
        _tag_redraw(context)
        self.report({'INFO'}, "颜色 (%.2f, %.2f, %.2f)，强度 %.3f" % (col[0], col[1], col[2], energy))
        return {'FINISHED'}


class WORLD_OT_add_bg_group(bpy.types.Operator):
    bl_idname = "world.add_bg_group"
    bl_label = "Add Background Group"
    bl_description = "把背景控制节点组接在已选中的环境纹理前面（需先在节点编辑器里选中环境纹理）"

    def execute(self, context):
        world = context.scene.world
        if world is None or world.node_tree is None:
            self.report({'ERROR'}, "当前场景没有世界节点树")
            return {'CANCELLED'}
        nt = world.node_tree

        env = next((n for n in nt.nodes
                    if n.bl_idname == "ShaderNodeTexEnvironment" and n.select), None)
        if env is None:
            self.report({'ERROR'}, "请先在 World 节点编辑器里选中一个环境纹理")
            return {'CANCELLED'}

        group = _ensure_group()
        if group is None:
            self.report({'ERROR'}, "找不到节点组 %s，插件里也没有附带数据文件" % GROUP_NAME_DEFAULT)
            return {'CANCELLED'}

        existing = next((n for n in nt.nodes
                         if n.bl_idname == "ShaderNodeGroup" and n.node_tree == group), None)
        if existing is not None:
            for n in nt.nodes:
                n.select = False
            existing.select = True
            nt.nodes.active = existing
            self.report({'INFO'}, "节点组已存在：%s" % existing.name)
            return {'FINISHED'}

        # 环境纹理原来的输入源；没有就退回 TexCoord.Generated
        src = env.inputs["Vector"].links[0].from_socket if env.inputs["Vector"].links else None
        if src is None:
            texco = next((n for n in nt.nodes if n.bl_idname == "ShaderNodeTexCoord"), None)
            if texco is None:
                texco = nt.nodes.new("ShaderNodeTexCoord")
                texco.location = (env.location.x - 600, env.location.y - 200)
            src = texco.outputs["Generated"]

        node = nt.nodes.new("ShaderNodeGroup")
        node.node_tree = group
        node.name = GROUP_NAME_DEFAULT
        node.label = "HDRI 背景控制"
        node.location = (env.location.x - 260, env.location.y)
        node.width = 200

        for l in list(env.inputs["Vector"].links):
            nt.links.remove(l)
        for l in list(node.inputs["Vector"].links):
            nt.links.remove(l)
        nt.links.new(src, node.inputs["Vector"])
        nt.links.new(node.outputs["Vector"], env.inputs["Vector"])

        for name, value in (("视野", 1.0), ("垂直压缩", 1.0), ("地平线保护带", 0.5),
                            ("水平旋转", 0.0), ("高度", 0.0), ("俯仰角", 0.0)):
            if name in node.inputs:
                node.inputs[name].default_value = value

        for n in nt.nodes:
            n.select = False
        node.select = True
        nt.nodes.active = node
        context.scene.hdri_tools.group_name = GROUP_NAME_DEFAULT
        self.report({'INFO'}, "已插入 %s（接在 %s 前面）" % (node.name, env.name))
        return {'FINISHED'}


class WORLD_PT_hdri_tools(bpy.types.Panel):
    bl_label = "HDRI 工具"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "world"

    def draw(self, context):
        layout = self.layout
        props = context.scene.hdri_tools

        box = layout.box()
        box.label(text="太阳:")
        col = box.column(align=True)
        col.operator("world.align_sun_to_hdri", text="太阳对准 HDRI", icon='LIGHT_SUN')
        col.operator("world.match_sun_light", text="匹配颜色与强度", icon='COLOR')

        layout.separator(factor=3.0)
        layout.operator("world.add_bg_group", text="添加背景控制节点组", icon='NODETREE')
        layout.separator(factor=2.0)
        col = layout.column(align=True)

        col.prop(props, "sun", text="太阳")
        sun = props.sun
        if _is_sun(sun):
            col.prop(sun, "rotation_euler", index=0, text="X 轴")
            col.prop(sun.data, "angle", text="角度")
            col.prop(sun.data, "color", text="颜色")
            col.prop(sun.data, "energy", text="强度")
            env_node = _find_group_node(context.scene, props.group_name)
            if env_node is not None and YAW_SOCKET in env_node.inputs:
                col.prop(env_node.inputs[YAW_SOCKET], "default_value", text="水平旋转")
            col.separator()
            col.prop(sun, "visible_glossy", text="高光中可见 (Glossy)")
        else:
            col.label(text="未选择太阳灯", icon='INFO')

        # 这三个是场景级开关，跟有没有太阳无关，始终显示
        col.prop(props, "world_sampling_off")
        col.prop(props, "clamp_direct_30")
        col.prop(props, "sync_yaw")

        col.separator()
        col.label(text="环境跟随:")
        col.prop(props, "group_name", text="节点组")
        node = _find_group_node(context.scene, props.group_name)
        if node is not None:
            col.label(text="已找到 %s" % node.name, icon='CHECKMARK')
        else:
            col.label(text="未找到该节点组", icon='ERROR')

_classes = (HDRI_TOOLS_Props, WORLD_OT_align_sun_to_hdri, WORLD_OT_match_sun_light,
            WORLD_OT_add_bg_group, WORLD_PT_hdri_tools)


def register():
    for cls in _classes:
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hdri_tools = bpy.props.PointerProperty(type=HDRI_TOOLS_Props)
    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") == "_yaw_handler":
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_yaw_handler)
    print("[HDRI] 已注册：World 属性 -> HDRI 工具（含 Yaw 跟随）")



def unregister():
    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") == "_yaw_handler":
            try:
                bpy.app.handlers.depsgraph_update_post.remove(h)
            except Exception:
                pass
    if hasattr(bpy.types.Scene, "hdri_tools"):
        try:
            del bpy.types.Scene.hdri_tools
        except Exception:
            pass
    for cls in reversed(_classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
