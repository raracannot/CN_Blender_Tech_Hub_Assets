# -*- coding: utf-8 -*-

bl_info = {
    "name": "插件启动耗时分析",
    "author": "Shuime",
    "version": (1, 0, 1),
    "blender": (3, 0, 0),
    "location": "编辑 > 偏好设置 > 插件",
    "description": "无需修改Blender本体源代码，记录插件启用耗时。",
    "warning": "会在用户脚本目录的 scripts/startup 下写入/删除一个临时补丁脚本，安全、可删除。",
    "doc_url": "",
    "category": "Development",
}

import bpy
import os
import addon_utils
from bpy.props import StringProperty, FloatVectorProperty, CollectionProperty, FloatProperty, BoolProperty
from bpy.types import Operator, AddonPreferences, PropertyGroup

# 会话命名空间键（仅当前 Blender 会话有效，不写入磁盘）
TIME_NS_KEY = 'TIME_PROFILER_RECORDS'

# ------------------------------------
# 路径与补丁脚本工具
# ------------------------------------


def get_user_startup_dir():
    # 用户脚本目录，例如：%APPDATA%/Blender Foundation/Blender/3.x/scripts/startup
    base = bpy.utils.user_resource('SCRIPTS', path="", create=True)
    startup_dir = os.path.join(base, "startup")
    os.makedirs(startup_dir, exist_ok=True)
    return startup_dir


def get_patch_file_path():
    return os.path.join(get_user_startup_dir(), "_addon_enable_time_profiler.py")


def write_patch_file():
    # 使用模块内部存储，避免被 .blend 文件覆盖
    patch_code = """
# 由 插件启动耗时分析器（Monkey-Patch 版） 自动生成
# 启动时对 addon_utils.enable 进行计时记录（使用模块内部存储）
import time
import bpy
import addon_utils
from bpy.app.handlers import persistent

# 使用模块内部变量存储，避免被 .blend 文件的 driver_namespace 覆盖
RECORDS = []
# 标记是否已经开始记录，避免重复清空
_RECORDING_STARTED = False

_old_enable = addon_utils.enable

def _profiled_enable(*args, **kwargs):
    global _RECORDING_STARTED
    # 第一次调用时清空记录，确保每次启动都是新的计时会话
    if not _RECORDING_STARTED:
        RECORDS.clear()
        _RECORDING_STARTED = True
    
    t0 = time.time()
    # 兼容 Blender 4.5+：enable 可能新增关键字参数（如 refresh_handled），故使用通配参数
    module_name = args[0] if args else kwargs.get('module_name', 'UNKNOWN')
    try:
        return _old_enable(*args, **kwargs)
    finally:
        elapsed = time.time() - t0
        try:
            RECORDS.append((elapsed, module_name))
        except Exception:
            pass
        # 如需调试时查看，可取消下行注释
        # print(f"[计时分析] 耗时: {elapsed:.4f}s | {module_name}")

@persistent
def _reset_recording_flag(dummy):
    \"\"\"文件加载后重置记录标志，为下次启动做准备\"\"\"
    global _RECORDING_STARTED
    _RECORDING_STARTED = False

# 符合 Blender 4.5+ 对启动脚本的要求：提供 register/unregister
def register():
    try:
        addon_utils.enable = _profiled_enable
        # 注册文件加载后的标志重置处理器
        if _reset_recording_flag not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_reset_recording_flag)
    except Exception:
        pass

def unregister():
    try:
        addon_utils.enable = _old_enable
        # 移除处理器
        if _reset_recording_flag in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_reset_recording_flag)
    except Exception:
        pass

# 立即应用补丁
addon_utils.enable = _profiled_enable
# 注册处理器
if _reset_recording_flag not in bpy.app.handlers.load_post:
    bpy.app.handlers.load_post.append(_reset_recording_flag)
"""
    with open(get_patch_file_path(), 'w', encoding='utf-8') as f:
        f.write(patch_code)


def remove_patch_file():
    p = get_patch_file_path()
    if os.path.exists(p):
        os.remove(p)


def is_patch_installed():
    """检查补丁文件是否已安装"""
    return os.path.exists(get_patch_file_path())


# ------------------------------------
# 操作：启用/禁用 补丁 & 打开目录
# ------------------------------------
class TIMEPROFILER_OT_EnablePatch(Operator):
    bl_idname = "time_profiler.enable_patch"
    bl_label = "启用计时补丁 (写入启动脚本)"
    bl_description = "在用户 scripts/startup 目录写入补丁脚本，重启 Blender 后生效"

    def execute(self, context):
        try:
            write_patch_file()
            self.report({'INFO'}, f"已写入补丁脚本: {get_patch_file_path()}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"写入补丁失败: {e}")
            return {'CANCELLED'}


class TIMEPROFILER_OT_DisablePatch(Operator):
    bl_idname = "time_profiler.disable_patch"
    bl_label = "禁用计时补丁 (移除启动脚本)"
    bl_description = "从用户 scripts/startup 目录删除补丁脚本"

    def execute(self, context):
        try:
            remove_patch_file()
            self.report({'INFO'}, "已移除补丁脚本。")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"移除补丁失败: {e}")
            return {'CANCELLED'}


class TIMEPROFILER_OT_OpenStartupFolder(Operator):
    bl_idname = "time_profiler.open_startup_folder"
    bl_label = "打开启动脚本目录"
    bl_description = "打开用户 scripts/startup 目录"

    def execute(self, context):
        folder = get_user_startup_dir()
        bpy.ops.wm.path_open(filepath=folder)
        return {'FINISHED'}


# 已移除：磁盘日志功能废弃，故不再提供“打开日志文件夹”操作符。


# ------------------------------------
# 数据模型 & 偏好设置 UI
# ------------------------------------
class TIMEPROFILER_ReportItem(PropertyGroup):
    time_str: StringProperty()
    name_str: StringProperty()
    color: FloatVectorProperty(subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.7, 0.7, 0.7))
    # 新增：用于分组与排序的原始数值（秒）
    time_value: FloatProperty(default=0.0)


class TimeProfilerAddonPreferences(AddonPreferences):
    bl_idname = __name__

    report_items: CollectionProperty(type=TIMEPROFILER_ReportItem)
    # 更新默认提示语：打开偏好设置即自动展示报告
    header_str: StringProperty(default="打开偏好设置即自动展示本会话报告。首次需启用补丁并重启 Blender。")

    # 桶标题颜色（仅用于展示，不保存到文件）
    col_crit: FloatVectorProperty(subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 0.0, 0.0), options={'HIDDEN'})
    col_high: FloatVectorProperty(subtype='COLOR', size=3, min=0.0, max=1.0, default=(1.0, 1.0, 0.0), options={'HIDDEN'})
    col_medium: FloatVectorProperty(subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.0, 1.0, 0.6), options={'HIDDEN'})
    col_low: FloatVectorProperty(subtype='COLOR', size=3, min=0.0, max=1.0, default=(0.0, 1.0, 1.0), options={'HIDDEN'})
    
    # 折叠面板状态
    show_minimal_items: BoolProperty(
        name="显示低耗时插件",
        description="显示/隐藏耗时低于0.05秒的插件",
        default=False
    )

    # 在绘制 UI 前从补丁模块中填充报告数据
    def _populate_report_from_memory(self):
        recs = []
        try:
            # 优先从补丁模块的内部存储读取数据
            import sys
            patch_module_name = '_addon_enable_time_profiler'
            if patch_module_name in sys.modules:
                patch_module = sys.modules[patch_module_name]
                if hasattr(patch_module, 'RECORDS'):
                    recs = list(patch_module.RECORDS)
            
            # 如果补丁模块数据为空，回退到旧的 driver_namespace 方式
            if not recs:
                recs = list(bpy.app.driver_namespace.get(TIME_NS_KEY) or [])
        except Exception:
            recs = []
        if not recs:
            version_str = ".".join(map(str, bpy.app.version))
            if len(self.report_items) > 0:
                # 不重新计时时保留上一次启动的结果，避免界面被清空
                self.header_str = f"Blender {version_str} 启动耗时报告报告（保留上次启动结果；打开工程不会重新计时）。如需重计，请重启 Blender。"
            else:
                self.header_str = f"Blender {version_str} 启动耗时报告报告（本会话内存，关闭后清空）。若为空，请启用补丁并重启 Blender。"
            return
        try:
            unique_addons = {}
            # 构建 module_id -> 可读名称 映射（优先 bl_info['name']）
            name_map = {}
            try:
                for mod in addon_utils.modules():
                    try:
                        blinfo = getattr(mod, 'bl_info', {}) or {}
                        display = blinfo.get('name') or getattr(mod, '__name__', '') or ''
                        candidates = set()
                        mn = getattr(mod, '__name__', '') or ''
                        if mn:
                            candidates.add(mn)
                            candidates.add(mn.split('.')[0])
                        pkg = getattr(mod, '__package__', '') or ''
                        if pkg:
                            candidates.add(pkg)
                            candidates.add(pkg.split('.')[0])
                        f = getattr(mod, '__file__', '') or ''
                        if f:
                            folder = os.path.basename(os.path.dirname(f))
                            if folder:
                                candidates.add(folder)
                        for cid in candidates:
                            name_map[cid] = display
                    except Exception:
                        pass
            except Exception:
                pass

            for item in recs:
                try:
                    elapsed, name_part = item
                except Exception:
                    continue
                try:
                    elapsed_time = float(elapsed)
                except Exception:
                    continue

                module_id = str(name_part)
                # 解析人类可读名称
                display_name = (
                    name_map.get(module_id)
                    or name_map.get(module_id.split('.')[0])
                    or module_id
                )
                if display_name == module_id:
                    # 兜底：将下划线/短横转换为空格
                    display_name = display_name.replace('_', ' ').replace('-', ' ')

                if module_id not in unique_addons or elapsed_time > unique_addons[module_id][0]:
                    unique_addons[module_id] = (elapsed_time, f"{elapsed_time:.4f}秒", display_name)

            processed_list = [(data[0], data[1], data[2]) for _, data in unique_addons.items()]
            processed_list.sort(key=lambda x: x[0], reverse=True)

            version_str = ".".join(map(str, bpy.app.version))
            self.header_str = f"Blender {version_str} 启动耗时报告 (共 {len(processed_list)} 个插件)"
            self.report_items.clear()

            for elapsed_time, time_str, name_str in processed_list:
                item = self.report_items.add()
                item.time_str = time_str
                item.name_str = name_str
                # 保存数值用于 UI 分组
                item.time_value = float(elapsed_time)

                color_val = (0.7, 0.7, 0.7)
                if elapsed_time >= 3.0:
                    color_val = (1.0, 0.0, 1.0)
                elif elapsed_time >= 1.0:
                    color_val = (1.0, 0.0, 0.0)
                elif elapsed_time >= 0.5:
                    color_val = (1.0, 1.0, 0.0)
                elif elapsed_time >= 0.2:
                    color_val = (0.0, 0.7, 1.0)
                elif elapsed_time >= 0.05:
                    color_val = (0.0, 1.0, 0.0)
                item.color = color_val
        except Exception as e:
            self.report_items.clear()
            self.header_str = f"读取或解析内存数据时出错: {e}"

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        # 自动填充报告（进入偏好设置即展示）
        self._populate_report_from_memory()

        box = layout.box()
        col = box.column(align=True)
        col.label(text="计时补丁", icon='MOD_TIME')
        
        # 检测补丁安装状态并显示提示
        patch_installed = is_patch_installed()
        status_row = col.row(align=True)
        if patch_installed:
            status_row.label(text="✓ 补丁已安装，重启 Blender 后生效", icon='CHECKMARK')
        else:
            status_row.label(text="⚠ 补丁未安装，需要启用补丁并重启 Blender", icon='ERROR')
        
        row = col.row(align=True)
        # 根据补丁状态调整按钮可用性
        if not patch_installed:
            row.operator("time_profiler.enable_patch", icon='CHECKMARK', text="启用计时补丁")
        else:
            # 补丁已安装时显示灰色按钮
            sub_row = row.row(align=True)
            sub_row.enabled = False
            sub_row.operator("time_profiler.enable_patch", icon='CHECKMARK', text="启用计时补丁")
        
        if patch_installed:
            row.operator("time_profiler.disable_patch", icon='X', text="删除计时补丁（无残留）")
        else:
            # 补丁未安装时显示灰色按钮
            sub_row = row.row(align=True)
            sub_row.enabled = False
            sub_row.operator("time_profiler.disable_patch", icon='X', text="删除计时补丁（无残留）")
        
        row.operator("time_profiler.open_startup_folder", icon='FILEBROWSER', text="打开启动目录")


        # 报告区域
        box2 = layout.box()
        header_row = box2.row()
        total_count = len(self.report_items)
        
        # 计算总耗时
        total_time = sum(item.time_value for item in self.report_items)
        total_time_str = f"{total_time:.3f}秒" if total_time < 10 else f"{total_time:.2f}秒"
        
        header_row.label(text=self.header_str or f"启动耗时报告 (共 {total_count} 个插件)", icon='GRAPH')
        # 在右侧显示总耗时
        header_row.separator()
        header_row.label(text=f"总耗时: {total_time_str}", icon='TIME')
        # 移除"加载/刷新报告"按钮，改为自动展示

        # 分四列展示：>=1.0秒（红）、>=0.5秒（黄）、>=0.2秒（绿/青）、>=0.05秒（青）
        # 低于0.05秒的插件单独放在底部折叠区域
        buckets = {
            'critical': [it for it in self.report_items if it.time_value >= 1.0],
            'high': [it for it in self.report_items if 0.5 <= it.time_value < 1.0],
            'medium': [it for it in self.report_items if 0.2 <= it.time_value < 0.5],
            'low': [it for it in self.report_items if 0.05 <= it.time_value < 0.2],
            'minimal': [it for it in self.report_items if it.time_value < 0.05],
        }
        # 排序：每个桶内从大到小
        for k in buckets:
            buckets[k] = sorted(buckets[k], key=lambda x: x.time_value, reverse=True)

        row_cols = box2.row(align=True)
        # 根据区域宽度自适应时间列的占比，尽量保证耗时文本不被折叠
        try:
            _region_w = context.region.width
        except Exception:
            _region_w = 600
        # 目标像素宽度（耗时文本区），并限制占比范围
        time_col_px = 140  # 进一步增加目标宽度，确保时间文本有充足空间
        # 计算理想占比，但设置更合理的最小值和最大值
        ideal_factor = time_col_px / max(_region_w, 1)
        time_factor = max(0.5, min(0.7, ideal_factor))  # 显著提高最小占比到0.35，最大占比到0.7
        
        # 当窗口很小时，优先保证时间列的最小可用宽度
        if _region_w < 400:
            time_factor = max(0.45, time_factor)  # 小窗口下大幅提高最小占比到0.45

        def draw_bucket(col, title, items, color_attr_name):
            b = col.box()
            
            # 计算该分区的总耗时
            bucket_total_time = sum(item.time_value for item in items)
            bucket_time_str = f"{bucket_total_time:.3f}秒" if bucket_total_time < 10 else f"{bucket_total_time:.2f}秒"
            
            # 在色块顶部单独显示小计（始终显示，没有插件时显示0秒）
            summary_row = b.row(align=True)
            summary_row.scale_y = 0.7
            summary_row.label(text=f"小计: {bucket_time_str}")
            
            # 颜色条作为列头视觉标识
            color_bar = b.row(align=True)
            color_bar.scale_y = 0.6
            # 使用偏好设置里的颜色属性绘制色条（只读）
            color_bar.prop(self, color_attr_name, text="")
            color_bar.enabled = False
            
            # 标题 + 数量
            h = b.row(align=True)
            h.label(text=f"{title}（{len(items)}）")
            
            # 列表（紧凑布局：用 split 控制时间列占比，避免名称被截断）
            for it in items:
                r = b.row(align=True)
                sp = r.split(factor=time_factor, align=True)
                left = sp.column()
                right = sp.column(align=True)
                right.alignment = 'RIGHT'
                left.label(text=it.time_str)
                right.separator(factor=0.5)
                right.label(text=it.name_str)

        # 使用split确保四列等宽分布
        split1 = row_cols.split(factor=0.25, align=True)
        col1 = split1.column(align=True)
        draw_bucket(col1, "≥ 1.0秒", buckets['critical'], "col_crit")
        
        split2 = split1.split(factor=0.333, align=True)  # 剩余75%的1/3
        col2 = split2.column(align=True)
        draw_bucket(col2, "≥ 0.5秒", buckets['high'], "col_high")
        
        split3 = split2.split(factor=0.5, align=True)  # 剩余50%的1/2
        col3 = split3.column(align=True)
        draw_bucket(col3, "≥ 0.2秒", buckets['medium'], "col_medium")
        
        col4 = split3.column(align=True)  # 最后剩余的25%
        draw_bucket(col4, "≥ 0.05秒", buckets['low'], "col_low")

        # 底部折叠区域：显示低于0.05秒的插件
        if buckets['minimal']:  # 只有当存在低耗时插件时才显示
            minimal_box = box2.box()
            
            # 计算低耗时插件的总耗时
            minimal_total_time = sum(item.time_value for item in buckets['minimal'])
            minimal_time_str = f"{minimal_total_time:.3f}秒" if minimal_total_time < 10 else f"{minimal_total_time:.2f}秒"
            
            # 小计行
            summary_row = minimal_box.row(align=True)
            summary_row.scale_y = 0.7
            summary_row.label(text=f"小计: {minimal_time_str}")
            
            # 折叠面板头部
            header_row = minimal_box.row(align=True)
            # 折叠图标和标题
            icon = 'DOWNARROW_HLT' if self.show_minimal_items else 'RIGHTARROW'
            header_row.prop(self, "show_minimal_items", text="", icon=icon, emboss=False)
            header_row.label(text=f"< 0.05秒 低耗时插件（{len(buckets['minimal'])}）")
            
            # 展开时显示插件列表
            if self.show_minimal_items:
                # 使用紧凑的多列布局来节省空间
                items_per_row = 3  # 每行显示3个插件
                minimal_items = buckets['minimal']
                
                for i in range(0, len(minimal_items), items_per_row):
                    row_items = minimal_items[i:i + items_per_row]
                    item_row = minimal_box.row(align=True)
                    
                    for j, item in enumerate(row_items):
                        if j > 0:
                            item_row.separator()
                        # 时间和名称在同一行，紧凑显示
                        item_col = item_row.column(align=True)
                        item_col.scale_y = 0.8  # 稍微压缩行高
                        item_col.label(text=f"{item.time_str} - {item.name_str}")
                    
                    # 如果这一行没有填满，添加空白列来保持对齐
                    for _ in range(items_per_row - len(row_items)):
                        item_row.column()


# ------------------------------------
# 注册/注销
# ------------------------------------
classes = (
    TIMEPROFILER_ReportItem,
    TIMEPROFILER_OT_EnablePatch,
    TIMEPROFILER_OT_DisablePatch,
    TIMEPROFILER_OT_OpenStartupFolder,
    # 刷新按钮与操作符已移除，不再注册 TIMEPROFILER_OT_FetchReport
    TimeProfilerAddonPreferences,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()