# N Panel Manager（N 面板管理）

一个用于管理 Blender 侧边栏（N 面板）的扩展：**按插件隐藏面板**，并把多个标签**合并成一个面板**。插件本身不占用侧边栏标签，所有设置都在「偏好设置 → 插件 → N Panel Manager」或 3D 视图的「视图 / 物体」菜单里。

---

## 一、它解决什么问题

N 面板越装越长：几十个插件各占一个标签，常用的一两个反而要来回找。这个扩展做两件事：

1. **隐藏**：不用的插件整组收起，侧边栏只留你要的；
2. **合并**：把多个插件的标签并到一个标签里。

---

## 二、两种合并逻辑（重点）

### 逻辑 A：纯第三方合并 —— 「切换栏」模式

成员全部是第三方插件（例如 `MP7`、`HWE`、`线程`）时：

```
┌─ 自定义面板名 ─────────────────┐
│ ▾ 切换                          │
│   [ MP7 ] [ HWE ] [ 线程 ]      │  ← 点谁显示谁
│ ▾ MP7 Tools                     │
│     …MP7 的面板内容…            │
└────────────────────────────────┘
```

- 顶部出现一栏「切换」，按成员名切换；
- **同一时刻只显示当前成员的面板**（其他成员的代理面板 `poll=False`，不绘制）；
- 适合“这些插件不同时用”的场景，侧边栏最省地方。

### 逻辑 B：原生标签作宿主 —— 「堆叠」模式

成员里只要包含**原生标签**（例如 Blender 自带的 `动画`、`条目`、`视图`），逻辑自动切换：

```
┌─ 动画（原生标签）──────────────┐
│ 全局变换                         │  ← 原生面板，原样保留
│   复制 / 粘贴 / 镜像 …          │
│ ▾ 布尔                           │  ← 第三方面板，自动堆到下面
│   自动布尔 / 笔刷布尔运算       │
│ ▾ 简易集合开关                   │
│   …                             │
└────────────────────────────────┘
```

- **不生成切换栏**：原生标签本来就是多面板并列，不需要切换；
- 第三方成员的面板全部**常驻堆叠**在原生面板下方，顺序 = 你勾选成员的顺序；
- 不会试图隐藏原生标签（原生面板大多隐藏不掉，硬藏还会崩），只是把内容垫到它下面；
- 原生标签自己的面板顺序完全不动。

### 补充：「一级菜单」开关

设置里有 `一级菜单` 开关：

- **关（默认）**：按上面 A/B 自动选择模式；
- **开**：所有合并组都变成“堆叠、无切换栏”，全部成员常驻显示，像一层扁平菜单。

### 合并标签的排序

- 默认按**添加顺序**排列（新建的排在最后）；
- 每组右侧 `▲ ▼` 可手动上/下移；
- 合并标签统一排在原生标签之后，**原生标签之间的顺序不会被改动**。

---

## 三、使用步骤

### 1. 打开设置

- `偏好设置 → 插件 → N Panel Manager`（完整列表，可滚动）
- 或 `3D 视图 → 视图菜单 / 物体菜单 → “N 面板管理…”`（左右两栏浮动面板）

### 2. 隐藏插件面板

「隐藏插件面板」区按**两列**列出所有带 N 面板的插件（插件名，不带数量）：

```
☑ 3D Viewport Pie Menus    ☑ MP7Tools
☑ Blender 内置             ☑ 饼菜单(Pie Menu Editor Fork)
☑ 布尔工具                 ☑ 自动绑定(Rigify)
☑ 简易集合开关动画          ☑ 简单烘焙
```

- `☑` = 显示中，点一下 → `☐` = 隐藏该插件的全部面板；
- 头部实时显示「已隐藏 N / 总数」；
- 顶部搜索框支持插件名、标签名、面板名过滤。

### 3. 新建合并面板

点「合并面板」右侧的 `＋`，侧边栏立刻出现一个**空白标签**：

```
空白合并面板
点一下下面的标签即可加入：
[动画 (4)] [MP7 (15)] [编辑 (3)] …
```

点哪个标签就把它并进来（设置里也能勾选）。列表只显示**尚未被其它合并面板占用**的标签——一个标签不会同时出现在两个合并组里。

### 4. 调整

- 组名可直接改（自动去重）；
- `👁` 临时停用该组（不删配置）；`✕` 删除该组；
- `▾/▸` 折叠详细设置，`▲ ▼` 调整顺序；
- 成员摘要区会提示「挂在原生标签「动画」下方」（逻辑 B）或显示成员列表（逻辑 A）。

### 5. 备份 / 迁移

设置顶部 `⤓ 导出` / `⤒ 导入`：把隐藏列表 + 全部分组导出成 JSON，换机器、重装 Blender、发给同事都能一键还原（导入会覆盖当前设置）。

---

## 四、注意事项

- **隐藏 = 彻底收起**：面板从侧边栏消失（该标签下所有面板都隐藏后，标签本身也会消失）。Blender 没有给插件开放“半折叠、只留标题”的接口。
- **少数面板隐藏不彻底**：内置面板中没有 `poll` 的、以及带子面板的父面板（例如 MeasureIt 主面板），这些需要“注销再注册”才能隐藏，而那正是 Blender 5.x `blender::ui::handler_panel` 崩溃的成因，所以刻意跳过。
- **合并是代理渲染**：代理面板继承原面板类，绝大多数插件正常；若某个面板绘制出错，面板内会显示 `⚠ 面板名 绘制失败` 与原因，便于反馈。
- **拖拽排序**：Blender 的 Python UI 没有拖放目标接口，所以是点击加入 / `▲▼` 排序。

---

## 五、安全设计（为什么它不会把 Blender 搞崩）

| 需求 | 做法 |
|---|---|
| 隐藏自带 `poll` 的面板 | 替换 `poll` 为恒 False（每帧实时查询，可逆） |
| 隐藏没有 `poll` 的面板 | 只对“安全面板”（非内置 / 无父 / 无子）做一次注销+重注册 |
| 合并 | **新建**代理面板类（只 register，从不 unregister），并继承源面板类 |
| 切换子标签 / 删除分组 | 只改 `poll` 或配置，不动注册表 |

不触碰内置面板与父子结构的重注册，是它能和 Blender 5.x 共存的根本原因。

---

## 六、版本

- 1.0.0：首次发布。按插件隐藏、两种合并逻辑、一级菜单、排序、配置导入导出。

---

## English summary

N Panel Manager hides selected Blender sidebar (N-panel) tabs per add-on, and merges several tabs into one panel.

Two merge modes:

- **Third-party only** → a switcher bar appears; only the active member's panels are drawn.
- **Contains a native tab** → no switcher; third-party panels are stacked **below** the native panels (native order untouched).

Merge tabs are ordered by creation time, can be reordered with `▲▼`, and always sort after native tabs. A `Flat` toggle turns every group into the stacked (switcher-less) style. Settings are in the add-on preferences and in the 3D View `View`/`Object` menus; configuration can be exported/imported as JSON.

The add-on never unregisters built-in or parent/child panel classes (that is what crashes Blender 5.x's `ui::handler_panel`); proxies are new classes only, and hiding is done via `poll`.
