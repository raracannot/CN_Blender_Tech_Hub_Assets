# SPDX-License-Identifier: GPL-3.0-or-later
"""N Panel Manager 1.0 — Blender 扩展。

功能：
  1. 按插件隐藏侧边栏(N 面板)里的面板。
  2. 合并标签：把多个标签合并成一个面板；可以先建空白面板，再点标签加入。
  3. 成员里含原生标签（bl_ui，例如“动画”）时，不隐藏原生标签，
     而是把第三方面板挂到该原生标签下方。
  4. 合并标签按添加顺序排列（可手动上移/下移），不改变原生标签的顺序。

设置入口（插件本身不占用侧边栏标签）：
  * 偏好设置 → 插件 → N Panel Manager
  * 3D 视图 → 视图 / 物体 菜单 → “N 面板管理…”

稳定性要点（避免 5.x 的 blender::ui::handler_panel 空指针崩溃）：
  * 不对内置面板、子面板、带子面板的父面板做“注销 + 重注册”；
  * 自带 poll 的面板只替换 poll 属性；没有 poll 的面板才对“安全面板”重注册一次；
  * 合并 = 新建代理面板类（只 register，从不注销），切换子标签只改 poll。
"""

import json
import os
import sys
import time
import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    StringProperty,
)
from bpy.types import AddonPreferences, Operator, Panel, PropertyGroup
try:
    from bpy_extras.io_utils import ExportHelper, ImportHelper
except Exception:      # 极简构建里没有 io_utils 时降级为纯文本路径输入
    ExportHelper = object
    ImportHelper = object

MANAGED_SPACES = {
    "VIEW_3D": "3D 视图",
    "NODE_EDITOR": "节点编辑器",
    "IMAGE_EDITOR": "图像编辑器",
}
REGION_TYPE = "UI"
HIDDEN_ATTR = "_npanmgr_hidden"
ORIG_POLL_ATTR = "_npanmgr_orig_poll"
HAD_POLL_ATTR = "_npanmgr_own_poll"
REREG_ATTR = "_npanmgr_reregistered"
BAR_PREFIX = "NPANMGR_PT_GRP_"
PROXY_PREFIX = "NPANMGR_PT_PX_"
OWN_PREFIX = "NPANMGR_"

# bl_order 决定 N 面板标签的先后：原生标签基本是 0，合并标签统一排在后面
ANCHOR_ORDER = 10000
ORDER_BASE = 5000
ORDER_STEP = 10

ACTIVE = {}          # group -> 当前子标签
CONFIGURED = set()   # (group, member, anchor)
VALID_TOKENS = set() # 当前有效的代理 token；不在里面的一律隐藏（防重复显示）
TOKEN_OWNER = {}     # token -> 唯一允许显示的代理类（防止旧代理同时可见）
PROXY_CACHE = {}
PROXY_ALL = []
DRAW_ERRORS = {}     # 源面板 idname -> 绘制异常文本（诊断用）
_addon_name_cache = {}

_SCAN_CACHE = {"time": 0.0, "panels": []}
_SCAN_TTL = 0.4
_PARENT_CACHE = {"time": 0.0, "parents": set()}
_WATCH = {"key": None, "tick": 0}


# ------------------------------------------------------------------------------
# 面板扫描

def _invalidate_scan():
    _SCAN_CACHE["time"] = 0.0
    _PARENT_CACHE["time"] = 0.0


def iter_panel_classes():
    seen = set()
    stack = list(Panel.__subclasses__())
    while stack:
        cls = stack.pop()
        if cls in seen:
            continue
        seen.add(cls)
        yield cls
        try:
            stack.extend(cls.__subclasses__())
        except Exception:
            pass


def module_root(cls):
    mod = getattr(cls, "__module__", "") or ""
    if not mod:
        return ""
    parts = mod.split(".")
    if parts[0] == "bl_ext" and len(parts) >= 3:
        return ".".join(parts[:3])
    return parts[0]


def addon_display_name(root):
    if root in _addon_name_cache:
        return _addon_name_cache[root]
    name = ""
    if root == "bl_ui":
        name = "Blender 内置"
    elif root.startswith("bl_ext.") and root.count(".") >= 2:
        _, repo_name, addon_name = root.split(".", 2)
        try:
            directory = None
            for repo in bpy.context.preferences.extensions.repos:
                if repo.module == repo_name:
                    directory = repo.directory
                    break
            if directory:
                import os
                manifest = os.path.join(directory, addon_name, "blender_manifest.toml")
                with open(manifest, "r", encoding="utf-8") as handle:
                    text = handle.read()
                try:
                    import tomllib
                    name = tomllib.loads(text).get("name", "")
                except Exception:
                    for line in text.splitlines():
                        if line.strip().startswith("name") and "=" in line:
                            name = line.split("=", 1)[1].strip().strip('"\'')
                            break
        except Exception:
            name = ""
    if not name:
        info = getattr(sys.modules.get(root), "bl_info", None) or {}
        name = info.get("name", "") or ""
    if not name:
        name = root
    _addon_name_cache[root] = name
    return name


def is_own(cls):
    ident = getattr(cls, "bl_idname", None) or cls.__name__
    return ident.startswith(OWN_PREFIX)


def panel_info(cls):
    if "bl_rna" not in cls.__dict__:
        return None
    space = getattr(cls, "bl_space_type", "") or ""
    if space not in MANAGED_SPACES:
        return None
    if (getattr(cls, "bl_region_type", "") or "") != REGION_TYPE:
        return None
    if is_own(cls):
        return None
    idname = getattr(cls, "bl_idname", None) or cls.__name__
    root = module_root(cls)
    return {
        "cls": cls,
        "space": space,
        "idname": str(idname),
        "label": str(getattr(cls, "bl_label", "") or cls.__name__),
        "category": str(getattr(cls, "bl_category", "") or "其它"),
        "root": root,
        "addon": addon_display_name(root),
        "parent": getattr(cls, "bl_parent_id", "") or "",
        "native": root == "bl_ui" or root.startswith("bl_ui."),
    }


def _scan():
    out = []
    for cls in iter_panel_classes():
        info = panel_info(cls)
        if info is not None:
            out.append(info)
    return out


def all_panels(space=None):
    now = time.monotonic()
    if (now - _SCAN_CACHE["time"]) > _SCAN_TTL:
        _SCAN_CACHE["panels"] = _scan()
        _SCAN_CACHE["time"] = now
    panels = _SCAN_CACHE["panels"]
    if space is None:
        return list(panels)
    return [i for i in panels if i["space"] == space]


def collect_addons(space):
    groups = {}
    for info in all_panels(space):
        entry = groups.get(info["root"])
        if entry is None:
            entry = groups[info["root"]] = {
                "root": info["root"],
                "name": info["addon"],
                "panels": [],
                "categories": set(),
            }
        entry["panels"].append(info)
        entry["categories"].add(info["category"])
    return sorted(groups.values(), key=lambda d: d["name"].lower())


def category_map(space):
    mapping = {}
    for info in all_panels(space):
        mapping.setdefault(info["category"], []).append(info)
    return dict(sorted(mapping.items(), key=lambda kv: kv[0].lower()))


# ------------------------------------------------------------------------------
# poll 替换 / 隐藏 / 恢复

@classmethod
def _false_poll(cls, context):
    return False


def is_hidden(cls):
    return bool(cls.__dict__.get(HIDDEN_ATTR, False))


def _has_registered_children(cls):
    ident = getattr(cls, "bl_idname", None) or cls.__name__
    return ident in _registered_parents()


def _registered_parents():
    """所有“有子面板”的面板 idname 集合（带短缓存，避免每个面板都扫一遍全局）。"""
    now = time.monotonic()
    if (now - _PARENT_CACHE["time"]) > _SCAN_TTL:
        parents = set()
        for other in iter_panel_classes():
            if "bl_rna" not in other.__dict__:
                continue
            parent = getattr(other, "bl_parent_id", "") or ""
            if parent:
                parents.add(parent)
        _PARENT_CACHE["parents"] = parents
        _PARENT_CACHE["time"] = now
    return _PARENT_CACHE["parents"]


def can_bake_poll(cls):
    root = module_root(cls)
    if root == "bl_ui" or root.startswith("bl_ui."):
        return False
    if getattr(cls, "bl_parent_id", ""):
        return False
    return not _has_registered_children(cls)


def _reregister(cls):
    if "bl_rna" not in cls.__dict__:
        return False
    try:
        bpy.utils.unregister_class(cls)
    except Exception as e:
        print("[NPM] unregister failed:", cls, e)
        return False
    try:
        bpy.utils.register_class(cls)
    except Exception as e:
        print("[NPM] register failed:", cls, e)
        return False
    return True


def hide_panel(cls):
    if is_hidden(cls):
        return False
    own_poll = cls.__dict__.get("poll")
    setattr(cls, ORIG_POLL_ATTR, own_poll)
    setattr(cls, HAD_POLL_ATTR, own_poll is not None)
    cls.poll = _false_poll
    baked = False
    if own_poll is None and can_bake_poll(cls):
        baked = _reregister(cls)
    setattr(cls, REREG_ATTR, baked)
    setattr(cls, HIDDEN_ATTR, True)
    return True


def show_panel(cls):
    if not is_hidden(cls):
        return False
    own_poll = getattr(cls, ORIG_POLL_ATTR, None)
    if getattr(cls, HAD_POLL_ATTR, False) and own_poll is not None:
        cls.poll = own_poll
    else:
        try:
            del cls.poll
        except AttributeError:
            pass
    if getattr(cls, REREG_ATTR, False):
        _reregister(cls)
    setattr(cls, REREG_ATTR, False)
    setattr(cls, HIDDEN_ATTR, False)
    return True


def bound_poll(cls):
    if is_hidden(cls):
        raw = cls.__dict__.get(ORIG_POLL_ATTR)
        if raw is None:
            return None
        try:
            return raw.__get__(None, cls)
        except Exception:
            return raw
    return getattr(cls, "poll", None)


def tag_redraw(context=None):
    ctx = context or bpy.context
    wm = getattr(ctx, "window_manager", None)
    if wm is None:
        return
    try:
        windows = list(wm.windows)
    except Exception:
        return
    for window in windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            for region in area.regions:
                try:
                    region.tag_redraw()
                except Exception:
                    pass


# ------------------------------------------------------------------------------
# 分组辅助

def _member_active(group_name, member):
    return ACTIVE.get(group_name) == member


def resolve_anchor(cats, members):
    """若成员里有“原生标签”，用它作为宿主标签（第三方面板堆到它下面）。

    判断标准是“这个标签里有原生的面板”——原生面板本来就隐藏不掉，
    与其硬隐藏不如当作宿主，把第三方内容垫在它下面。
    """
    for member in members:
        infos = cats.get(member) or []
        if any(i["native"] for i in infos):
            return member
    return ""


def primary_panel_idname(cats, member):
    """成员里“主面板”：子面板最多的那个；没有子面板就取第一个顶层面板。

    合并后这个面板的标题会被隐藏，整个成员的内容直接铺在子标签按钮下面，
    不再出现“上面插件名、下面又一遍插件名”的两层结构。
    """
    infos = cats.get(member) or []
    if not infos:
        return ""
    names = {i["idname"] for i in infos}
    children = {}
    for info in infos:
        parent = info["parent"]
        if parent and parent in names:
            children[parent] = children.get(parent, 0) + 1
    if children:
        return max(children.items(), key=lambda kv: kv[1])[0]
    tops = [i for i in infos if not i["parent"] or i["parent"] not in names]
    return (tops or infos)[0]["idname"]


def group_sequence(prefs, space):
    """按 order 排序后的该编辑器分组。"""
    groups = [g for g in prefs.groups if g.space == space]
    return sorted(groups, key=lambda g: (g.order, g.name.lower()))


def normalize_orders(prefs):
    """每个编辑器内把 order 重新编号成 1..N（保持相对次序，补齐缺号/重复号）。

    这样“新增的合并面板自动排在最后”始终成立，不依赖历史 order 值。
    """
    changed = False
    for space in {g.space for g in prefs.groups}:
        for index, group in enumerate(group_sequence(prefs, space), start=1):
            if group.order != index:
                group.order = index
                changed = True
    return changed


def ensure_keys(prefs):
    """给分组补稳定键（老数据兼容）；键一旦生成就不再变。"""
    used = {g.key for g in prefs.groups if g.key}
    changed = False
    counter = 0
    for group in prefs.groups:
        if group.key:
            continue
        counter += 1
        key = "#%d" % counter
        while key in used:
            counter += 1
            key = "#%d" % counter
        group.key = key
        used.add(key)
        changed = True
    return changed


def normalize_names(prefs):
    """分组名去重：分组是按名字做键的（bar/代理/ACTIVE），重名会互相串台。"""
    changed = False
    seen = set()
    for group in prefs.groups:
        base = (group.name or "").strip() or "面板"
        name = base
        index = 2
        while name in seen:
            name = "%s%d" % (base, index)
            index += 1
        seen.add(name)
        if name != group.name:
            group.name = name
            changed = True
    return changed


def _make_proxy(src, gkey, glabel, member, anchor, group_order, order_seed,
                parent_idname=None, flat=False, primary=False,
                member_index=0, panel_index=0, group_slot=0):
    src_draw = getattr(src["cls"], "draw", None)
    if src_draw is None:
        return None
    src_poll = bound_poll(src["cls"])
    anchored = bool(anchor)
    # 堆叠模式：挂在原生标签下，或开启“一级菜单”→ 所有成员一起显示，不要切换
    stacked = anchored or flat
    token = (gkey, member, anchor, group_order, flat, primary, glabel, src["idname"])

    def draw(self, context):
        try:
            return src_draw(self, context)
        except Exception as exc:      # 某个面板自己的绘制出错时，给出可读提示而不是空白
            DRAW_ERRORS[src["idname"]] = str(exc)
            print("[NPM] draw failed:", src["idname"], type(exc).__name__, exc)
            try:
                self.layout.label(text="⚠ %s 绘制失败" % src["label"], icon="ERROR")
                self.layout.label(text=str(exc)[:120])
            except Exception:
                pass
            return None

    @classmethod
    def poll(cls, context):
        if token not in VALID_TOKENS:
            return False          # 配置/样式变了，旧代理自动作废（避免重复显示）
        if TOKEN_OWNER.get(token) is not cls:
            return False          # 同一 token 已有更新的代理，旧的静音
        if not stacked and not _member_active(gkey, member):
            return False
        if src_poll is None:
            return True
        try:
            return bool(src_poll(context))
        except Exception:
            return False

    options = set(getattr(src["cls"], "bl_options", set()) or set())
    options.discard("INSTANCED")

    if anchored:
        order = ANCHOR_ORDER + group_order * 200 + member_index * 20 + (panel_index % 20)
    elif flat:
        # 堆叠且没有切换栏：由代理自己的顺序决定标签位置，所以要跟着排序走
        order = ORDER_BASE + group_order * 200 + member_index * 20 + (panel_index % 20)
    else:
        # 有切换栏时，标签位置由「切换栏」的 bl_order 决定；
        # 代理用一个**固定槽位**（按分组键算），排序时就不用重建它们。
        order = ORDER_BASE + (group_slot % 200) * 200 + (order_seed % 200)

    # 主面板的标题直接用成员名（例如 “MP7”），避免和插件名重复
    label = member if primary else src["label"]

    ident = "%s%d_%s" % (PROXY_PREFIX, len(PROXY_ALL), "".join(
        c if c.isalnum() else "" for c in src["idname"])[:24])

    attrs = {
        "bl_idname": ident,
        "bl_label": label,
        "bl_space_type": src["space"],
        "bl_region_type": REGION_TYPE,
        "bl_category": anchor or glabel,
        "bl_order": order,
        "bl_options": options,
        "draw": draw,
        "poll": poll,
        "_npanmgr_src_idname": src["idname"],
        "_npanmgr_group": gkey,
        "_npanmgr_member": member,
        "_npanmgr_token": token,
    }
    if parent_idname:
        attrs["bl_parent_id"] = parent_idname
    # 关键：代理要继承“原面板类”，否则源面板 draw 里调用的自身方法
    # （例如 SimpleBake 的 self.draw_version_info）在代理上不存在，会直接报错。
    src_cls = src["cls"]
    try:
        proxy = type("NPANMGR_PX_%d" % len(PROXY_ALL), (src_cls,), attrs)
        bpy.utils.register_class(proxy)
    except Exception as e:
        print("[NPM] proxy register (inherit) failed:", src["idname"], e)
        try:
            proxy = type("NPANMGR_PX_%d" % len(PROXY_ALL), (Panel,), attrs)
            bpy.utils.register_class(proxy)
        except Exception as e2:
            print("[NPM] proxy register (fallback) failed:", src["idname"], e2)
            return None
    PROXY_ALL.append(proxy)
    TOKEN_OWNER[token] = proxy      # 同名 token 的旧代理自动静音
    return proxy


def _draw_add_row(layout, gkey, gi, space, members):
    """空白合并面板：列出可加入的标签，点一下就加进来。"""
    prefs = get_prefs()
    layout.label(text="空白合并面板", icon="BLANK1")
    layout.label(text="点一下下面的标签即可加入：", icon="INFO")
    cats = category_map(space)
    used = set()
    if prefs is not None:
        for other in prefs.groups:
            if (other.key or other.name) != gkey:
                for m in other.members:
                    used.add(m.category)
    grid = layout.grid_flow(columns=2, align=True)
    grid.alignment = "LEFT"
    shown = 0
    for category, infos in cats.items():
        if category in used or category in members:
            continue
        if shown >= 12:
            layout.label(text="……更多见「偏好设置 → 插件」", icon="DOT")
            break
        shown += 1
        op = grid.operator("npanmgr.group_member",
                           text="%s (%d)" % (category, len(infos)),
                           emboss=False, icon="CHECKBOX_DEHLT")
        op.index = gi
        op.category = category


def _ensure_group_bar(gkey, glabel, space, gi, anchor, group_order, flat=False):
    ident = "%s%d_%s" % (BAR_PREFIX, gi, "".join(
        c if c.isalnum() else "" for c in gkey)[:12])

    def draw(self, context):
        layout = self.layout
        prefs = get_prefs(context)
        if prefs is None:
            return
        group = _find_group(prefs, gkey)
        if group is None:
            return
        # 索引在绘制时按 key 现查：删过其它组后 gi 会变，用创建时的索引会点错组
        gi_now = _group_index(prefs, gkey)
        members = [m.category for m in group.members]
        if not members:
            _draw_add_row(layout, gkey, gi_now, space, members)
            return
        # 用一整个 row 把按钮包起来，避免无标题面板的边框被切掉
        row = layout.row(align=True)
        flow = row.grid_flow(columns=min(4, max(1, len(members))),
                             align=True, even_columns=True, even_rows=False)
        for category in members:
            act = ACTIVE.get(gkey) == category
            op = flow.operator("npanmgr.set_member", text=category,
                               emboss=True, depress=act)
            op.group = gkey
            op.member = category

    @classmethod
    def poll(cls, context):
        # 原生标签宿主 / 一级菜单（堆叠）模式都不需要切换按钮
        if anchor:
            return False
        prefs = get_prefs(context)
        if prefs is None:
            return False
        if getattr(prefs, "flat_style", False):
            return False      # 当前是堆叠模式（用实时设置判断，旧栏也会自动隐藏）
        group = _find_group(prefs, gkey)
        if group is None or not group.enabled:
            return False
        if group.order != group_order:
            return False       # 排序变了，旧的一栏作废
        if group.name != glabel:
            return False       # 改名了：旧栏（旧标签名）作废，避免留下幽灵标签
        # 只有一个成员时不需要子标签按钮（本身就是一级菜单）
        return len(group.members) != 1

    attrs = {
        "bl_idname": ident,
        "bl_label": "切换",
        "bl_space_type": space,
        "bl_region_type": REGION_TYPE,
        "bl_category": anchor or glabel,
        "bl_order": (ANCHOR_ORDER if anchor else ORDER_BASE) + group_order * ORDER_STEP,
        "bl_options": set(),
        "draw": draw,
        "poll": poll,
        "_npanmgr_group": gkey,
    }
    try:
        bar = type("NPANMGR_BAR_%d" % gi, (Panel,), attrs)
        bpy.utils.register_class(bar)
    except Exception as e:
        print("[NPM] group bar register failed:", gkey, e)
        return None
    PROXY_ALL.append(bar)
    return bar


def _sync_proxies():
    global CONFIGURED, VALID_TOKENS
    prefs = get_prefs()
    if prefs is None:
        return

    flat = bool(getattr(prefs, "flat_style", True))
    DRAW_ERRORS.clear()

    wanted = {}
    bars = {}
    configured = set()
    tokens = set()
    maps = {}
    for gi, group in enumerate(prefs.groups):
        if not group.enabled:
            continue
        gkey = group.key or group.name          # 稳定键：改名不会变
        members = [m.category for m in group.members if m.category]
        cats = maps.get(group.space)
        if cats is None:
            cats = maps[group.space] = category_map(group.space)
        anchor = resolve_anchor(cats, members) if members else ""
        bars[gkey] = (group.space, gi, anchor, group.order, group.name)
        # 固定槽位（按稳定键算）：有切换栏时，排序只需要重建切换栏，不用重建代理
        try:
            slot = int(gkey[1:]) if gkey.startswith("#") else (abs(hash(gkey)) % 199 + 1)
        except ValueError:
            slot = abs(hash(gkey)) % 199 + 1
        slot = slot % 199 + 1
        if not members:
            continue
        # 有切换栏（非堆叠、非原生宿主）时，标签位置由切换栏决定，代理顺序不必跟着排序变
        order_part = group.order if (flat or anchor) else 0
        if ACTIVE.get(gkey) not in members:
            ACTIVE[gkey] = group.active if group.active in members else members[0]
        for member_index, member in enumerate(members):
            configured.add((gkey, member, anchor))
            if member == anchor:
                # 宿主是原生标签：原生面板本身就在，不能再代理一份，否则同一面板会画两遍
                continue
            primary = primary_panel_idname(cats, member)
            infos = cats.get(member, ())
            member_names = {i["idname"] for i in infos}
            for panel_index, info in enumerate(infos):
                # 父面板不在本成员里的子面板不要单独代理，否则会变成“飘在外面”的一级面板
                if info["parent"] and info["parent"] not in member_names:
                    continue
                item = dict(info)
                item["_mi"] = member_index
                item["_pi"] = panel_index
                item["_slot"] = slot
                is_primary = info["idname"] == primary
                variant = (anchor, order_part, flat, is_primary, group.name)
                tokens.add((gkey, member, anchor, order_part, flat,
                            is_primary, group.name, info["idname"]))
                wanted[(gkey, member, variant, info["idname"])] = item

    CONFIGURED = configured
    VALID_TOKENS = tokens

    for gkey, (space, gi, anchor, group_order, glabel) in bars.items():
        if anchor or flat:
            # 原生宿主 / 一级菜单（堆叠）：都不要切换栏
            continue
        key = ("bar", gkey, anchor, group_order, glabel)
        if PROXY_CACHE.get(key) is None:
            bar = _ensure_group_bar(gkey, glabel, space, gi, anchor, group_order, flat)
            if bar is not None:
                PROXY_CACHE[key] = bar

    pending = dict(wanted)
    made = {}
    for _pass in range(2):
        for key, info in list(pending.items()):
            gkey, member, variant, src_idname = key
            if key in PROXY_CACHE:
                made[key] = PROXY_CACHE[key]
                del pending[key]
                continue
            parent_proxy = None
            if info["parent"]:
                parent_key = (gkey, member, variant, info["parent"])
                parent_proxy = made.get(parent_key) or PROXY_CACHE.get(parent_key)
                if parent_proxy is None:
                    continue
            anchor, group_order, flat, primary, glabel = variant
            proxy = _make_proxy(
                info, gkey, glabel, member, anchor, group_order,
                order_seed=len(PROXY_ALL),
                parent_idname=getattr(parent_proxy, "bl_idname", None),
                flat=flat, primary=primary,
                member_index=info.get("_mi", 0),
                panel_index=info.get("_pi", 0),
                group_slot=info.get("_slot", 1),
            )
            if proxy is not None:
                PROXY_CACHE[key] = proxy
                made[key] = proxy
                del pending[key]


# ------------------------------------------------------------------------------
# 应用设置

def _effective_hidden(info, hidden_addons, member_categories, anchored, by_key):
    # 1) 用户显式隐藏的插件优先（即使它的标签被当成原生宿主）
    if (info["space"], info["root"]) in hidden_addons:
        return True
    # 2) 原生宿主标签保持显示，第三方面板堆到它下面
    if (info["space"], info["category"]) in anchored:
        return False
    if (info["space"], info["category"]) in member_categories:
        return True
    seen = set()
    cur = info
    while cur is not None:
        if (cur["space"], cur["root"]) in hidden_addons:
            return True
        if (cur["space"], cur["category"]) in anchored:
            return False
        if (cur["space"], cur["category"]) in member_categories:
            return True
        parent = cur["parent"]
        if not parent or parent in seen:
            return False
        seen.add(parent)
        cur = by_key.get((cur["space"], parent))
    return False


def apply_settings(context=None):
    prefs = get_prefs(context)
    if prefs is None:
        return 0

    ensure_keys(prefs)
    normalize_orders(prefs)
    normalize_names(prefs)

    hidden_addons = {(it.space, it.addon_key) for it in prefs.hidden}
    member_categories = set()
    anchored = set()
    maps = {}
    for group in prefs.groups:
        if not group.enabled:
            continue
        members = [m.category for m in group.members if m.category]
        if not members:
            continue
        cats = maps.get(group.space)
        if cats is None:
            cats = maps[group.space] = category_map(group.space)
        anchor = resolve_anchor(cats, members)
        if anchor:
            anchored.add((group.space, anchor))
        for member in members:
            if member != anchor:
                member_categories.add((group.space, member))

    if not hidden_addons and not member_categories and not PROXY_CACHE:
        return 0

    _invalidate_scan()
    infos = all_panels()
    by_key = {(i["space"], i["idname"]): i for i in infos}

    changed = 0
    for info in infos:
        want = _effective_hidden(info, hidden_addons, member_categories, anchored, by_key)
        if want:
            changed += 1 if hide_panel(info["cls"]) else 0
        else:
            changed += 1 if show_panel(info["cls"]) else 0

    _sync_proxies()
    if changed:
        tag_redraw(context)
    return changed


# ------------------------------------------------------------------------------
# 偏好设置 / 数据

def get_prefs(context=None):
    ctx = context or bpy.context
    try:
        addon = ctx.preferences.addons.get(__package__)
    except Exception:
        return None
    if addon is None:
        return None
    return getattr(addon, "preferences", None)


def _find_group(prefs, ident):
    """按稳定键找分组；键找不到时退回按名字（兼容旧数据/旧调用）。"""
    for group in prefs.groups:
        if group.key and group.key == ident:
            return group
    for group in prefs.groups:
        if group.name == ident:
            return group
    return None


def _group_index(prefs, ident):
    for index, group in enumerate(prefs.groups):
        if group.key and group.key == ident:
            return index
    for index, group in enumerate(prefs.groups):
        if group.name == ident:
            return index
    return -1


class NPANMGR_PG_hidden(PropertyGroup):
    space: StringProperty(default="VIEW_3D")
    addon_key: StringProperty(default="")


class NPANMGR_PG_member(PropertyGroup):
    category: StringProperty(default="")


class NPANMGR_PG_group(PropertyGroup):
    name: StringProperty(name="面板名", default="我的面板")
    key: StringProperty(default="")      # 稳定键：分组改名不会影响代理/排序/子标签状态
    space: StringProperty(default="VIEW_3D")
    enabled: BoolProperty(name="启用", default=True)
    expanded: BoolProperty(name="展开设置", default=True)
    order: IntProperty(name="排序", default=1)
    active: StringProperty(default="")
    members: CollectionProperty(type=NPANMGR_PG_member)


# ------------------------------------------------------------------------------
# 界面

def _draw_top(layout, prefs, wide=False):
    row = layout.row(align=True)
    row.prop(prefs, "space_filter", text="")
    row.operator("npanmgr.report", text="", icon="INFO")
    row.operator("npanmgr.export_settings", text="", icon="EXPORT")
    row.operator("npanmgr.import_settings", text="", icon="IMPORT")

    row = layout.row(align=True)
    row.prop(prefs, "filter_text", text="", icon="VIEWZOOM")
    if wide:
        row.operator("npanmgr.refresh", text="", icon="FILE_REFRESH")
        row.operator("npanmgr.reset_all", text="", icon="LOOP_BACK")

    if wide:
        layout.prop(prefs, "auto_apply", text="自动保持隐藏")
    else:
        layout.prop(prefs, "auto_apply", text="保持隐藏状态")
        sub = layout.row(align=True)
        sub.operator("npanmgr.refresh", text="刷新", icon="FILE_REFRESH")
        sub.operator("npanmgr.reset_all", text="全部恢复", icon="LOOP_BACK")


def _draw_hide_section(layout, prefs, space, text, max_rows=0):
    box = layout.box()
    hidden = {(i.space, i.addon_key) for i in prefs.hidden}
    entries = collect_addons(space)
    if text:
        entries = [e for e in entries
                   if text in e["name"].lower() or text in e["root"].lower()]

    count = len([e for e in entries if (space, e["root"]) in hidden])
    head = box.row(align=True)
    head.label(text="隐藏插件面板", icon="HIDE_ON")
    head.label(text="已隐藏 %d / %d" % (count, len(entries)))

    if not entries:
        box.label(text="没有匹配的插件", icon="BLANK1")
        return

    # 双排排列，只显示插件名（不显示面板数量）
    grid = box.grid_flow(columns=2, align=True, even_columns=True)
    grid.alignment = "LEFT"
    limit = max_rows * 2 if max_rows else 0
    for index, entry in enumerate(entries):
        if limit and index >= limit:
            box.label(text="……完整列表见「偏好设置 → 插件」", icon="DOT")
            break
        off = (space, entry["root"]) in hidden
        op = grid.operator(
            "npanmgr.toggle_addon",
            text=entry["name"],
            emboss=False,
            icon="CHECKBOX_DEHLT" if off else "CHECKBOX_HLT",
        )
        op.space = space
        op.root = entry["root"]


def _category_addons(infos):
    """该标签下涉及的插件名（去重、保持出现顺序）。"""
    names = []
    for info in infos:
        name = info["addon"]
        if name and name not in names:
            names.append(name)
    return names


def _i18n(text):
    """按当前界面语言翻译（标签名/插件名在侧边栏里本来就是翻译过的）。"""
    try:
        from bpy.app.translations import pgettext_iface
        return pgettext_iface(text)
    except Exception:
        return text


def _category_label(category, infos, addons=None):
    """标签按钮文字：标签名 + 插件名 + 面板数。

    标签名常常是英文/插件自定的（例如 Bool Tool 用 “Edit”），
    把插件名也带出来，才找得到“布尔工具”。
    """
    addons = addons if addons is not None else _category_addons(infos)
    cat = _i18n(category)
    if not addons:
        return "%s (%d)" % (cat, len(infos))
    names = [_i18n(a) for a in addons]
    if len(names) == 1 and names[0] == cat:
        return "%s (%d)" % (cat, len(infos))
    if len(names) <= 2:
        joined = "、".join(names)
    else:
        joined = "%s 等 %d 个插件" % (names[0], len(names))
    return "%s · %s (%d)" % (cat, joined, len(infos))


def _draw_merge_section(layout, prefs, space, text, max_rows=0, wide=False):
    box = layout.box()
    head = box.row(align=True)
    head.label(text="合并面板", icon="MOD_LENGTH")
    head.prop(prefs, "flat_style", text="一级菜单" if wide else "",
              icon="SORTALPHA", toggle=True)
    add = head.operator("npanmgr.group_add", text="", icon="ADD")
    add.space = space

    groups = group_sequence(prefs, space)
    if not groups:
        box.label(text="＋ 新建：会先出现一个空白的合并面板", icon="BLANK1")
        return

    cats = category_map(space)

    # 已被其它合并面板使用的标签，本面板里不再显示（自动隐藏）
    used_by_other = {}
    for other in prefs.groups:
        for m in other.members:
            used_by_other.setdefault(m.category, other.name)

    total = len(groups)
    for position, group in enumerate(groups):
        gi = _group_index(prefs, group.name)
        members = [m.category for m in group.members]

        row = box.row(align=True)
        toggle = row.operator(
            "npanmgr.group_expand", text="", emboss=False,
            icon="TRIA_DOWN" if group.expanded else "TRIA_RIGHT")
        toggle.index = gi
        row.prop(group, "name", text="")
        row.label(text="%d" % len(members))

        # 排序按钮始终可见（收起状态也要能排）
        up_cell = row.row(align=True)
        up_cell.enabled = position > 0
        up = up_cell.operator("npanmgr.group_move", text="", icon="TRIA_UP")
        up.index = gi
        up.delta = -1
        down_cell = row.row(align=True)
        down_cell.enabled = position < total - 1
        down = down_cell.operator("npanmgr.group_move", text="", icon="TRIA_DOWN")
        down.index = gi
        down.delta = 1

        row.prop(group, "enabled", text="",
                 icon="HIDE_OFF" if group.enabled else "HIDE_ON")
        rm = row.operator("npanmgr.group_remove", text="", icon="X")
        rm.index = gi

        if not group.expanded:
            continue

        gbox = box.box()
        if not members:
            gbox.label(text="空白：点下面的标签开始合并", icon="BLANK1")
        else:
            anchor = resolve_anchor(cats, members)
            if anchor:
                gbox.label(text="挂在原生标签「%s」下方" % anchor, icon="ANCHOR_TOP")
            gbox.label(text="已合并 %d 个标签" % len(members), icon="CHECKMARK")
            chips = gbox.grid_flow(columns=2, align=True, even_columns=True)
            chips.alignment = "LEFT"
            for name in members:
                chips.label(text="· " + name)

        # 2 列，给“标签 · 插件名”留够宽度
        grid = gbox.grid_flow(columns=2, align=True, even_columns=True)
        grid.alignment = "LEFT"
        shown = 0
        for category, infos in cats.items():
            addons = _category_addons(infos)
            if text and text not in category.lower() \
                    and not any(text in i["label"].lower() for i in infos) \
                    and not any(text in a.lower() for a in addons):
                continue
            owner = used_by_other.get(category)
            if owner and owner != group.name:
                continue
            if max_rows and shown >= max_rows:
                gbox.label(text="……共 %d 个标签" % len(cats), icon="DOT")
                break
            shown += 1
            on = category in members
            op = grid.operator(
                "npanmgr.group_member",
                text=_category_label(category, infos, addons),
                emboss=False,
                icon="CHECKBOX_HLT" if on else "CHECKBOX_DEHLT",
            )
            op.index = gi
            op.category = category


def draw_settings(layout, context, wide=False):
    prefs = get_prefs(context)
    if prefs is None:
        layout.label(text="插件未启用？", icon="ERROR")
        return

    space = prefs.space_filter
    text = prefs.filter_text.strip().lower()
    _draw_top(layout, prefs, wide)

    if wide:
        columns = layout.row()
        left = columns.column()
        right = columns.column()
        _draw_hide_section(left, prefs, space, text, max_rows=11)
        _draw_merge_section(right, prefs, space, text, max_rows=18, wide=True)
    else:
        _draw_hide_section(layout, prefs, space, text)
        _draw_merge_section(layout, prefs, space, text)


class NPANMGR_AddonPreferences(AddonPreferences):
    bl_idname = __package__

    space_filter: EnumProperty(
        name="编辑器",
        items=[(k, v, "") for k, v in MANAGED_SPACES.items()],
        default="VIEW_3D",
    )
    filter_text: StringProperty(name="搜索", default="")
    auto_apply: BoolProperty(
        name="自动保持",
        description="后台定期复查（其他插件重新注册面板后自动重新隐藏）",
        default=True,
    )
    flat_style: BoolProperty(
        name="一级菜单",
        description="开启后合并标签里不再显示切换按钮，所有成员的面板直接依次堆叠",
        default=False,
    )
    hidden: CollectionProperty(type=NPANMGR_PG_hidden)
    groups: CollectionProperty(type=NPANMGR_PG_group)

    def draw(self, context):
        draw_settings(self.layout, context)


# ------------------------------------------------------------------------------
# 操作符

class NPANMGR_OT_open(Operator):
    bl_idname = "npanmgr.open"
    bl_label = "N 面板管理…"
    bl_description = "打开 N 面板管理：按插件隐藏面板 / 合并标签"

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=880)

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        draw_settings(self.layout, context, wide=True)


class NPANMGR_OT_toggle_addon(Operator):
    bl_idname = "npanmgr.toggle_addon"
    bl_label = "隐藏/显示该插件的面板"
    bl_options = {"INTERNAL"}

    space: StringProperty(default="VIEW_3D")
    root: StringProperty(default="")

    def execute(self, context):
        prefs = get_prefs(context)
        index = -1
        for i, item in enumerate(prefs.hidden):
            if item.space == self.space and item.addon_key == self.root:
                index = i
                break
        if index >= 0:
            prefs.hidden.remove(index)
        else:
            item = prefs.hidden.add()
            item.space = self.space
            item.addon_key = self.root
        apply_settings(context)
        tag_redraw(context)
        return {"FINISHED"}


class NPANMGR_OT_group_add(Operator):
    bl_idname = "npanmgr.group_add"
    bl_label = "新建合并面板"
    bl_options = {"INTERNAL"}

    space: StringProperty(default="VIEW_3D")

    def execute(self, context):
        prefs = get_prefs(context)
        name = "我的面板"
        n = 2
        while any(g.name == name for g in prefs.groups):
            name = "我的面板%d" % n
            n += 1
        group = prefs.groups.add()
        group.name = name
        group.key = "#%d" % (len(prefs.groups) + 1)
        used = {g.key for g in prefs.groups if g.key and g is not group}
        counter = len(prefs.groups) + 1
        while group.key in used:
            counter += 1
            group.key = "#%d" % counter
        group.space = self.space
        group.expanded = True
        others = [g.order for g in prefs.groups
                  if g.space == self.space and (g.key or g.name) != group.key]
        group.order = (max(others) + 1) if others else 1
        apply_settings(context)
        tag_redraw(context)
        return {"FINISHED"}


class NPANMGR_OT_group_move(Operator):
    bl_idname = "npanmgr.group_move"
    bl_label = "调整合并面板顺序"
    bl_description = "上移 / 下移该合并面板（只影响合并标签之间的顺序）"
    bl_options = {"INTERNAL"}

    index: IntProperty(default=0)
    delta: IntProperty(default=0)

    def execute(self, context):
        prefs = get_prefs(context)
        if not (0 <= self.index < len(prefs.groups)):
            return {"CANCELLED"}
        group = prefs.groups[self.index]
        siblings = group_sequence(prefs, group.space)
        names = [g.name for g in siblings]
        if group.name not in names:
            return {"CANCELLED"}
        position = names.index(group.name)
        target = position + self.delta
        if not (0 <= target < len(siblings)):
            return {"CANCELLED"}
        other = siblings[target]
        group.order, other.order = other.order, group.order
        for i, g in enumerate(group_sequence(prefs, group.space), start=1):
            g.order = i
        apply_settings(context)
        tag_redraw(context)
        return {"FINISHED"}


class NPANMGR_OT_group_expand(Operator):
    bl_idname = "npanmgr.group_expand"
    bl_label = "展开/收起该合并面板的设置"
    bl_options = {"INTERNAL"}

    index: IntProperty(default=0)

    def execute(self, context):
        prefs = get_prefs(context)
        if 0 <= self.index < len(prefs.groups):
            group = prefs.groups[self.index]
            group.expanded = not group.expanded
        return {"FINISHED"}


class NPANMGR_OT_group_remove(Operator):
    bl_idname = "npanmgr.group_remove"
    bl_label = "删除合并面板"
    bl_options = {"INTERNAL"}

    index: IntProperty(default=0)

    def execute(self, context):
        prefs = get_prefs(context)
        if 0 <= self.index < len(prefs.groups):
            group = prefs.groups[self.index]
            ACTIVE.pop(group.key or group.name, None)
            prefs.groups.remove(self.index)
        apply_settings(context)
        tag_redraw(context)
        return {"FINISHED"}


class NPANMGR_OT_group_member(Operator):
    bl_idname = "npanmgr.group_member"
    bl_label = "加入/移出合并面板"
    bl_options = {"INTERNAL"}

    index: IntProperty(default=0)
    category: StringProperty(default="")

    def execute(self, context):
        prefs = get_prefs(context)
        if not (0 <= self.index < len(prefs.groups)):
            return {"CANCELLED"}
        group = prefs.groups[self.index]
        found = -1
        for i, member in enumerate(group.members):
            if member.category == self.category:
                found = i
                break
        if found >= 0:
            group.members.remove(found)
        else:
            for other in prefs.groups:
                if (other.key or other.name) == (group.key or group.name):
                    continue
                for m in other.members:
                    if m.category == self.category:
                        self.report({"WARNING"},
                                    "标签「%s」已在合并面板「%s」中" % (self.category, other.name))
                        return {"CANCELLED"}
            member = group.members.add()
            member.category = self.category
        apply_settings(context)
        tag_redraw(context)
        return {"FINISHED"}


class NPANMGR_OT_set_member(Operator):
    bl_idname = "npanmgr.set_member"
    bl_label = "切换到该子面板"
    bl_options = {"INTERNAL"}

    group: StringProperty(default="")
    member: StringProperty(default="")

    def execute(self, context):
        prefs = get_prefs(context)
        group = _find_group(prefs, self.group)
        if group is None:
            return {"CANCELLED"}
        group.active = self.member
        ACTIVE[group.key or group.name] = self.member
        tag_redraw(context)
        return {"FINISHED"}


class NPANMGR_OT_reset_all(Operator):
    bl_idname = "npanmgr.reset_all"
    bl_label = "全部恢复"
    bl_description = "清空所有隐藏与合并设置，恢复默认侧边栏"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        global CONFIGURED, VALID_TOKENS
        prefs = get_prefs(context)
        while len(prefs.hidden):
            prefs.hidden.remove(0)
        for group in prefs.groups:
            while len(group.members):
                group.members.remove(0)
        while len(prefs.groups):
            prefs.groups.remove(0)
        ACTIVE.clear()
        CONFIGURED = set()
        VALID_TOKENS = set()      # 让所有代理立即失效，否则会残留“幽灵面板”
        TOKEN_OWNER.clear()
        DRAW_ERRORS.clear()
        _invalidate_scan()
        for info in all_panels():
            show_panel(info["cls"])
        tag_redraw(context)
        self.report({"INFO"}, "已恢复全部面板")
        return {"FINISHED"}


class NPANMGR_OT_refresh(Operator):
    bl_idname = "npanmgr.refresh"
    bl_label = "刷新"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        n = apply_settings(context)
        tag_redraw(context)
        self.report({"INFO"}, "刷新完成（变更 %d）" % n)
        return {"FINISHED"}


class NPANMGR_OT_report(Operator):
    bl_idname = "npanmgr.report"
    bl_label = "输出诊断信息"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        prefs = get_prefs(context)
        print("=" * 60)
        print("[NPM] hidden:", [(i.space, i.addon_key) for i in prefs.hidden])
        for group in prefs.groups:
            members = [m.category for m in group.members]
            cats = category_map(group.space)
            print("[NPM] group:", group.name, group.space, members,
                  "order=", group.order,
                  "anchor=", resolve_anchor(cats, members),
                  "active=", group.active, "enabled=", group.enabled)
        for info in all_panels():
            print("[NPM] %-30s cat=%-18s hidden=%s native=%s root=%s" % (
                info["idname"], info["category"], is_hidden(info["cls"]),
                info["native"], info["root"]))
        print("[NPM] proxies:", len(PROXY_ALL), "configured:", len(CONFIGURED))
        if DRAW_ERRORS:
            print("[NPM] draw errors:", DRAW_ERRORS)
        by_member = {}
        for proxy in PROXY_ALL:
            mem = getattr(proxy, "_npanmgr_member", None)
            if mem:
                by_member.setdefault(mem, []).append(
                    (getattr(proxy, "_npanmgr_src_idname", ""),
                     bool(proxy.poll(bpy.context))))
        for mem, items in by_member.items():
            print("[NPM] member:", mem, "proxies:", len(items),
                  "visible:", sum(1 for _, v in items if v))
            for src, vis in items:
                print("[NPM]    ", src, "visible=", vis)
        print("=" * 60)
        self.report({"INFO"}, "诊断信息已输出到系统控制台")
        return {"FINISHED"}


# ------------------------------------------------------------------------------
# 配置导入 / 导出（JSON，方便备份、换机、分享）

SETTINGS_VERSION = 1


def _settings_blob(prefs):
    return {
        "version": SETTINGS_VERSION,
        "flat_style": bool(getattr(prefs, "flat_style", False)),
        "auto_apply": bool(getattr(prefs, "auto_apply", True)),
        "hidden": [{"space": h.space, "addon": h.addon_key} for h in prefs.hidden],
        "groups": [{
            "name": g.name,
            "key": g.key,
            "space": g.space,
            "order": g.order,
            "enabled": g.enabled,
            "expanded": g.expanded,
            "active": g.active,
            "members": [m.category for m in g.members],
        } for g in prefs.groups],
    }


def _apply_settings_blob(prefs, blob):
    """把 JSON 内容写回偏好设置（覆盖当前配置）。返回 (组数, 隐藏数)。"""
    if not isinstance(blob, dict):
        raise ValueError("不是有效的设置文件")
    while len(prefs.hidden):
        prefs.hidden.remove(0)
    for group in prefs.groups:
        while len(group.members):
            group.members.remove(0)
    while len(prefs.groups):
        prefs.groups.remove(0)

    for entry in blob.get("hidden") or []:
        space = entry.get("space") or "VIEW_3D"
        addon = entry.get("addon") or ""
        if not addon:
            continue
        item = prefs.hidden.add()
        item.space = space
        item.addon_key = addon

    for entry in blob.get("groups") or []:
        name = str(entry.get("name") or "我的面板")
        group = prefs.groups.add()
        group.name = name
        group.key = str(entry.get("key") or "")
        group.space = str(entry.get("space") or "VIEW_3D")
        try:
            group.order = int(entry.get("order") or 1)
        except Exception:
            group.order = 1
        group.enabled = bool(entry.get("enabled", True))
        group.expanded = bool(entry.get("expanded", True))
        group.active = str(entry.get("active") or "")
        for category in entry.get("members") or []:
            member = group.members.add()
            member.category = str(category)

    if "flat_style" in blob:
        prefs.flat_style = bool(blob["flat_style"])
    if "auto_apply" in blob:
        prefs.auto_apply = bool(blob["auto_apply"])
    return len(prefs.groups), len(prefs.hidden)


class NPANMGR_OT_export_settings(Operator, ExportHelper):
    bl_idname = "npanmgr.export_settings"
    bl_label = "导出设置…"
    bl_description = "把隐藏列表与合并分组导出成 JSON（可备份/换机/分享）"

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context, event):
        prefs = get_prefs(context)
        if prefs is None:
            return {"CANCELLED"}
        if not self.filepath:
            base = bpy.path.abspath("//") or ""
            self.filepath = os.path.join(base, "n_panel_manager.json")
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        prefs = get_prefs(context)
        if prefs is None:
            return {"CANCELLED"}
        try:
            with open(self.filepath, "w", encoding="utf-8") as handle:
                json.dump(_settings_blob(prefs), handle, ensure_ascii=False, indent=2)
        except Exception as exc:
            self.report({"ERROR"}, "导出失败：%s" % exc)
            return {"CANCELLED"}
        self.report({"INFO"}, "已导出到 %s" % self.filepath)
        return {"FINISHED"}


class NPANMGR_OT_import_settings(Operator, ImportHelper):
    bl_idname = "npanmgr.import_settings"
    bl_label = "导入设置…"
    bl_description = "从 JSON 恢复隐藏列表与合并分组（会覆盖当前设置）"

    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={"HIDDEN"})

    def invoke(self, context, event):
        prefs = get_prefs(context)
        if prefs is None:
            return {"CANCELLED"}
        if not self.filepath:
            base = bpy.path.abspath("//") or ""
            self.filepath = os.path.join(base, "n_panel_manager.json")
        return ImportHelper.invoke(self, context, event)

    def execute(self, context):
        prefs = get_prefs(context)
        if prefs is None:
            return {"CANCELLED"}
        try:
            with open(self.filepath, "r", encoding="utf-8") as handle:
                blob = json.load(handle)
            groups, hidden = _apply_settings_blob(prefs, blob)
        except Exception as exc:
            self.report({"ERROR"}, "导入失败：%s" % exc)
            return {"CANCELLED"}
        mod = sys.modules.get(__package__)
        if mod is not None:
            try:
                mod.ensure_keys(prefs)
                mod.normalize_orders(prefs)
                mod.normalize_names(prefs)
            except Exception:
                pass
        apply_settings(context)
        tag_redraw(context)
        self.report({"INFO"}, "已导入 %d 个分组、%d 项隐藏" % (groups, hidden))
        return {"FINISHED"}


# ------------------------------------------------------------------------------
# 菜单入口

def _menu_entry(self, context):
    self.layout.separator()
    self.layout.operator("npanmgr.open", icon="SORTALPHA")


# ------------------------------------------------------------------------------
# 自动应用

def _config_key(prefs):
    """配置指纹：只有配置变化时才重新应用（每 4 次仍强制跑一次，防漏）。"""
    groups = []
    for g in prefs.groups:
        groups.append((g.name, g.order, g.enabled,
                       tuple(m.category for m in g.members)))
    hidden = tuple((h.space, h.addon_key) for h in prefs.hidden)
    return (tuple(groups), hidden, bool(getattr(prefs, "flat_style", True)))


def _watchdog():
    try:
        prefs = get_prefs()
        if prefs is not None and prefs.auto_apply:
            _WATCH["tick"] += 1
            key = _config_key(prefs)
            if key != _WATCH["key"] or _WATCH["tick"] % 4 == 0:
                _WATCH["key"] = key
                apply_settings()
    except Exception:
        pass
    return 4.0


def _apply_once():
    try:
        apply_settings()
    except Exception:
        pass
    return None


def _on_load_post(_dummy):
    try:
        _invalidate_scan()
        _addon_name_cache.clear()
        if not bpy.app.timers.is_registered(_apply_once):
            bpy.app.timers.register(_apply_once, first_interval=0.3, persistent=False)
    except Exception:
        pass


CLASSES = (
    NPANMGR_PG_hidden,
    NPANMGR_PG_member,
    NPANMGR_PG_group,
    NPANMGR_AddonPreferences,
    NPANMGR_OT_open,
    NPANMGR_OT_toggle_addon,
    NPANMGR_OT_group_add,
    NPANMGR_OT_group_move,
    NPANMGR_OT_group_expand,
    NPANMGR_OT_group_remove,
    NPANMGR_OT_group_member,
    NPANMGR_OT_set_member,
    NPANMGR_OT_reset_all,
    NPANMGR_OT_refresh,
    NPANMGR_OT_report,
    NPANMGR_OT_export_settings,
    NPANMGR_OT_import_settings,
)

MENUS = (
    (bpy.types.VIEW3D_MT_view, _menu_entry),
    (bpy.types.VIEW3D_MT_object, _menu_entry),
)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    for owner, func in MENUS:
        try:
            owner.append(func)
        except Exception:
            pass
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not bpy.app.timers.is_registered(_watchdog):
        bpy.app.timers.register(_watchdog, first_interval=1.0, persistent=True)
    if not bpy.app.timers.is_registered(_apply_once):
        bpy.app.timers.register(_apply_once, first_interval=0.5, persistent=False)


def unregister():
    global CONFIGURED, VALID_TOKENS
    for cls in iter_panel_classes():
        try:
            if is_hidden(cls):
                show_panel(cls)
        except Exception:
            pass
    CONFIGURED = set()
    VALID_TOKENS = set()      # 代理面板也一起失效（代理不注销，靠这个隐藏）
    TOKEN_OWNER.clear()
    DRAW_ERRORS.clear()
    PROXY_CACHE.clear()
    ACTIVE.clear()
    for owner, func in MENUS:
        try:
            owner.remove(func)
        except Exception:
            pass
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for func in (_watchdog, _apply_once):
        try:
            if bpy.app.timers.is_registered(func):
                bpy.app.timers.unregister(func)
        except Exception:
            pass
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
    tag_redraw()
