"""Ari打圆 operators for Blender 5.2 LTS.

Open chains use the Circularize construction from ResampleMesh. Unconstrained
closed boundaries call Blender's native ``mesh.circularize``. GetPriority adds
two-point diameter or three-point circle constraints; face interiors stay put.
"""

from __future__ import annotations

import bmesh
import bpy
import hashlib
import json
import math
import uuid
from bpy.app.handlers import persistent
from bpy.props import (
    BoolProperty,
    BoolVectorProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from mathutils import Vector

from . import geometry

ADDON_ID = __package__ or __name__
_HISTORY_SESSION = uuid.uuid4().hex
_PRIORITY_UNDO_LAYER = '.ari_circle_priority_undo'
_PRIORITY_VERTEX_LAYER = '.ari_circle_vertex_id'
_PRIORITY_VERTEX_NEXT = '.ari_circle_vertex_id_next'
_PRIORITY_UNDO = {}
_PRIORITY_REVISION = 0
_FAILURE_HISTORY = {}

SELECTION_RESULT_ITEMS = (
    ('KEEP', "保持", "保持圆形化之前的选择"),
    ('LOOP_INNER', "循环线内侧区域", "使用 Blender 的 Loop Inner-Region"),
    ('BOUNDARY', "选中项的边界", "选择原选区的边界"),
    ('NONE', "无", "圆形化后取消全部选择"),
)
CIRCULARIZE_FIT_ITEMS = (
    ('LEAST_SQUARE', "最佳拟合", "使用最佳拟合圆"),
    ('CONTRACT', "收缩拟合", "使用收缩拟合圆"),
)


class AriCircleError(RuntimeError):
    pass


def _update_regular_defaults(preferences, context):
    # An explicit N-panel change should still control the next Alignment,
    # even after a different value was remembered from the Redo panel.
    last = context.window_manager.operator_properties_last("view3d.ari_circle_align")
    if last is not None:
        last.arc_regular = preferences.regular
        last.circle_regular = preferences.regular


def _update_planarize_defaults(preferences, context):
    last = context.window_manager.operator_properties_last("view3d.ari_circle_align")
    if last is not None:
        last.arc_planarize = preferences.planarize
        last.circle_flatten = 1.0 if preferences.planarize else 0.0


class AriPreferences(bpy.types.AddonPreferences):
    bl_idname = ADDON_ID
    angle_enabled: BoolProperty(name="角度捕捉", default=False)
    angle: FloatProperty(
        name="Angle", default=180.0, min=0.1, max=359.9,
        soft_min=30.0, soft_max=270.0, step=10, precision=3,
    )
    regular: BoolProperty(name="Regular", default=True, update=_update_regular_defaults)
    planarize: BoolProperty(name="平化", default=True, update=_update_planarize_defaults)

    def draw(self, _context):
        layout = self.layout
        layout.label(text="开放区间设置")
        layout.prop(self, "angle_enabled")
        layout.prop(self, "angle")
        layout.prop(self, "regular")
        layout.prop(self, "planarize")


def get_preferences(context):
    addon = context.preferences.addons.get(ADDON_ID)
    return addon.preferences if addon else None


def _initial_spacing_settings(context, preferences):
    """Use panel defaults only before Blender has remembered operator values."""
    last = context.window_manager.operator_properties_last("view3d.ari_circle_align")
    defaults = dict(arc_regular=preferences.regular, arc_planarize=preferences.planarize,
                    circle_regular=preferences.regular,
                    circle_flatten=1.0 if preferences.planarize else 0.0)
    # Blender marks inherited values as "ghost" properties. They still count
    # as memory, including after switching between open and closed operations.
    return {name: value for name, value in defaults.items()
            if last is None or not last.is_property_set(name, ghost=False)}


def _active_edit_mesh(context):
    obj = context.active_object
    if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT':
        raise AriCircleError("请在网格 Edit Mode 中选择顶点、边或面")
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    return obj, bm


def _to_tuple(vector):
    return (float(vector.x), float(vector.y), float(vector.z))


def _world_points(obj, verts):
    matrix = obj.matrix_world
    return [_to_tuple(matrix @ vert.co) for vert in verts]


def _local_point(obj, point):
    return obj.matrix_world.inverted() @ Vector(point)


def _component_edges(edges):
    remaining = set(edges)
    components = []
    while remaining:
        seed = min(remaining, key=lambda edge: edge.index)
        remaining.remove(seed)
        component = {seed}
        stack = [seed]
        while stack:
            edge = stack.pop()
            for vert in edge.verts:
                for linked in vert.link_edges:
                    if linked in remaining:
                        remaining.remove(linked)
                        component.add(linked)
                        stack.append(linked)
        components.append(component)
    return components


def _component_faces(faces):
    """Separate the selection, not the whole mesh it belongs to.

    Faces touching at a vertex stay together: they cannot be moved independently
    without moving that shared vertex in a skipped region as well.
    """
    remaining = set(faces)
    components = []
    while remaining:
        seed = min(remaining, key=lambda face: face.index)
        remaining.remove(seed)
        component, stack = {seed}, [seed]
        while stack:
            face = stack.pop()
            for vert in face.verts:
                for linked in vert.link_faces:
                    if linked in remaining:
                        remaining.remove(linked)
                        component.add(linked)
                        stack.append(linked)
        components.append(component)
    return components


def _ordered_edge_component(edges):
    adjacency = {}
    for edge in edges:
        for vert in edge.verts:
            adjacency.setdefault(vert, []).append(edge)
    if any(len(linked) > 2 for linked in adjacency.values()):
        raise AriCircleError("选中的边包含分叉，请选择单条连续边链或单个边环")
    endpoints = [vert for vert, linked in adjacency.items() if len(linked) == 1]
    if len(endpoints) not in (0, 2):
        raise AriCircleError("无法将当前边选择解析为单条连续链")
    closed = len(endpoints) == 0
    start = min(endpoints or adjacency.keys(), key=lambda vert: vert.index)
    ordered = [start]
    used_edges = set()
    current = start
    previous_edge = None
    while True:
        candidates = [
            edge for edge in adjacency[current]
            if edge is not previous_edge and edge not in used_edges
        ]
        if not candidates:
            break
        edge = min(candidates, key=lambda item: item.index)
        used_edges.add(edge)
        next_vert = edge.other_vert(current)
        if next_vert is start:
            closed = True
            break
        ordered.append(next_vert)
        previous_edge = edge
        current = next_vert
    if len(used_edges) != len(edges):
        raise AriCircleError("边选择中包含无法排序的分叉或断裂部分")
    return [vert.index for vert in ordered], closed


def _selected_vertices_in_history(bm):
    selected = {vert for vert in bm.verts if vert.select and not vert.hide}
    history = [
        element for element in bm.select_history
        if isinstance(element, bmesh.types.BMVert) and element in selected
    ]
    ordered = []
    for vert in history:
        if vert not in ordered:
            ordered.append(vert)
    ordered.extend(sorted(selected - set(ordered), key=lambda vert: vert.index))
    return ordered


def _selected_vertex_components(bm):
    selected = {vert for vert in bm.verts if vert.select and not vert.hide}
    if not selected:
        return []
    selected_edges = {
        edge for edge in bm.edges
        if edge.select and not edge.hide and all(vert in selected for vert in edge.verts)
    }
    if not selected_edges:
        selected_edges = {
            edge for edge in bm.edges
            if not edge.hide and all(vert in selected for vert in edge.verts)
        }
    if not selected_edges:
        ordered = _selected_vertices_in_history(bm)
        return [([vert.index for vert in ordered], False)]
    sequences = [
        _ordered_edge_component(component)
        for component in _component_edges(selected_edges)
    ]
    used = {index for sequence, _closed in sequences for index in sequence}
    for vert in sorted(selected - {bm.verts[index] for index in used}, key=lambda item: item.index):
        sequences.append(([vert.index], False))
    return sequences


def _boundary_edges_from_faces(faces):
    counts = {}
    for face in faces:
        for edge in face.edges:
            counts[edge] = counts.get(edge, 0) + 1
    return [edge for edge, count in counts.items() if count == 1]


def _outer_region_boundary(obj, bm, face_indices):
    """Return the outer boundary of a selected face region.

    A face-region selection can have more than one boundary component (for
    example, an annular selection has an outer and an inner loop).  Blender's
    native To Circle operates on every selected vertex, so passing the whole
    region would also move the inner loop and the interior topology.  Pick the
    boundary component with the largest mean radius from the region center and
    use only that component for the native operation.
    """
    faces = [bm.faces[index] for index in face_indices]
    boundary = _boundary_edges_from_faces(faces)
    if not boundary:
        raise AriCircleError("选中的面没有可处理的外部边界")

    region_vertices = {
        vert for face in faces for vert in face.verts
    }
    if not region_vertices:
        raise AriCircleError("选中的面没有可处理的顶点")
    center = Vector((0.0, 0.0, 0.0))
    for vert in region_vertices:
        center += obj.matrix_world @ vert.co
    center /= len(region_vertices)

    candidates = []
    for component in _component_edges(boundary):
        vertex_indices, closed = _ordered_edge_component(component)
        if len(vertex_indices) < 3:
            continue
        points = [obj.matrix_world @ bm.verts[index].co for index in vertex_indices]
        mean_radius = sum((point - center).length for point in points) / len(points)
        candidates.append((mean_radius, set(vertex_indices), {edge.index for edge in component}, closed))

    if not candidates:
        raise AriCircleError("无法识别选中的面区域外部边界")
    # The outer loop is the component furthest from the selected region's
    # center.  The index tie-breaker keeps the result deterministic on meshes
    # with equal-radius components.
    _radius, vertex_indices, edge_indices, closed = max(
        candidates,
        key=lambda item: (item[0], min(item[1])),
    )
    if not closed:
        raise AriCircleError("选中的面区域外部边界不是闭合边环")
    return vertex_indices, edge_indices


def selected_sequences(context):
    obj, bm = _active_edit_mesh(context)
    vertex_mode, edge_mode, face_mode = context.tool_settings.mesh_select_mode
    if face_mode:
        faces = [face for face in bm.faces if face.select and not face.hide]
        if faces:
            boundary = _boundary_edges_from_faces(faces)
            if not boundary:
                raise AriCircleError("选中的面没有可处理的边界")
            return obj, [
                _ordered_edge_component(component)
                for component in _component_edges(boundary)
            ]
    if edge_mode:
        edges = [edge for edge in bm.edges if edge.select and not edge.hide]
        if edges:
            return obj, [
                _ordered_edge_component(component)
                for component in _component_edges(edges)
            ]
    if vertex_mode:
        sequences = _selected_vertex_components(bm)
        if sequences:
            return obj, sequences
    raise AriCircleError("请选择至少三个顶点，或选择一条边链/边环")


def _priority_indices(scene, obj):
    if scene.ari_circle_priority_object != obj:
        return set()
    result = set()
    for value in scene.ari_circle_priority_indices.strip().split(','):
        try:
            if value:
                result.add(int(value))
        except ValueError:
            pass
    references = _priority_reference_map(scene, obj)
    return {references.get(index, (index, 0))[0] for index in result}


def _priority_reference_map(scene, obj):
    """Resolve saved vertex identities to current indices, never old positions.

    F dissolves interior vertices and renumbers the survivors. Integer custom
    data stays attached to surviving BMesh vertices, including across Undo and
    mode changes. Missing/ambiguous identities use out-of-range indices so the
    existing constraint validation cannot silently target an unrelated vertex.
    """
    if scene.ari_circle_priority_object != obj or not scene.ari_circle_priority_references:
        return {}
    saved = json.loads(scene.ari_circle_priority_references)
    if obj.data.is_editmode:
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.index_update()
        layer = bm.verts.layers.int.get(_PRIORITY_VERTEX_LAYER)
        identities = [v[layer] for v in bm.verts] if layer else [0] * len(bm.verts)
    else:
        layer = obj.data.attributes.get(_PRIORITY_VERTEX_LAYER)
        identities = [item.value for item in layer.data] if layer else [0] * len(obj.data.vertices)
    positions = {}
    for index, identity in enumerate(identities):
        if identity:
            positions[identity] = index if identity not in positions else None
    result = {}
    for ordinal, (old_index, identity) in enumerate(saved):
        index = positions.get(identity)
        result[old_index] = (len(identities) + ordinal if index is None else index, identity)
    return result


def _make_priority_references(scene, obj, indices):
    """Assign durable IDs only when recording/migrating pins, not while drawing."""
    previous = {index: identity for index, identity in _priority_reference_map(scene, obj).values()}
    mesh = obj.data
    editing = mesh.is_editmode
    bm = bmesh.from_edit_mesh(mesh) if editing else bmesh.new()
    if not editing:
        bm.from_mesh(mesh)
    try:
        bm.verts.ensure_lookup_table()
        layer = bm.verts.layers.int.get(_PRIORITY_VERTEX_LAYER)
        if layer is None:
            layer = bm.verts.layers.int.new(_PRIORITY_VERTEX_LAYER)
        counts = {}
        for vert in bm.verts:
            identity = vert[layer]
            counts[identity] = counts.get(identity, 0) + 1
        next_id = max(mesh.get(_PRIORITY_VERTEX_NEXT, 0), max(counts, default=0),
                      max(previous.values(), default=0))
        saved = []
        for index in sorted(indices):
            if 0 <= index < len(bm.verts):
                vert = bm.verts[index]
                identity = vert[layer]
                if not identity or counts[identity] > 1:
                    next_id += 1
                    identity = vert[layer] = next_id
                saved.append((index, identity))
            elif index in previous:
                # Appending a new pick must not reassign a deleted old pin.
                saved.append((index, previous[index]))
        mesh[_PRIORITY_VERTEX_NEXT] = next_id
        if editing:
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        else:
            bm.to_mesh(mesh)
        return json.dumps(saved, separators=(',', ':'))
    finally:
        if not editing:
            bm.free()


@persistent
def _migrate_priority_references(_unused=None):
    # Also run once after registration (when Blender's restricted context has
    # ended), so intact pins in an older file acquire IDs before mesh edits.
    for scene in bpy.data.scenes:
        obj = scene.ari_circle_priority_object
        if obj is not None and scene.ari_circle_priority_indices and not scene.ari_circle_priority_references:
            scene.ari_circle_priority_references = _make_priority_references(
                scene, obj, _priority_indices(scene, obj))


def _alignment_priority(context, obj):
    """Disabling constraints keeps the stored set available for re-enabling."""
    return (_priority_indices(context.scene, obj)
            if context.window_manager.ari_circle_priority_enabled else set())


def _redraw_priority_controls(window_manager, _context):
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _encode_indices(indices):
    return ','.join(str(index) for index in sorted(indices))


def _priority_state(scene):
    owner = scene.ari_circle_priority_object
    return (owner.session_uid if owner else None, scene.ari_circle_priority_indices,
            scene.ari_circle_priority_references)


def _priority_undo_token(bm):
    layer = bm.verts.layers.int.get(_PRIORITY_UNDO_LAYER)
    return max((vert[layer] for vert in bm.verts), default=0) if layer else 0


def _write_priority(context, obj, indices):
    """Keep the Scene API, but carry its history through native mesh undo.

    Edit Mode undo restores BMesh custom data, not Scene properties. A hidden
    integer layer identifies each saved snapshot. Store IDs rather than RNA
    references because global undo may replace the underlying datablocks.
    """
    global _PRIORITY_REVISION
    scene = context.scene
    _migrate_priority_references()
    edit_obj = context.edit_object
    record = None
    if edit_obj is not None and edit_obj.type == 'MESH':
        bm = bmesh.from_edit_mesh(edit_obj.data)
        if bm.verts:
            key = (scene.session_uid, edit_obj.data.session_uid)
            token = _priority_undo_token(bm)
            record = _PRIORITY_UNDO.setdefault(key, {
                'observed': token, 'next': token, 'states': {}, 'revisions': {},
            })
            # Capture the state *before* creating the first layer, too. Undo
            # of the first GetPriority removes that layer entirely (token 0).
            record['states'][token] = _priority_state(scene)
            record['revisions'][token] = scene.ari_circle_priority_revision
            record['next'] += 1
            token = record['next']
            layer = bm.verts.layers.int.get(_PRIORITY_UNDO_LAYER)
            if layer is None:
                layer = bm.verts.layers.int.new(_PRIORITY_UNDO_LAYER)
            for vert in bm.verts:
                vert[layer] = token
            record['observed'] = token
            bmesh.update_edit_mesh(edit_obj.data, loop_triangles=False, destructive=False)
    _PRIORITY_REVISION = max(_PRIORITY_REVISION, scene.ari_circle_priority_revision) + 1
    scene.ari_circle_priority_revision = _PRIORITY_REVISION
    references = _make_priority_references(scene, obj, indices) if obj and indices else ''
    scene.ari_circle_priority_object = obj if indices else None
    scene.ari_circle_priority_indices = _encode_indices(indices)
    scene.ari_circle_priority_references = references
    if record is not None:
        record['states'][token] = _priority_state(scene)
        record['revisions'][token] = scene.ari_circle_priority_revision


@persistent
def _remember_priority_before_undo(_unused):
    # A loaded .blend (or re-enabled add-on) can already contain saved picks,
    # but has no Python undo cache yet. Seed its current snapshot before an
    # unrelated operator's redo has a chance to roll the Scene properties back.
    context = bpy.context
    scene, obj = context.scene, context.edit_object
    if (scene is None or obj is None or obj.type != 'MESH'
            or scene.ari_circle_priority_object != obj):
        return
    key = (scene.session_uid, obj.data.session_uid)
    if key in _PRIORITY_UNDO:
        return
    token = _priority_undo_token(bmesh.from_edit_mesh(obj.data))
    _PRIORITY_UNDO[key] = dict(observed=token, next=token,
                              states={token: _priority_state(scene)},
                              revisions={token: scene.ari_circle_priority_revision})


@persistent
def _restore_priority_after_undo(_unused):
    context = bpy.context
    _restore_failure_history()
    obj = context.edit_object
    if obj is None or obj.type != 'MESH':
        return  # Object Mode uses Blender's normal Scene-property undo.
    scene = context.scene
    record = _PRIORITY_UNDO.get((scene.session_uid, obj.data.session_uid))
    if record is None:
        return
    bm = bmesh.from_edit_mesh(obj.data)
    if not bm.verts:
        return  # Deleting geometry is not an explicit Clear of the saved set.
    token = _priority_undo_token(bm)
    revision = record['revisions'].get(token, 0)
    if token == record['observed'] and scene.ari_circle_priority_revision > revision:
        # A later pick on another mesh, or Object Mode Clear, owns the Scene.
        return
    # A mixed global/edit undo may roll Scene properties back even when the
    # BMesh token stays unchanged. Always reconcile that stale Scene snapshot.
    record['observed'] = token
    state = record['states'].get(token)
    if state is None:
        return
    owner_uid, indices, references = state
    owner = next((item for item in bpy.data.objects if item.session_uid == owner_uid), None)
    scene.ari_circle_priority_object = owner
    scene.ari_circle_priority_indices = indices if owner else ''
    scene.ari_circle_priority_references = references if owner else ''
    scene.ari_circle_priority_revision = revision
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _decode_indices(values):
    return {int(value) for value in values.split(',') if value}


def _encode_vertex_coordinates(bm, indices):
    return json.dumps(
        [[index, *bm.verts[index].co] for index in sorted(indices)],
        separators=(',', ':'),
    )


def _decode_vertex_coordinates(values):
    try:
        return [
            (int(value[0]), tuple(float(item) for item in value[1:4]))
            for value in json.loads(values or '[]') if len(value) == 4
        ]
    except (TypeError, ValueError, json.JSONDecodeError) as error:
        raise AriCircleError("无法恢复 Alignment 的初始顶点位置，请重新执行") from error


def _snapshot_source(operator, context):
    obj, bm = _active_edit_mesh(context)
    vertex_indices = {vert.index for vert in bm.verts if vert.select and not vert.hide}
    edge_indices = {edge.index for edge in bm.edges if edge.select and not edge.hide}
    face_indices = {face.index for face in bm.faces if face.select and not face.hide}
    source_vertices = set(vertex_indices)
    for index in edge_indices:
        source_vertices.update(vert.index for vert in bm.edges[index].verts)
    for index in face_indices:
        source_vertices.update(vert.index for vert in bm.faces[index].verts)
    operator.source_object_name = obj.name
    operator.source_select_mode = tuple(context.tool_settings.mesh_select_mode)
    operator.source_vert_indices = _encode_indices(vertex_indices)
    operator.source_selected_edge_indices = _encode_indices(edge_indices)
    operator.source_face_indices = _encode_indices(face_indices)
    operator.source_vertex_coordinates = _encode_vertex_coordinates(bm, source_vertices)
    operator.source_snapshot = True


def _source_object(context, operator):
    # A redo must operate on the object that is currently active in this
    # ViewLayer. Looking the object up in bpy.data and calling select_set() is
    # unsafe: an object can exist in bpy.data while not being linked to the
    # current ViewLayer, which produces Blender's misleading "not in view
    # layer" error. A changed active object is a normal redo mismatch.
    obj = context.active_object
    if obj is None or obj.type != 'MESH' or obj.name != operator.source_object_name:
        raise AriCircleError("重做目标对象已改变，请重新执行 Alignment")
    if obj.mode != 'EDIT':
        raise AriCircleError("请在同一个网格 Edit Mode 中调整 Alignment")
    return obj, bmesh.from_edit_mesh(obj.data)


def _set_exact_selection(context, obj, select_mode, vertex_indices, edge_indices, face_indices):
    mode = tuple(bool(value) for value in select_mode)
    if not any(mode):
        mode = (False, True, False)
    context.tool_settings.mesh_select_mode = mode
    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    for face in bm.faces:
        face.select_set(False)
    for edge in bm.edges:
        edge.select_set(False)
    for vert in bm.verts:
        vert.select_set(False)
    if mode[2]:
        for index in face_indices:
            if 0 <= index < len(bm.faces):
                bm.faces[index].select_set(True)
    elif mode[1]:
        for index in edge_indices:
            if 0 <= index < len(bm.edges):
                bm.edges[index].select_set(True)
    else:
        for index in vertex_indices:
            if 0 <= index < len(bm.verts):
                bm.verts[index].select_set(True)
    bm.select_flush_mode()
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _restore_source(context, operator):
    obj, bm = _source_object(context, operator)
    bm.verts.ensure_lookup_table()
    for index, coordinate in _decode_vertex_coordinates(operator.source_vertex_coordinates):
        if not 0 <= index < len(bm.verts):
            raise AriCircleError("网格拓扑已改变，请重新执行 Alignment")
        bm.verts[index].co = coordinate
    bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=False)
    _set_exact_selection(
        context, obj, tuple(operator.source_select_mode),
        _decode_indices(operator.source_vert_indices),
        _decode_indices(operator.source_selected_edge_indices),
        _decode_indices(operator.source_face_indices),
    )
    return obj, bmesh.from_edit_mesh(obj.data)


def _selected_loop_edge_indices(bm, sequences):
    edge_indices = set()
    for vertex_indices, closed in sequences:
        if not closed:
            continue
        for index, first_index in enumerate(vertex_indices):
            second_index = vertex_indices[(index + 1) % len(vertex_indices)]
            first = bm.verts[first_index]
            second = bm.verts[second_index]
            edge = next(
                (candidate for candidate in first.link_edges
                 if candidate.other_vert(first) is second), None,
            )
            if edge is None:
                raise AriCircleError("无法从所选顶点恢复闭合边环")
            edge_indices.add(edge.index)
    return edge_indices


def _closed_selection_kind(context):
    _obj, bm = _active_edit_mesh(context)
    if context.tool_settings.mesh_select_mode[2]:
        if any(face.select and not face.hide for face in bm.faces):
            return 'REGION'
    _obj, sequences = selected_sequences(context)
    if all(closed for _indices, closed in sequences):
        return 'LOOP'
    if not any(closed for _indices, closed in sequences):
        return 'OPEN'
    raise AriCircleError("当前选择同时包含开放链和闭合环，请分开执行 Alignment")


def _closed_source_data(context, selection_kind):
    obj, bm = _active_edit_mesh(context)
    face_indices = {face.index for face in bm.faces if face.select and not face.hide}
    if selection_kind == 'REGION':
        edge_indices = {
            edge.index for edge in _boundary_edges_from_faces(
                [bm.faces[index] for index in face_indices]
            )
        }
        vertex_indices = {
            vert.index for index in face_indices for vert in bm.faces[index].verts
        }
    else:
        _obj, sequences = selected_sequences(context)
        edge_indices = _selected_loop_edge_indices(bm, sequences)
        vertex_indices = {
            index for sequence, _closed in sequences for index in sequence
        }
    return obj, bm, vertex_indices, edge_indices, face_indices


def _closed_selection_regions(bm, selection_kind, edge_indices, face_indices):
    if selection_kind == 'REGION':
        return [
            dict(vertices={v.index for f in faces for v in f.verts},
                 edges={e.index for f in faces for e in f.edges},
                 faces={f.index for f in faces})
            for faces in _component_faces([bm.faces[i] for i in face_indices])
        ]
    return [
        dict(vertices={v.index for e in edges for v in e.verts},
             edges={e.index for e in edges},
             faces={i for i in face_indices if all(e in edges for e in bm.faces[i].edges)})
        for edges in _component_edges([bm.edges[i] for i in edge_indices])
    ]


def _set_boundary_selection(context, obj, edge_indices):
    context.tool_settings.mesh_select_mode = (False, True, False)
    bm = bmesh.from_edit_mesh(obj.data)
    for face in bm.faces:
        face.select_set(False)
    for edge in bm.edges:
        edge.select_set(edge.index in edge_indices)
    for vert in bm.verts:
        vert.select_set(any(edge.select for edge in vert.link_edges))
    bm.select_flush_mode()
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _set_region_selection(context, obj, face_indices):
    context.tool_settings.mesh_select_mode = (False, False, True)
    bm = bmesh.from_edit_mesh(obj.data)
    for face in bm.faces:
        face.select_set(False)
    for edge in bm.edges:
        edge.select_set(False)
    for vert in bm.verts:
        vert.select_set(False)
    for face in bm.faces:
        face.select_set(face.index in face_indices)
    bm.select_flush_mode()
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _deselect_all(obj):
    bm = bmesh.from_edit_mesh(obj.data)
    for face in bm.faces:
        face.select_set(False)
    for edge in bm.edges:
        edge.select_set(False)
    for vert in bm.verts:
        vert.select_set(False)
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


def _apply_result_selection(context, operator, obj, selection_kind, edge_indices, face_indices):
    if operator.selection_result == 'KEEP':
        _set_exact_selection(
            context, obj, tuple(operator.source_select_mode),
            _decode_indices(operator.source_vert_indices),
            _decode_indices(operator.source_selected_edge_indices),
            _decode_indices(operator.source_face_indices),
        )
    elif operator.selection_result == 'NONE':
        _deselect_all(obj)
    elif operator.selection_result == 'BOUNDARY':
        _set_boundary_selection(context, obj, edge_indices)
    else:
        _set_boundary_selection(context, obj, edge_indices)
        result = bpy.ops.mesh.loop_to_region(select_bigger=False)
        if 'FINISHED' not in result:
            if selection_kind == 'REGION':
                _set_region_selection(context, obj, face_indices)
            else:
                raise AriCircleError("无法选择闭合环内侧区域")


def _topology_signature(bm):
    """Reject history indices after topology changes, including equal counts."""
    digest = hashlib.sha256()
    digest.update(str((len(bm.verts), len(bm.edges), len(bm.faces))).encode('ascii'))
    for edge in bm.edges:
        digest.update(str(tuple(sorted(v.index for v in edge.verts))).encode('ascii'))
    for face in bm.faces:
        digest.update(str(tuple(v.index for v in face.verts)).encode('ascii'))
    return digest.hexdigest()


def _clear_failure_history(scene):
    scene.ari_circle_failure_data = ''
    scene.ari_circle_failure_object = None
    scene.ari_circle_failure_mesh = None
    _FAILURE_HISTORY[scene.session_uid] = (None, None, '')


def _restore_failure_history():
    """The latest failed selection is session data, outside geometry undo.

    Keep IDs, not RNA references: global undo can replace the datablocks.
    Only a new failure, explicit Clear, or file load replaces this record.
    """
    if not _FAILURE_HISTORY:
        return
    objects = {obj.session_uid: obj for obj in bpy.data.objects}
    meshes = {mesh.session_uid: mesh for mesh in bpy.data.meshes}
    for scene in bpy.data.scenes:
        state = _FAILURE_HISTORY.get(scene.session_uid)
        if state is None:
            continue
        owner_uid, mesh_uid, data = state
        scene.ari_circle_failure_object = objects.get(owner_uid)
        scene.ari_circle_failure_mesh = meshes.get(mesh_uid)
        scene.ari_circle_failure_data = data


@persistent
def _clear_failure_history_on_load(_unused):
    # History is a session convenience, not a selection saved in a .blend file.
    _PRIORITY_UNDO.clear()
    for scene in getattr(bpy.data, 'scenes', ()):
        _clear_failure_history(scene)
    _FAILURE_HISTORY.clear()


def _failure_history(scene):
    if scene.ari_circle_failure_object is None or scene.ari_circle_failure_mesh is None:
        return None
    try:
        data = json.loads(scene.ari_circle_failure_data or '{}')
    except (TypeError, ValueError):
        return None
    return data if data.get('session') == _HISTORY_SESSION and data.get('regions') else None


def _store_failure_history(context, operator, obj, bm, failures):
    # Only new failures replace the record. Successful operations leave the
    # previous failed selection available until explicitly cleared.
    if not failures:
        return
    source = dict(vertices=_decode_indices(operator.source_vert_indices),
                  edges=_decode_indices(operator.source_selected_edge_indices),
                  faces=_decode_indices(operator.source_face_indices))
    regions = [
        dict(number=failure['number'], reason=failure['reason'],
             priority_count=failure['priority_count'],
             **{key: sorted(failure[key] & source[key]) for key in source})
        for failure in failures
    ]
    data = dict(session=_HISTORY_SESSION, mode=list(operator.source_select_mode), regions=regions,
                topology=_topology_signature(bm))
    context.scene.ari_circle_failure_object = obj
    context.scene.ari_circle_failure_mesh = obj.data
    context.scene.ari_circle_failure_data = json.dumps(data, separators=(',', ':'))
    _FAILURE_HISTORY[context.scene.session_uid] = (
        obj.session_uid, obj.data.session_uid, context.scene.ari_circle_failure_data)


def _align_multiple_closed_regions(context, operator, obj, bm, selection_kind,
                                   regions, edge_indices, face_indices):
    """Only two anchors on each region's own outer boundary enable a batch item."""
    saved = _alignment_priority(context, obj)
    pending, failures, completed = {}, [], 0
    for number, region in enumerate(regions, 1):
        priority_count = None
        try:
            if selection_kind == 'REGION':
                boundary_vertices, boundary_edges = _outer_region_boundary(obj, bm, region['faces'])
            else:
                boundary_vertices, boundary_edges = region['vertices'], region['edges']
            anchors = saved & boundary_vertices
            priority_count = len(anchors)
            if priority_count != 2:
                raise AriCircleError(f"边界包含 {priority_count} 个固定点，需要恰好 2 个")
            targets, _edges = _priority_pair_targets(obj, bm, boundary_edges, anchors, operator)
        except (AriCircleError, ValueError, ZeroDivisionError) as error:
            failures.append(dict(region, number=number, priority_count=priority_count, reason=str(error)))
            continue
        pending.update(targets)
        completed += 1

    # Fit every item from its original coordinates before writing any result.
    for index, target in pending.items():
        bm.verts[index].co = target
    bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=False)
    operator.fixed_diameter = True
    _store_failure_history(context, operator, obj, bm, failures)
    _apply_result_selection(context, operator, obj, selection_kind, edge_indices, face_indices)
    if failures:
        operator.report({'WARNING'}, f"已圆化 {completed} 个区域，跳过 {len(failures)} 个；可用“选择失效历史”选回")
    else:
        operator.report({'INFO'}, f"已圆化全部 {completed} 个区域")
    return {'FINISHED'}


def _circle_from_three_points(points):
    """The formula used by big_tools' rara.model_find_circle_center."""
    p1, p2, p3 = (Vector(point) for point in points)
    v1, v2 = p2 - p1, p3 - p1
    normal = v1.cross(v2)
    scale2 = max(v1.length_squared, v2.length_squared, 1.0e-10)
    if normal.length_squared < scale2 * 1.0e-12:
        raise AriCircleError("GetPriority=3 的三个顶点几乎共线，无法确定圆")
    normal.normalize()
    a = (p2 - p3).length_squared
    b = (p3 - p1).length_squared
    c = (p1 - p2).length_squared
    denominator = 2.0 * (a * b + b * c + c * a) - (a * a + b * b + c * c)
    if abs(denominator) < 1.0e-15:
        raise AriCircleError("GetPriority=3 的三个顶点无法确定有效圆")
    center = Vector((
        (a * (b + c - a) * p1.x + b * (c + a - b) * p2.x + c * (a + b - c) * p3.x) / denominator,
        (a * (b + c - a) * p1.y + b * (c + a - b) * p2.y + c * (a + b - c) * p3.y) / denominator,
        (a * (b + c - a) * p1.z + b * (c + a - b) * p2.z + c * (a + b - c) * p3.z) / denominator,
    ))
    radius = (p1 - center).length
    if radius <= geometry.EPSILON:
        raise AriCircleError("GetPriority=3 计算出的圆半径无效")
    return center, radius, normal


def _priority_three_targets(obj, bm, vertex_indices, priority_indices, operator):
    """Fit the selected boundary to the circle through all three references.

    References belong to the active mesh, but need not belong to the selection
    or its operation boundary. They define the mathematical circle; no new mesh
    vertices or edges are needed at the external reference positions.
    """
    anchors = sorted(priority_indices)
    if len(anchors) != 3 or any(index < 0 or index >= len(bm.verts) for index in anchors):
        raise AriCircleError("GetPriority=3 的参考顶点已失效，请清除并重新拾取三个顶点")
    anchor_points = _world_points(obj, [bm.verts[index] for index in anchors])
    center, radius, normal = _circle_from_three_points(anchor_points)
    points = _world_points(obj, [bm.verts[index] for index in vertex_indices])
    result = []
    for index, point in zip(vertex_indices, points):
        source = Vector(point)
        if operator.circle_flatten > 0.0:
            source -= normal * ((source - center).dot(normal) * operator.circle_flatten)
        radial = source - center
        radial -= normal * radial.dot(normal)
        if radial.length <= geometry.EPSILON:
            radial = Vector(anchor_points[0]) - center
            radial -= normal * radial.dot(normal)
        if radial.length <= geometry.EPSILON:
            raise AriCircleError("无法为选区建立圆周方向")
        target = center + radial.normalized() * radius
        if index in anchors:
            # GetPriority=3 defines the circle itself. The three defining
            # vertices are fixed even when Factor is below one or a custom
            # radius was left over in the native To Circle panel.
            result.append(point)
        else:
            result.append(tuple(source.lerp(target, operator.circle_factor)))
    return result


def _priority_pair_targets(obj, bm, edge_indices, priority_indices, operator):
    """Build two semicircles on the loop containing both diameter anchors.

    A similarity transform of an unconstrained native circle only fixes a
    chord. With unequal side counts that chord is not a diameter. Apply the
    diameter constraint directly, using edge order to split the two paths.
    """
    components = _component_edges([bm.edges[i] for i in edge_indices])
    for component in components:
        vertices = {v.index for edge in component for v in edge.verts}
        if not priority_indices.intersection(vertices):
            continue
        if not priority_indices.issubset(vertices):
            raise AriCircleError("GetPriority=2 的两个顶点必须位于同一个闭合边环")
        ordered, closed = _ordered_edge_component(component)
        if not closed:
            raise AriCircleError("GetPriority=2 需要闭合边环")
        points = _world_points(obj, [bm.verts[i] for i in ordered])
        anchors = [position for position, i in enumerate(ordered) if i in priority_indices]
        targets, normal_tuple = geometry.diameter_circle(points, anchors, operator.circle_regular)
        normal = Vector(normal_tuple)
        center = (Vector(points[anchors[0]]) + Vector(points[anchors[1]])) * 0.5
        result = {}
        for index, point, target in zip(ordered, points, targets):
            if index in priority_indices:
                continue  # Leave the stored local coordinates bit-for-bit intact.
            height = (Vector(point) - center).dot(normal)
            target = Vector(target) + normal * height * (1.0 - operator.circle_flatten)
            original = bm.verts[index].co
            local = original.lerp(_local_point(obj, target), operator.circle_factor)
            for axis, locked in enumerate(operator.circle_lock):
                if locked:
                    local[axis] = original[axis]
            result[index] = local
        return result, {edge.index for edge in component}
    raise AriCircleError("GetPriority=2 必须在当前闭合选区中包含两个优先顶点")


def _native_closed_to_circle(context, operator, selection_kind, vertex_indices, edge_indices, face_indices,
                             *, apply_selection=True):
    obj, bm = _active_edit_mesh(context)
    # A face-region selection may contain an inner loop and many interior
    # vertices.  To Circle must receive only the region's outer boundary;
    # otherwise Blender correctly circularizes every selected vertex, which is
    # not the desired To Circle Plus behavior for a multi-layer face region.
    if selection_kind == 'REGION':
        operation_vertex_set, operation_edge_set = _outer_region_boundary(
            obj, bm, face_indices,
        )
    else:
        operation_vertex_set = set(vertex_indices)
        operation_edge_set = set(edge_indices)
    operation_vertex_indices = sorted(operation_vertex_set)
    operation_edge_indices = set(operation_edge_set)
    if len(operation_vertex_indices) < 3:
        raise AriCircleError("圆形化至少需要三个外部边界顶点")

    saved_priority = _alignment_priority(context, obj)
    # Three saved vertices define a circle even when zero, one or two of them
    # are on this boundary. Do not reclassify that mode by selection overlap.
    # Keep the existing zero/two-point behavior unchanged.
    priority = (saved_priority if len(saved_priority) == 3 else
                saved_priority.intersection(operation_vertex_set))
    operator.fixed_diameter = len(priority) == 2
    if len(priority) == 3:
        target = _priority_three_targets(
            obj, bm, operation_vertex_indices, priority, operator,
        )
        for index, point in zip(operation_vertex_indices, target):
            if index in priority:
                continue  # Preserve reference coordinates exactly, including under object transforms.
            bm.verts[index].co = _local_point(obj, point)
        bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=False)
    else:
        if priority and len(priority) != 2:
            raise AriCircleError("闭合区间的 GetPriority 只支持两个或三个顶点")
        pair_targets = {}
        if len(priority) == 2:
            pair_targets, pair_edges = _priority_pair_targets(
                obj, bm, operation_edge_indices, priority, operator,
            )
            operation_edge_indices -= pair_edges
        # Restrict native To Circle to the operation boundary.  The original
        # region selection is restored below. Unconstrained loops continue to
        # use Blender's native algorithm and all its original parameters.
        if operation_edge_indices:
            _set_boundary_selection(context, obj, operation_edge_indices)
            result = bpy.ops.mesh.circularize(
                factor=operator.circle_factor,
                fit_method=operator.circle_fit_method,
                angle=operator.circle_angle,
                use_custom_radius=operator.circle_use_custom_radius,
                custom_radius=operator.circle_custom_radius,
                regular=operator.circle_regular,
                flatten=operator.circle_flatten,
                lock=operator.circle_lock,
            )
            if 'FINISHED' not in result:
                raise AriCircleError("Blender 圆形化操作执行失败")
        if pair_targets:
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            for index, target in pair_targets.items():
                bm.verts[index].co = target
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=False)
    if apply_selection:
        _apply_result_selection(context, operator, obj, selection_kind, edge_indices, face_indices)
    return len(operation_vertex_indices)


def _fallback_normal(context):
    region_3d = getattr(context, 'region_data', None)
    if region_3d is not None:
        try:
            return _to_tuple(region_3d.view_rotation @ Vector((0.0, 0.0, 1.0)))
        except (AttributeError, TypeError, ValueError):
            pass
    return (0.0, 0.0, 1.0)


def _normal_for(points, center, fallback):
    normal = geometry.polygon_normal(points, center, fallback=fallback)
    if normal is None:
        raise AriCircleError("所选点无法确定计算平面")
    return normal


def _resolve_angle(points, angle_enabled, angle):
    if angle_enabled:
        return max(0.1, min(359.9, float(angle)))
    try:
        return geometry.estimate_arc_angle(points)
    except ValueError as error:
        raise AriCircleError(str(error)) from error


def _circularize_arc_targets(points, angle_degrees, normal, flip=False):
    if len(points) < 3:
        raise AriCircleError("开放链至少需要三个顶点")
    signed_angle = math.radians(max(0.1, min(359.9, float(angle_degrees))) * (-1.0 if flip else 1.0))
    first, second, last, penultimate = points[0], points[1], points[-1], points[-2]
    midpoint = geometry.mul(geometry.add(first, last), 0.5)
    chord_half = geometry.sub(midpoint, first)
    half_chord = geometry.length(chord_half)
    if half_chord <= geometry.EPSILON:
        raise AriCircleError("开放链首尾端点不能重合")
    axis = geometry.normalize(geometry.cross(
        chord_half,
        geometry.add(geometry.sub(first, second), geometry.sub(last, penultimate)),
    )) or geometry.normalize(normal)
    if axis is None:
        raise AriCircleError("无法建立开放链圆弧平面")
    tangent = geometry.normalize(geometry.cross(axis, chord_half))
    if tangent is None:
        raise AriCircleError("无法建立开放链圆弧方向")
    center = geometry.add(midpoint, geometry.mul(tangent, half_chord / math.tan(signed_angle * 0.5)))
    radial = geometry.sub(first, center)
    result = []
    for index in range(len(points)):
        radians = signed_angle * index / (len(points) - 1)
        rotated = geometry.add(
            geometry.mul(radial, math.cos(radians)),
            geometry.mul(geometry.cross(axis, radial), math.sin(radians)),
        )
        result.append(geometry.add(center, rotated))
    return result


def _open_targets(context, obj, bm, vertex_indices, operator, angle):
    points = _world_points(obj, [bm.verts[index] for index in vertex_indices])
    normal = _normal_for(points, geometry.bbox_center(points), _fallback_normal(context))
    if operator.arc_regular:
        return _circularize_arc_targets(points, angle, normal, operator.arc_flip)
    arc_normal = geometry.mul(normal, -1.0) if operator.arc_flip else normal
    target, _radius = geometry.nonregular_arc(
        points, angle, arc_normal, planarize=operator.arc_planarize, circle=True,
    )
    return target


class ARI_OT_align(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_align"
    bl_label = "Ari打圆"
    bl_description = "开放链使用 Circularize，闭合环使用 Blender To Circle Plus"
    bl_options = {'REGISTER', 'UNDO'}

    # Keep current-operation snapshots for Redo, but never remember them as
    # defaults for a *new* invocation. Only user-facing settings are reusable.
    mode: StringProperty(default='ALIGN', options={'HIDDEN', 'SKIP_SAVE'})
    use_operator_settings: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    source_snapshot: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    source_object_name: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    source_kind: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    source_select_mode: BoolVectorProperty(size=3, default=(False, True, False), options={'HIDDEN', 'SKIP_SAVE'})
    source_vert_indices: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    source_selected_edge_indices: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    source_face_indices: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    source_vertex_coordinates: StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    angle_input_enabled: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})
    angle_input: FloatProperty(default=180.0, min=0.1, max=359.9, options={'HIDDEN', 'SKIP_SAVE'})

    arc_angle: FloatProperty(name="Angle", default=180.0, min=0.1, max=359.9, precision=3)
    arc_flip: BoolProperty(name="Flip", default=False)
    arc_regular: BoolProperty(name="Regular", default=True)
    arc_planarize: BoolProperty(name="平化", default=True)
    circle_factor: FloatProperty(name="Factor", default=1.0, min=0.0, max=1.0, subtype='FACTOR')
    circle_fit_method: EnumProperty(name="Method", items=CIRCULARIZE_FIT_ITEMS, default='LEAST_SQUARE')
    circle_angle: FloatProperty(name="Rotation", default=0.0, subtype='ANGLE')
    circle_use_custom_radius: BoolProperty(name="Use Custom Radius", default=False)
    circle_custom_radius: FloatProperty(name="Radius", default=1.0, min=0.000001, precision=4)
    circle_regular: BoolProperty(name="Space Evenly", default=True)
    circle_flatten: FloatProperty(name="Flatten", default=1.0, min=0.0, max=1.0, subtype='FACTOR')
    circle_lock: BoolVectorProperty(name="Lock", size=3, default=(False, False, False))
    selection_result: EnumProperty(name="选区", items=SELECTION_RESULT_ITEMS, default='KEEP')
    operation_kind: StringProperty(default='OPEN', options={'HIDDEN', 'SKIP_SAVE'})
    fixed_diameter: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def check(self, _context):
        return True

    def invoke(self, context, _event):
        # A shortcut copies button properties when it is assigned. Each new
        # invocation must read today's selection and panel settings, while
        # execute() still retains the current operation's source for F9 redo.
        self.source_snapshot = False
        self.source_object_name = ''
        self.source_kind = ''
        self.source_vert_indices = ''
        self.source_selected_edge_indices = ''
        self.source_face_indices = ''
        self.source_vertex_coordinates = ''
        self.use_operator_settings = False
        return self.execute(context)

    def draw(self, _context):
        layout = self.layout
        if self.operation_kind == 'CLOSED':
            layout.label(text="To Circle Plus")
            layout.prop(self, "circle_factor", text="Factor")
            fit = layout.column()
            fit.enabled = not self.fixed_diameter
            fit.prop(self, "circle_fit_method", text="Method")
            fit.prop(self, "circle_angle", text="Rotation")
            row = fit.row(align=True)
            row.prop(self, "circle_use_custom_radius", text="Radius")
            radius = row.row(align=True)
            radius.enabled = self.circle_use_custom_radius
            radius.prop(self, "circle_custom_radius", text="")
            layout.prop(self, "circle_regular", text="Space Evenly")
            layout.prop(self, "circle_flatten", text="Flatten")
            lock = layout.row(align=True)
            lock.label(text="Lock")
            axes = lock.row(align=True)
            for index, axis in enumerate("XYZ"):
                axes.prop(self, "circle_lock", index=index, text=axis, toggle=True)
            if self.fixed_diameter:
                layout.label(text="两点确定直径，两侧各为 180°")
            layout.separator()
            layout.prop(self, "selection_result", text="选区", expand=True)
            return
        layout.label(text="Circularize")
        layout.prop(self, "arc_angle", text="Angle")
        layout.prop(self, "arc_flip", text="Flip")
        layout.prop(self, "arc_regular", text="Regular")
        row = layout.row()
        row.enabled = not self.arc_regular
        row.prop(self, "arc_planarize", text="平化")

    def _load_panel_settings(self, context):
        preferences = get_preferences(context)
        if preferences is not None and not self.use_operator_settings:
            self.angle_input_enabled = preferences.angle_enabled
            self.angle_input = preferences.angle
            self.arc_angle = preferences.angle
            for name, value in _initial_spacing_settings(context, preferences).items():
                if not self.properties.is_property_set(name, ghost=False):
                    setattr(self, name, value)
            self.use_operator_settings = True
        return preferences

    def execute(self, context):
        try:
            preferences = self._load_panel_settings(context)
            if self.mode == 'GET_ANGLE':
                if preferences is None:
                    raise AriCircleError("插件设置未初始化，请重新启用 Ari打圆")
                obj, sequences = selected_sequences(context)
                bm = bmesh.from_edit_mesh(obj.data)
                angles = []
                for indices, closed in sequences:
                    if not closed:
                        points = _world_points(obj, [bm.verts[index] for index in indices])
                        angles.append(_resolve_angle(points, False, self.arc_angle))
                if not angles:
                    raise AriCircleError("当前选择没有开放链，无法获取角度")
                preferences.angle = sum(angles) / len(angles)
                self.arc_angle = preferences.angle
                self.report({'INFO'}, f"平均角度: {preferences.angle:.3f}")
                return {'FINISHED'}
            if self.mode != 'ALIGN':
                raise AriCircleError("未知的 Alignment 操作")

            first_execution = not self.source_snapshot
            if self.source_snapshot:
                obj, bm = _restore_source(context, self)
            else:
                _snapshot_source(self, context)
                obj, bm = _active_edit_mesh(context)
                self.source_kind = _closed_selection_kind(context)

            if self.source_kind in {'REGION', 'LOOP'}:
                self.operation_kind = 'CLOSED'
                _obj, bm, vertex_indices, edge_indices, face_indices = _closed_source_data(
                    context, self.source_kind,
                )
                if len(vertex_indices) < 3:
                    raise AriCircleError("圆形化至少需要三个顶点")
                regions = _closed_selection_regions(bm, self.source_kind, edge_indices, face_indices)
                if len(regions) > 1 and _alignment_priority(context, obj):
                    return _align_multiple_closed_regions(
                        context, self, obj, bm, self.source_kind, regions, edge_indices, face_indices,
                    )
                # With constraints disabled or no saved points, each region
                # uses the existing Vertex=0 native operation independently.
                # Apply output selection once, after every region is finished.
                moved = 0
                for region in regions:
                    moved += _native_closed_to_circle(
                        context, self, self.source_kind, sorted(region['vertices']),
                        region['edges'], region['faces'], apply_selection=False,
                    )
                _apply_result_selection(context, self, obj, self.source_kind, edge_indices, face_indices)
                self.report({'INFO'}, f"圆形化处理了 {moved} 个顶点")
                return {'FINISHED'}

            if self.source_kind != 'OPEN':
                raise AriCircleError("无法识别当前选择")
            self.operation_kind = 'OPEN'
            obj, bm = _active_edit_mesh(context)
            _obj, sequences = selected_sequences(context)
            if any(closed for _indices, closed in sequences):
                raise AriCircleError("当前选择包含闭合环，请重新执行")
            if first_execution and not self.angle_input_enabled:
                measured = []
                for indices, _closed in sequences:
                    points = _world_points(obj, [bm.verts[index] for index in indices])
                    measured.append(_resolve_angle(points, False, self.arc_angle))
                if measured:
                    self.arc_angle = sum(measured) / len(measured)
            angle = self.arc_angle if (not self.angle_input_enabled or self.source_snapshot) else self.angle_input
            for indices, _closed in sequences:
                if len(indices) < 3:
                    raise AriCircleError("开放链至少需要三个顶点")
                target = _open_targets(context, obj, bm, indices, self, angle)
                for index, point in zip(indices, target):
                    bm.verts[index].co = _local_point(obj, point)
            bmesh.update_edit_mesh(obj.data, loop_triangles=True, destructive=False)
            self.report({'INFO'}, f"已处理 {sum(len(indices) for indices, _closed in sequences)} 个顶点")
            return {'FINISHED'}
        except AriCircleError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        except (ValueError, ZeroDivisionError) as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class ARI_OT_select_failure_history(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_select_failure_history"
    bl_label = "选择失效历史"
    bl_description = "选回最近一次多区域圆化中未执行的原始面或边选区"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'
                and context.scene.ari_circle_failure_object == obj
                and context.scene.ari_circle_failure_mesh == obj.data
                and _failure_history(context.scene) is not None)

    def execute(self, context):
        obj, bm = _active_edit_mesh(context)
        data = _failure_history(context.scene)
        if not data:
            return {'CANCELLED'}
        if data['topology'] != _topology_signature(bm):
            self.report({'WARNING'}, "网格拓扑已改变，暂时无法选回；失效历史仍保留，可撤销拓扑修改后选回或手动清除")
            return {'CANCELLED'}
        indices = {key: set().union(*(set(region[key]) for region in data['regions']))
                   for key in ('vertices', 'edges', 'faces')}
        _set_exact_selection(context, obj, tuple(data['mode']),
                             indices['vertices'], indices['edges'], indices['faces'])
        self.report({'INFO'}, f"已选回 {len(data['regions'])} 个未执行区域")
        return {'FINISHED'}


class ARI_OT_clear_failure_history(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_clear_failure_history"
    bl_label = "清除"
    bl_description = "清除临时保存的失效选区，不改变网格和 GetPriority"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _failure_history(context.scene) is not None

    def execute(self, context):
        _clear_failure_history(context.scene)
        return {'FINISHED'}


class ARI_OT_set_priority(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_set_priority"
    bl_label = "Get Priority"
    bl_description = "将所选顶点追加到 GetPriority（自动去重）；Ctrl 点击替换原有集合"
    bl_options = {'REGISTER', 'UNDO'}

    replace: BoolProperty(default=False, options={'HIDDEN', 'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (context.window_manager.ari_circle_priority_enabled and obj is not None
                and obj.type == 'MESH' and obj.mode == 'EDIT')

    def invoke(self, context, event):
        self.replace = bool(event.ctrl)
        return self.execute(context)

    def execute(self, context):
        try:
            obj, bm = _active_edit_mesh(context)
            indices = {vert.index for vert in bm.verts if vert.select and not vert.hide}
            if not self.replace:
                indices.update(_priority_indices(context.scene, obj))
                if not indices:
                    return {'CANCELLED'}
            _write_priority(context, obj, indices)
            self.report({'INFO'}, f"已记录 {len(indices)} 个优先顶点")
            return {'FINISHED'}
        except AriCircleError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class ARI_OT_clear_priority(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_clear_priority"
    bl_label = "Clear"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.window_manager.ari_circle_priority_enabled

    def execute(self, context):
        _write_priority(context, None, set())
        return {'FINISHED'}


class ARI_OT_select_priority(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_select_priority"
    bl_label = "Select Priority"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (context.window_manager.ari_circle_priority_enabled and obj is not None
                and obj.type == 'MESH' and obj.mode == 'EDIT'
                and bool(_priority_indices(context.scene, obj)))

    def execute(self, context):
        try:
            obj, bm = _active_edit_mesh(context)
            priority = _priority_indices(context.scene, obj)
            if not priority:
                raise AriCircleError("没有可选择的优先顶点")
            context.tool_settings.mesh_select_mode = (True, False, False)
            for vert in bm.verts:
                vert.select_set(vert.index in priority)
            bm.select_flush_mode()
            bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
            return {'FINISHED'}
        except AriCircleError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class ARI_OT_set_angle(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_set_angle"
    bl_label = "Set Angle"
    angle: FloatProperty(min=0.1, max=359.9)

    def execute(self, context):
        preferences = get_preferences(context)
        if preferences is not None:
            preferences.angle = self.angle
        return {'FINISHED'}


class ARI_OT_ring(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_ring"
    bl_label = "并排边"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        try:
            obj, bm = _active_edit_mesh(context)
            if not any(edge.select for edge in bm.edges):
                raise AriCircleError("请先选择一条边")
            context.tool_settings.mesh_select_mode = (False, True, False)
            result = bpy.ops.mesh.select_edge_ring_multi()
            if 'FINISHED' not in result:
                raise AriCircleError("并排边环选择执行失败")
            return {'FINISHED'}
        except AriCircleError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}


class ARI_OT_contiguous(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_contiguous"
    bl_label = "连续"
    bl_options = {'REGISTER', 'UNDO'}
    angle: IntProperty(name="Angle", default=30, min=0, max=360)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        obj, bm = _active_edit_mesh(context)
        seeds = [edge for edge in bm.edges if edge.select]
        for seed_edge in seeds:
            original_a, original_b = seed_edge.verts
            for start, previous in ((original_a, original_b), (original_b, original_a)):
                current, prev = start, previous
                while True:
                    candidates = [edge for edge in current.link_edges if not edge.select]
                    if seed_edge.is_boundary:
                        candidates = [edge for edge in candidates if edge.is_boundary]
                    if not candidates:
                        break
                    scored = []
                    for edge in candidates:
                        nxt = edge.other_vert(current)
                        try:
                            turn = math.degrees((current.co - prev.co).angle(nxt.co - current.co))
                        except ValueError:
                            turn = 180.0
                        scored.append((turn, edge.index, edge, nxt))
                    turn, _index, chosen, nxt = min(scored, key=lambda item: (item[0], item[1]))
                    if not seed_edge.is_boundary and turn >= self.angle:
                        break
                    chosen.select_set(True)
                    prev, current = current, nxt
        bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}


class ARI_OT_toggle_setting(bpy.types.Operator):
    bl_idname = "view3d.ari_circle_toggle_setting"
    bl_label = "切换 Ari打圆选项"
    # Match the original preference/WindowManager checkboxes: no undo step.
    setting: EnumProperty(items=(
        ('ANGLE', "角度捕捉", "切换角度捕捉"),
        ('REGULAR', "Regular", "切换等距排列"),
        ('PLANARIZE', "平化", "切换平化；Regular 开启时不可用"),
        ('PRIORITY', "启用 GetPriority", "切换固定点约束，保留已存顶点；不计入撤销历史"),
    ))

    @classmethod
    def poll(cls, context):
        return get_preferences(context) is not None

    @classmethod
    def description(cls, _context, properties):
        return {
            'ANGLE': "切换角度捕捉",
            'REGULAR': "切换等距排列",
            'PLANARIZE': "切换平化；Regular 开启时不可用",
            'PRIORITY': "切换固定点约束，保留已存顶点；不计入撤销历史",
        }[properties.setting]

    def execute(self, context):
        if self.setting == 'PRIORITY':
            wm = context.window_manager
            wm.ari_circle_priority_enabled = not wm.ari_circle_priority_enabled
        else:
            preferences = get_preferences(context)
            if self.setting == 'PLANARIZE' and preferences.regular:
                return {'CANCELLED'}
            name = {'ANGLE': 'angle_enabled', 'REGULAR': 'regular',
                    'PLANARIZE': 'planarize'}[self.setting]
            setattr(preferences, name, not getattr(preferences, name))
        _redraw_priority_controls(context.window_manager, context)
        return {'FINISHED'}


def _setting_button(layout, setting, enabled, text):
    button = layout.operator(ARI_OT_toggle_setting.bl_idname, text=text,
                             icon='CHECKBOX_HLT' if enabled else 'CHECKBOX_DEHLT',
                             emboss=False)
    button.setting = setting


class ARI_PT_main(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_ari_circle_vertex"
    bl_label = "Ari打圆"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Ari打圆"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        preferences = get_preferences(context)
        obj = context.active_object
        scene = context.scene
        if preferences is None:
            layout.label(text="请重新启用插件")
            return
        box = layout.box()
        box.label(text="Option")
        row = box.row(align=True)
        _setting_button(row, 'ANGLE', preferences.angle_enabled, "角度捕捉")
        value = row.row(align=True)
        value.enabled = preferences.angle_enabled
        value.prop(preferences, "angle", text="")
        getter = row.operator(ARI_OT_align.bl_idname, text="Get", icon='FILE_REFRESH')
        getter.mode = 'GET_ANGLE'
        presets = box.row(align=True)
        for preset in (90.0, 180.0):
            op = presets.operator(ARI_OT_set_angle.bl_idname, text=f"{preset:.0f}°")
            op.angle = preset
        row = box.row(align=True)
        _setting_button(row, 'PRIORITY', context.window_manager.ari_circle_priority_enabled, "")
        priority_controls = row.row(align=True)
        priority_controls.enabled = context.window_manager.ari_circle_priority_enabled
        priority_object = scene.ari_circle_priority_object
        priority_count = 0
        if priority_object == obj and scene.ari_circle_priority_indices:
            priority_count = len([value for value in scene.ari_circle_priority_indices.split(',') if value])
        status = priority_controls.row(align=True)
        status.enabled = priority_count > 0
        status.operator(ARI_OT_select_priority.bl_idname, text=f"{priority_count} Vertex", icon='SELECT_SET')
        priority_controls.operator(ARI_OT_clear_priority.bl_idname, text="Clear", icon='X')
        priority_controls.operator_context = 'INVOKE_DEFAULT'
        priority_controls.operator(ARI_OT_set_priority.bl_idname, text="GetPriority", icon='PINNED').replace = False
        row = box.row(align=True)
        _setting_button(row, 'REGULAR', preferences.regular, "Regular")
        planar = row.row(align=True)
        planar.enabled = not preferences.regular
        _setting_button(planar, 'PLANARIZE', preferences.planarize, "平化")
        controls = layout.row(align=True)
        controls.operator(ARI_OT_contiguous.bl_idname, text="连续", icon='SELECT_EXTEND')
        controls.operator(ARI_OT_ring.bl_idname, text="并排边", icon='EDGESEL')
        button = layout.row(align=True)
        button.scale_y = 1.4
        operator = button.operator(ARI_OT_align.bl_idname, text="Alignment", icon='CHECKMARK')
        operator.mode = 'ALIGN'
        # Only the action belongs to the button/shortcut. invoke() obtains the
        # live panel settings; Blender supplies remembered Redo parameters.

        history = _failure_history(scene)
        row = layout.row(align=True)
        row.enabled = history is not None
        row.operator(ARI_OT_select_failure_history.bl_idname, text="选择失效历史", icon='RESTRICT_SELECT_OFF')
        row.operator(ARI_OT_clear_failure_history.bl_idname, text="清除", icon='X')
        if history:
            layout.label(text=f"已记录 {len(history['regions'])} 个未执行区域", icon='INFO')


classes = (
    AriPreferences,
    ARI_OT_align,
    ARI_OT_select_failure_history,
    ARI_OT_clear_failure_history,
    ARI_OT_set_priority,
    ARI_OT_clear_priority,
    ARI_OT_select_priority,
    ARI_OT_set_angle,
    ARI_OT_ring,
    ARI_OT_contiguous,
    ARI_OT_toggle_setting,
    ARI_PT_main,
)


# Blender's native Assign Shortcut menu recognizes VIEW3D_OT identifiers.
# Keep the previous Python identifiers available for saved scripts/keymaps,
# but hide those compatibility aliases from operator search results.
legacy_classes = tuple(
    type('ARI_CIRCLE_VERTEX_OT_' + cls.bl_idname.removeprefix('view3d.ari_circle_'),
         (bpy.types.Operator,), dict(
                      {name: value for name, value in vars(cls).items()
                       if name not in {'__dict__', '__weakref__'}},
                      __module__=__name__,
                      bl_idname='ari_circle_vertex.' + cls.bl_idname.removeprefix('view3d.ari_circle_'),
                      bl_label=cls.bl_label,
                      bl_options=set(getattr(cls, 'bl_options', ())) | {'INTERNAL'},
                      __annotations__=dict(cls.__dict__.get('__annotations__', {}))))
    for cls in classes if issubclass(cls, bpy.types.Operator) and cls != ARI_OT_toggle_setting
)


def register():
    for cls in (*classes, *legacy_classes):
        bpy.utils.register_class(cls)
    bpy.types.Scene.ari_circle_priority_object = PointerProperty(type=bpy.types.Object)
    bpy.types.Scene.ari_circle_priority_indices = StringProperty(default='')
    bpy.types.Scene.ari_circle_priority_references = StringProperty(default='', options={'HIDDEN'})
    bpy.types.Scene.ari_circle_priority_revision = IntProperty(default=0, options={'HIDDEN'})
    # WindowManager UI state is outside both mesh and global undo. Toggling
    # this switch must neither add a step nor roll back with a geometry undo.
    bpy.types.WindowManager.ari_circle_priority_enabled = BoolProperty(
        name="启用 GetPriority", default=False, options={'SKIP_SAVE'},
        description="启用固定点与拾取按钮；关闭时保留已存顶点并执行普通圆形化；开关不计入撤销历史",
        update=_redraw_priority_controls,
    )
    bpy.types.Scene.ari_circle_failure_object = PointerProperty(type=bpy.types.Object, options={'HIDDEN', 'SKIP_SAVE'})
    bpy.types.Scene.ari_circle_failure_mesh = PointerProperty(type=bpy.types.Mesh, options={'HIDDEN', 'SKIP_SAVE'})
    bpy.types.Scene.ari_circle_failure_data = StringProperty(default='', options={'HIDDEN', 'SKIP_SAVE'})
    # Blender restricts access to scene data while enabling an add-on. A new
    # session token invalidates any old record without reading scenes here.
    bpy.app.handlers.load_post.append(_clear_failure_history_on_load)
    bpy.app.handlers.load_post.append(_migrate_priority_references)
    bpy.app.timers.register(_migrate_priority_references, first_interval=0.0)
    bpy.app.handlers.undo_pre.append(_remember_priority_before_undo)
    bpy.app.handlers.redo_pre.append(_remember_priority_before_undo)
    bpy.app.handlers.undo_post.append(_restore_priority_after_undo)
    bpy.app.handlers.redo_post.append(_restore_priority_after_undo)


def unregister():
    if bpy.app.timers.is_registered(_migrate_priority_references):
        bpy.app.timers.unregister(_migrate_priority_references)
    if _migrate_priority_references in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_migrate_priority_references)
    for handlers in (bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if _remember_priority_before_undo in handlers:
            handlers.remove(_remember_priority_before_undo)
    for handlers in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _restore_priority_after_undo in handlers:
            handlers.remove(_restore_priority_after_undo)
    if _clear_failure_history_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_clear_failure_history_on_load)
    _clear_failure_history_on_load(None)
    del bpy.types.Scene.ari_circle_failure_data
    del bpy.types.Scene.ari_circle_failure_mesh
    del bpy.types.Scene.ari_circle_failure_object
    del bpy.types.WindowManager.ari_circle_priority_enabled
    if hasattr(bpy.types.Scene, 'ari_circle_priority_indices'):
        del bpy.types.Scene.ari_circle_priority_indices
    del bpy.types.Scene.ari_circle_priority_revision
    del bpy.types.Scene.ari_circle_priority_references
    if hasattr(bpy.types.Scene, 'ari_circle_priority_object'):
        del bpy.types.Scene.ari_circle_priority_object
    for cls in reversed((*classes, *legacy_classes)):
        bpy.utils.unregister_class(cls)

