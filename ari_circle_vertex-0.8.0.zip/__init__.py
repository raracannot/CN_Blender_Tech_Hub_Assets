"""Ari打圆: circle and arc alignment tools for Blender 5.2 LTS.

Three-point circles support fixed references outside the selected boundary.
Independent selected regions support per-boundary pairs and temporary failure history.
Priority picks accumulate with native undo; Ctrl replaces the stored set.
Optional priority constraints leave empty or disabled selections on native circularization.
Redo settings use Blender's native operator memory without reusing selection snapshots.
Saved selections are reconciled after third-party redo and mixed native undo.
"""

bl_info = {
    "name": "Ari打圆",
    "author": "不中用的华强、南柯一梦 JR",
    "version": (0, 8, 0),
    "blender": (4, 5, 0),
    "location": "View3D > Sidebar > Ari打圆",
    "description": "由AriCircleVertex演化而来的专家级硬表面弧度定义工具",
    "category": "Mesh",
}

blender_ops = None


def register():
    global blender_ops
    import importlib
    import sys

    # Updating a ZIP in the same Blender session may retain the old geometry
    # module even though blender_ops is reloaded. Refresh its helpers first.
    geometry_name = f"{__package__}.geometry"
    if geometry_name in sys.modules:
        importlib.reload(sys.modules[geometry_name])
    module_name = f"{__package__}.blender_ops"
    if module_name in sys.modules:
        blender_ops = importlib.reload(sys.modules[module_name])
    else:
        blender_ops = importlib.import_module(".blender_ops", __name__)
    if blender_ops is None:
        raise RuntimeError("Ari打圆 must be registered from Blender's Python runtime")
    blender_ops.register()


def unregister():
    if blender_ops is None:
        return
    blender_ops.unregister()


if __name__ == "__main__":
    register()
