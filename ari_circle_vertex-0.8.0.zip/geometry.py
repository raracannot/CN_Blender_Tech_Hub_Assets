"""Pure geometry used by the Ari打圆 Blender add-on.

The functions in this module intentionally use plain 3-tuples/lists so they
can be unit-tested without importing Blender's Python runtime.
"""

from __future__ import annotations

import math


EPSILON = 1.0e-9


def add(a, b):
    return (a[0] + b[0], a[1] + b[1], a[2] + b[2])


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def mul(a, scalar):
    return (a[0] * scalar, a[1] * scalar, a[2] * scalar)


def dot(a, b):
    return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]


def cross(a, b):
    return (
        a[1] * b[2] - a[2] * b[1],
        a[2] * b[0] - a[0] * b[2],
        a[0] * b[1] - a[1] * b[0],
    )


def length(a):
    return math.sqrt(dot(a, a))


def normalize(a, fallback=None):
    size = length(a)
    if size <= EPSILON:
        return fallback
    return mul(a, 1.0 / size)


def distance(a, b):
    return length(sub(a, b))


def average(points):
    if not points:
        return (0.0, 0.0, 0.0)
    total = (0.0, 0.0, 0.0)
    for point in points:
        total = add(total, point)
    return mul(total, 1.0 / len(points))


def bbox_center(points):
    if not points:
        return (0.0, 0.0, 0.0)
    min_x = max_x = points[0][0]
    min_y = max_y = points[0][1]
    min_z = max_z = points[0][2]
    for point in points[1:]:
        min_x = min(min_x, point[0])
        max_x = max(max_x, point[0])
        min_y = min(min_y, point[1])
        max_y = max(max_y, point[1])
        min_z = min(min_z, point[2])
        max_z = max(max_z, point[2])
    return (
        (min_x + max_x) * 0.5,
        (min_y + max_y) * 0.5,
        (min_z + max_z) * 0.5,
    )


def project_point_to_plane(point, plane_point, plane_normal):
    """Project point onto the plane containing plane_point with plane_normal."""
    normal = normalize(plane_normal)
    if normal is None:
        return point
    offset = dot(sub(point, plane_point), normal)
    return sub(point, mul(normal, offset))


def angle_between(a, b):
    length_a = length(a)
    length_b = length(b)
    if length_a <= EPSILON or length_b <= EPSILON:
        return 0.0
    cosine = dot(a, b) / (length_a * length_b)
    return math.acos(max(-1.0, min(1.0, cosine)))


def _normal_from_edges(points, center):
    normals = []
    for index, point in enumerate(points):
        next_point = points[(index + 1) % len(points)]
        normal = normalize(cross(sub(point, center), sub(next_point, center)))
        if normal is not None:
            normals.append(normal)
    return normalize(average(normals)) if normals else None


def polygon_normal(points, center=None, fallback=None):
    """Match the MEL script's averaged triangle-normal calculation."""
    if len(points) < 3:
        return fallback
    if center is None:
        center = bbox_center(points)
    normal = _normal_from_edges(points, center)
    if normal is not None:
        return normal

    # A Newell-style fallback handles points that are planar but have a
    # degenerate bbox-center triangle, which is common for collinear input.
    accumulated = (0.0, 0.0, 0.0)
    for index, point in enumerate(points):
        next_point = points[(index + 1) % len(points)]
        accumulated = add(
            accumulated,
            (
                (point[1] - next_point[1]) * (point[2] + next_point[2]),
                (point[2] - next_point[2]) * (point[0] + next_point[0]),
                (point[0] - next_point[0]) * (point[1] + next_point[1]),
            ),
        )
    return normalize(accumulated, fallback)


def diameter_circle(points, anchor_positions, regular=True):
    """Constrain an ordered closed loop to two fixed diameter endpoints.

    Each topological path between the anchors occupies 180 degrees, regardless
    of how many edges it contains. The original loop determines the plane and
    winding. Nonregular spacing preserves relative projected angular intervals
    within each path. The returned normal also supports partial flattening.
    """
    if len(points) < 3 or len(set(anchor_positions)) != 2:
        raise ValueError("两点定直径需要一个闭合边环和两个不同的优先顶点")
    first, second = sorted(anchor_positions)
    if not 0 <= first < second < len(points):
        raise ValueError("两个优先顶点必须位于同一个闭合边环")
    center = mul(add(points[first], points[second]), 0.5)
    radius = distance(points[first], points[second]) * 0.5
    if radius <= EPSILON:
        raise ValueError("GetPriority=2 的两个顶点不能重合")
    axis = mul(sub(points[first], center), 1.0 / radius)

    # Area normal, constrained to a plane that contains the fixed diameter.
    # No view direction or globally even vertex count participates in fitting.
    area = (0.0, 0.0, 0.0)
    for i, point in enumerate(points):
        area = add(area, cross(sub(point, center), sub(points[(i + 1) % len(points)], center)))
    normal = normalize(sub(area, mul(axis, dot(area, axis))))
    if normal is None:
        raise ValueError("当前边环无法确定包含两个优先顶点的圆平面")
    tangent = normalize(cross(normal, axis))

    paths = (list(range(first, second + 1)),
             list(range(second, len(points))) + list(range(first + 1)))
    result = list(points)
    for side, path in enumerate(paths):
        if regular:
            weights = [1.0] * (len(path) - 1)
        else:
            radial = [normalize(sub(sub(points[i], center),
                                    mul(normal, dot(sub(points[i], center), normal))))
                      for i in path]
            weights = [angle_between(a, b) if a is not None and b is not None else 0.0
                       for a, b in zip(radial, radial[1:])]
            if sum(weights) <= EPSILON:
                weights = [distance(points[a], points[b]) for a, b in zip(path, path[1:])]
        total = sum(weights)
        if total <= EPSILON:
            raise ValueError("两个优先顶点之间的边链长度无效")
        travelled = 0.0
        for step, index in enumerate(path[1:-1]):
            travelled += weights[step]
            angle = math.pi * (side + travelled / total)
            radial = add(mul(axis, math.cos(angle)), mul(tangent, math.sin(angle)))
            result[index] = add(center, mul(radial, radius))
    # Do not round-trip the anchor coordinates through trigonometry.
    result[first], result[second] = points[first], points[second]
    return result, normal


def _first_vertex_index(points, center, priority_positions, normal):
    if priority_positions:
        for index, point in enumerate(points):
            if index in priority_positions:
                return index

    # AriCircleVertex chooses the vector closest to the world Y axis when no
    # priority vertex is set. This preserves the original orientation rule.
    axis = (0.0, 1.0, 0.0)
    return min(
        range(len(points)),
        key=lambda index: angle_between(axis, sub(points[index], center)),
    )


def regular_polygon(points, center, radius, normal, priority_positions=None):
    """Return equal-angle positions while keeping a stable first vertex."""
    if len(points) < 3:
        raise ValueError("A circle needs at least three vertices")
    normal = normalize(normal)
    if normal is None:
        raise ValueError("The selected vertices do not define a plane")
    if radius <= EPSILON:
        raise ValueError("The circle radius must be greater than zero")

    priority_positions = priority_positions or set()
    first_index = _first_vertex_index(points, center, priority_positions, normal)
    ordered = points[first_index:] + points[:first_index]
    first_radius = project_point_to_plane(ordered[0], center, normal)
    first_radius = normalize(sub(first_radius, center))
    if first_radius is None:
        raise ValueError("The first vertex is at the circle center")

    tangent = normalize(cross(normal, first_radius))
    if tangent is None:
        raise ValueError("Unable to establish a circle orientation")

    ordered_result = []
    count = len(ordered)
    for index in range(count):
        angle = (2.0 * math.pi * index) / count
        radial = add(mul(first_radius, math.cos(angle)), mul(tangent, math.sin(angle)))
        ordered_result.append(add(center, mul(radial, radius)))

    # The caller still owns the original mesh order. Map the generated points
    # back before writing coordinates so a priority vertex stays at its index.
    ordered_indices = list(range(first_index, count)) + list(range(first_index))
    result = [None] * count
    for ordered_index, original_index in enumerate(ordered_indices):
        result[original_index] = ordered_result[ordered_index]
    return result, first_index


def average_radius(points, center):
    if not points:
        return 0.0
    return sum(distance(point, center) for point in points) / len(points)


def estimate_arc_angle(points):
    """Infer the central arc angle using the same interior-angle method as MEL."""
    if len(points) < 3:
        raise ValueError("An arc needs at least three vertices")
    first = points[0]
    last = points[-1]
    angles = [
        angle_between(sub(point, first), sub(point, last))
        for point in points[1:-1]
    ]
    if not angles:
        raise ValueError("An arc needs at least one interior vertex")
    angle = 360.0 - math.degrees(sum(angles) / len(angles)) * 2.0
    return max(0.1, min(359.9, angle))


def arc_radius(points, angle_degrees):
    chord = distance(points[0], points[-1])
    if chord <= EPSILON:
        raise ValueError("The arc endpoints must be different")
    half_angle = math.radians(angle_degrees * 0.5)
    sine = math.sin(half_angle)
    if abs(sine) <= EPSILON:
        raise ValueError("The arc angle must be between zero and 360 degrees")
    return (chord * 0.5) / sine


def _arc_frame(points, normal):
    first = points[0]
    last = points[-1]
    chord = normalize(sub(last, first))
    if chord is None:
        raise ValueError("The arc endpoints must be different")
    normal = normalize(normal)
    if normal is None:
        raise ValueError("The selected vertices do not define an arc plane")
    # The normal estimated from an open chain can contain a small component
    # along the chord. Remove it so the generated arc plane contains both
    # endpoints exactly.
    normal = normalize(sub(normal, mul(chord, dot(normal, chord))))
    if normal is None:
        # A straight chain has no measured plane. Pick the world axis least
        # aligned with its chord to provide a deterministic fallback plane.
        fallback_axis = min(
            ((1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)),
            key=lambda axis: abs(dot(axis, chord)),
        )
        normal = normalize(
            sub(fallback_axis, mul(chord, dot(fallback_axis, chord)))
        )
    if normal is None:
        raise ValueError("The selected vertices do not define an arc plane")
    sag_direction = normalize(cross(chord, normal))
    if sag_direction is None:
        raise ValueError("The arc chord and normal are parallel")
    tangent = normalize(cross(normal, sag_direction))
    if tangent is None:
        raise ValueError("Unable to establish an arc orientation")
    return chord, normal, sag_direction, tangent


def regular_arc(points, angle_degrees, normal):
    """Generate an equal-angle arc with the original endpoints fixed."""
    if len(points) < 3:
        raise ValueError("An arc needs at least three vertices")
    angle_degrees = max(0.1, min(359.9, float(angle_degrees)))
    radius = arc_radius(points, angle_degrees)
    _chord, normal, sag_direction, tangent = _arc_frame(points, normal)
    first = points[0]
    last = points[-1]
    midpoint = mul(add(first, last), 0.5)
    half_angle = math.radians(angle_degrees * 0.5)
    center = sub(midpoint, mul(sag_direction, radius * math.cos(half_angle)))

    result = []
    for index in range(len(points)):
        fraction = index / (len(points) - 1)
        angle = (fraction - 0.5) * math.radians(angle_degrees)
        radial = add(
            mul(sag_direction, math.cos(angle)),
            mul(tangent, math.sin(angle)),
        )
        result.append(add(center, mul(radial, radius)))
    return result, radius


def nonregular_arc(points, angle_degrees, normal, planarize=True, circle=True):
    """Project and/or circularize an open chain without equalizing spacing."""
    if len(points) < 3:
        raise ValueError("An arc needs at least three vertices")
    angle_degrees = max(0.1, min(359.9, float(angle_degrees)))
    radius = arc_radius(points, angle_degrees)
    _chord, normal, sag_direction, _tangent = _arc_frame(points, normal)
    first = points[0]
    last = points[-1]
    midpoint = mul(add(first, last), 0.5)
    half_angle = math.radians(angle_degrees * 0.5)
    center = sub(midpoint, mul(sag_direction, radius * math.cos(half_angle)))

    chord = sub(last, first)
    plane_normal = normalize(cross(chord, sag_direction))
    if plane_normal is None:
        raise ValueError("Unable to establish the arc plane")

    result = []
    for point in points:
        new_point = point
        if planarize:
            new_point = project_point_to_plane(new_point, first, plane_normal)
        if circle:
            radial = normalize(sub(new_point, center))
            if radial is None:
                raise ValueError("An arc vertex coincides with the computed center")
            new_point = add(center, mul(radial, radius))
        result.append(new_point)
    return result, radius


def nonregular_circle(
    points,
    center,
    radius,
    normal,
    planarize=True,
    circle=True,
):
    """Project and/or circularize a closed chain while preserving its spacing."""
    normal = normalize(normal)
    if normal is None:
        raise ValueError("The selected vertices do not define a plane")
    if radius <= EPSILON:
        raise ValueError("The circle radius must be greater than zero")

    result = []
    for point in points:
        new_point = point
        if planarize:
            new_point = project_point_to_plane(new_point, center, normal)
        if circle:
            radial = normalize(sub(new_point, center))
            if radial is None:
                raise ValueError("A circle vertex coincides with the computed center")
            new_point = add(center, mul(radial, radius))
        result.append(new_point)
    return result
