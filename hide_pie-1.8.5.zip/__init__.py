bl_info = {
    "name": "隐藏饼菜单",
    "author": "CYX",
    "version": (1, 8, 5),
    "blender": (2, 80, 0),
    "location": "3D View > H Key",
    "description": "集合所有隐藏功能的饼菜单",
    "category": "3D View",
}

import bpy
import bmesh
import gpu
import blf
import time
import os
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.types import Menu, Operator, AddonPreferences
from bpy_extras import view3d_utils
from bpy.app.handlers import persistent
from bpy.props import StringProperty

# ====================== 全局变量 ======================
original_object_names = set()
hidden_part_names = []  # 存储元组 (原始物体名, 隐藏物体名)
is_hide_mode_active = False  # 跟踪隐藏模式是否激活
original_cursor = 'DEFAULT'  # 保存原始光标类型
IS_EDIT_ISOLATION_ACTIVE = False # 是否正在编辑模式下隔离
LAST_MODE = 'OBJECT' # 用于检测模式切换
IS_EDIT_MESH_TOGGLED = False

_PLUGIN_TUTORIAL_URL = "https://www.bilibili.com/video/BV1xXKo6REdS/"
_PLUGIN_REPOSITORY_URL = "https://m.tb.cn/h.RGAwykG?tk=gEP8gQ41XkB"
_ICON_FILES = {
    "tutorial": "bili.png",
    "repository": "repository.jpg",
}
_PREVIEW_COLLECTIONS = {}


def _addon_icons_dir():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")


def _load_custom_icons():
    if _PREVIEW_COLLECTIONS.get("main") is not None:
        return

    try:
        import bpy.utils.previews
    except Exception as ex:
        print("[Hide Pie] 无法加载自定义图标预览:", ex)
        return

    pcoll = bpy.utils.previews.new()
    icons_dir = _addon_icons_dir()

    for key, filename in _ICON_FILES.items():
        icon_path = os.path.join(icons_dir, filename)
        if not os.path.exists(icon_path):
            print("[Hide Pie] 图标文件不存在:", icon_path)
            continue
        try:
            pcoll.load(key, icon_path, "IMAGE")
        except Exception as ex:
            print("[Hide Pie] 加载图标失败 %s: %s" % (icon_path, ex))

    _PREVIEW_COLLECTIONS["main"] = pcoll


def _unload_custom_icons():
    pcoll = _PREVIEW_COLLECTIONS.pop("main", None)
    if pcoll is None:
        return

    try:
        import bpy.utils.previews
        bpy.utils.previews.remove(pcoll)
    except Exception:
        pass


def _custom_icon_id(name):
    pcoll = _PREVIEW_COLLECTIONS.get("main")
    if pcoll is None:
        return 0

    try:
        preview = pcoll.get(name)
    except Exception:
        preview = None

    if preview is None:
        return 0

    return getattr(preview, "icon_id", 0)

# GPU边框相关全局变量
BORDER_SETTINGS = {
    "width": 2,
    "color": (1.0, 1.0, 1.0, 1.0),
    "opacity": 0.5,
    "top": True,
    "bottom": True,
    "left": True,
    "right": True
}
DRAW_HANDLES = set()
IS_DRAWING_BORDER = False
border_draw_callback = None

# ====================== 文字显示管理器类 ======================
class TextDisplayManager:
    def __init__(self):
        self.identifier = "hide_pie_text_display"
        self.handler = None
        self.timer = None
        self.visible = False
        self.text = "当前隐藏的所有物体"
        self.color = (1.0, 1.0, 1.0, 1.0)
        self.size = 20
        self.position_offset = 100
        self.timeout = 3.0
        self.fading = False
        self.start_time = 0.0
        self.is_permanent = False
        
    @property
    def is_alpha_animation(self):
        return not self.is_permanent and self.fading
        
    @property
    def is_timeout(self):
        if self.is_permanent or self.timeout is None or not self.fading or not self.visible:
            return False
        return (time.time() - self.start_time) > self.timeout
        
    @property
    def alpha(self):
        if self.is_permanent or not self.is_alpha_animation or not self.visible:
            return 1.0
        dt = time.time() - self.start_time
        if dt > self.timeout:
            return 0.0
        return 1.0 - (dt / self.timeout)

text_display = TextDisplayManager()

# ====================== 文字绘制函数 ======================
def draw_text_callback():
    if not text_display.visible:
        return
    
    alpha = text_display.alpha
    if alpha <= 0 and not text_display.is_permanent:
        stop_text_display()
        return
    
    blend_mode = gpu.state.blend_get()
    gpu.state.blend_set('ALPHA')
    
    font_id = 0
    blf.size(font_id, text_display.size)
    r, g, b, _ = text_display.color
    blf.color(font_id, r, g, b, alpha)
    
    context = bpy.context
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'WINDOW':
                    width = region.width
                    height = region.height
                    text_width, text_height = blf.dimensions(font_id, text_display.text)
                    x = (width - text_width) / 2
                    y = height - text_display.size - text_display.position_offset
                    blf.position(font_id, x, y, 0)
                    blf.draw(font_id, text_display.text)
    
    gpu.state.blend_set(blend_mode)

def update_text_timer():
    if not text_display.visible:
        return None
    if not text_display.is_permanent and text_display.is_timeout:
        stop_text_display()
        return None
    
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
    return 0.1 if text_display.is_permanent else 0.05

def start_text_display(context, text="", duration=1.0, is_permanent=False):
    global text_display
    stop_text_display()
    
    text_display.visible = True
    text_display.text = text if text else text_display.text
    text_display.timeout = duration
    text_display.start_time = time.time()
    text_display.fading = not is_permanent
    text_display.is_permanent = is_permanent
    
    if not text_display.handler:
        try:
            text_display.handler = bpy.types.SpaceView3D.draw_handler_add(
                draw_text_callback, (), 'WINDOW', 'POST_PIXEL'
            )
        except Exception as e:
            print(f"注册文字绘制回调失败: {str(e)}")
    
    if not text_display.timer and not bpy.app.timers.is_registered(update_text_timer):
        try:
            text_display.timer = bpy.app.timers.register(
                update_text_timer, first_interval=0.05 if not is_permanent else 0.1, persistent=True
            )
        except Exception as e:
            print(f"注册文字定时器失败: {str(e)}")
            
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def stop_text_display():
    global text_display
    if text_display.handler:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(text_display.handler, 'WINDOW')
        except Exception as e:
            print(f"移除文字绘制句柄错误: {e}")
    text_display.handler = None
    
    if text_display.timer and bpy.app.timers.is_registered(update_text_timer):
        try:
            bpy.app.timers.unregister(update_text_timer)
        except Exception as e:
            print(f"移除文字定时器错误: {e}")
    text_display.timer = None
    text_display.visible = False
    text_display.fading = False
    text_display.is_permanent = False
    
    context = bpy.context
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def show_text_only(context, text, duration=1.0, is_permanent=False):
    start_text_display(context, text, duration, is_permanent)

# ====================== 核心辅助函数 ======================
def is_object_valid(obj_name):
    return obj_name in bpy.data.objects

def get_original_mesh_and_matrix(obj):
    return obj.data, obj.matrix_world

def build_bvh(me, mat_world):
    verts_world = [mat_world @ v.co for v in me.vertices]
    tris = []
    me.calc_loop_triangles()
    for tri in me.loop_triangles:
        tris.append([tri.vertices[0], tri.vertices[1], tri.vertices[2]])
    return BVHTree.FromPolygons(verts_world, tris), tris

def region_ray_from_event(context, event):
    region = context.region
    rv3d = context.region_data
    coord = Vector((event.mouse_region_x, event.mouse_region_y))
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    direction = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    return origin, direction

def face_index_from_hit(me, tris, hit_polygon_index):
    return me.loop_triangles[hit_polygon_index].polygon_index

def hide_target_island_object_mode(obj, face_index):
    base_name = obj.name
    original_object_names.add(base_name)
    original_selected = [o for o in bpy.context.selected_objects]
    original_active = bpy.context.view_layer.objects.active
    
    if face_index < 0 or face_index >= len(obj.data.polygons):
        return None

    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='DESELECT')

    bm = bmesh.from_edit_mesh(obj.data)
    bm.faces.ensure_lookup_table()
    
    if face_index >= len(bm.faces):
        bpy.ops.object.mode_set(mode='OBJECT')
        return None

    seed_face = bm.faces[face_index]
    stack = [seed_face]
    target_faces = {seed_face}

    while stack:
        f = stack.pop()
        for v in f.verts:
            for e in v.link_edges:
                for f2 in e.link_faces:
                    if f2 not in target_faces:
                        target_faces.add(f2)
                        stack.append(f2)

    if not target_faces:
        bpy.ops.object.mode_set(mode='OBJECT')
        return None

    for f in target_faces:
        f.select_set(True)

    bm.select_flush(True)
    bmesh.update_edit_mesh(obj.data)

    new_obj = None
    try:
        if obj.data.total_face_sel > 0:
            bpy.ops.mesh.separate(type='SELECTED')
        else:
            bpy.ops.mesh.separate(type='SELECTED')
            
    except RuntimeError:
        print(f"Hide Pie Error: 无法分离网格 (索引 {face_index})")
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        for o in original_selected: o.select_set(True)
        bpy.context.view_layer.objects.active = original_active
        return None

    bpy.ops.object.mode_set(mode='OBJECT')

    objs = bpy.context.selected_objects.copy()
    if obj in objs:
        objs.remove(obj)
    
    new_obj = objs[0] if objs else None

    obj.name = base_name
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)

    if new_obj:
        existing = [o.name for o in bpy.data.objects if o.name.startswith(base_name + "-hide")]
        max_num = 0
        for name in existing:
            suffix = name.replace(base_name + "-hide", "")
            if suffix.isdigit():
                max_num = max(max_num, int(suffix))
        
        new_name = f"{base_name}-hide{max_num+1:02d}"
        new_obj.name = new_name
        new_obj.parent = obj
        new_obj.matrix_parent_inverse = obj.matrix_world.inverted()
        
        # 【关键】这里同时设置了 Viewport Hide (Monitor) 和 Hide Set (Eye)
        new_obj.hide_set(True)
        new_obj.hide_viewport = True
        new_obj.hide_render = True
        hidden_part_names.append((base_name, new_name))

    bpy.ops.object.select_all(action='DESELECT')
    for o in original_selected:
        if o.name in bpy.data.objects:
            o.select_set(True)
    
    if original_active and original_active.name in bpy.data.objects:
        bpy.context.view_layer.objects.active = original_active
        
    return new_obj

# ====================== GPU边框绘制函数 ======================
class BorderDrawCallback:
    def __init__(self):
        self.shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        
    def draw(self):
        if not IS_DRAWING_BORDER:
            return
        
        gpu.state.blend_set('ALPHA')
        
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        width = region.width
                        height = region.height
                        border_size = BORDER_SETTINGS["width"]
                        border_color = list(BORDER_SETTINGS["color"])
                        border_color[3] = BORDER_SETTINGS["opacity"]
                        self.shader.uniform_float("color", border_color)
                        indices = [(0, 1, 2), (0, 2, 3)]
                        
                        if BORDER_SETTINGS["top"]:
                            top_vertices = [(0, height), (width, height), (width, height - border_size), (0, height - border_size)]
                            batch = batch_for_shader(self.shader, 'TRIS', {"pos": top_vertices}, indices=indices)
                            batch.draw(self.shader)
                        if BORDER_SETTINGS["bottom"]:
                            bottom_vertices = [(0, 0), (width, 0), (width, border_size), (0, border_size)]
                            batch = batch_for_shader(self.shader, 'TRIS', {"pos": bottom_vertices}, indices=indices)
                            batch.draw(self.shader)
                        if BORDER_SETTINGS["left"]:
                            left_vertices = [(0, height), (border_size, height), (border_size, 0), (0, 0)]
                            batch = batch_for_shader(self.shader, 'TRIS', {"pos": left_vertices}, indices=indices)
                            batch.draw(self.shader)
                        if BORDER_SETTINGS["right"]:
                            right_vertices = [(width - border_size, height), (width, height), (width, 0), (width - border_size, 0)]
                            batch = batch_for_shader(self.shader, 'TRIS', {"pos": right_vertices}, indices=indices)
                            batch.draw(self.shader)
        gpu.state.blend_set('NONE')

def start_border_drawing(context):
    global IS_DRAWING_BORDER, DRAW_HANDLES, border_draw_callback
    
    if IS_DRAWING_BORDER and DRAW_HANDLES:
        return
    
    if DRAW_HANDLES:
        stop_border_drawing(context)

    border_draw_callback = BorderDrawCallback()
    try:
        draw_handle = bpy.types.SpaceView3D.draw_handler_add(
            border_draw_callback.draw, (), 'WINDOW', 'POST_PIXEL'
        )
        DRAW_HANDLES.add(draw_handle)
        IS_DRAWING_BORDER = True
        
        if not context.window_manager.draw_border_active:
            context.window_manager.draw_border_active = True
        if not context.scene.draw_border_state:
            context.scene.draw_border_state = True
        
        if context.mode == 'EDIT_MESH':
             show_text_only(context, f"编辑模式 (隐藏状态)", is_permanent=True)
        else:
            # visible_get() 会同时检查 Eye 和 Monitor，如果任一为 False 则返回 False
            # 所以这里的计数是准确的（包含了被禁用的物体）
            hidden_count = len([obj for obj in context.scene.objects if not obj.visible_get()])
            show_text_only(context, f"当前隐藏的所有物体", is_permanent=True)
        
        tag_redraw_all_3d_views(context)
            
    except Exception as e:
        print(f"注册绘制回调失败: {str(e)}")

def stop_border_drawing(context):
    global IS_DRAWING_BORDER, DRAW_HANDLES
    
    stop_text_display()

    if not DRAW_HANDLES and not IS_DRAWING_BORDER:
        if context.window_manager.draw_border_active:
            context.window_manager.draw_border_active = False
        if context.scene.draw_border_state: 
             context.scene.draw_border_state = False
        return
    
    for handle in DRAW_HANDLES:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
        except Exception as e:
            print(f"移除绘制句柄错误: {e}")
            
    DRAW_HANDLES.clear()
    IS_DRAWING_BORDER = False
    
    if context.window_manager.draw_border_active:
        context.window_manager.draw_border_active = False
    if context.scene.draw_border_state:
        context.scene.draw_border_state = False
    
    tag_redraw_all_3d_views(context)

def tag_redraw_all_3d_views(context):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


# ====================== 集合可见性辅助函数 ======================
def iter_layer_collections(layer_collection):
    """递归遍历当前 ViewLayer 的 LayerCollection。"""
    if layer_collection is None:
        return
    yield layer_collection
    for child in layer_collection.children:
        yield from iter_layer_collections(child)

def layer_collections_for_collection(context, collection):
    """查找当前 ViewLayer 中指向指定 Collection 的所有 LayerCollection。"""
    if not context or not getattr(context, "view_layer", None):
        return []
    root = context.view_layer.layer_collection
    return [lc for lc in iter_layer_collections(root) if lc.collection == collection]

def is_master_scene_collection(context, collection):
    """避免把场景根集合当作普通集合列出来。"""
    return bool(context and getattr(context, "scene", None) and collection == context.scene.collection)

def is_collection_hidden(context, collection):
    """统一判断集合是否被隐藏。

    Blender 里集合有两套常见隐藏状态：
    1. Collection.hide_viewport：Outliner 的显示器/Monitor，全局禁用视图显示；
    2. LayerCollection.hide_viewport：Outliner 的眼睛/Eye，只在当前 ViewLayer 隐藏。

    之前饼菜单只检查第 1 种，所以手动点眼睛隐藏的集合不会出现在“恢复隐藏集合”里。
    """
    if collection is None or is_master_scene_collection(context, collection):
        return False
    if collection.hide_viewport:
        return True
    return any(lc.hide_viewport for lc in layer_collections_for_collection(context, collection))

def get_hidden_collections(context):
    """按当前 ViewLayer 的层级顺序返回被隐藏的集合，兼容 Eye 与 Monitor。"""
    hidden = []
    seen = set()

    if context and getattr(context, "view_layer", None):
        for lc in iter_layer_collections(context.view_layer.layer_collection):
            col = lc.collection
            if col is None or is_master_scene_collection(context, col):
                continue
            if is_collection_hidden(context, col) and col.name not in seen:
                hidden.append(col)
                seen.add(col.name)

    # 补充：有些 data collections 可能不在当前 ViewLayer 树中，但 Monitor 被关了。
    for col in bpy.data.collections:
        if col.hide_viewport and col.name not in seen:
            hidden.append(col)
            seen.add(col.name)

    return hidden

def set_collection_hidden(context, collection, hidden=True):
    """设置集合隐藏状态。

    优先设置当前 ViewLayer 的 Eye 隐藏，这和用户在 Outliner 手动点眼睛的行为一致；
    如果该集合不在当前 ViewLayer 中，则退回到 Collection.hide_viewport。
    显示时会同时恢复 Eye 和 Monitor，避免集合仍被另一种开关挡住。
    """
    if collection is None or is_master_scene_collection(context, collection):
        return False

    layer_cols = layer_collections_for_collection(context, collection)
    changed = False

    if hidden:
        if layer_cols:
            for lc in layer_cols:
                if not lc.hide_viewport:
                    lc.hide_viewport = True
                    changed = True
        else:
            if not collection.hide_viewport:
                collection.hide_viewport = True
                changed = True
    else:
        if collection.hide_viewport:
            collection.hide_viewport = False
            changed = True
        for lc in layer_cols:
            if lc.hide_viewport:
                lc.hide_viewport = False
                changed = True

    return changed

def restore_collection_visibility(context, collection):
    """恢复指定集合的所有常见隐藏状态。"""
    return set_collection_hidden(context, collection, hidden=False)

@persistent
def undo_callback(scene, depsgraph=None):
    global IS_DRAWING_BORDER, hidden_part_names, original_object_names
    
    try:
        context = bpy.context
        
        new_hidden_list = []
        new_original_set = set()
        
        for obj in bpy.data.objects:
            if "-hide" in obj.name:
                parts = obj.name.rsplit("-hide", 1)
                if len(parts) == 2 and parts[1].isdigit():
                    base_name = parts[0]
                    if base_name in bpy.data.objects:
                        new_hidden_list.append((base_name, obj.name))
                        new_original_set.add(base_name)
        
        hidden_part_names[:] = new_hidden_list
        original_object_names.clear()
        original_object_names.update(new_original_set)
        
        if is_hide_mode_active and context.area:
            count = len(hidden_part_names)
            context.area.tag_redraw()
            
        target_scene = scene if scene else context.scene
        desired_state = getattr(target_scene, "draw_border_state", False)
        
        if IS_DRAWING_BORDER != desired_state:
            if desired_state:
                start_border_drawing(context)
            else:
                stop_border_drawing(context)
        
        tag_redraw_all_3d_views(context)
                        
    except Exception as e:
        print(f"撤销/重做回调执行失败: {e}")

@persistent
def mode_change_handler(scene):
    global IS_EDIT_ISOLATION_ACTIVE, LAST_MODE, IS_EDIT_MESH_TOGGLED
    
    context = bpy.context
    current_mode = context.mode
    
    if current_mode == LAST_MODE:
        return

    # --- A: 物体模式 -> 编辑模式 ---
    if LAST_MODE == 'OBJECT' and current_mode == 'EDIT_MESH':
        if IS_EDIT_ISOLATION_ACTIVE:
            active_obj = context.view_layer.objects.active
            for obj in scene.objects:
                if obj == active_obj: 
                    continue
                if active_obj and obj.data == active_obj.data:
                    continue
                
                if obj.visible_get():
                    obj.hide_set(True)

    # --- B: 编辑模式 -> 物体模式 ---
    elif LAST_MODE == 'EDIT_MESH' and current_mode == 'OBJECT':
        if IS_EDIT_ISOLATION_ACTIVE:
            for obj in scene.objects:
                if not obj.hide_render:
                    obj.hide_set(False)
                    obj.hide_viewport = False # 【修复】确保Monitor被重新开启
        
        if IS_EDIT_MESH_TOGGLED:
            targets = [o for o in context.selected_objects if o.type == 'MESH']
            if context.active_object and context.active_object.type == 'MESH' and context.active_object not in targets:
                targets.append(context.active_object)
            
            for obj in targets:
                mesh = obj.data
                if mesh.vertices:
                    mesh.vertices.foreach_set("hide", [False] * len(mesh.vertices))
                if mesh.edges:
                    mesh.edges.foreach_set("hide", [False] * len(mesh.edges))
                if mesh.polygons:
                    mesh.polygons.foreach_set("hide", [False] * len(mesh.polygons))
                mesh.update()
            
            IS_EDIT_MESH_TOGGLED = False

    LAST_MODE = current_mode

# ====================== 操作器定义 ======================

class VIEW3D_OT_hide_island_under_mouse(Operator):
    """隐藏鼠标下的网格岛屿（左键点击隐藏，右键退出）"""
    bl_idname = "view3d.hide_island_under_mouse"
    bl_label = "隐藏鼠标下的网格岛屿"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.area and context.area.type == 'VIEW_3D'

    def modal(self, context, event):
        global is_hide_mode_active, original_cursor
        
        if is_hide_mode_active and context.mode != 'EDIT_MESH':
            context.window.cursor_set('HAND')
        
        count = len(hidden_part_names)
        context.area.header_text_set(f"隐藏模式: 左键点击隐藏网格岛屿，右键退出 (已隐藏: {count} 个)")
        
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            context.area.header_text_set(None)
            is_hide_mode_active = False
            context.window.cursor_set(original_cursor)
            self.report({'INFO'}, f"已退出隐藏模式，共隐藏 {len(hidden_part_names)} 个网格岛屿")
            return {'FINISHED'}
            
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            
            if context.mode != 'EDIT_MESH':
                depsgraph = context.evaluated_depsgraph_get()
                try:
                    origin, direction = region_ray_from_event(context, event)
                except Exception:
                    context.area.header_text_set(None)
                    is_hide_mode_active = False
                    context.window.cursor_set(original_cursor)
                    return {'CANCELLED'}

                hit_result = context.scene.ray_cast(depsgraph, origin, direction)
                if not hit_result[0] or hit_result[4].type != 'MESH':
                    return {'RUNNING_MODAL'}
                
                obj = hit_result[4]
                me, mat_world = get_original_mesh_and_matrix(obj)
                bvh, tris = build_bvh(me, mat_world)
                hit = bvh.ray_cast(origin, direction)
                
                if hit is None or hit[2] is None:
                    origin2 = origin + direction * 1e-4
                    hit = bvh.ray_cast(origin2, direction)
                    if hit is None:
                        return {'RUNNING_MODAL'}

                try:
                    face_idx = face_index_from_hit(me, tris, hit[2])
                except:
                    return {'RUNNING_MODAL'}

                hidden_obj = hide_target_island_object_mode(obj, face_idx)
                if hidden_obj:
                    current_count = len(hidden_part_names)
                    self.report({'INFO'}, f"已隐藏 (总计: {current_count} 个)")
                    bpy.ops.ed.undo_push(message=f"隐藏网格岛屿 {current_count}")
                    
                return {'RUNNING_MODAL'}
            
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global is_hide_mode_active, original_cursor
        
        if is_hide_mode_active:
            context.area.header_text_set(None)
            is_hide_mode_active = False
            context.window.cursor_set(original_cursor)
            return {'FINISHED'}
            
        if context.mode == 'EDIT_MESH':
            try:
                bpy.ops.mesh.select_linked(delimit=set())
                bpy.ops.mesh.hide(unselected=False)
                self.report({'INFO'}, "已隐藏选中元素所在的松散块")
                bpy.ops.ed.undo_push(message="隐藏编辑模式松散块")
            except Exception as e:
                self.report({'WARNING'}, "请先选中网格的一部分")
            
            return {'FINISHED'}
        
        original_cursor = 'DEFAULT'
        context.window.cursor_set('EYEDROPPER')
        
        is_hide_mode_active = True
        context.window_manager.modal_handler_add(self)
        
        msg = "编辑模式隐藏" if context.mode == 'EDIT_MESH' else "隐藏模式"
        context.area.header_text_set(f"{msg}: 左键点击隐藏，右键退出")
        
        return {'RUNNING_MODAL'}

class VIEW3D_OT_reveal_all_islands(Operator):
    """显示所有隐藏的网格岛屿"""
    bl_idname = "view3d.reveal_all_islands"
    bl_label = "显示所有隐藏的网格岛屿"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        global is_hide_mode_active, original_cursor
        hidden_count = len(hidden_part_names)
        if is_hide_mode_active:
            context.area.header_text_set(None)
            is_hide_mode_active = False
            context.window.cursor_set(original_cursor)
            
        hidden_groups = {}
        for orig_name, hidden_name in hidden_part_names:
            if orig_name not in hidden_groups:
                hidden_groups[orig_name] = []
            hidden_groups[orig_name].append(hidden_name)

        for orig_name in original_object_names:
            if not is_object_valid(orig_name): continue
            orig_obj = bpy.data.objects[orig_name]
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = orig_obj
            orig_obj.select_set(True)
            valid_hidden = []
            if orig_name in hidden_groups:
                for hidden_name in hidden_groups[orig_name]:
                    if is_object_valid(hidden_name):
                        hidden_obj = bpy.data.objects[hidden_name]
                        # 【修复】恢复时同时开启 Eye 和 Monitor
                        hidden_obj.hide_set(False)
                        hidden_obj.hide_viewport = False
                        hidden_obj.hide_render = False
                        hidden_obj.select_set(True)
                        valid_hidden.append(hidden_obj)
            if valid_hidden:
                bpy.ops.object.join()
        
        hidden_part_names.clear()
        original_object_names.clear()
        self.report({'INFO'}, f"已显示所有隐藏的网格岛屿")
        return {'FINISHED'}

class VIEW3D_OT_hide_object_collection(Operator):
    """隐藏选中物体所属的集合"""
    bl_idname = "view3d.hide_object_collection"
    bl_label = "隐藏所属集合"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        target_collections = obj.users_collection
        
        if not target_collections:
            self.report({'WARNING'}, "当前物体不属于任何集合")
            return {'CANCELLED'}
        
        count = 0
        for col in target_collections:
            if set_collection_hidden(context, col, hidden=True):
                count += 1

        tag_redraw_all_3d_views(context)
        self.report({'INFO'}, f"已隐藏 {count if count else len(target_collections)} 个集合")
        return {'FINISHED'}

class VIEW3D_OT_isolate_object_collection(Operator):
    """独显选中物体所属集合：只保留该集合及其父级路径，隐藏其它集合"""
    bl_idname = "view3d.isolate_object_collection"
    bl_label = "独显所属集合"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        obj = context.active_object
        root = context.view_layer.layer_collection if context.view_layer else None
        if root is None:
            self.report({'WARNING'}, "找不到当前 ViewLayer")
            return {'CANCELLED'}

        # 物体可能同时属于多个集合。这里把所有普通所属集合都作为独显目标。
        target_collections = [
            col for col in obj.users_collection
            if col is not None and not is_master_scene_collection(context, col)
        ]
        if not target_collections:
            self.report({'WARNING'}, "当前物体不属于任何普通集合")
            return {'CANCELLED'}

        target_keys = {col.as_pointer() for col in target_collections}
        keep_paths = set()
        matched_target_keys = set()

        def walk_collect_keep_paths(layer_collection, path_keys=()):
            """收集目标集合在当前 ViewLayer 里的完整路径。

            关键点：不能先显示目标再隐藏其它集合；如果后续把父级误隐藏，
            子集合还是会不可见。所以这里先计算“必须保留的路径”，后面两段式处理。
            """
            if layer_collection is None or layer_collection.collection is None:
                return

            col = layer_collection.collection
            key = col.as_pointer()
            current_path = path_keys + (key,)

            if key in target_keys:
                matched_target_keys.add(key)
                # 保留目标集合本身以及它所有父级路径。
                for i in range(1, len(current_path) + 1):
                    keep_paths.add(current_path[:i])

            for child in layer_collection.children:
                walk_collect_keep_paths(child, current_path)

        walk_collect_keep_paths(root)

        if not matched_target_keys:
            self.report({'WARNING'}, "选中物体所属集合不在当前 ViewLayer 中")
            return {'CANCELLED'}

        hidden_count = 0
        shown_count = 0

        def walk_apply_visibility(layer_collection, path_keys=()):
            nonlocal hidden_count, shown_count
            if layer_collection is None or layer_collection.collection is None:
                return

            col = layer_collection.collection
            key = col.as_pointer()
            current_path = path_keys + (key,)

            if is_master_scene_collection(context, col):
                # 场景根集合永远保持显示，只继续处理子集合。
                if col.hide_viewport:
                    col.hide_viewport = False
                    shown_count += 1
                for child in layer_collection.children:
                    walk_apply_visibility(child, current_path)
                return

            if current_path in keep_paths:
                # 目标集合和父级路径必须同时打开 Eye 和 Monitor。
                if col.hide_viewport:
                    col.hide_viewport = False
                    shown_count += 1
                if layer_collection.hide_viewport:
                    layer_collection.hide_viewport = False
                    shown_count += 1
            else:
                # 其它集合只关当前 ViewLayer 的 Eye，不动全局 Monitor。
                if not layer_collection.hide_viewport:
                    layer_collection.hide_viewport = True
                    hidden_count += 1

            for child in layer_collection.children:
                walk_apply_visibility(child, current_path)

        # 两段式：先按路径统一处理，再额外保险打开目标集合本体。
        walk_apply_visibility(root)

        for col in target_collections:
            if col.as_pointer() not in matched_target_keys:
                continue
            if col.hide_viewport:
                col.hide_viewport = False
                shown_count += 1
            for lc in layer_collections_for_collection(context, col):
                if lc.hide_viewport:
                    lc.hide_viewport = False
                    shown_count += 1

        tag_redraw_all_3d_views(context)
        target_label = "、".join(sorted(col.name for col in target_collections if col.as_pointer() in matched_target_keys))
        self.report({'INFO'}, f"已独显所属集合: {target_label}，隐藏其它 {hidden_count} 个集合")
        return {'FINISHED'}

class VIEW3D_OT_restore_specific_collection(Operator):
    """恢复指定的隐藏集合"""
    bl_idname = "view3d.restore_specific_collection"
    bl_label = "恢复集合"
    bl_options = {'REGISTER', 'UNDO'}

    collection_name: bpy.props.StringProperty(name="Collection Name")

    def execute(self, context):
        col = bpy.data.collections.get(self.collection_name)
        if col:
            restore_collection_visibility(context, col)
            tag_redraw_all_3d_views(context)
            self.report({'INFO'}, f"已显示集合: {self.collection_name}")
        else:
            self.report({'WARNING'}, f"找不到集合: {self.collection_name}")
        return {'FINISHED'}

class VIEW3D_OT_show_all_collections(Operator):
    """显示所有被隐藏的集合"""
    bl_idname = "view3d.show_all_collections"
    bl_label = "显示所有集合"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        hidden_cols = get_hidden_collections(context)
        for col in hidden_cols:
            restore_collection_visibility(context, col)
        
        tag_redraw_all_3d_views(context)
        count = len(hidden_cols)
        if count == 0:
            self.report({'INFO'}, "没有隐藏的集合")
        else:
            self.report({'INFO'}, f"已显示 {count} 个集合")
            
        return {'FINISHED'}

class VIEW3D_OT_toggle_selected_children(Operator):
    """切换所选物体子集的可见性"""
    bl_idname = "view3d.toggle_selected_children"
    bl_label = "切换所选物体的子集可见性"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects: return {'CANCELLED'}
        
        all_children = []
        for obj in selected_objects:
            stack = [obj]
            while stack:
                current = stack.pop()
                for child in current.children:
                    all_children.append(child)
                    stack.append(child)
        
        if not all_children: return {'CANCELLED'}
        all_children = list(set(all_children))
        
        # visible_get() 返回 True 仅当 Eye 和 Monitor 都开启时。
        # 如果有任意子集是可见的，我们倾向于全部隐藏。
        has_visible_children = any(child.visible_get() for child in all_children)
        
        for child in all_children:
            if has_visible_children:
                # 隐藏：只关掉眼睛即可（标准隐藏），或者你可以选择也关掉 Monitor，但通常 hide_set 足够
                if child.visible_get(): 
                    child.hide_set(True)
            else:
                # 显示：强制开启眼睛和 Monitor
                child.hide_set(False)
                child.hide_viewport = False
                
        return {'FINISHED'}

class VIEW3D_OT_toggle_visibility(Operator):
    """切换可见性：显示隐藏物体并隐藏可见物体（支持顺序撤销和编辑模式白框）"""
    bl_idname = "view3d.toggle_visibility"
    bl_label = "隐藏互换"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global is_hide_mode_active, original_cursor, IS_DRAWING_BORDER, IS_EDIT_MESH_TOGGLED
        
        if is_hide_mode_active:
            context.area.header_text_set(None)
            is_hide_mode_active = False
            context.window.cursor_set(original_cursor)

        if context.mode == 'EDIT_MESH':
            IS_EDIT_MESH_TOGGLED = True
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.mesh.reveal()
            bpy.ops.mesh.hide(unselected=True)
            self.report({'INFO'}, "已互换网格显示")
            return {'FINISHED'}

        # 物体模式逻辑
        # visible_get() 为 True 表示可见。
        # visible_get() 为 False 表示隐藏（可能是 Eye Off，也可能是 Monitor Off）
        visible_objects = [obj for obj in context.scene.objects if obj.visible_get()]
        hidden_objects = [obj for obj in context.scene.objects if not obj.visible_get()]
        
        for obj in visible_objects: 
            obj.hide_set(True)
            
        for obj in hidden_objects: 
            obj.hide_set(False)
            obj.hide_viewport = False # 【修复】强制开启 Monitor，确保被禁用的物体也能显示
        
        if IS_DRAWING_BORDER:
            stop_border_drawing(context)
        else:
            start_border_drawing(context)
        
        return {'FINISHED'}


class VIEW3D_OT_show_all_except_render_hidden(Operator):
    """按住Shift点击显示全部包括渲染禁用
按住Ctrl点击显示所有未渲染禁用的物体"""
    bl_idname = "view3d.show_all_except_render_hidden"
    bl_label = "显示全部"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        global is_hide_mode_active, original_cursor, IS_DRAWING_BORDER
        
        if is_hide_mode_active:
            context.area.header_text_set(None)
            is_hide_mode_active = False
            context.window.cursor_set(original_cursor)

        if context.mode == 'EDIT_MESH':
            bpy.ops.mesh.reveal()
            self.report({'INFO'}, "已显示所有网格")
            return {'FINISHED'}
            
        if IS_DRAWING_BORDER:
             self.report({'WARNING'}, "当前处于隐藏互换模式，操作已忽略")
             return {'CANCELLED'}

        # --- 逻辑修改部分 ---
        if event.shift:
            # Shift + 点击：暴力显示所有，不管渲染禁用状态
            for obj in context.scene.objects: 
                obj.hide_set(False)
                obj.hide_viewport = False
            self.report({'INFO'}, "显示所有物体 (包含渲染禁用者)")

        elif event.ctrl:
            # Ctrl + 点击：显示那些【没有被渲染禁用】的隐藏物体
            count = 0
            for obj in context.scene.objects:
                if not obj.hide_render: # 只有渲染开启的物体才执行显示
                    if obj.hide_get() or obj.hide_viewport:
                        obj.hide_set(False)
                        obj.hide_viewport = False
                        count += 1
            self.report({'INFO'}, f"已恢复 {count} 个未被渲染禁用的物体")

        else:
            # 普通点击：执行你原始的逻辑（通常也是恢复非渲染禁用的）
            for obj in context.scene.objects:
                if not obj.hide_render: 
                    obj.hide_set(False)
                    obj.hide_viewport = False
                    
        return {'FINISHED'}

class VIEW3D_OT_isolate_edit_object(Operator):
    """隔离当前编辑的物体（支持记忆状态：退出重进保持隔离）"""
    bl_idname = "view3d.isolate_edit_object"
    bl_label = "隔离编辑物体"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and context.active_object

    def execute(self, context):
        global IS_EDIT_ISOLATION_ACTIVE
        
        active_obj = context.active_object
        
        others = []
        for o in context.scene.objects:
            if o == active_obj: 
                continue
            if o.data == active_obj.data:
                continue
            others.append(o)
        
        any_visible = any(o.visible_get() for o in others)

        if any_visible:
            # === 开启隔离 ===
            for o in others:
                o.hide_set(True)
            IS_EDIT_ISOLATION_ACTIVE = True
            self.report({'INFO'}, "已开启隔离 (关联物体保持可见)")
        else:
            # === 关闭隔离 ===
            for o in others:
                if not o.hide_render:
                    o.hide_set(False)
                    o.hide_viewport = False # 【修复】恢复时开启 Monitor
            IS_EDIT_ISOLATION_ACTIVE = False
            self.report({'INFO'}, "已关闭隔离 (恢复正常显示)")

        return {'FINISHED'}

# (其他辅助 Operator 类)
class VIEW3D_OT_disable_render_for_hidden(Operator):
    bl_idname = "view3d.disable_render_for_hidden"
    bl_label = "隐藏物体渲染禁用"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        count = 0
        for obj in context.scene.objects:
            if not obj.visible_get():
                obj.hide_render = True
                count += 1
        self.report({'INFO'}, f"已设置 {count} 个物体")
        return {'FINISHED'}

class VIEW3D_OT_enable_render_for_visible(Operator):
    bl_idname = "view3d.enable_render_for_visible"
    bl_label = "可见物体渲染启用"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        count = 0
        for obj in context.scene.objects:
            if obj.visible_get() and obj.hide_render:
                obj.hide_render = False
                count += 1
        self.report({'INFO'}, f"已设置 {count} 个物体")
        return {'FINISHED'}

class VIEW3D_OT_show_render_enabled_hidden(Operator):
    bl_idname = "view3d.show_render_enabled_hidden"
    bl_label = "显示渲染启用物体"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        count = 0
        for obj in context.scene.objects:
            if not obj.visible_get() and not obj.hide_render:
                obj.hide_set(False)
                obj.hide_viewport = False
                count += 1
        self.report({'INFO'}, f"已显示 {count} 个渲染开启的物体")
        return {'FINISHED'}

class VIEW3D_OT_hide_render_disabled_visible(Operator):
    bl_idname = "view3d.hide_render_disabled_visible"
    bl_label = "隐藏渲染禁用物体"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        count = 0
        for obj in context.scene.objects:
            if obj.visible_get() and obj.hide_render:
                obj.hide_set(True)
                count += 1
        self.report({'INFO'}, f"已隐藏 {count} 个渲染禁用的物体")
        return {'FINISHED'}

# ====================== 辅助函数：统一判断隐藏状态 ======================
def is_effectively_hidden(obj):
    # 只要眼睛(hide_get)或者是显示器(hide_viewport)有一个是关的，就算隐藏
    return obj.hide_get() or obj.hide_viewport

# ====================== 右下角小按钮的操作符修改 ======================

class VIEW3D_OT_handle_wireframe_objects(Operator):
    bl_idname = "view3d.handle_wireframe_objects"
    bl_label = "线框物体切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.display_type == 'WIRE']
        # 逻辑：只要有一个是“有效隐藏”状态，目标就是“全部显示”
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        
        for obj in objs:
            obj.hide_set(target_hide) # 设置眼睛
            if not target_hide:       # 如果是显示操作
                obj.hide_viewport = False # 强制打开显示器
        return {'FINISHED'}

class VIEW3D_OT_hide_all_empty_objects(Operator):
    bl_idname = "view3d.hide_all_empty_objects"
    bl_label = "空物体切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'EMPTY']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_all_lights(Operator):
    bl_idname = "view3d.hide_all_lights"
    bl_label = "灯光切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_point_lights(Operator):
    bl_idname = "view3d.hide_point_lights"
    bl_label = "点光源切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'POINT']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_sun_lights(Operator):
    bl_idname = "view3d.hide_sun_lights"
    bl_label = "日光切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SUN']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_spot_lights(Operator):
    bl_idname = "view3d.hide_spot_lights"
    bl_label = "聚光灯切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_area_lights(Operator):
    bl_idname = "view3d.hide_area_lights"
    bl_label = "面光源切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'AREA']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_all_cameras(Operator):
    bl_idname = "view3d.hide_all_cameras"
    bl_label = "相机切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'CAMERA']
        has_hidden = any(is_effectively_hidden(obj) for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_all_lights(Operator):
    bl_idname = "view3d.hide_all_lights"
    bl_label = "灯光切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT']
        has_hidden = any(not obj.visible_get() for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_point_lights(Operator):
    bl_idname = "view3d.hide_point_lights"
    bl_label = "点光源切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'POINT']
        has_hidden = any(not obj.visible_get() for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_sun_lights(Operator):
    bl_idname = "view3d.hide_sun_lights"
    bl_label = "日光切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SUN']
        has_hidden = any(not obj.visible_get() for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_spot_lights(Operator):
    bl_idname = "view3d.hide_spot_lights"
    bl_label = "聚光灯切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SPOT']
        has_hidden = any(not obj.visible_get() for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_area_lights(Operator):
    bl_idname = "view3d.hide_area_lights"
    bl_label = "面光源切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'LIGHT' and obj.data.type == 'AREA']
        has_hidden = any(not obj.visible_get() for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_OT_hide_all_cameras(Operator):
    bl_idname = "view3d.hide_all_cameras"
    bl_label = "相机切换"
    bl_options = {'REGISTER', 'UNDO'}
    def execute(self, context):
        objs = [obj for obj in context.scene.objects if obj.type == 'CAMERA']
        has_hidden = any(not obj.visible_get() for obj in objs)
        target_hide = not has_hidden
        for obj in objs: 
            obj.hide_set(target_hide)
            if not target_hide: obj.hide_viewport = False
        return {'FINISHED'}

class VIEW3D_MT_hidden_collections_list(Menu):
    bl_label = "恢复隐藏的集合"

    def draw(self, context):
        layout = self.layout
        
        # 1. 获取所有被隐藏的集合
        hidden_cols = get_hidden_collections(context)

        # 2. 如果没有隐藏的集合，显示提示
        if not hidden_cols:
            layout.label(text="当前无隐藏集合", icon='INFO')
            return

        # 3. 添加一个“显示全部”的快捷按钮在最上方
        layout.operator("view3d.show_all_collections", text="显示所有集合", icon='HIDE_OFF')
        layout.separator()

        # 4. 循环列出每个隐藏的集合
        for col in hidden_cols:
            op = layout.operator("view3d.restore_specific_collection", text=col.name, icon='OUTLINER_COLLECTION')
            op.collection_name = col.name

# ====================== 饼菜单定义 ======================
class VIEW3D_MT_hide_pie(Menu):
    bl_label = "隐藏饼菜单"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        
        # 辅助lambda：统计有效隐藏的数量 (眼睛关 或 显示器关)
        count_hidden = lambda objs: len([o for o in objs if o.hide_get() or o.hide_viewport])

        # ====================== 1. 预计算数据与文字逻辑 ======================
        
        # --- 集合 (右上) ---
        hidden_cols_count = len(get_hidden_collections(context))
        txt_cols = f"恢复隐藏集合 ({hidden_cols_count})" if hidden_cols_count > 0 else "恢复隐藏集合..."

        # ====================== 2. 编辑模式逻辑 ======================
        if context.mode == 'EDIT_MESH':
            is_toggle_active = getattr(context.window_manager, "draw_border_active", False)

            # 1. 右
            pie.operator("mesh.hide", text="隐藏未选中").unselected = True
            # 2. 左
            pie.operator("view3d.toggle_visibility", text="网格隐藏互换") 
            # 3. 下
            pie.operator("mesh.hide", text="取消隐藏" if is_toggle_active else "隐藏选中").unselected = False
            # 4. 上
            pie.operator("view3d.show_all_except_render_hidden", text="显示全部")

            # 5. 左上
            top_left_col = pie.column(align=True)
            top_left_col.scale_x = 1.0; top_left_col.scale_y = 1.5
            top_left_col.operator("view3d.hide_island_under_mouse", text="隐藏当前松散块", icon='MESH_ICOSPHERE')
            
            # 6. --- 右上：编辑模式不显示集合按钮 ---
            pie.separator()

            # 7. 左下
            active_obj = context.active_object
            others_visible = False
            if active_obj:
                others_visible = any(o.visible_get() for o in context.scene.objects if o != active_obj)
            
            bot_left_col = pie.column(align=True)
            bot_left_col.scale_x = 1.0; bot_left_col.scale_y = 1.5
            if others_visible:
                bot_left_col.operator("view3d.isolate_edit_object", text="隔离编辑物体", icon='FULLSCREEN_ENTER')
            else:
                bot_left_col.operator("view3d.isolate_edit_object", text="显示背景物体", icon='FULLSCREEN_EXIT')
            return

        # ====================== 3. 物体模式逻辑 ======================
        pie.operator("object.hide_view_set", text="隐藏未选中").unselected = True
        pie.operator("view3d.toggle_visibility", text="隐藏互换")
        
        is_toggle_active = getattr(context.window_manager, "draw_border_active", False)
        pie.operator("object.hide_view_set", text="取消隐藏" if is_toggle_active else "隐藏选中").unselected = False

        pie.operator("view3d.show_all_except_render_hidden", text="显示全部")
        
        # --- 左上 ---
        top_left_col = pie.column(align=True)
        top_left_col.scale_x = 1.1; top_left_col.scale_y = 1.1
        hidden_count = len(hidden_part_names)
        
        txt_hide_island = "隐藏松散块"
        txt_show_island = f"显示所有隐藏网格 ({hidden_count})" if hidden_count > 0 else "显示所有松散块"
        
        top_left_col.operator("view3d.hide_island_under_mouse", text=txt_hide_island, icon='MESH_ICOSPHERE')
        top_left_col.operator("view3d.reveal_all_islands", text=txt_show_island, icon='MESH_CUBE')
        top_left_col.separator()
        
        selected_objects = context.selected_objects
        if selected_objects:
            all_children_count = 0
            hidden_children_count = 0
            for obj in selected_objects:
                stack = [obj]
                while stack:
                    current = stack.pop()
                    for child in current.children:
                        all_children_count += 1
                        # 子集统计：也要算上显示器禁用的
                        if child.hide_get() or child.hide_viewport: 
                            hidden_children_count += 1
                        stack.append(child)
            if all_children_count > 0:
                has_visible_children = hidden_children_count < all_children_count
                if has_visible_children:
                    txt_child = "隐藏子集" 
                else:
                    txt_child = f"显示子集 ({hidden_children_count})"
                top_left_col.operator("view3d.toggle_selected_children", text=txt_child, icon='OUTLINER_OB_GROUP_INSTANCE', depress=has_visible_children)
            else:
                top_left_col.label(text="无子集", icon='INFO')
        else:
            top_left_col.operator("view3d.toggle_selected_children", text="子集可见性", icon='OUTLINER_OB_GROUP_INSTANCE', depress=False)

        # --- 右上：集合控制 ---
        top_right_col = pie.column(align=True)
        top_right_col.scale_x = 1.1
        top_right_col.operator("view3d.isolate_object_collection", text="独显所属集合", icon='OUTLINER_COLLECTION')
        top_right_col.operator("view3d.hide_object_collection", text="隐藏所属集合", icon='OUTLINER_COLLECTION')
        top_right_col.operator("view3d.show_all_collections", text="显示所有集合", icon='HIDE_OFF')
        top_right_col.menu("VIEW3D_MT_hidden_collections_list", text=txt_cols, icon='OUTLINER_COLLECTION')

        # --- 左下：渲染控制 (这个不需要改，因为visible_get如果为False已经是我们要的效果，渲染隐藏是单独的属性) ---
        render_col = pie.column(align=True); render_col.scale_x = 1.09; render_col.scale_y = 1.0
        
        ho = [o for o in context.scene.objects if not o.visible_get()]
        all_h_rd = len(context.scene.objects)>0 and (len(ho)==0 or all(o.hide_render for o in ho))
        txt_disable_render = f"隐藏物体渲染禁用 ({len(ho)})" if len(ho) > 0 else "隐藏物体渲染禁用"
        render_col.operator("view3d.disable_render_for_hidden", text=txt_disable_render, icon='RESTRICT_RENDER_ON', depress=all_h_rd)
        
        vo = [o for o in context.scene.objects if o.visible_get()]
        all_v_re = len(vo)>0 and all(not o.hide_render for o in vo)
        render_col.operator("view3d.enable_render_for_visible", text="可见物体渲染启用", icon='RESTRICT_RENDER_OFF', depress=all_v_re)

        ron_objs = [o for o in context.scene.objects if not o.hide_render]
        all_ron_visible = len(context.scene.objects)>0 and (len(ron_objs)==0 or all(o.visible_get() for o in ron_objs))
        txt_show_ron = f"显示渲染启用物体 ({len(ron_objs)})" if len(ron_objs) > 0 else "显示渲染启用物体"
        render_col.operator("view3d.show_render_enabled_hidden", text=txt_show_ron, icon='HIDE_OFF', depress=all_ron_visible)

        roff_objs = [o for o in context.scene.objects if o.hide_render]
        all_roff_hidden = len(context.scene.objects)>0 and (len(roff_objs)==0 or all(not o.visible_get() for o in roff_objs))
        txt_hide_roff = f"隐藏渲染禁用物体 ({len(roff_objs)})" if len(roff_objs) > 0 else "隐藏渲染禁用物体"
        render_col.operator("view3d.hide_render_disabled_visible", text=txt_hide_roff, icon='HIDE_ON', depress=all_roff_hidden)

        # --- 右下：灯光杂项 (核心修改部分) ---
        combined_col = pie.column(align=True)
        combined_col.scale_x = 1.1; combined_col.scale_y = 1.0
        
        light_grid = combined_col.grid_flow(columns=2, align=True)
        
        pl = [o for o in context.scene.objects if o.type == 'LIGHT' and o.data.type == 'POINT']
        pl_hidden = count_hidden(pl) 
        vis_pl = len(pl) > 0 and pl_hidden == 0
        txt_pl = f"点光 ({pl_hidden})" if pl_hidden > 0 else "点光"
        light_grid.operator("view3d.hide_point_lights", text=txt_pl, icon='LIGHT_POINT', depress=vis_pl)
        
        sl = [o for o in context.scene.objects if o.type == 'LIGHT' and o.data.type == 'SUN']
        sl_hidden = count_hidden(sl)
        vis_sl = len(sl) > 0 and sl_hidden == 0
        txt_sl = f"日光 ({sl_hidden})" if sl_hidden > 0 else "日光"
        light_grid.operator("view3d.hide_sun_lights", text=txt_sl, icon='LIGHT_SUN', depress=vis_sl)
        
        spl = [o for o in context.scene.objects if o.type == 'LIGHT' and o.data.type == 'SPOT']
        spl_hidden = count_hidden(spl)
        vis_spl = len(spl) > 0 and spl_hidden == 0
        txt_spl = f"聚光 ({spl_hidden})" if spl_hidden > 0 else "聚光"
        light_grid.operator("view3d.hide_spot_lights", text=txt_spl, icon='LIGHT_SPOT', depress=vis_spl)
        
        al = [o for o in context.scene.objects if o.type == 'LIGHT' and o.data.type == 'AREA']
        al_hidden = count_hidden(al)
        vis_al = len(al) > 0 and al_hidden == 0
        txt_al = f"面光 ({al_hidden})" if al_hidden > 0 else "面光"
        light_grid.operator("view3d.hide_area_lights", text=txt_al, icon='LIGHT_AREA', depress=vis_al)

        combined_col.separator()
        combined_col.separator() 

        misc_grid = combined_col.grid_flow(columns=2, align=True)
        
        lo = [o for o in context.scene.objects if o.type == 'LIGHT']
        lo_hidden = count_hidden(lo)
        vis_lo = len(lo)>0 and lo_hidden == 0
        txt_lo = f"灯光 ({lo_hidden})" if lo_hidden > 0 else "灯光"
        misc_grid.operator("view3d.hide_all_lights", text=txt_lo, icon='LIGHT', depress=vis_lo)
        
        co = [o for o in context.scene.objects if o.type == 'CAMERA']
        co_hidden = count_hidden(co)
        vis_co = len(co)>0 and co_hidden == 0
        txt_co = f"相机 ({co_hidden})" if co_hidden > 0 else "相机"
        misc_grid.operator("view3d.hide_all_cameras", text=txt_co, icon='CAMERA_DATA', depress=vis_co)
        
        wo = [o for o in context.scene.objects if o.display_type == 'WIRE']
        wo_hidden = count_hidden(wo)
        vis_wo = len(wo)>0 and wo_hidden == 0
        txt_wo = f"线框 ({wo_hidden})" if wo_hidden > 0 else "线框"
        misc_grid.operator("view3d.handle_wireframe_objects", text=txt_wo, icon='SHADING_WIRE', depress=vis_wo)
        
        eo = [o for o in context.scene.objects if o.type == 'EMPTY']
        eo_hidden = count_hidden(eo)
        vis_eo = len(eo)>0 and eo_hidden == 0
        txt_eo = f"空物体 ({eo_hidden})" if eo_hidden > 0 else "空物体"
        misc_grid.operator("view3d.hide_all_empty_objects", text=txt_eo, icon='EMPTY_AXIS', depress=vis_eo)

# ====================== 注册/注销 ======================
keymaps_items_dict = {
    "Object Mode": ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Object Mode', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "Mesh":        ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Mesh', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "Curve":       ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Curve', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "Armature":    ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Armature', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "Lattice":     ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Lattice', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "Metaball":    ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Metaball', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "Grease Pencil": ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', 'Grease Pencil', 'EMPTY', 'WINDOW', 'H', 'PRESS', False, False, False],
    "3D View":     ['wm.call_menu_pie', 'VIEW3D_MT_hide_pie', '3D View', 'VIEW_3D', 'WINDOW', 'H', 'PRESS', False, False, False],
}
addon_keymaps = []

class HIDE_PIE_OT_open_link(Operator):
    bl_idname = "hide_pie.open_link"
    bl_label = "打开链接"
    bl_description = "打开插件相关链接"
    bl_options = {"INTERNAL"}

    url: StringProperty(
        name="链接",
        default="",
        options={"SKIP_SAVE"},
    )

    def execute(self, context):
        if not self.url:
            self.report({"WARNING"}, "链接为空")
            return {"CANCELLED"}

        try:
            bpy.ops.wm.url_open(url=self.url)
        except Exception:
            try:
                import webbrowser
                webbrowser.open(self.url)
            except Exception as ex:
                self.report({"ERROR"}, "打开链接失败: %s" % ex)
                return {"CANCELLED"}

        return {"FINISHED"}


class BPM_OT_Add_Hotkey(Operator):
    bl_idname = "template.add_hotkey"
    bl_label = "添加热键"
    def execute(self, context):
        add_hotkey()
        return {'FINISHED'}

class HidePiePreferences(AddonPreferences):
    bl_idname = __name__

    def draw(self, context):
        layout = self.layout

        row = layout.row(align=True)
        row.scale_y = 1.0
        split = row.split(factor=0.5, align=True)

        tutorial_row = split.row(align=True)
        tutorial_icon = _custom_icon_id("tutorial")
        if tutorial_icon:
            op = tutorial_row.operator(
                "hide_pie.open_link",
                text="插件教程",
                icon_value=tutorial_icon,
            )
        else:
            op = tutorial_row.operator(
                "hide_pie.open_link",
                text="插件教程",
                icon="HELP",
            )
        op.url = _PLUGIN_TUTORIAL_URL

        repository_row = split.row(align=True)
        repository_icon = _custom_icon_id("repository")
        if repository_icon:
            op = repository_row.operator(
                "hide_pie.open_link",
                text="插件仓库",
                icon_value=repository_icon,
            )
        else:
            op = repository_row.operator(
                "hide_pie.open_link",
                text="插件仓库",
                icon="FILE_FOLDER",
            )
        op.url = _PLUGIN_REPOSITORY_URL

        layout.separator()

        wm = context.window_manager
        kc = wm.keyconfigs.user

        # 偏好设置里只显示一个快捷键条目，避免出现 8 个 H。
        # 注意：这里只影响“显示”，不会影响 add_hotkey() 给各模式注册快捷键。
        display_key = "3D View"
        items = keymaps_items_dict[display_key]

        km = kc.keymaps.get(items[2])
        if km:
            for km_item in km.keymap_items:
                if km_item.idname == items[0] and (not items[1] or km_item.properties.name == items[1]):
                    layout.context_pointer_set('keymap', km)
                    from rna_keymap_ui import draw_kmi
                    draw_kmi([], kc, km, km_item, layout, 0)
                    return

        layout.operator("template.add_hotkey", text="添加热键")

def add_hotkey():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc: return
    for items in keymaps_items_dict.values():
        km = kc.keymaps.get(items[2])
        if not km: km = kc.keymaps.new(name=items[2], space_type=items[3], region_type=items[4])
        exists = False
        for kmi in km.keymap_items:
            if kmi.idname == items[0] and ((items[1] and kmi.properties.name == items[1]) or not items[1]):
                exists = True; break
        if not exists:
            kmi = km.keymap_items.new(items[0], items[5], items[6], ctrl=items[7], shift=items[8], alt=items[9])
            if items[1]: kmi.properties.name = items[1]
            kmi.active = True
            addon_keymaps.append((km, kmi))

def register_properties():
    bpy.types.WindowManager.draw_border_active = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.draw_border_state = bpy.props.BoolProperty(default=False)

def unregister_properties():
    del bpy.types.WindowManager.draw_border_active
    del bpy.types.Scene.draw_border_state

def register():
    _load_custom_icons()
    register_properties()
    classes = [
        VIEW3D_OT_hide_island_under_mouse, VIEW3D_OT_reveal_all_islands, VIEW3D_OT_toggle_selected_children,
        VIEW3D_OT_hide_object_collection, VIEW3D_OT_isolate_object_collection, VIEW3D_OT_show_all_collections,
        VIEW3D_OT_restore_specific_collection, 
        VIEW3D_MT_hidden_collections_list,
        VIEW3D_OT_toggle_visibility, VIEW3D_OT_disable_render_for_hidden, VIEW3D_OT_enable_render_for_visible,
        VIEW3D_OT_show_render_enabled_hidden, VIEW3D_OT_hide_render_disabled_visible,
        VIEW3D_OT_show_all_except_render_hidden, VIEW3D_OT_handle_wireframe_objects, VIEW3D_OT_hide_all_empty_objects,
        VIEW3D_OT_hide_all_lights, VIEW3D_OT_hide_point_lights, VIEW3D_OT_hide_sun_lights, VIEW3D_OT_hide_spot_lights,
        VIEW3D_OT_hide_area_lights, VIEW3D_OT_hide_all_cameras, 
        VIEW3D_OT_isolate_edit_object,
        VIEW3D_MT_hide_pie, HIDE_PIE_OT_open_link, BPM_OT_Add_Hotkey, HidePiePreferences
    ]
    for cls in classes: bpy.utils.register_class(cls)
    add_hotkey()
    
    if undo_callback not in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.append(undo_callback)
    
    if undo_callback not in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.append(undo_callback)
        
    if mode_change_handler not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(mode_change_handler)

def unregister():
    stop_border_drawing(bpy.context)
    classes = [
        VIEW3D_OT_hide_island_under_mouse, VIEW3D_OT_reveal_all_islands, VIEW3D_OT_toggle_selected_children,
        VIEW3D_OT_hide_object_collection, VIEW3D_OT_isolate_object_collection, VIEW3D_OT_show_all_collections,
        VIEW3D_OT_restore_specific_collection, 
        VIEW3D_MT_hidden_collections_list,
        VIEW3D_OT_toggle_visibility, VIEW3D_OT_disable_render_for_hidden, VIEW3D_OT_enable_render_for_visible,
        VIEW3D_OT_show_render_enabled_hidden, VIEW3D_OT_hide_render_disabled_visible,
        VIEW3D_OT_show_all_except_render_hidden, VIEW3D_OT_handle_wireframe_objects, VIEW3D_OT_hide_all_empty_objects,
        VIEW3D_OT_hide_all_lights, VIEW3D_OT_hide_point_lights, VIEW3D_OT_hide_sun_lights, VIEW3D_OT_hide_spot_lights,
        VIEW3D_OT_hide_area_lights, VIEW3D_OT_hide_all_cameras, 
        VIEW3D_OT_isolate_edit_object,
        VIEW3D_MT_hide_pie, HIDE_PIE_OT_open_link, BPM_OT_Add_Hotkey, HidePiePreferences
    ]
    for cls in reversed(classes): bpy.utils.unregister_class(cls)
    unregister_properties()
    for km, kmi in addon_keymaps: km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    if undo_callback in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.remove(undo_callback)
        
    if undo_callback in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.remove(undo_callback)
        
    if mode_change_handler in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(mode_change_handler)

    _unload_custom_icons()

if __name__ == "__main__":
    register()