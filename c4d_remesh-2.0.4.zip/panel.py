# -*- coding: utf-8 -*-
# N 面板模块: ZRemesher 烘焙路径的完整界面面。
#
# 包含: 面板(VIEW3D_PT_zremesh)、面板操作符(执行/清空)、
# 参数容器(ZMRemeshSettings/ZMFactoryState), 以及历史 UI
# (历史操作符 + 列表绘制 + 展示辅助)。
#
# 版本化记账(命名/时间戳/上限裁剪)位于 factory.py(写回侧),
# 本文件通过 get_real_data_name/get_zm_meshes 从 factory 复用。

import os
import datetime
import json

import bpy
from bpy.props import (IntProperty, BoolProperty, FloatProperty, StringProperty, PointerProperty)

from .factory import (ZRemesherFactory, get_real_data_name, get_zm_meshes)
from . import settings
from . import zm_modifier

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_BUNDLED_BIN = os.path.join(_ADDON_DIR, "bin")


# ────────────── 历史: 展示辅助 ──────────────

def get_display_time(mesh):
    return mesh.get("zm_time", "--")


def get_params_json(mesh):
    return mesh.get("zm_params", "")


def get_stats(mesh):
    return f"{len(mesh.vertices)}v {len(mesh.polygons)}f"


def params_summary(p_json):
    try:
        p = json.loads(p_json)
    except Exception:
        return ""
    mode = p.get('polygon_target_mode', 'COUNT')
    if mode == 'EDGE':
        return f"边长{p.get('edge_length', '')}"
    if mode == 'PERCENT':
        return f"{p.get('target_percentage', '')}%"
    cnt = p.get('polygon_count', 0)
    sc = p.get('polygon_scale', 1.0)
    return f"{cnt}面" if sc == 1.0 else f"{cnt}x{sc}面"


def apply_params_to_scene(params_json, props):
    """把历史条目的参数 JSON 填入面板(scene.zremesh_props), 供参考/重跑。"""
    if not params_json:
        return
    try:
        params = json.loads(params_json)
    except Exception:
        return
    if not isinstance(params, dict):
        return
    for k, v in params.items():
        if k == 'guide_splines':
            obj = bpy.data.objects.get(v) if v else None
            try:
                props.guide_splines = obj if obj and obj.type == 'CURVE' else None
            except Exception:
                pass
        elif k == 'density_map':
            try:
                props.density_map = v or ''
            except Exception:
                pass
        else:
            if not hasattr(props, k):
                continue
            try:
                setattr(props, k, v)
            except Exception:
                pass


def apply_history(obj, mesh_name):
    """应用历史: 将目标提升为原始, 清理其余历史与原稿。返回 (removed, skipped, real_name)。"""
    mesh = bpy.data.meshes.get(mesh_name)
    if mesh is None:
        return 0, 0, None
    real = get_real_data_name(mesh.name)
    if obj.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    others = []
    origin = bpy.data.meshes.get(real)
    if origin is not None and origin != mesh:
        others.append(origin)
    for m in get_zm_meshes(real):
        if m != mesh:
            others.append(m)

    if obj.data != mesh:
        obj.data = mesh

    removed = skipped = 0
    for m in others:
        if m.users > 0:
            skipped += 1
            continue
        bpy.data.meshes.remove(m, do_unlink=True)
        removed += 1

    if bpy.data.meshes.get(real) is None and mesh.name != real:
        mesh.name = real
    obj.data = mesh
    return removed, skipped, real


# ────────────── 历史操作符 ──────────────

class MESH_OT_zremesh_history_switch(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_switch"
    bl_label = "切换历史"
    bl_description = "将物体网格数据切换为该历史版本"
    bl_options = {'REGISTER', 'UNDO'}
    mesh_name: bpy.props.StringProperty()

    def execute(self, ctx):
        obj = ctx.object
        if not obj:
            return {"CANCELLED"}
        mesh = bpy.data.meshes.get(self.mesh_name)
        if mesh is None:
            self.report({"WARNING"}, "历史网格不存在(可能已被清理)")
            return {"CANCELLED"}
        if obj.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        obj.data = mesh
        # 自动把该历史的参数填入面板
        apply_params_to_scene(mesh.get("zm_params", ""), ctx.scene.zremesh_props)
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 切换历史")
        except Exception:
            pass
        return {"FINISHED"}


class MESH_OT_zremesh_history_remove(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_remove"
    bl_label = "删除历史"
    bl_description = "删除该历史网格(正被引用时不可删除)"
    bl_options = {'REGISTER', 'UNDO'}
    mesh_name: bpy.props.StringProperty()

    def execute(self, ctx):
        mesh = bpy.data.meshes.get(self.mesh_name)
        if mesh is None:
            return {"CANCELLED"}
        if mesh.users > 0:
            self.report({"WARNING"}, f"{mesh.name} 正被引用, 无法删除")
            return {"CANCELLED"}
        bpy.data.meshes.remove(mesh, do_unlink=True)
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 删除历史")
        except Exception:
            pass
        return {"FINISHED"}


class MESH_OT_zremesh_history_apply(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_apply"
    bl_label = "应用历史"
    bl_description = "将所选历史提升为原始, 清理其余历史与原稿(高危操作, 需二次确认)"
    bl_options = {'REGISTER', 'UNDO'}
    mesh_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.object
        if not obj:
            return {"CANCELLED"}
        removed, skipped, real = apply_history(obj, self.mesh_name)
        if real is None:
            self.report({"WARNING"}, "历史网格不存在(可能已被清理)")
            return {"CANCELLED"}
        self.report({"INFO"}, f"已应用历史 [{real}], 清理 {removed} 个, 跳过 {skipped} 个(被引用)")
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 应用历史")
        except Exception:
            pass
        return {"FINISHED"}


class MESH_OT_zremesh_history_clear(bpy.types.Operator):
    bl_idname = "mesh.zremesh_history_clear"
    bl_label = "清空历史"
    bl_description = "清除该物体的所有拓扑历史, 保留原版网格"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, ctx):
        obj = ctx.object
        if not obj:
            return {"CANCELLED"}
        real = get_real_data_name(obj.data.name)
        removed = skipped = 0
        for m in get_zm_meshes(real):
            if m.users > 0:
                skipped += 1
                continue
            bpy.data.meshes.remove(m, do_unlink=True)
            removed += 1
        self.report({"INFO"}, f"已清空 {removed} 个历史, 跳过 {skipped} 个(被引用)")
        try:
            bpy.ops.ed.undo_push(message="ZRemesher 清空历史")
        except Exception:
            pass
        return {"FINISHED"}


def draw_history(layout, obj):
    """在 N 面板绘制历史列表。"""
    real = get_real_data_name(obj.data.name)
    box = layout.box()
    row = box.row()
    row.label(text="历史", icon="TIME")
    row.operator(MESH_OT_zremesh_history_clear.bl_idname, text="清空", icon="TRASH")

    def _row(mesh, label=None, icon='MESH_DATA', show_apply=True, show_remove=True):
        r = box.row(align=True)
        is_current = obj.data == mesh
        op = r.operator(MESH_OT_zremesh_history_switch.bl_idname, text="", icon="FILE_REFRESH",
                        depress=is_current)
        op.mesh_name = mesh.name
        r.label(text=label if label else get_display_time(mesh), icon=icon)
        r.label(text=get_stats(mesh))
        summary = "" if label else params_summary(get_params_json(mesh))
        if summary:
            r.label(text=summary)
        if show_apply:
            op = r.operator(MESH_OT_zremesh_history_apply.bl_idname, text="应用", icon="CHECKMARK")
            op.mesh_name = mesh.name
        if show_remove:
            op = r.operator(MESH_OT_zremesh_history_remove.bl_idname, text="", icon="X")
            op.mesh_name = mesh.name

    origin = bpy.data.meshes.get(real)
    if origin is not None:
        _row(origin, label="原版", icon='OBJECT_ORIGIN', show_apply=False, show_remove=False)

    snaps = sorted(get_zm_meshes(real), key=lambda m: m.name)
    if not snaps and origin is None:
        box.label(text="暂无历史", icon="INFO")
        return
    for m in snaps:
        _row(m)


# ────────────── 参数容器 ──────────────

_scene_annots = settings.make_props()
_scene_annots['progress'] = FloatProperty(name="进度", default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
_scene_annots['status'] = StringProperty(name="状态", default="")

ZMRemeshSettings = type(
    'ZMRemeshSettings', (bpy.types.PropertyGroup,),
    {'__annotations__': _scene_annots})


class ZMFactoryState(bpy.types.PropertyGroup):
    running: BoolProperty(name="运行中", default=False)
    progress: FloatProperty(name="进度", default=0.0, min=0.0, max=100.0, subtype='PERCENTAGE')
    status: StringProperty(name="状态", default="")
    queue_len: IntProperty(name="队列", default=0)


# ────────────── 面板操作符 ──────────────

class MESH_OT_zremesh(bpy.types.Operator):
    bl_idname = "mesh.zremesh_remesh"
    bl_label = "ZRemesher"
    bl_description = "采用ZBrush的ZRemesher算法对网格进行重拓扑\n是在处理有机形状时，该算法能够自动识别边缘循环，并能够以相当高的质量展示这些形状"

    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, ctx):
        if ZRemesherFactory.instance().is_busy():
            return False
        return any(o.type == "MESH" for o in ctx.selected_objects)

    def invoke(self, ctx, event):
        return self.execute(ctx)

    def execute(self, ctx):
        if ctx.object and ctx.object.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        if not os.path.isfile(os.path.join(_BUNDLED_BIN, "xremeshlib2.dll")):
            self.report({"ERROR"}, f"动态库缺失:{_BUNDLED_BIN}")
            return {"CANCELLED"}

        targets = [o for o in ctx.selected_objects if o.type == 'MESH']
        if not targets:
            self.report({"ERROR"}, "请先选择网格物体")
            return {"CANCELLED"}

        params = settings.collect_params(ctx.scene.zremesh_props)
        fac = ZRemesherFactory.instance()
        n = 0
        for t in targets:
            mod = zm_modifier.find_modifier(t)
            if mod is not None and (mod.show_viewport or mod.show_render):
                mod.show_viewport = False
                mod.show_render = False
                self.report({"WARNING"}, f"已自动禁用 {t.name} 上的 ZRemesher 修改器")
            if fac.submit(t, params):
                n += 1
        self.report({"INFO"}, f"已加入队列:{n} 个物体")
        return {"FINISHED"}


class MESH_OT_zremesh_cancel(bpy.types.Operator):
    bl_idname = "mesh.zremesh_cancel"
    bl_label = "清空队列"
    bl_description = "清空等待中的任务;正在计算的任务无法中断,完成后将被丢弃"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, ctx):
        fac = ZRemesherFactory.instance()
        return fac.is_busy() or fac.queue_length() > 0

    def execute(self, ctx):
        ZRemesherFactory.instance().cancel_all()
        self.report({"INFO"}, "已清空队列")
        return {"FINISHED"}


# ────────────── N 面板 ──────────────

class VIEW3D_PT_zremesh(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ZRemesher"
    bl_label = "ZRemesher重拓扑"

    def draw(self, ctx):
        layout = self.layout
        p = ctx.scene.zremesh_props
        fac = ZRemesherFactory.instance()
        split_factor = 0.25

        obj = ctx.active_object
        box = layout.box()
        if obj and obj.type == "MESH":
            row=box.row()
            row.label(text=f"当前物体:{obj.name}", icon="OBJECT_DATAMODE")
            sel_meshes = [o for o in ctx.selected_objects if o.type == 'MESH']
            row.label(text=f"将重拓扑 {len(sel_meshes)} 个选中网格", icon="MOD_REMESH")
            box.label(text=f"顶点:{len(obj.data.vertices)}  面:{len(obj.data.polygons)}")
        else:
            box.label(text="未选择网格物体", icon="INFO")

        box = layout.box()
        box.label(text="目标:", icon="MOD_REMESH")
        row = box.row(align=True)
        row.prop(p, "polygon_target_mode", expand=True)
        row = box.row(align=True)
        if p.polygon_target_mode == 'COUNT':
            row.prop(p, "polygon_count")
        elif p.polygon_target_mode == 'EDGE':
            row.prop(p, "edge_length")
        elif p.polygon_target_mode == 'PERCENT':
            row.prop(p, "target_percentage", slider=True)
        row.prop(p, "polygon_scale")

        box = layout.box()
        split = box.split(factor=split_factor)
        split.prop(p, "density_enable", text="密度图")
        row = split.row(align=True)
        row.enabled = p.density_enable
        if obj and obj.type == "MESH":
            row.prop_search(p, "density_map", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
        else:
            row.enabled = False
            row.prop(p, "density_map", text="")
        row.prop(p, "density_scale", slider=True)

        split = box.split(factor=split_factor)
        split.prop(p, "adaptive", text="自适应")
        row = split.row(align=True)
        row.enabled = p.adaptive
        row.prop(p, "adaptiveness")

        split = box.split(factor=split_factor)
        split.prop(p, "hard_edge_enable", text="硬边保护")
        row = split.row(align=True)
        row.enabled = p.hard_edge_enable
        row.prop(p, "hard_edge_type", text="")
        if p.hard_edge_type == 'AUTO':
            row.prop(p, "hard_edge_angle", slider=True)
        elif p.hard_edge_type == 'SHARP':
            row.label(text="使用标记的锐边", icon='EDGESEL')
        elif p.hard_edge_type == 'VGROUP':
            if obj and obj.type == 'MESH':
                row.prop_search(p, "hard_edge_vgroup", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
            else:
                row.prop(p, "hard_edge_vgroup", text="")

        split = box.split(factor=split_factor)
        split.prop(p, "guide_enable", text="流线引导")
        row = split.row(align=True)
        row.enabled = p.guide_enable
        row.prop(p, "guide_type", text="")

        if p.guide_type == 'CURVE':
            row.prop(p, "guide_splines", text="")
        elif p.guide_type == 'SHARP_EDGES':
            row.label(text="锐边作为流线", icon="EDGESEL")
        elif p.guide_type == 'SEAM_EDGES':
            row.label(text="UV缝合边作为流线", icon="UV")

        box = layout.box()
        split = box.split(factor=split_factor)
        split.label(text="优化", icon="SHADING_RENDERED")
        row = split.row()
        row.prop(p, "freeze_borders", text="锁定边界", toggle=True)
        row.prop(p, "preprocess_weld", text="预焊接", toggle=True)
        row.prop(p, "denoise_strength", text="", slider=True)
        split = box.split(factor=split_factor)
        split.label(text="对称", icon="MOD_MIRROR")
        row = split.row(align=True)
        row.prop(p, "symmetry_x", icon="EVENT_X", text="", toggle=True)
        row.prop(p, "symmetry_y", icon="EVENT_Y", text="", toggle=True)
        row.prop(p, "symmetry_z", icon="EVENT_Z", text="", toggle=True)
        row.separator()
        sub = row.row()
        sub.enabled = p.symmetry_x or p.symmetry_y or p.symmetry_z
        sub.prop(p, "sym_direction", expand=True)

        layout.separator()

        box = layout.box()
        col = box.column(align=True)
        col.scale_y = 1.5
        if fac.is_busy():
            col.enabled = False
            col.operator(MESH_OT_zremesh.bl_idname, text="运行中…", icon="TIME")
        else:
            col.operator(MESH_OT_zremesh.bl_idname, text="执行重拓扑", icon="MOD_REMESH")

        fs = ctx.window_manager.zremesh_factory
        split = box.split(factor=split_factor)
        split.label(text="进度", icon="INFO")
        row = split.row(align=True)
        row.enabled = False
        row.prop(fs, "progress", text="", slider=True)
        if fs.status:
            box.label(text=fs.status)
        if fs.running:
            box.label(text=f"队列:{fs.queue_len}", icon="FILE_TICK")
            box.operator(MESH_OT_zremesh_cancel.bl_idname, text="清空队列", icon="CANCEL")

        if obj and obj.type == "MESH":
            draw_history(box, obj)


_REGISTER_CLASSES = (ZMRemeshSettings, ZMFactoryState,
                     MESH_OT_zremesh, MESH_OT_zremesh_cancel,
                     VIEW3D_PT_zremesh,
                     MESH_OT_zremesh_history_switch, MESH_OT_zremesh_history_apply,
                     MESH_OT_zremesh_history_remove, MESH_OT_zremesh_history_clear)


def register():
    for c in _REGISTER_CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.zremesh_props = PointerProperty(type=ZMRemeshSettings)
    bpy.types.WindowManager.zremesh_factory = PointerProperty(type=ZMFactoryState)


def unregister():
    try:
        del bpy.types.WindowManager.zremesh_factory
    except Exception:
        pass
    try:
        del bpy.types.Scene.zremesh_props
    except Exception:
        pass
    for c in reversed(_REGISTER_CLASSES):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass
