# -*- coding: utf-8 -*-
# ZRemesher 队列工厂: 生产者 / 存储队列 / 消费者 三段式
#
# 线程模型:
#   主线程    : submit / bpy.app.timers 心跳 / 任务准备(_prepare_task) / 写回(_writeback)
#   后台线程  : 仅调用 xremesh_extract.extract_mesh(DLL 计算, 零 bpy 调用)
#   任务对象  : 跨线程共享, 靠 GIL 保证简单字段读写的原子性
#
# 状态机:
#   工厂: IDLE <-> RUNNING(bpy.app.timers 心跳)
#   任务: PENDING -> RUNNING -> DONE / FAILED / CANCELLED / SKIPPED
#
# DLL 说明: xremesh_extract 在模块级 import 时若 bin/ 缺失会抛异常,
# 因此这里延迟 import, 由 worker 线程捕获并写入任务错误。

import os
import re
import json
import time
import datetime
import threading
import traceback
from collections import OrderedDict

import bpy
import numpy as np
from mathutils import kdtree

from . import settings

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_BUNDLED_BIN = os.path.join(_ADDON_DIR, "bin")

_remesh_extract = None


def _get_extract():
    global _remesh_extract
    if _remesh_extract is None:
        from . import xremesh_extract
        _remesh_extract = xremesh_extract
    return _remesh_extract


# ────────────── 版本化记账(写回侧) ──────────────
# 每次写回都会把物体网格换成新 mesh, 旧网格留在 bpy.data 成为历史版本。
# 命名/时间戳/上限裁剪是"创建新版本"的记账动作, 与 _writeback 内聚于此。
# 命名规范:
#   原版网格 = {real_name}                    (物体初始网格, 永久保留)
#   拓扑网格 = {real_name}.zm{YYYYMMDDHHMMSSffffff}
# 上限: _HISTORY_CAP 个拓扑 + 原版永久, 超限淘汰最旧未被引用的拓扑。

_HISTORY_CAP = 5
_NAME_FORMAT = "%Y%m%d%H%M%S%f"
_DISPLAY_FORMAT = "%m/%d %H:%M"


def get_real_data_name(data_name):
    """去掉 .zm<时间戳> 后缀, 得到真实(原版)网格名。"""
    m = re.match(r"^(.*?)(\.zm\d+)$", data_name)
    return m.group(1) if m else data_name


def get_zm_meshes(real_name):
    """返回属于该真实名的所有拓扑网格(未排序)。"""
    pattern = re.compile(rf"^{re.escape(real_name)}\.zm\d+$")
    return [m for m in bpy.data.meshes if pattern.match(m.name)]


def new_mesh_name(real_name):
    return f"{real_name}.zm{datetime.datetime.now().strftime(_NAME_FORMAT)}"


def display_now():
    return datetime.datetime.now().strftime(_DISPLAY_FORMAT)


def enforce_cap(real_name, obj, cap=_HISTORY_CAP):
    """超上限时淘汰最旧拓扑网格。跳过仍被引用的(当前 obj.data 或其它物体)。"""
    candidates = sorted(get_zm_meshes(real_name), key=lambda m: m.name)
    if len(candidates) <= cap:
        return
    protected = {m.name for m in candidates if m.users > 0}
    removable = [m for m in candidates if m.name not in protected]
    excess = len(candidates) - cap
    if excess <= 0:
        return
    for m in removable[:excess]:
        try:
            bpy.data.meshes.remove(m, do_unlink=False)
        except Exception:
            pass


class TaskState:
    PENDING = 'PENDING'
    RUNNING = 'RUNNING'
    DONE = 'DONE'
    FAILED = 'FAILED'
    CANCELLED = 'CANCELLED'
    SKIPPED = 'SKIPPED'


class _RemeshJob:
    """单个任务的后台计算结果容器(线程写, 主线程读)。"""

    def __init__(self):
        self.progress = 0.0
        self.status = ''
        self.error = None
        self.verts = None
        self.faces = None
        self.hard_edges = []
        self._dll_pct = 0.0


class RemeshTask:
    """一个队列条目。object_name 为键名, 消费时按名取对象。
    prepare_fn / writeback_fn: 可选自定义准备与写回(修改器模式使用)。
    cache_obj: 修改器模式的缓存物体。
    manual: True 表示用户手动触发(修改器模式用于区分自动/手动)。"""

    __slots__ = ('object_name', 'params', 'force', 'state', 'progress',
                 'status', 'error', 'cancelled', 'job', 'prep',
                 'start_time', 'done_time', 'manual',
                 'prepare_fn', 'writeback_fn', 'cache_obj')

    def __init__(self, object_name, params, force=False, manual=False):
        self.object_name = object_name
        self.params = dict(params)
        self.force = bool(force)
        self.manual = bool(manual)
        self.state = TaskState.PENDING
        self.progress = 0.0
        self.status = ''
        self.error = None
        self.cancelled = False
        self.job = None
        self.prep = None
        self.start_time = 0.0
        self.done_time = 0.0
        self.prepare_fn = None
        self.writeback_fn = None
        self.cache_obj = None


def _read_vertex_group_weights(obj, vg_name, mesh=None):
    m = mesh if mesh is not None else obj.data
    vg = obj.vertex_groups.get(vg_name)
    if not vg:
        return None
    n = len(m.vertices)
    out = [0.0] * n
    if m is obj.data:
        for i in range(n):
            try:
                out[i] = vg.weight(i)
            except RuntimeError:
                pass
    else:
        gi = vg.index
        for i in range(n):
            for g in m.vertices[i].groups:
                if g.group == gi:
                    out[i] = g.weight
                    break
    return out


def _sample_spline_points(ctx, curve_obj, step=0.02):
    try:
        depsgraph = ctx.evaluated_depsgraph_get()
        eo = curve_obj.evaluated_get(depsgraph)
        tmp = eo.to_mesh()
    except Exception:
        return []
    mw = curve_obj.matrix_world
    verts = [mw @ v.co.copy() for v in tmp.vertices]
    edges = [tuple(e.vertices) for e in tmp.edges]
    try:
        eo.to_mesh_clear()
    except Exception:
        pass
    if not edges:
        return verts
    pts = []
    for a, b in edges:
        va, vb = verts[a], verts[b]
        seg_len = (vb - va).length
        n_sub = max(1, int(seg_len / step))
        for k in range(n_sub):
            t = k / n_sub
            pts.append(va.lerp(vb, t))
    pts.append(verts[edges[-1][1]])
    return pts


def _sample_marked_edge_polylines(obj, flag='SHARP', step=0.02, mesh=None, mw=None):
    """从网格的标记边构建多条流线:把共享顶点的标记边链成折线,
    每条折线沿边按 step 插值成细密点链。返回 [(世界坐标点列表)...]。
    flag: 'SHARP' 用 use_edge_sharp 锐边,'SEAM' 用 use_seam 缝合边。
    无标记边或无法成链时返回 []。"""
    me = mesh if mesh is not None else obj.data
    mw = mw if mw is not None else obj.matrix_world
    n_v = len(me.vertices)
    if not n_v or not len(me.edges):
        return []
    co = np.empty(n_v * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    m3 = np.array([[mw[0][0], mw[0][1], mw[0][2]],
                   [mw[1][0], mw[1][1], mw[1][2]],
                   [mw[2][0], mw[2][1], mw[2][2]]], dtype=np.float64)
    t = np.array([mw[0][3], mw[1][3], mw[2][3]], dtype=np.float64)
    co_w = (co.reshape(-1, 3).astype(np.float64) @ m3.T + t).astype(np.float32)

    marked = []
    for e in me.edges:
        if (flag == 'SEAM' and e.use_seam) or (flag != 'SEAM' and e.use_edge_sharp):
            marked.append((e.vertices[0], e.vertices[1]))
    if not marked:
        return []

    adj = {}
    edge_set = set()
    for a, b in marked:
        edge_set.add((a, b) if a < b else (b, a))
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    used = set()
    polylines = []
    for a, b in marked:
        key = (a, b) if a < b else (b, a)
        if key in used:
            continue
        line = [a, b]
        used.add(key)
        prev, cur = a, b
        while True:
            nxt = [x for x in adj.get(cur, []) if x != prev and (min(cur, x), max(cur, x)) in edge_set]
            if not nxt:
                break
            nxt = nxt[0]
            ekey = (min(cur, nxt), max(cur, nxt))
            if ekey in used:
                break
            used.add(ekey)
            line.append(nxt)
            prev, cur = cur, nxt
        prev, cur = b, a
        while True:
            nxt = [x for x in adj.get(cur, []) if x != prev and (min(cur, x), max(cur, x)) in edge_set]
            if not nxt:
                break
            nxt = nxt[0]
            ekey = (min(cur, nxt), max(cur, nxt))
            if ekey in used:
                break
            used.add(ekey)
            line.insert(0, nxt)
            prev, cur = cur, nxt

        pts = []
        for i in range(len(line) - 1):
            va = co_w[line[i]]
            vb = co_w[line[i + 1]]
            seg_len = float(np.linalg.norm(vb - va))
            n_sub = max(1, int(seg_len / step))
            if n_sub > 1:
                ts = np.linspace(0.0, 1.0, n_sub, endpoint=False, dtype=np.float32)
                seg_pts = va[None, :] + (vb - va)[None, :] * ts[:, None]
                pts.extend((float(p[0]), float(p[1]), float(p[2])) for p in seg_pts)
            else:
                pts.append((float(va[0]), float(va[1]), float(va[2])))
        last = co_w[line[-1]]
        pts.append((float(last[0]), float(last[1]), float(last[2])))
        if len(pts) >= 2:
            polylines.append(pts)

    return polylines


def _weights_from_spline_proximity(src_world_coords, curve_pts, radius, strength=1.0):
    if not curve_pts or radius <= 0 or not src_world_coords:
        return [0.0] * len(src_world_coords)
    kd = kdtree.KDTree(len(curve_pts))
    for i, c in enumerate(curve_pts):
        kd.insert(c, i)
    kd.balance()
    inv_r = 1.0 / radius
    out = [0.0] * len(src_world_coords)
    for i, wc in enumerate(src_world_coords):
        _, _, d = kd.find(wc)
        if d is not None and d < radius:
            out[i] = (1.0 - d * inv_r) * strength
    return out


def _mesh_to_world_triangles(obj, ctx, mesh=None, mw=None):
    """通过 foreach_get + numpy 将网格提取为世界坐标顶点 + 三角形索引。
    默认经 depsgraph 求值以应用修改器; 传入 mesh/mw 时直接用该网格数据
    (原始网格, 用于"基于原稿重拓扑", 不应用修改器)。"""
    if mesh is None or mw is None:
        depsgraph = ctx.evaluated_depsgraph_get()
        eo = obj.evaluated_get(depsgraph)
        tmp = eo.to_mesh()
        try:
            n_v = len(tmp.vertices)
            co = np.empty(n_v * 3, dtype=np.float32)
            tmp.vertices.foreach_get("co", co)
            tmp.calc_loop_triangles()
            n_t = len(tmp.loop_triangles)
            tris = np.empty(n_t * 3, dtype=np.int32)
            tmp.loop_triangles.foreach_get("vertices", tris)
            tris = tris.reshape(-1, 3)
        finally:
            eo.to_mesh_clear()
        mw = obj.matrix_world
    else:
        n_v = len(mesh.vertices)
        co = np.empty(n_v * 3, dtype=np.float32)
        mesh.vertices.foreach_get("co", co)
        mesh.calc_loop_triangles()
        n_t = len(mesh.loop_triangles)
        tris = np.empty(n_t * 3, dtype=np.int32)
        mesh.loop_triangles.foreach_get("vertices", tris)
        tris = tris.reshape(-1, 3)

    m3 = np.array([[mw[0][0], mw[0][1], mw[0][2]],
                   [mw[1][0], mw[1][1], mw[1][2]],
                   [mw[2][0], mw[2][1], mw[2][2]]], dtype=np.float64)
    t = np.array([mw[0][3], mw[1][3], mw[2][3]], dtype=np.float64)
    co3 = co.reshape(-1, 3).astype(np.float64)
    verts_w = (co3 @ m3.T + t).astype(np.float32)
    return verts_w, tris


def _collect_hard_edges(obj, p, mesh=None, mw=None):
    m = mesh if mesh is not None else obj.data
    mw = mw if mw is not None else obj.matrix_world
    pairs = []
    seen = set()

    def _add(a, b):
        k = (a, b) if a < b else (b, a)
        if k not in seen:
            pairs.append((a, b))
            seen.add(k)

    htype = p.get('hard_edge_type')
    if htype == 'SHARP':
        for e in m.edges:
            if e.use_edge_sharp:
                _add(e.vertices[0], e.vertices[1])
    elif htype == 'VGROUP':
        heg = (p.get('hard_edge_vgroup') or '').strip()
        if heg and heg in obj.vertex_groups:
            he_ws = _read_vertex_group_weights(obj, heg, mesh=m)
            if he_ws:
                for e in m.edges:
                    a, b = e.vertices[0], e.vertices[1]
                    if he_ws[a] > 0.5 and he_ws[b] > 0.5:
                        _add(a, b)
    if not pairs:
        return [], []
    midpoints = [
        (mw @ ((m.vertices[a].co + m.vertices[b].co) * 0.5))
        for (a, b) in pairs
    ]
    return pairs, midpoints


def _collect_guide_curves(ctx, obj, p, mesh=None, mw=None):
    gt = p.get('guide_type', 'CURVE')
    if gt == 'CURVE':
        cname = (p.get('guide_splines') or '').strip()
        if cname:
            curve_obj = bpy.data.objects.get(cname)
            if curve_obj and curve_obj.type == 'CURVE':
                pts = _sample_spline_points(ctx, curve_obj)
                if pts:
                    return [pts]
    elif gt in ('SHARP_EDGES', 'SEAM_EDGES'):
        flag = 'SEAM' if gt == 'SEAM_EDGES' else 'SHARP'
        lines = _sample_marked_edge_polylines(obj, flag=flag, mesh=mesh, mw=mw)
        if lines:
            return lines
    return None


class ZRemesherFactory:
    """单例队列消费者。

    submit() -> OrderedDict 队列 -> bpy.app.timers 心跳轮询 -> 后台线程执行 -> 主线程写回
    """

    _instance = None

    @classmethod
    def instance(cls):
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._queue = OrderedDict()
        self._current = None
        self._thread = None
        self._state = 'IDLE'
        self._timer = None
        self._done_count = 0
        self._run_start_time = 0.0

    # ────────────── 对外 API ──────────────

    def submit(self, obj, params, force=False):
        name = getattr(obj, 'name', None)
        if not name:
            return False
        task = RemeshTask(object_name=name, params=params, force=force)
        self._queue[name] = task
        self._start()
        return True

    def submit_task(self, task):
        """通用入队: 由调用方构造 RemeshTask(可携带 prepare_fn/writeback_fn)。"""
        if not task.object_name:
            return False
        self._queue[task.object_name] = task
        self._start()
        return True

    def is_busy(self):
        return self._state == 'RUNNING'

    def queue_length(self):
        return len(self._queue) + (1 if self._current is not None else 0)

    def progress(self):
        """返回 (百分比, 状态文本, 总任务数)。"""
        cur = self._current
        total = len(self._queue) + (1 if cur is not None else 0) + self._done_count
        if total == 0:
            return 0.0, '空闲', 0
        cur_frac = (cur.progress / 100.0) if cur is not None else 0.0
        pct = min(100.0, (self._done_count + cur_frac) / total * 100.0)
        st = ''
        if cur is not None:
            st = cur.status or f'正在处理 {cur.object_name}'
        elif self._done_count:
            st = f'已完成 {self._done_count} 个任务'
        return pct, st, total

    def cancel_all(self):
        self._queue.clear()
        if self._current is not None:
            self._current.cancelled = True
        self._done_count = 0

    def shutdown(self):
        self._queue.clear()
        if self._current is not None:
            self._current.cancelled = True
        self._stop()

    # ────────────── 心跳生命周期 ──────────────

    def _start(self):
        if self._state == 'RUNNING':
            return
        if self._timer is not None:
            return
        self._state = 'RUNNING'
        self._done_count = 0
        try:
            self._timer = bpy.app.timers.register(self._heartbeat, first_interval=0.1)
        except Exception:
            traceback.print_exc()
            self._state = 'IDLE'
            self._timer = None

    def _stop(self):
        self._state = 'IDLE'
        if self._timer is not None:
            try:
                bpy.app.timers.unregister(self._timer)
            except Exception:
                try:
                    bpy.app.timers.unregister(self._heartbeat)
                except Exception:
                    pass
            self._timer = None

    def _heartbeat(self):
        try:
            return self._pump()
        except Exception:
            traceback.print_exc()
            self._state = 'IDLE'
            self._timer = None
            return None

    def _pump(self):
        # 1. 后台线程执行中 → 轮询
        if self._thread is not None:
            if self._thread.is_alive():
                self._update_state_props()
                self._tag_redraw()
                return 0.1
            self._thread = None
            self._finalize_current()
            self._current = None
        # 2. 队列非空 → 准备并启动下一个任务
        if self._queue:
            self._consume_next()
            self._update_state_props()
            self._tag_redraw()
            return 0.1
        # 3. 空闲 → 停止心跳
        self._done_count = 0
        self._stop()
        self._update_state_props()
        self._tag_redraw()
        return None

    # ────────────── 任务消费 / 执行 / 写回 ──────────────

    def _consume_next(self):
        if not self._queue:
            return
        key, task = self._queue.popitem(last=False)
        task.state = TaskState.RUNNING
        task.start_time = time.time()
        task.status = '提取网格数据…'
        self._current = task
        try:
            if task.prepare_fn is not None:
                prep = task.prepare_fn(task)
            else:
                prep = self._prepare_task(task)
        except Exception as e:
            traceback.print_exc()
            task.state = TaskState.FAILED
            task.error = str(e)
            task.status = f'准备失败: {e}'
            self._current = None
            self._done_count += 1
            return
        if prep is None:
            task.state = TaskState.SKIPPED
            task.status = task.status or f'跳过 {task.object_name}'
            self._current = None
            self._done_count += 1
            return
        task.prep = prep
        self._run_start_time = time.time()
        self._thread = threading.Thread(target=self._worker, args=(task,), daemon=True)
        self._thread.start()

    def _prepare_task(self, task):
        """主线程: 按任务快照解析资源并提取网格。返回 prep 字典, 失败返回 None。"""
        p = task.params
        obj = bpy.data.objects.get(task.object_name)
        if obj is None or obj.type != 'MESH':
            task.status = f'跳过: 找不到物体 {task.object_name}'
            return None
        ctx = bpy.context

        # 基于原稿重拓扑: 源网格取"原版网格"(obj.data 无 .zm 后缀时即自身),
        # 而非物体当前挂载的拓扑版本。这样每次点击都从原始物体拓扑,
        # 各版本互相独立, 不会"用上一次的结果再拓扑"。
        real = get_real_data_name(obj.data.name)
        src_mesh = obj.data
        if real != obj.data.name:
            origin = bpy.data.meshes.get(real)
            if origin is not None:
                src_mesh = origin
        if not len(src_mesh.vertices):
            task.status = f'跳过: 原稿网格 {src_mesh.name} 无顶点'
            return None
        mw = obj.matrix_world

        cfg = settings.build_dll_config(p)

        vertex_weights = None
        vg_name = (p.get('density_map') or '').strip()
        if p.get('density_enable') and vg_name and vg_name in obj.vertex_groups:
            ws = _read_vertex_group_weights(obj, vg_name, mesh=src_mesh)
            if ws is not None and any(w > 0 for w in ws):
                vertex_weights = ws

        input_hard_edges = None
        source_midpoints = []
        if p.get('hard_edge_enable'):
            pairs, midpoints = _collect_hard_edges(obj, p, mesh=src_mesh, mw=mw)
            if pairs:
                input_hard_edges = pairs
                source_midpoints = midpoints

        guide_curves = None
        if p.get('guide_enable'):
            guide_curves = _collect_guide_curves(ctx, obj, p, mesh=src_mesh, mw=mw)

        input_data = _mesh_to_world_triangles(obj, ctx, mesh=src_mesh, mw=mw)

        return {
            'obj': obj,
            'src_mesh': src_mesh,
            'cfg': cfg,
            'vertex_weights': vertex_weights,
            'input_hard_edges': input_hard_edges,
            'source_midpoints': source_midpoints,
            'guide_curves': guide_curves,
            'input_data': input_data,
        }

    def _worker(self, task):
        """后台线程: 仅调用 DLL, 零 bpy 访问。"""
        try:
            prep = task.prep
            xe = _get_extract()

            def prog_cb(pct, msg):
                task.progress = max(task.progress, float(pct))
                task.status = ''

            verts, faces, hard_edges = xe.extract_mesh(
                None, settings=prep['cfg'],
                use_cache=not task.force,
                progress_callback=prog_cb,
                guide_curves=prep['guide_curves'],
                vertex_weights=prep['vertex_weights'],
                input_hard_edges=prep['input_hard_edges'],
                input_data=prep['input_data'])
            job = _RemeshJob()
            job.verts = verts
            job.faces = faces
            job.hard_edges = hard_edges
            task.job = job
            task.progress = 95.0
        except Exception as e:
            traceback.print_exc()
            job = _RemeshJob()
            job.error = str(e)
            task.job = job
            task.error = str(e)

    def _finalize_current(self):
        task = self._current
        if task is None:
            return
        task.done_time = time.time()
        if task.cancelled:
            task.state = TaskState.CANCELLED
            task.status = '已取消'
            self._done_count += 1
            return
        job = task.job
        if job is None or job.error:
            task.state = TaskState.FAILED
            task.error = (job.error if job else None) or '无结果'
            task.status = f'失败: {str(task.error)[:60]}'
            self._done_count += 1
            return
        try:
            if task.writeback_fn is not None:
                task.writeback_fn(task)
            else:
                self._writeback(task)
            task.state = TaskState.DONE
            task.progress = 100.0
            task.status = f'完成 {task.object_name}'
            self._done_count += 1
        except Exception as e:
            traceback.print_exc()
            task.state = TaskState.FAILED
            task.error = str(e)
            task.status = f'后处理失败: {e}'
            self._done_count += 1

    def _writeback(self, task):
        """主线程: 由任务结果构建新网格并回写场景。"""
        from mathutils import Vector
        p = task.params
        prep = task.prep
        job = task.job
        obj_old = prep['obj']
        verts, faces = job.verts, job.faces

        mw = obj_old.matrix_world.copy() if obj_old else None
        if mw is not None:
            mw_inv = mw.inverted()
            v = np.asarray(verts, dtype=np.float64).reshape(-1, 3)
            m3 = np.array([[mw_inv[0][0], mw_inv[0][1], mw_inv[0][2]],
                           [mw_inv[1][0], mw_inv[1][1], mw_inv[1][2]],
                           [mw_inv[2][0], mw_inv[2][1], mw_inv[2][2]]], dtype=np.float64)
            t = np.array([mw_inv[0][3], mw_inv[1][3], mw_inv[2][3]], dtype=np.float64)
            local_v = (v @ m3.T + t).astype(np.float32)
        else:
            local_v = np.asarray(verts, dtype=np.float32).reshape(-1, 3)

        real_name = get_real_data_name(obj_old.data.name)
        me = bpy.data.meshes.new(name=new_mesh_name(real_name))

        n_v = len(local_v)
        n_f = len(faces)
        me.vertices.add(n_v)
        total_l = 0
        for f in faces:
            total_l += len(f)
        me.loops.add(total_l)
        me.polygons.add(n_f)

        co_flat = np.ascontiguousarray(local_v, dtype=np.float32).ravel()
        me.vertices.foreach_set("co", co_flat)

        lv = np.empty(total_l, dtype=np.int32)
        ls = np.empty(n_f, dtype=np.int32)
        lt = np.empty(n_f, dtype=np.int32)
        base = 0
        for i, f in enumerate(faces):
            c = len(f)
            lv[base:base + c] = f
            ls[i] = base
            lt[i] = c
            base += c
        me.loops.foreach_set("vertex_index", lv)
        me.polygons.foreach_set("loop_start", ls)
        me.polygons.foreach_set("loop_total", lt)
        me.update()
        me.validate(verbose=False)

        # 复制材质(拓扑改变, 顶点组不映射丢弃)
        old_mesh = obj_old.data
        for mat in old_mesh.materials:
            me.materials.append(mat)

        # 历史元数据: 时间戳 + 参数 JSON(供将来"用该参数重算")
        me["zm_time"] = display_now()
        me["zm_params"] = json.dumps(p, ensure_ascii=False)

        hard_edges = job.hard_edges or []
        if hard_edges and p.get('hard_edge_enable'):
            key_set = set((a, b) if a < b else (b, a) for a, b in hard_edges)
            marked = 0
            for e in me.edges:
                v0, v1 = e.vertices[0], e.vertices[1]
                key = (v0, v1) if v0 < v1 else (v1, v0)
                if key in key_set:
                    e.use_edge_sharp = True
                    marked += 1
            print(f"[ZMRemesh] applied {marked}/{len(hard_edges)} hard edges as sharp", flush=True)

        user_pairs = prep['input_hard_edges']
        if user_pairs and p.get('hard_edge_enable') and p.get('hard_edge_type') in ('SHARP', 'VGROUP'):
            if mw is not None:
                orig_coords = [(mw_inv @ Vector(c)) for c in prep['source_midpoints']]
            else:
                orig_coords = list(prep['source_midpoints'])
            if orig_coords:
                mp_tree = kdtree.KDTree(len(me.edges))
                for ei, e in enumerate(me.edges):
                    a = me.vertices[e.vertices[0]].co
                    b = me.vertices[e.vertices[1]].co
                    mp = ((a.x + b.x) * 0.5, (a.y + b.y) * 0.5, (a.z + b.z) * 0.5)
                    mp_tree.insert(mp, ei)
                mp_tree.balance()
                n_mapped = 0
                for mid in orig_coords:
                    _, ei, _ = mp_tree.find(mid)
                    if ei is not None and not me.edges[ei].use_edge_sharp:
                        me.edges[ei].use_edge_sharp = True
                        n_mapped += 1
                print(f"[ZMRemesh] post-mapped {n_mapped}/{len(orig_coords)} user hard edges to output", flush=True)

        # 同一物体换网格数据(非破坏历史: 旧网格留在 bpy.data 作为历史, 原版永久)
        if obj_old.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass
        obj_old.data = me
        bpy.context.view_layer.objects.active = obj_old
        obj_old.select_set(True)

        side = p.get('sym_direction', 'NEGATIVE')
        sym_dirs = []
        if p.get('symmetry_x'):
            sym_dirs.append(f'{side}_X')
        if p.get('symmetry_y'):
            sym_dirs.append(f'{side}_Y')
        if p.get('symmetry_z'):
            sym_dirs.append(f'{side}_Z')
        if sym_dirs:
            vs = obj_old.data.vertices
            if len(vs):
                xs = [v.co.x for v in vs]
                ys = [v.co.y for v in vs]
                zs = [v.co.z for v in vs]
                diag = ((max(xs) - min(xs)) ** 2 + (max(ys) - min(ys)) ** 2 + (max(zs) - min(zs)) ** 2) ** 0.5
            else:
                diag = 1.0
            thr = max(diag * 1e-3, 1e-4)
            bpy.ops.object.mode_set(mode='EDIT')
            for d in sym_dirs:
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.symmetrize(direction=d, threshold=thr)
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.remove_doubles(threshold=thr)
            try:
                bpy.ops.mesh.normals_make_consistent(inside=False)
            except Exception:
                pass
            bpy.ops.object.mode_set(mode='OBJECT')

        # 历史上限: 5 拓扑 + 原版永久
        enforce_cap(real_name, obj_old)

        try:
            bpy.ops.ed.undo_push(message="ZRemesher Remesh")
        except Exception:
            pass

    # ────────────── UI 状态同步 ──────────────

    def _update_state_props(self):
        try:
            wm = bpy.context.window_manager
        except Exception:
            return
        if not hasattr(wm, 'zremesh_factory'):
            return
        st = wm.zremesh_factory
        pct, status, total = self.progress()
        st.progress = pct
        st.status = status
        st.running = self.is_busy()
        st.queue_len = total

    def _tag_redraw(self):
        try:
            screen = bpy.context.screen
        except Exception:
            return
        if screen is None:
            return
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
