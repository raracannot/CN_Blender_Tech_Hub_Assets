
# 运算核心：bin/xremeshlib2.dll（源自 C4D 的 \resource\modules\c4d_objects\libs\win64\）
#
# ── 三个 DLL 版本说明（2026.2 版）──────────────────────────────────────
# xremeshlib2.dll  ZRemesher 重拓扑核心（Exoside QuadRemesher 同源）
#   · 内部导出名必须与文件名一致（改名为其它会触发模块名校验失败 → 空输出）
#   · PE 编译时间 2022-09-07，代码段 .text 经确认与旧版逐字节一致
#   · 2026.2 版带 2026-04-08 DigiCert 代码签名（旧版证书 2022-2023）
#   · 构建树：c:\dev\mxexternallibs\suitesparse-5.6.0（Maxon MXE）
#   · 授权：需 QRLib_start() 一次性初始化；运行中切勿调用 QRLib_end()
#     （QRLib_end 会销毁全局应用对象，导致后续 doQuadRemeshing 空输出）
#
# tbb.dll          Intel Threading Building Blocks 并行库
#   · PE 编译时间 2020-09-15，导出 243 个 tbb::* 符号
#   · 2026.2 版（236 KB）与旧版（445 KB）为不同构建，需与 xremeshlib 成套使用
#   · 提供多线程并行，但实测 ZRemesher 瓶颈为单线程串行阶段，线程数无加速收益
#
# ChSolver.dll     SuiteSparse CHOLMOD 稀疏 Cholesky 分解求解器
#   · CHOLMOD 6.5.0（PDB: CholMod-6.5.0.pdb），源码包 suitesparse-5.6.0
#   · PE 编译时间 2022-09-07（与 xremeshlib 同批构建）
#   · 导出 10 个 cholmod_* 函数（start/analyze/factorize/solve/finish）
#   · 重拓扑内部求解依赖；自身无独立配置项，由 xremeshlib2.dll 运行时调用
# ─────────────────────────────────────────────────────────────────────
# 建议：三个 DLL 必须成套替换，勿混用不同版本的 tbb/ChSolver。
#
# ── v2.0.3 队列式重构 ────────────────────────────────────────────────
# 计算编排已从 Modal 操作符迁至 factory.ZRemesherFactory（单例队列消费者）：
#   submit() -> OrderedDict 队列(物体名去重) -> bpy.app.timers 心跳
#              -> 后台线程跑 DLL -> 主线程写回
# 操作符降级为入队入口。
#
# ── 模块结构 ─────────────────────────────────────────────────────────
# __init__.py        纯注册壳（bl_info + register/unregister + 生命周期）
# panel.py           专门 N 面板：面板 / 面板操作符 / 参数容器 / 历史 UI
# zm_modifier.py     专门修改器：非破坏"几何节点修改器 + 隐藏缓存物体"路径
# factory.py         队列引擎 + 数据准备 + 写回（含版本化记账）
# settings.py        参数 schema 单一来源
# xremesh_extract.py DLL 计算核（零 bpy 调用）
#
# ── ZRemesher 修改器(非破坏) ────────────────────────────────────────
# zm_modifier.py 基于 0820 思路实现"几何节点修改器 + 隐藏缓存物体":
#   OBJECT_MT_modifier_add 添加 → 缓存物体(.ZM_REMESH_*_CACHE)持有结果
#   → 参数修改自动重算(防抖) / 手动刷新 / 实时更新开关(depsgraph)。
#   源网格保留, 可与其他修改器堆叠。

bl_info = {
    'name': 'ZRemesher',
    'description': '最好最快的重拓扑工具，移植自 Maxon-C4D 原生Zremesher',
    'author': 'FQ Maxon',
    'version': (2, 0, 4),
    'blender': (5, 0, 0),
    'location': '3DView->Panel',
}

import bpy

from .factory import ZRemesherFactory
from . import panel
from . import zm_modifier


def _load_post(dummy):
    ZRemesherFactory.instance().cancel_all()
    ZRemesherFactory.instance()._stop()


def register():
    panel.register()
    zm_modifier.register()
    if _load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_load_post)


def unregister():
    if _load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_load_post)
    ZRemesherFactory.instance().shutdown()
    zm_modifier.unregister()
    panel.unregister()


if __name__ == "__main__":
    register()
