# -*- coding: utf-8 -*-
# ZRemesher 设置 schema 单一来源。
#
# 所有重拓扑参数(共 24 个)只在 __INIT__ 处统一定义一次, 三个容器
# (Scene.zremesh_props / MESH_OT_zremesh / Object.zremesh_mod) 的属性、
# 参数收集(collect_params)、DLL 配置映射(build_dll_config)均由此生成。
# 新增/调整参数时仅需修改 _PROPS 与 build_dll_config。

import bpy

# ── 参数顺序(即 PARAM_KEYS 顺序, 也是参数 dict 的键序) ────────────────
_PARAMS = [
    'polygon_target_mode', 'polygon_count', 'edge_length', 'target_percentage',
    'polygon_scale', 'density_enable', 'density_map', 'density_scale',
    'adaptive', 'adaptiveness', 'hard_edge_enable', 'hard_edge_type',
    'hard_edge_vgroup', 'hard_edge_angle', 'freeze_borders', 'preprocess_weld',
    'denoise_strength', 'symmetry_x', 'symmetry_y', 'symmetry_z', 'sym_direction',
    'guide_enable', 'guide_type', 'guide_splines',
]

# ── 枚举项 ─────────────────────────────────────────────────────────────
_TARGET_MODE_ITEMS = [
    ('COUNT', '多边形数量', '参考指定面数量对网格面进行重拓扑\n请注意，这是一个[非绝对]的目标值，多边形数量会接近这个数值', 1),
    ('EDGE', '多边形长度', '参考指定边长度对网格面进行重拓扑\n注意，边长越短，网格越密，请确保参数不要超出网格尺寸', 2),
    ('PERCENT', '百分比面数', '参考输入网格面数量对网格面进行重拓扑\n100%的表示生成的多边形数量与原始对象几乎相同。数值越小，生成的多边形数量就越少', 3),
]

_HARDEDGE_TYPE_ITEMS = [
    ('AUTO', '角度', '自动识别角度转折', 1),
    ('SHARP', '锐边', '仅使用标记为锐边的边', 2),
    ('VGROUP', '顶点组', '仅使用指定顶点组标记的边', 3),
]

_GUIDE_TYPE_ITEMS = [
    ('CURVE', '曲线物体', '使用样条工具来定义边缘流动的方向', 1),
    ('SHARP_EDGES', '锐边', '使用锐边来定义边缘流动的方向', 2),
    ('SEAM_EDGES', '缝合边', '使用缝合边来定义边缘流动的方向', 3),
]

# ── 属性规格表: (name, bpy.props 工厂, kwargs) ─────────────────────────
_PROPS = [
    ('polygon_target_mode', bpy.props.EnumProperty,
     dict(name="Polygon 目标模式", items=_TARGET_MODE_ITEMS, default='COUNT',
          description="目标模式:多边形数量 / 网格密度 / 输入面数百分比")),
    ('polygon_count', bpy.props.IntProperty,
     dict(name="多边形数量", default=5000, min=100, soft_max=50000,
          description="目标多边形数量(当模式为“多边形数量”时生效)")),
    ('edge_length', bpy.props.FloatProperty,
     dict(name="目标边长", default=0.1, min=0.001, max=100.0,
          description="目标边长(当模式为“网格密度”时生效)")),
    ('target_percentage', bpy.props.FloatProperty,
     dict(name="目标面数百分比", default=10.0, min=0.1, max=200.0,
          description="目标面数 = 输入面数的百分比(当模式为“输入面数百分比”时生效)")),
    ('polygon_scale', bpy.props.FloatProperty,
     dict(name="面数倍率", default=1.0, min=0.01, max=10.0,
          description="面数倍率——应用于目标数量的倍数")),
    ('density_enable', bpy.props.BoolProperty,
     dict(name="密度图", default=False,
          description="启用密度图控制。关闭后忽略密度图顶点组,\n按均匀密度重拓扑")),
    ('density_map', bpy.props.StringProperty,
     dict(name="密度图",
          description="顶点组,其权重将偏置 ZRemesher 原生的 "
                     "顶点颜色密度管线")),
    ('density_scale', bpy.props.FloatProperty,
     dict(name="密度缩放", default=1.0, min=0.0, soft_max=3.0,
          description="密度图局部集中的强度。\n0 = 关闭(忽略密度图)。1 = 默认(约 2.5×\n绘制区域的多边形)。2-3 = 更强。更高的值\n会增大输入曲率的感应幅度,\n驱动 ZRemesher 的自适应模式在绘制区域\n集中更多的多边形")),
    ('adaptive', bpy.props.BoolProperty,
     dict(name="自适应", default=True, description="启用自适应细分")),
    ('adaptiveness', bpy.props.FloatProperty,
     dict(name="自适应强度", default=0.5, min=0.0, max=1.0,
          description="自适应强度 (0=关闭, 1=最大)\n参数越大，网格的均匀性会相应降低，"
                     "分配更多四边面给局部细节丰富区域\n\n在需提高细节丰富的区域的网格密度时建议设置为1\n"
                     "在需要输出方形均匀拓扑时建议设置为0")),
    ('hard_edge_enable', bpy.props.BoolProperty,
     dict(name="启用硬边", default=True, description="是否开启硬边保护功能")),
    ('hard_edge_type', bpy.props.EnumProperty,
     dict(name="硬边类型", items=_HARDEDGE_TYPE_ITEMS, default='AUTO',
          description="硬边处理模式: 自动检测角度 或 使用手动标记的边")),
    ('hard_edge_vgroup', bpy.props.StringProperty,
     dict(name="硬边顶点组",
          description="顶点组中带权重的顶点用于标记硬边。\n两端点都在该组内(权重 > 0.5)的边"
                     "将作为硬边输入给 ZRemesher")),
    ('hard_edge_angle', bpy.props.FloatProperty,
     dict(name="硬边角度阈值", default=30.0, min=0.0, max=180.0,
          description="自动硬边检测的角度阈值(当模式为“自动”时生效)")),
    ('freeze_borders', bpy.props.BoolProperty,
     dict(name="冻结边界", default=False,
          description="冻结输入边界:边界点保持不动。开启后大幅提速,\n并保持边界轮廓,"
                     "但边界处的四边形会被固定")),
    ('preprocess_weld', bpy.props.BoolProperty,
     dict(name="预处理焊接", default=False,
          description="重拓扑前焊接输入网格的重复点,改善质量")),
    ('denoise_strength', bpy.props.FloatProperty,
     dict(name="降噪强度", default=0.0, min=0.0, max=1.0,
          description="输出网格的降噪平滑强度 (0=关闭, 1=最大)")),
    ('symmetry_x', bpy.props.BoolProperty,
     dict(name="对称 X", default=False, description="沿 X 轴对称")),
    ('symmetry_y', bpy.props.BoolProperty,
     dict(name="对称 Y", default=False, description="沿 Y 轴对称")),
    ('symmetry_z', bpy.props.BoolProperty,
     dict(name="对称 Z", default=False, description="沿 Z 轴对称")),
    ('sym_direction', bpy.props.EnumProperty,
     dict(name="保留方向",
          items=[('NEGATIVE', '负半空间 (-)', '保留 -X/-Y/-Z,镜像到 +', 0),
                 ('POSITIVE', '正半空间 (+)', '保留 +X/+Y/+Z,镜像到 -', 1)],
          default='NEGATIVE',
          description="对称化沿各轴切开后保留哪一侧")),
    ('guide_enable', bpy.props.BoolProperty,
     dict(name="启用流线", default=False,
          description="是否使用曲线或指定网格边作为引导流线")),
    ('guide_type', bpy.props.EnumProperty,
     dict(name="流线来源", items=_GUIDE_TYPE_ITEMS, default='CURVE',
          description="流线数据来源: 曲线物体 / 锐边 / 缝合边")),
    ('guide_splines', bpy.props.PointerProperty,
     dict(name="流线图", type=bpy.types.Object,
          poll=lambda self, obj: obj.type == 'CURVE',
          description="引导曲线(从场景中选取;仅限曲线类型)\n曲线附近的输出四边形会被细分"
                     "半径随模型尺寸自动缩放")),
]

PARAM_KEYS = tuple(_PARAMS)

# 参数 dict 的默认值(用于 build_dll_config 兜底, 以及 JSON 回放)。Guide/
# density 类以字符串表示; 其余取属性规格里的 default。
DEFAULTS = {}
for _name, _fac, _kw in _PROPS:
    _d = _kw.get('default')
    DEFAULTS[_name] = _d if _d is not None else ''


def make_props(update=None):
    """生成 bpy.props 字典: {name: prop 实例}。
    传 update 回调时(修改器模式)赋给所有参数属性。"""
    out = {}
    for name, factory, kw in _PROPS:
        kw = dict(kw)
        if update is not None:
            kw['update'] = update
        out[name] = factory(**kw)
    return out


def collect_params(*sources):
    """按 PARAM_KEYS 从多个来源(先者优先)收集参数 dict。
    guide_splines 统一转为物体名字符串(或空串)。
    若所有来源都缺少某参数, 用 DEFAULTS 兜底。"""
    _MISSING = object()
    params = {}
    for k in PARAM_KEYS:
        val = _MISSING
        for s in sources:
            v = getattr(s, k, _MISSING)
            if v is not _MISSING:
                val = v
                break
        if val is _MISSING:
            val = DEFAULTS.get(k)
        if k == 'guide_splines':
            params[k] = val.name if (val is not None and hasattr(val, 'name')) else (val or '')
        else:
            params[k] = val
    return params


def build_dll_config(p):
    """参数 dict → DLL 配置 dict(供 xremesh_extract / extract_mesh 使用)。"""
    get = lambda k: p.get(k, DEFAULTS[k])

    he_mode_int = 0
    if get('hard_edge_enable'):
        he_mode_int = 1 if get('hard_edge_type') == 'AUTO' else 2

    return {
        'target_quads':        int(get('polygon_count')),
        'edge_length':         float(get('edge_length')),
        'target_percentage':   float(get('target_percentage')),
        'polygon_scale':       float(get('polygon_scale')),
        'polygon_target_mode': {'AUTO': 0, 'COUNT': 1, 'EDGE': 2, 'PERCENT': 3}.get(get('polygon_target_mode'), 1),
        'adaptive':            bool(get('adaptive')),
        'adaptiveness':        float(get('adaptiveness')),
        'hard_edge_mode':      he_mode_int,
        'hard_edge_angle':     float(get('hard_edge_angle')),
        'freeze_borders':      bool(get('freeze_borders')),
        'preprocess_weld':     bool(get('preprocess_weld')),
        'denoise_strength':    float(get('denoise_strength')),
        'density_scale':       float(get('density_scale')),
        'symmetry_x':          bool(get('symmetry_x')),
        'symmetry_y':          bool(get('symmetry_y')),
        'symmetry_z':          bool(get('symmetry_z')),
    }
