
# 运算核心：bin/xremeshlib2.dll（源自 C4D 的 \resource\modules\c4d_objects\libs\win64\）
#
# ── 三个 DLL 版本说明（2026.2 版）──────────────────────────────────────
# xremeshlib2.dll  ZRemesher 重拓扑核心（Exoside QuadRemesher 同源）
#   · 内部导出名必须与文件名一致（改名为其它会触发模块名校验失败 → 空输出）
#   · PE 编译时间 2022-09-07，代码段 .text 经确认与旧版逐字节一致
#   · 2026.2 版带 2026-04-08 DigiCert 代码签名（旧版证书 2022-2023）
#   · 构建树：c:\dev\mxexternallibs\suitesparse-5.6.0（Maxon MXE）
#   · 授权：需 QRLib_start() 一次性初始化；运行中切勿调用 QRLib_end()
#     （QRLib_end 会销毁全局应用对象，导致后续 doQuadRemeshing 空输出）
#
# tbb.dll          Intel Threading Building Blocks 并行库
#   · PE 编译时间 2020-09-15，导出 243 个 tbb::* 符号
#   · 2026.2 版（236 KB）与旧版（445 KB）为不同构建，需与 xremeshlib 成套使用
#   · 提供多线程并行，但实测 ZRemesher 瓶颈为单线程串行阶段，线程数无加速收益
#
# ChSolver.dll     SuiteSparse CHOLMOD 稀疏 Cholesky 分解求解器
#   · CHOLMOD 6.5.0（PDB: CholMod-6.5.0.pdb），源码包 suitesparse-5.6.0
#   · PE 编译时间 2022-09-07（与 xremeshlib 同批构建）
#   · 导出 10 个 cholmod_* 函数（start/analyze/factorize/solve/finish）
#   · 重拓扑内部求解依赖；自身无独立配置项，由 xremeshlib2.dll 运行时调用
# ─────────────────────────────────────────────────────────────────────
# 建议：三个 DLL 必须成套替换，勿混用不同版本的 tbb/ChSolver。

bl_info = {
    'name': 'ZRemesher',
    'description': '最好最快的重拓扑工具，移植自 Maxon-C4D 原生Zremesher',
    'author': 'FQ Maxon',
    'version': (2, 0, 2),
    'blender': (5, 0, 0),
    'location': '3DView->Panel',
}

import os
import bpy
import sys
import time
import threading
import traceback
import numpy as np
from mathutils import kdtree

from bpy.props import (IntProperty, BoolProperty, FloatProperty,EnumProperty, StringProperty, PointerProperty)

_ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
_BUNDLED_BIN = os.path.join(_ADDON_DIR, "bin")

IS_RUNNING = False
def get_is_running():
    return IS_RUNNING
def set_is_running(set = False): 
    global IS_RUNNING
    IS_RUNNING = set
    return IS_RUNNING

def _load_remesh_lib():
    global xremesh_extract
    try:
        from . import xremesh_extract
        import importlib
        importlib.reload(xremesh_extract)
        return xremesh_extract
    except ImportError as e:
        raise RuntimeError(f"失败 to import xremesh_extract: {e}")

def _read_vertex_group_weights(obj, vg_name):

    vg = obj.vertex_groups.get(vg_name)
    if not vg:
        return None
    n = len(obj.data.vertices)
    out = [0.0] * n
    for i in range(n):
        try: out[i] = vg.weight(i)
        except RuntimeError: pass
    return out

def _sample_spline_points(ctx, curve_obj, step=0.02):
    try:
        depsgraph = ctx.evaluated_depsgraph_get()
        eo = curve_obj.evaluated_get(depsgraph)
        tmp = eo.to_mesh()
    except Exception:
        return []
    mw = curve_obj.matrix_world
    verts = [mw @ v.co.copy() for v in tmp.vertices]
    edges = [tuple(e.vertices) for e in tmp.edges]
    try: eo.to_mesh_clear()
    except Exception: pass
    if not edges:
        return verts
    pts = []
    for a, b in edges:
        va, vb = verts[a], verts[b]
        seg_len = (vb - va).length
        n_sub = max(1, int(seg_len / step))
        for k in range(n_sub):
            t = k / n_sub
            pts.append(va.lerp(vb, t))

    pts.append(verts[edges[-1][1]])
    return pts


def _sample_marked_edge_polylines(obj, flag='SHARP', step=0.02):
    """从网格的标记边构建多条流线:把共享顶点的标记边链成折线,
    每条折线沿边按 step 插值成细密点链。返回 [(世界坐标点列表)...]。
    flag: 'SHARP' 用 use_edge_sharp 锐边,'SEAM' 用 use_seam 缝合边。
    无标记边或无法成链时返回 []。"""
    me = obj.data
    n_v = len(me.vertices)
    if not n_v or not len(me.edges):
        return []
    co = np.empty(n_v * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    mw = obj.matrix_world
    m3 = np.array([[mw[0][0], mw[0][1], mw[0][2]],
                   [mw[1][0], mw[1][1], mw[1][2]],
                   [mw[2][0], mw[2][1], mw[2][2]]], dtype=np.float64)
    t = np.array([mw[0][3], mw[1][3], mw[2][3]], dtype=np.float64)
    co_w = (co.reshape(-1, 3).astype(np.float64) @ m3.T + t).astype(np.float32)

    marked = []
    for e in me.edges:
        if (flag == 'SEAM' and e.use_seam) or (flag != 'SEAM' and e.use_edge_sharp):
            marked.append((e.vertices[0], e.vertices[1]))
    if not marked:
        return []

    # 构建 顶点->边 邻接表,用于链成折线
    adj = {}
    edge_set = set()
    for a, b in marked:
        edge_set.add((a, b) if a < b else (b, a))
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    used = set()
    polylines = []
    for a, b in marked:
        key = (a, b) if a < b else (b, a)
        if key in used:
            continue
        # 从 (a,b) 开始向两端扩展成一条折线
        line = [a, b]
        used.add(key)
        # 向前延伸
        prev, cur = a, b
        while True:
            nxt = [x for x in adj.get(cur, []) if x != prev and (min(cur, x), max(cur, x)) in edge_set]
            if not nxt:
                break
            nxt = nxt[0]
            ekey = (min(cur, nxt), max(cur, nxt))
            if ekey in used:
                break
            used.add(ekey)
            line.append(nxt)
            prev, cur = cur, nxt
        # 向后延伸(从起点反向)
        prev, cur = b, a
        while True:
            nxt = [x for x in adj.get(cur, []) if x != prev and (min(cur, x), max(cur, x)) in edge_set]
            if not nxt:
                break
            nxt = nxt[0]
            ekey = (min(cur, nxt), max(cur, nxt))
            if ekey in used:
                break
            used.add(ekey)
            line.insert(0, nxt)
            prev, cur = cur, nxt

        # 沿折线各段插值成细密点链
        pts = []
        for i in range(len(line) - 1):
            va = co_w[line[i]]
            vb = co_w[line[i + 1]]
            seg_len = float(np.linalg.norm(vb - va))
            n_sub = max(1, int(seg_len / step))
            if n_sub > 1:
                ts = np.linspace(0.0, 1.0, n_sub, endpoint=False, dtype=np.float32)
                seg_pts = va[None, :] + (vb - va)[None, :] * ts[:, None]
                pts.extend((float(p[0]), float(p[1]), float(p[2])) for p in seg_pts)
            else:
                pts.append((float(va[0]), float(va[1]), float(va[2])))
        last = co_w[line[-1]]
        pts.append((float(last[0]), float(last[1]), float(last[2])))
        if len(pts) >= 2:
            polylines.append(pts)

    return polylines


def _weights_from_spline_proximity(src_world_coords, curve_pts, radius, strength=1.0):
    if not curve_pts or radius <= 0 or not src_world_coords:
        return [0.0] * len(src_world_coords)
    kd = kdtree.KDTree(len(curve_pts))
    for i, c in enumerate(curve_pts):
        kd.insert(c, i)
    kd.balance()
    inv_r = 1.0 / radius
    out = [0.0] * len(src_world_coords)
    for i, wc in enumerate(src_world_coords):
        _, _, d = kd.find(wc)
        if d is not None and d < radius:
            out[i] = (1.0 - d * inv_r) * strength
    return out

def _mesh_to_world_triangles(obj, ctx):
    """通过 foreach_get + numpy 将活动网格提取为世界坐标顶点 + 三角形索引。
    经 depsgraph 求值以应用修改器(等效于旧 OBJ 导出的 apply_modifiers=True),
    使用 Blender 原生 loop_triangles 三角化(与 OBJ 导出一致,正确处理 n-gon)。
    返回 (verts_np, tris_np):verts 为 float32 (N,3) 世界坐标,
    tris 为 int32 (M,3)。"""
    depsgraph = ctx.evaluated_depsgraph_get()
    eo = obj.evaluated_get(depsgraph)
    tmp = eo.to_mesh()
    try:
        n_v = len(tmp.vertices)
        co = np.empty(n_v * 3, dtype=np.float32)
        tmp.vertices.foreach_get("co", co)
        # Blender 原生三角化:与 wm.obj_export 的 triangulated 输出一致,
        # 对 n-gon 从几何合适角扇出(而非固定从 loop[0] 扇出)。
        tmp.calc_loop_triangles()
        n_t = len(tmp.loop_triangles)
        tris = np.empty(n_t * 3, dtype=np.int32)
        tmp.loop_triangles.foreach_get("vertices", tris)
        tris = tris.reshape(-1, 3)
    finally:
        eo.to_mesh_clear()

    # 本地 -> 世界:co_w = co @ m3.T + t (行向量)
    mw = obj.matrix_world
    m3 = np.array([[mw[0][0], mw[0][1], mw[0][2]],
                   [mw[1][0], mw[1][1], mw[1][2]],
                   [mw[2][0], mw[2][1], mw[2][2]]], dtype=np.float64)
    t = np.array([mw[0][3], mw[1][3], mw[2][3]], dtype=np.float64)
    co3 = co.reshape(-1, 3).astype(np.float64)
    verts_w = (co3 @ m3.T + t).astype(np.float32)
    return verts_w, tris

_TARGET_MODE_ITEMS = [
    ('COUNT', '多边形数量', '参考指定面数量对网格面进行重拓扑\n请注意，这是一个[非绝对]的目标值，多边形数量会接近这个数值', 1),
    ('EDGE', '多边形长度', '参考指定边长度对网格面进行重拓扑\n注意，边长越短，网格越密，请确保参数不要超出网格尺寸', 2),
    ('PERCENT', '百分比面数', '参考输入网格面数量对网格面进行重拓扑\n100%的表示生成的多边形数量与原始对象几乎相同。数值越小，生成的多边形数量就越少', 3),
]

_HARDEDGE_TYPE_ITEMS = [
    ('AUTO', '角度', '自动识别角度转折', 1),
    ('SHARP', '锐边', '仅使用标记为锐边的边', 2),
    ('VGROUP', '顶点组', '仅使用指定顶点组标记的边', 3),
]

_GUIDE_TYPE_ITEMS = [
    ('CURVE', '曲线物体', '使用样条工具来定义边缘流动的方向', 1),
    ('SHARP_EDGES', '锐边', '使用锐边来定义边缘流动的方向', 2),
    ('SEAM_EDGES', '缝合边', '使用缝合边来定义边缘流动的方向', 3),
]


class ZMRemeshSettings(bpy.types.PropertyGroup):

    polygon_target_mode: EnumProperty(
        name="Polygon 目标模式", items=_TARGET_MODE_ITEMS, default='COUNT',
        description="目标模式:多边形数量 / 网格密度 / 输入面数百分比")
    polygon_count: IntProperty(
        name="多边形数量", default=5000, min=100, soft_max=50000,
        description="目标多边形数量(当模式为“多边形数量”时生效)")
    edge_length: FloatProperty(
        name="目标边长", default=0.1, min=0.001, max=100.0,
        description="目标边长(当模式为“网格密度”时生效)")
    target_percentage: FloatProperty(
        name="目标面数百分比", default=10.0, min=0.1, max=200.0,
        description="目标面数 = 输入面数的百分比(当模式为“输入面数百分比”时生效)")
    polygon_scale: FloatProperty(
        name="面数倍率", default=1.0, min=0.01, max=10.0,
        description="面数倍率——应用于目标数量的倍数")
    density_enable: BoolProperty(
        name="密度图", default=False,
        description="启用密度图控制。关闭后忽略密度图顶点组,\n按均匀密度重拓扑")
    density_map: StringProperty(
        name="密度图",
        description="顶点组,其权重将偏置 ZRemesher 原生的 "
                    "顶点颜色密度管线")
    density_scale: FloatProperty(
        name="密度缩放", default=1.0, min=0.0, soft_max=3.0,
        description="密度图局部集中的强度。\n0 = 关闭(忽略密度图)。1 = 默认(约 2.5×\n绘制区域的多边形)。2-3 = 更强。更高的值\n会增大输入曲率的感应幅度,\n驱动 ZRemesher 的自适应模式在绘制区域\n集中更多的多边形")
    adaptive: BoolProperty(
        name="自适应", default=True,
        description="启用自适应细分")
    adaptiveness: FloatProperty(
        name="自适应强度", default=0.5, min=0.0, max=1.0,
        description="自适应强度 (0=关闭, 1=最大)\n参数越大，网格的均匀性会相应降低，分配更多四边面给局部细节丰富区域\n\n在需提高细节丰富的区域的网格密度时建议设置为1\n在需要输出方形均匀拓扑时建议设置为0")
    hard_edge_enable: BoolProperty(
        name="启用硬边", default=True,
        description="是否开启硬边保护功能")
    hard_edge_type: EnumProperty(
        name="硬边类型", items=_HARDEDGE_TYPE_ITEMS, default='AUTO',
        description="硬边处理模式: 自动检测角度 或 使用手动标记的边")
    hard_edge_vgroup: StringProperty(
        name="硬边顶点组",
        description="顶点组中带权重的顶点用于标记硬边。\n两端点都在该组内(权重 > 0.5)的边\n将作为硬边输入给 ZRemesher")
    hard_edge_angle: FloatProperty(
        name="硬边角度阈值", default=30.0, min=0.0, max=180.0,
        description="自动硬边检测的角度阈值(当模式为“自动”时生效)")
    freeze_borders: BoolProperty(
        name="冻结边界", default=False,
        description="冻结输入边界:边界点保持不动。开启后大幅提速,\n并保持边界轮廓,但边界处的四边形会被固定")
    preprocess_weld: BoolProperty(
        name="预处理焊接", default=False,
        description="重拓扑前焊接输入网格的重复点,改善质量")
    denoise_strength: FloatProperty(
        name="降噪强度", default=0.0, min=0.0, max=1.0,
        description="输出网格的降噪平滑强度 (0=关闭, 1=最大)")
    replace_original: BoolProperty(
        name="替换原始网格", default=True,
        description="重拓扑完成后是否删除原始网格。\n关闭时保留原始网格,便于对照与重新调整参数")
    symmetry_x: BoolProperty(name="对称 X", default=False,description="沿 X 轴对称")
    symmetry_y: BoolProperty(name="对称 Y", default=False,description="沿 Y 轴对称")
    symmetry_z: BoolProperty(name="对称 Z", default=False,description="沿 Z 轴对称")
    sym_direction: EnumProperty(
        name="保留方向",
        items=[('NEGATIVE', '负半空间 (-)', '保留 -X/-Y/-Z,镜像到 +', 0),
               ('POSITIVE', '正半空间 (+)', '保留 +X/+Y/+Z,镜像到 -', 1)],
        default='NEGATIVE',
        description="对称化沿各轴切开后保留哪一侧")

    guide_enable: BoolProperty(
        name="启用流线", default=False,
        description="是否使用曲线或指定网格边作为引导流线")
    guide_type: EnumProperty(
        name="流线来源", items=_GUIDE_TYPE_ITEMS, default='CURVE',
        description="流线数据来源: 曲线物体 / 锐边 / 缝合边")

    guide_splines: PointerProperty(
        name="流线图",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CURVE',
        description="引导曲线(从场景中选取;仅限曲线类型)\n曲线附近的输出四边形会被细分\n半径随模型尺寸自动缩放")

    progress:   FloatProperty(name="进度", default=0.0, min=0.0, max=100.0,subtype='PERCENTAGE')
    status:     StringProperty(name="状态", default="")

class _RemeshJob:
    def __init__(self):
        self.progress = 0.0
        self.status   = ''
        self.error    = None
        self.done     = False
        self.verts    = None
        self.faces    = None
        self.hard_edges = []
        self._dll_pct = 0.0

class MESH_OT_zremesh(bpy.types.Operator):
    bl_idname = "mesh.zremesh_remesh"
    bl_label = "ZRemesher"
    bl_description = "采用ZBrush的ZRemesher算法对网格进行重拓扑\n是在处理有机形状时，该算法能够自动识别边缘循环，并能够以相当高的质量展示这些形状"
    
    bl_options = {"INTERNAL"}

    polygon_target_mode:   EnumProperty(items=_TARGET_MODE_ITEMS, default='COUNT')
    polygon_count:         IntProperty(default=5000, min=100, soft_max=50000)
    edge_length:           FloatProperty(default=0.1, min=0.001, max=100.0)
    target_percentage:     FloatProperty(default=10.0, min=0.1, max=200.0)
    polygon_scale:         FloatProperty(default=1.0, min=0.01, max=10.0)
    density_enable:        BoolProperty(default=True)
    density_scale:         FloatProperty(default=1.0, min=0.0, soft_max=3.0)
    adaptive:              BoolProperty(default=True)
    adaptiveness:          FloatProperty(default=0.5, min=0.0, max=1.0)
    hard_edge_enable:  BoolProperty(default=False)
    hard_edge_type:    EnumProperty(items=_HARDEDGE_TYPE_ITEMS, default='AUTO')
    hard_edge_vgroup:      StringProperty(default='')
    hard_edge_angle:       FloatProperty(default=30.0, min=0.0, max=180.0)
    freeze_borders:        BoolProperty(default=False)
    preprocess_weld:       BoolProperty(default=False)
    denoise_strength:      FloatProperty(default=0.0, min=0.0, max=1.0)
    replace_original:      BoolProperty(default=True)
    symmetry_x:            BoolProperty(default=False)
    symmetry_y:            BoolProperty(default=False)
    symmetry_z:            BoolProperty(default=False)
    sym_direction:         EnumProperty(
        items=[('NEGATIVE', '-', '', 0), ('POSITIVE', '+', '', 1)],
        default='NEGATIVE')
    guide_enable:      BoolProperty(default=False)
    guide_type:        EnumProperty(items=_GUIDE_TYPE_ITEMS, default='CURVE')
    use_scene_props:       BoolProperty(default=False, options={'HIDDEN'})
    blocking:              BoolProperty(default=False, options={'HIDDEN'})

    _SETTINGS_KEYS = ('polygon_target_mode','polygon_count','edge_length',
                   'target_percentage','polygon_scale','density_enable',
                   'density_scale',
                   'adaptive','adaptiveness',
                   'hard_edge_enable','hard_edge_type','hard_edge_vgroup','hard_edge_angle',
                   'freeze_borders','preprocess_weld','denoise_strength','replace_original',
                   'symmetry_x','symmetry_y','symmetry_z',
                   'sym_direction','guide_enable','guide_type')

    _timer    = None
    _thread   = None
    _state    = None
    _source_obj_name = ''
    _mesh_input = None

    @classmethod
    def poll(cls, ctx):
        if getattr(ctx.scene, 'zremesh_props', None) and get_is_running():
            return False
        return ctx.active_object and ctx.active_object.type == "MESH"

    def _sync_settings_from_scene(self, ctx):
        if self.use_scene_props:
            p = ctx.scene.zremesh_props
            for k in self._SETTINGS_KEYS:
                setattr(self, k, getattr(p, k))
            self.use_scene_props = False

    def _build_dll_config(self):
        # 计算硬边模式整数值
        he_mode_int = 0
        if self.hard_edge_enable:
            he_mode_int = 1 if self.hard_edge_type == 'AUTO' else 2

        return {
            'target_quads':       int(self.polygon_count),
            'edge_length':        float(self.edge_length),
            'target_percentage':  float(self.target_percentage),
            'polygon_scale':      float(self.polygon_scale),
            'polygon_target_mode':{'AUTO':0,'COUNT':1,'EDGE':2,'PERCENT':3}[self.polygon_target_mode],
            'adaptive':           bool(self.adaptive),
            'adaptiveness':       float(self.adaptiveness),
            'hard_edge_mode':     he_mode_int,
            'hard_edge_angle':    float(self.hard_edge_angle),
            'freeze_borders':     bool(self.freeze_borders),
            'preprocess_weld':    bool(self.preprocess_weld),
            'denoise_strength':   float(self.denoise_strength),
            'density_scale':      float(self.density_scale),
            'symmetry_x':         bool(self.symmetry_x),
            'symmetry_y':         bool(self.symmetry_y),
            'symmetry_z':         bool(self.symmetry_z),
        }

    @staticmethod
    def _run_remesh_worker(xe, input_data, cfg, state, guide_curves=None, vertex_weights=None,
                input_hard_edges=None):
        try:
            state.status = ''
            state.progress = 2.0

            def prog_cb(pct, msg):
                state._dll_pct = max(state._dll_pct, float(pct))
                state.status = ''

            verts, faces, hard_edges = xe.extract_mesh(None, settings=cfg,
                                           use_cache=True,
                                           progress_callback=prog_cb,
                                           guide_curves=guide_curves,
                                           vertex_weights=vertex_weights,
                                           input_hard_edges=input_hard_edges,
                                           input_data=input_data)
            state.verts = verts
            state.faces = faces
            state.hard_edges = hard_edges
            state.progress = 95.0
            state.status = '导入结果…'
        except Exception as e:
            traceback.print_exc()
            state.error = str(e)
        finally:
            state.done = True

    def _apply_remesh_result(self, ctx):

        from mathutils import Vector
        verts = self._state.verts
        faces = self._state.faces
        obj_old = bpy.data.objects.get(self._source_obj_name)

        mw = obj_old.matrix_world.copy() if obj_old else None
        if mw is not None:
            mw_inv = mw.inverted()
            # 用 numpy 向量化完成世界->本地坐标变换,避免逐顶点 Python 循环
            v = np.asarray(verts, dtype=np.float64).reshape(-1, 3)
            m3 = np.array([[mw_inv[0][0], mw_inv[0][1], mw_inv[0][2]],
                           [mw_inv[1][0], mw_inv[1][1], mw_inv[1][2]],
                           [mw_inv[2][0], mw_inv[2][1], mw_inv[2][2]]],
                          dtype=np.float64)
            t = np.array([mw_inv[0][3], mw_inv[1][3], mw_inv[2][3]], dtype=np.float64)
            local_v = (v @ m3.T + t).astype(np.float32)
        else:
            local_v = np.asarray(verts, dtype=np.float32).reshape(-1, 3)

        me = bpy.data.meshes.new(name=f'{self._source_obj_name}_zm_remesh')

        # 通过 foreach_set 构建网格(假定输出为四边形),与 MCP
        # 直接内存交换测试验证过的写回方式一致。
        n_v = len(local_v)
        n_f = len(faces)
        me.vertices.add(n_v)
        total_l = 0
        for f in faces:
            total_l += len(f)
        me.loops.add(total_l)
        me.polygons.add(n_f)

        co_flat = np.ascontiguousarray(local_v, dtype=np.float32).ravel()
        me.vertices.foreach_set("co", co_flat)

        lv = np.empty(total_l, dtype=np.int32)
        ls = np.empty(n_f, dtype=np.int32)
        lt = np.empty(n_f, dtype=np.int32)
        base = 0
        for i, f in enumerate(faces):
            c = len(f)
            lv[base:base + c] = f
            ls[i] = base
            lt[i] = c
            base += c
        me.loops.foreach_set("vertex_index", lv)
        me.polygons.foreach_set("loop_start", ls)
        me.polygons.foreach_set("loop_total", lt)
        me.update()
        me.validate(verbose=False)

        hard_edges = getattr(self._state, 'hard_edges', None) or []
        if hard_edges and self.hard_edge_enable:
            key_set = set()
            for a, b in hard_edges:
                key_set.add((a, b) if a < b else (b, a))
            marked = 0
            for e in me.edges:
                v0, v1 = e.vertices[0], e.vertices[1]
                key = (v0, v1) if v0 < v1 else (v1, v0)
                if key in key_set:
                    e.use_edge_sharp = True
                    marked += 1
            print(f"[ZMRemesh] applied {marked}/{len(hard_edges)} hard edges as sharp",
                  flush=True)

        # FROM_EDGES 模式:用户显式指定的硬边(来自锐边标记或 hard_edge_vgroup)
        # 可能不会出现在 DLL 的 getHardEdges 输出中,因为该输出的描述符
        # 只返回自动检测到的折痕。这里把用户输入的点对按中点邻近度
        # 映射到最近的输出边上。
        user_pairs = getattr(self, '_hard_edge_pairs', None)
        if user_pairs and self.hard_edge_enable and self.hard_edge_type in ('SHARP', 'VGROUP'):
            orig_coords = [(mw_inv @ Vector(c))
                            for c in (self._source_hard_edge_midpoints or [])]
            if orig_coords:
                # 在输出边上构建中点查找树
                mp_tree = kdtree.KDTree(len(me.edges))
                for ei, e in enumerate(me.edges):
                    a = me.vertices[e.vertices[0]].co
                    b = me.vertices[e.vertices[1]].co
                    mp = ((a.x + b.x) * 0.5, (a.y + b.y) * 0.5,
                           (a.z + b.z) * 0.5)
                    mp_tree.insert(mp, ei)
                mp_tree.balance()
                # 将每个用户输入中点吸附到最近的输出边
                n_mapped = 0
                for mid in orig_coords:
                    _, ei, _ = mp_tree.find(mid)
                    if ei is not None and not me.edges[ei].use_edge_sharp:
                        me.edges[ei].use_edge_sharp = True
                        n_mapped += 1
                print(f"[ZMRemesh] post-mapped {n_mapped}/{len(orig_coords)} "
                      f"user hard edges to output", flush=True)

        new = bpy.data.objects.new(me.name, me)
        bpy.context.collection.objects.link(new)

        if obj_old:
            new.matrix_world = mw
            if self.replace_original:
                bpy.data.objects.remove(obj_old, do_unlink=True)
        ctx.view_layer.objects.active = new
        new.select_set(True)

        side = self.sym_direction
        sym_dirs = []
        if self.symmetry_x: sym_dirs.append(f'{side}_X')
        if self.symmetry_y: sym_dirs.append(f'{side}_Y')
        if self.symmetry_z: sym_dirs.append(f'{side}_Z')
        if sym_dirs:

            ctx.view_layer.objects.active = new

            vs = new.data.vertices
            if len(vs):
                xs = [v.co.x for v in vs]; ys = [v.co.y for v in vs]; zs = [v.co.z for v in vs]
                diag = ((max(xs)-min(xs))**2 + (max(ys)-min(ys))**2 + (max(zs)-min(zs))**2) ** 0.5
            else:
                diag = 1.0
            # 对称化阈值:三轴同时启用时若阈值过小,会在轴平面
            # 交叠处产生缝隙。使用 1e-3 * 对角线长度,以稳健地焊接
            # 多个对称平面交叠处的重合顶点。
            thr = max(diag * 1e-3, 1e-4)
            bpy.ops.object.mode_set(mode='EDIT')
            for d in sym_dirs:
                # 每轮都全选——symmetrize 会重置选择状态,
                # 若不重新选择,下一轴可能作用于部分网格,
                # 导致三轴交叠处(XYZ 全开)产生破碎面。
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.symmetrize(direction=d, threshold=thr)
            # 所有对称轮次后的收尾:焊接幸存的重合顶点,
            # 再统一面法线方向(三轴镜像有时会翻转部分镜像面)。
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.remove_doubles(threshold=thr)
            try:
                bpy.ops.mesh.normals_make_consistent(inside=False)
            except Exception:
                pass
            bpy.ops.object.mode_set(mode='OBJECT')

    def invoke(self, ctx, event):
        return self.execute(ctx)

    def execute(self, ctx):
        self._sync_settings_from_scene(ctx)
        p = ctx.scene.zremesh_props
        self._run_start_time = time.time()
        
        # 启动时报告模式
        mode_name = "同步" if self.blocking else "异步"
        self.report({'INFO'}, f"开始重拓扑 ({mode_name}模式)")
        
        # 操作符假定处于 OBJECT 模式(复制/导出/替换需要)。若用户
        # 从权重绘制 / 编辑 / 雕刻等模式调用,先切换回 OBJECT 模式。
        if ctx.object and ctx.object.mode != 'OBJECT':
            try:
                bpy.ops.object.mode_set(mode='OBJECT')
            except Exception:
                pass

        if not os.path.isfile(os.path.join(_BUNDLED_BIN, "xremeshlib2.dll")):
            self.report({"ERROR"}, f"动态库缺失:{_BUNDLED_BIN}")
            return {"CANCELLED"}
        try:
            xe = _load_remesh_lib()
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}

        obj = ctx.active_object
        self._source_obj_name = obj.name
        set_is_running(True)
        p.progress = 1.0

        self._density_weights = None
        self._guide_curves = None
        self._hard_edge_pairs = None



        vg_name = (p.density_map or '').strip()
        if p.density_enable and vg_name and vg_name in obj.vertex_groups:
            ws = _read_vertex_group_weights(obj, vg_name)
            if ws is not None and any(w > 0 for w in ws):
                self._density_weights = ws
                print(f"[ZMRemesh] density map: {sum(1 for w in ws if w>0)} "
                      f"weighted verts of {len(ws)}", flush=True)

        # 在 FROM_EDGES 模式收集硬边对
        if p.hard_edge_enable:
            pairs = []
            seen = set()
            src_desc = []  # 提前初始化，防止 NameError
            
            def _add(a, b):
                k = (a, b) if a < b else (b, a)
                if k not in seen:
                    pairs.append((a, b))
                    seen.add(k)

            if p.hard_edge_type == 'SHARP':
                # 模式1：仅锐边
                for e in obj.data.edges:
                    if e.use_edge_sharp:
                        _add(e.vertices[0], e.vertices[1])
                src_desc.append("sharp flags")
                
            elif p.hard_edge_type == 'VGROUP':
                # 模式2：仅顶点组
                heg = (p.hard_edge_vgroup or '').strip()
                if heg and heg in obj.vertex_groups:
                    he_ws = _read_vertex_group_weights(obj, heg)
                    if he_ws:
                        for e in obj.data.edges:
                            a, b = e.vertices[0], e.vertices[1]
                            if he_ws[a] > 0.5 and he_ws[b] > 0.5:
                                _add(a, b)
                    src_desc.append(f"vgroup '{heg}'")
            
            self._source_hard_edge_midpoints = None
            if pairs:
                self._hard_edge_pairs = pairs
                mw = obj.matrix_world
                self._source_hard_edge_midpoints = [
                    (mw @ ((obj.data.vertices[a].co +
                            obj.data.vertices[b].co) * 0.5))
                    for (a, b) in pairs
                ]
                
                sdesc = " + ".join(src_desc)
                print(f"[ZMRemesh] hard edges input: {len(pairs)} pairs ({sdesc})", flush=True)

        if p.guide_enable:
            if p.guide_type == 'CURVE':
                if p.guide_splines and p.guide_splines.type == 'CURVE':
                    curve_pts = _sample_spline_points(ctx, p.guide_splines)
                    if curve_pts:
                        self._guide_curves = [curve_pts]
                        print(f"[ZMRemesh] guide splines '{p.guide_splines.name}': "
                              f"{len(curve_pts)} samples", flush=True)
            elif p.guide_type in ('SHARP_EDGES', 'SEAM_EDGES'):
                flag = 'SEAM' if p.guide_type == 'SEAM_EDGES' else 'SHARP'
                lines = _sample_marked_edge_polylines(obj, flag=flag)
                if lines:
                    self._guide_curves = lines
                    total = sum(len(l) for l in lines)
                    kind = 'seam' if flag == 'SEAM' else 'sharp-edge'
                    print(f"[ZMRemesh] {kind} guide: {len(lines)} polylines, "
                          f"{total} total points", flush=True)

        p.status = '提取网格数据…'
        self._mesh_input = _mesh_to_world_triangles(obj, ctx)
        print(f"[ZMRemesh] direct-array input: {len(self._mesh_input[0])} verts, "
              f"{len(self._mesh_input[1])} tris", flush=True)

        cfg = self._build_dll_config()
        print(f"[ZMRemesh] extract_mesh cfg={cfg}", flush=True)

        guide_curves = self._guide_curves if self._guide_curves else None
        vertex_weights = self._density_weights if self._density_weights else None
        input_hard_edges = self._hard_edge_pairs

        if self.blocking:
            try:
                verts, faces, hard_edges = xe.extract_mesh(None,
                                               settings=cfg, use_cache=True,
                                               guide_curves=guide_curves,
                                               vertex_weights=vertex_weights,
                                               input_hard_edges=input_hard_edges,
                                               input_data=self._mesh_input)
            except Exception as e:
                traceback.print_exc()
                set_is_running(False)
                p.status = '失败'
                self.report({"ERROR"}, f"失败:{e}")
                return {"CANCELLED"}
            self._state = _RemeshJob()
            self._state.verts = verts
            self._state.faces = faces
            self._state.hard_edges = hard_edges
            self._apply_remesh_result(ctx)
            nv = len(ctx.active_object.data.vertices)
            nf = len(ctx.active_object.data.polygons)
            p.progress = 100.0; p.status = f'完成:{nv}v {nf}p'
            set_is_running(False)
            self.report({"INFO"}, p.status)

            try: bpy.ops.ed.undo_push(message="C4D Standalone Remesh")
            except Exception: pass
            return {'FINISHED'}

        self._state = _RemeshJob()
        self._state.status = ''
        self._run_start_time = time.time()
        self._thread = threading.Thread(
            target=self._run_remesh_worker, daemon=True,
            args=(xe, self._mesh_input, cfg, self._state, guide_curves,
                  vertex_weights, input_hard_edges))
        self._thread.start()

        wm = ctx.window_manager
        self._timer = wm.event_timer_add(0.2, window=ctx.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, ctx, event):
        if event.type == 'TIMER':
            p  = ctx.scene.zremesh_props
            st = self._state
            if st.progress < 90.0 and not st.done:
                elapsed    = time.time() - self._run_start_time
                expected   = 85.0
                time_based = 2.0 + min(1.0, elapsed / expected) * 85.0
                cb_based   = 2.0 + st._dll_pct * 90.0
                p.progress = max(min(88.0, time_based), cb_based)
            else:
                p.progress = st.progress
            p.status = st.status

            for area in ctx.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

            if st.done:
                ctx.window_manager.event_timer_remove(self._timer)
                self._timer = None
                self._thread.join()
                duration = time.time() - self._run_start_time
                
                if st.error:
                    set_is_running(False)
                    p.status = f'失败:{st.error[:60]}'
                    self.report({"ERROR"}, p.status)
                    return {'CANCELLED'}
                try:
                    self._apply_remesh_result(ctx)
                except Exception as e:
                    traceback.print_exc()
                    set_is_running(False)
                    p.status = f'后处理失败:{e}'
                    self.report({"ERROR"}, p.status)
                    return {'CANCELLED'}
                nv = len(ctx.active_object.data.vertices)
                nf = len(ctx.active_object.data.polygons)
                p.progress = 100.0
                p.status = f'完成:{nv}v {nf}p (耗时:{duration:.2f}s)'
                set_is_running(False)
                self.report({"INFO"}, p.status)

                try: bpy.ops.ed.undo_push(message="C4D Standalone Remesh")
                except Exception: pass
                return {'FINISHED'}
        return {'PASS_THROUGH'}

    def cancel(self, ctx):
        if self._timer is not None:
            ctx.window_manager.event_timer_remove(self._timer)
            self._timer = None
        p = ctx.scene.zremesh_props
        set_is_running(False)
        p.status = '已取消(动态库仍在后台运行直至完成)'

class VIEW3D_PT_zremesh(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "ZRemesher"
    bl_label = "ZRemesher重拓扑"

    def draw(self, ctx):
        layout = self.layout
        p = ctx.scene.zremesh_props
        split_factor=0.25

        obj = ctx.active_object
        if obj and obj.type == "MESH":
            box = layout.box()
            box.label(text=f"当前物体:{obj.name}", icon="OBJECT_DATAMODE")
            box.label(text=f"顶点:{len(obj.data.vertices)}  面:{len(obj.data.polygons)}")

        box = layout.box()
        box.label(text="目标:", icon="MOD_REMESH")
        row = box.row(align=True); row.prop(p, "polygon_target_mode", expand=True)
        row = box.row(align=True)
        if p.polygon_target_mode == 'COUNT':
            row.prop(p, "polygon_count")
        elif p.polygon_target_mode == 'EDGE':
            row.prop(p, "edge_length")
        elif p.polygon_target_mode == 'PERCENT':
            row.prop(p, "target_percentage", slider=True)
        row.prop(p, "polygon_scale")
        
        box = layout.box()
        split = box.split(factor=split_factor)
        split.prop(p, "density_enable", text="密度图")
        row = split.row(align=True)
        row.enabled = p.density_enable
        if obj and obj.type == "MESH":
            row.prop_search(p, "density_map", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
        else:
            row.enabled = False
            row.prop(p, "density_map", text="")
        row.prop(p, "density_scale", slider=True)

        split = box.split(factor=split_factor)
        split.prop(p, "adaptive", text="自适应")
        row = split.row(align=True)
        row.enabled = p.adaptive
        row.prop(p, "adaptiveness")

        split = box.split(factor=split_factor)
        split.prop(p, "hard_edge_enable", text="硬边保护")
        row = split.row(align=True)
        row.enabled = p.hard_edge_enable
        row.prop(p, "hard_edge_type", text="")
        if p.hard_edge_type == 'AUTO':
            row.prop(p, "hard_edge_angle", slider=True)
        elif p.hard_edge_type == 'SHARP':
            row.label(text="使用标记的锐边", icon='EDGESEL') # 提示文字
        elif p.hard_edge_type == 'VGROUP':
            if obj and obj.type == 'MESH':
                row.prop_search(p, "hard_edge_vgroup", obj, "vertex_groups", text="", icon='GROUP_VERTEX')
            else:
                row.prop(p, "hard_edge_vgroup", text="")

        split = box.split(factor=split_factor)
        split.prop(p, "guide_enable", text="流线引导")
        row = split.row(align=True)
        row.enabled = p.guide_enable
        row.prop(p, "guide_type", text="")
        
        if p.guide_type == 'CURVE':
            row.prop(p, "guide_splines", text="")
        elif p.guide_type == 'SHARP_EDGES':
            row.label(text="锐边作为流线", icon="EDGESEL")
        elif p.guide_type == 'SEAM_EDGES':
            row.label(text="UV缝合边作为流线", icon="UV")

        box = layout.box()
        split = box.split(factor=split_factor)
        split.label(text="优化", icon="SHADING_RENDERED")
        row = split.row()
        row.prop(p, "freeze_borders", text="锁定边界", toggle=True)
        row.prop(p, "preprocess_weld", text="预焊接", toggle=True)
        row.prop(p, "denoise_strength", text="", slider=True)
        split = box.split(factor=split_factor)
        split.label(text="对称", icon="MOD_MIRROR")
        row = split.row(align=True)
        row.prop(p, "symmetry_x", icon="EVENT_X", text="", toggle=True)
        row.prop(p, "symmetry_y", icon="EVENT_Y", text="", toggle=True)
        row.prop(p, "symmetry_z", icon="EVENT_Z", text="", toggle=True)
        row.separator()
        sub = row.row()
        sub.enabled = p.symmetry_x or p.symmetry_y or p.symmetry_z
        sub.prop(p, "sym_direction", expand=True)

        layout.separator()

        box = layout.box()
        col = box.column(align=True)
        col.scale_y = 1.5
        if get_is_running():
            col.enabled = False
            col.operator(MESH_OT_zremesh.bl_idname,text="运行中…", icon="TIME")
        else:
            row=col.row()
            replace_original_icon = "AREA_JOIN_DOWN" if p.replace_original else "AREA_DOCK"
            row.prop(p, "replace_original",text="",icon=replace_original_icon)
            
            op = row.operator(MESH_OT_zremesh.bl_idname,text="执行重拓扑", icon="MOD_REMESH")
            op.use_scene_props = True
        
        
        
        split = box.split(factor=split_factor)
        split.label(text="进度", icon="INFO")
        row = split.row(align=True)
        row.enabled = False
        row.prop(p, "progress", text="", slider=True)        

        # if p.status:
            # pbox.label(text=p.status)
            

_REGISTER_CLASSES = (ZMRemeshSettings, MESH_OT_zremesh, VIEW3D_PT_zremesh)

def register():
    for c in _REGISTER_CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.zremesh_props = PointerProperty(type=ZMRemeshSettings)

def unregister():
    del bpy.types.Scene.zremesh_props
    for c in reversed(_REGISTER_CLASSES):
        bpy.utils.unregister_class(c)

if __name__ == "__main__":
    register()
